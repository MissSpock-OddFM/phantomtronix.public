'use strict';
const { app, BrowserWindow, WebContentsView, ipcMain, clipboard, dialog, safeStorage, protocol, session, nativeTheme } = require('electron');
const fs = require('fs');
const webPlugins=require('./core/quin-web-plugins');
const servicePlugins=require('./core/quin-service-plugins');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const cp = require('child_process');
const { PanelsSupervisor } = require('./core/panels-supervisor');
const { AgentRelay } = require('./core/agent-relay');
const { RelayPackageStore } = require('./core/relay-package');
const { admitRepairProposal } = require('./core/repair-admission');
const { CLinkBrowserRuntime, REQUIRED_ELECTRON } = require('./core/browser-runtime');
const { TEST_SIZES } = require('./core/message-qualification');
const { BackpackManager } = require('./core/backpack-manager');
const { AliceSeatService } = require('./core/alice-seat-service');
const {QuinL1Runner,OBJECTIVE: L1_OBJECTIVE}=require('./core/quin-l1-runner');
const aliceCbVoice = require('./core/alice-cb-voice');
const { CompanionZipIntake } = require('./core/companion-zip-intake.cjs');
const { createAgentShelf } = require('./core/agent-shelf.cjs'); // Miss Spock R315: automatic agent shelf sync
const { CompanionActivationRecovery } = require('./core/companion-activation-recovery.cjs');
const { checkCompanionStartup } = require('./core/companion-startup-preflight.cjs');
const { createRecoveryShell } = require('./core/companion-recovery-shell.cjs');
const { UniversalCompanionPrimary } = require('./core/universal-companion-primary.cjs');
const { CompanionTurnSeat, CommandStationSeats } = require('./core/companion-turn-seat.cjs');
const { createCompanionActivationIpc } = require('./core/companion-activation-ipc.cjs');
const { RestrictedBrowserCartridge } = require('./core/restricted-browser-cartridge.cjs');
const { CompanionChatGPTBridge } = require('./core/companion-chatgpt-bridge.cjs');
const { CompanionOrchestrator } = require('./core/companion-orchestrator');
const { ProviderSecretStore } = require('./core/provider-secret-store');
const { testProviderKey } = require('./core/provider-connectivity');
const { ProviderAdapterRegistry } = require('./core/provider-adapter-registry');
const { AlphaShadowRunner } = require('./core/alpha-shadow-runner');
const { CompanionContextBuilder } = require('./core/companion-context-builder');
const { ApiUsageLedger } = require('./core/api-usage-ledger');
const { AlphaPrimaryRunner } = require('./core/alpha-primary-runner');
const { ApiPrimarySoak } = require('./core/api-primary-soak');
const { ReadOnlyWorkerExperiment } = require('./core/read-only-worker-experiment');
const { Round9Reconciliation } = require('./core/round9-reconciliation');
const { explicitSpecialistRelayRequested: specialistRelayRequested } = require('./core/relay-intent');

const BUILD = 'Quin-0.1.0-alpha-c42-fork';
const MISSION = 'QUIN_FORK_002_Browser_PANELS_RobotRock';
const R8_MISSION = 'AM-032R8A_WORKER_STRUCTURED_REPORT_HOTFIX';
const FIELD_TEST_MODE = process.env.CLINK_FIELD_TEST_MODE === '1';
const PROFILE_ROOT_OVERRIDE = FIELD_TEST_MODE ? String(process.env.CLINK_PROFILE_ROOT||'').trim() : '';
if (FIELD_TEST_MODE && !PROFILE_ROOT_OVERRIDE) throw new Error('CLINK_FIELD_TEST_PROFILE_ROOT_REQUIRED');
const PROFILE_ROOT = PROFILE_ROOT_OVERRIDE ? path.resolve(PROFILE_ROOT_OVERRIDE) : path.join(app.getPath('appData'), 'PhantomTronix', 'Quin');
const QUIN_PROFILE_ROOT = path.join(app.getPath('appData'), 'PhantomTronix', 'Quin');
const PROVIDER_AUTH_DIR = path.join(QUIN_PROFILE_ROOT,'providers','chatgpt-web');
const PROVIDER_AUTH_STATE_FILE = path.join(PROVIDER_AUTH_DIR,'auth-state.json');
const APP_ICON = path.join(__dirname, 'assets', 'clink-icon.png');
const LINUX_DESKTOP_ID = 'com.phantomtronix.clink';
const LINUX_DESKTOP_NAME = `${LINUX_DESKTOP_ID}.desktop`;
const LINUX_DURABLE_APP_DIR = path.join(os.homedir(),'.local','share','phantomtronix','quin','current');
const LINUX_DURABLE_LAUNCHER = path.join(os.homedir(),'.local','bin','phantomtronix-quin');
const LINUX_RUNTIME_CACHE = path.join(QUIN_PROFILE_ROOT,'runtime','electron-path');
let shutdownStarted=false;
let shutdownPromise=null;
let quitScheduled=false;
let inlineAuthView=null;
let inlineAuthPoll=null;
let inlineAuthActive=false;
const PANELS_ROOT = path.join(__dirname, 'panels-os');
const LOG_DIR = path.join(PROFILE_ROOT, 'logs', 'vanilla-core');
const LOG_FILE = path.join(LOG_DIR, 'AM027R28B.jsonl');
const BOOT_LOG = path.join(LOG_DIR, 'AM027R28B-BOOT.txt');
const QUAL_DIR = path.join(PROFILE_ROOT,'qualification');
const QUAL_LATEST = path.join(QUAL_DIR,'browser-message-throughput-latest.json');
const QUAL_HISTORY = path.join(QUAL_DIR,'browser-message-throughput-history.jsonl');
const TERMINAL_SESSION_ID = `TERM-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

protocol.registerSchemesAsPrivileged(['quinplugin','quinservice'].map(scheme=>({scheme,privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true}})));
app.setName('PhantomTronix C.Link Terminal');

// R365: read-only GUI acceptance. Never navigate Browser during installation.
if(process.env.CLINK_R365_SMOKE_MARKER){
 const fs365=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let wrote=false;
  win.webContents.on('did-finish-load',()=>setTimeout(async()=>{
   if(wrote||win.isDestroyed())return;
   let details={ok:false};
   try{details=await win.webContents.executeJavaScript(`(()=>{
    const shell=document.getElementById('clink-r358-shell');
    const d=typeof window.__CLINK_R365_DIAGNOSTICS__==='function'
     ?window.__CLINK_R365_DIAGNOSTICS__():null;
    return {ok:!!shell&&!!d&&d.hasExit&&d.hasReopen,
     nativeBrowserButton:!!d?.nativeBrowserButton,readOnly:true,
     browserInteraction:'NOT_ATTEMPTED'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const proof={loaded:true,visible:win.isVisible(),details,
                timestamp:new Date().toISOString(),pid:process.pid};
   try{fs365.writeFileSync(process.env.CLINK_R365_SMOKE_MARKER,JSON.stringify(proof));wrote=true;}catch(_){}
  },1800));
 });
}


// R363 real Electron smoke: verifies the one-stop manager without mutating packages.
if(process.env.CLINK_R363_SMOKE_MARKER){
 const fs363=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let loaded=false,failed=false,done=false;
  const probe=async()=>{
   if(!loaded||done||win.isDestroyed())return;
   let details={ok:false,error:'NOT_LOADED'};
   try {details=await win.webContents.executeJavaScript(`(async()=>{
     return typeof window.__CLINK_R363_TEST__==='function' ? await window.__CLINK_R363_TEST__() : {ok:false,error:'R363_TEST_MISSING'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const event={loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()};
   try{fs363.writeFileSync(process.env.CLINK_R363_SMOKE_MARKER,JSON.stringify(event));}catch(_e){}
   if(details.ok)done=true;
  };
  win.webContents.on('did-finish-load',()=>{loaded=true;setTimeout(probe,2500);setTimeout(probe,6500);setTimeout(probe,11000);});
  win.webContents.on('did-fail-load',()=>{failed=true;});
 });
}


// R362 GUI verification: tests Alice and Companion Home controls without sending messages.
if (process.env.CLINK_R362_SMOKE_MARKER) {
 const fs362=require('node:fs');
 app.on('browser-window-created',(_ev,w)=>{
  let loaded=false,failed=false,once=false;
  const check=async()=>{
   if(w.isDestroyed()||!loaded||once)return;
   let details={};
   try {details=await w.webContents.executeJavaScript(`(async()=>{
     return typeof window.__CLINK_R362_TEST__==='function'?await window.__CLINK_R362_TEST__():{ok:false,error:'R362_TEST_UNAVAILABLE'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const event={loaded,failed,visible:w.isVisible(),details,pid:process.pid,time:new Date().toISOString()};
   try{fs362.writeFileSync(process.env.CLINK_R362_SMOKE_MARKER,JSON.stringify(event));}catch(_e){}
   if(details.ok)once=true;
  };
  w.webContents.on('did-finish-load',()=>{loaded=true;setTimeout(check,3000);setTimeout(check,6500);setTimeout(check,10000);});
  w.webContents.on('did-fail-load',()=>{failed=true;});
 });
}


// R361 independent GUI verification (one-shot, triggered only by relay).
if (process.env.CLINK_R361_SMOKE_MARKER) {
 const fs361=require('node:fs');
 app.on('browser-window-created', (_evt, win) => {
  let loaded=false,failed=false;
  const inspect=async()=>{
   if(win.isDestroyed()||!loaded)return;
   let details={};
   try {details=await win.webContents.executeJavaScript(`(()=>{
     const s=window.__CLINK_R361_DIAGNOSTICS__;
     return typeof s==='function'?s():{ready:false,error:'R361_DIAGNOSTICS_NOT_MOUNTED'};
   })()`,true);} catch(err){details={error:String(err)};}
   try {fs361.writeFileSync(process.env.CLINK_R361_SMOKE_MARKER,
    JSON.stringify({loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}
   catch(_err){}
  };
  win.webContents.on('did-finish-load',()=>{loaded=true;[500,1500,3000,5000,7500].forEach(ms=>setTimeout(inspect,ms));});
  win.webContents.on('did-fail-load',()=>{failed=true;void inspect();});
 });
}


// R360: visible, Home-start, Alice blank UI smoke when explicitly requested by relay.
if (process.env.CLINK_R360_SMOKE_MARKER) {
 const fs360=require('node:fs');
 app.on('browser-window-created',(_event,w)=>{
  let loaded=false,failed=false;
  const run=async()=>{
   if(w.isDestroyed()||!loaded)return;
   let details={};
   try {details=await w.webContents.executeJavaScript(`(()=>{
     const alice=document.getElementById('aliceSeatPanel');
     const transcript=document.getElementById('aliceSeatTranscript');
     const home=document.getElementById('quinHome');
     return {ready:window.__CLINK_R360_READY__===true,
       homeVisible:!!home&&!home.hidden,
       aliceHidden:!!alice&&alice.hidden,
       aliceEscape:!!alice?.querySelector('.clink-r360-return'),
       companionEscape:!!document.getElementById('companionSeatPanel')?.querySelector('.clink-r360-return'),
       transcriptChildren:transcript?.childElementCount??-1,
       appTitle:document.title,
       cLinkShell:!!document.getElementById('clink-r358-shell')};
   })()`,true);}
   catch(e){details={error:String(e)};}
   try{fs360.writeFileSync(process.env.CLINK_R360_SMOKE_MARKER,JSON.stringify({loaded,failed,visible:w.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}catch(_e){}
  };
  w.webContents.on('did-finish-load',()=>{loaded=true;[250,750,1500,2900,5200,8000].forEach(ms=>setTimeout(run,ms));});
  w.webContents.on('did-fail-load',()=>{failed=true;void run();});
 });
}


// R358 smoke: actual visible C.Link desktop AND working 8-slot application grid.
if (process.env.CLINK_R358_SMOKE_MARKER) {
 const smokeFs=require('node:fs');
 app.on('browser-window-created', (_evt,win)=>{
  let loaded=false,failed=false,details={};
  const record=event=>{try{smokeFs.writeFileSync(process.env.CLINK_R358_SMOKE_MARKER,JSON.stringify({event,loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}catch(_e){}};
  const check=async()=>{
   if(!loaded||win.isDestroyed())return;
   try{
    details=await win.webContents.executeJavaScript(`(()=>{
      const shell=document.getElementById('clink-r358-shell');const deck=document.getElementById('clink-r358-deck');const grid=document.getElementById('clink-r358-card-grid');const sidebar=document.getElementById('clink-r358-side');
      const rect=shell?.getBoundingClientRect();const style=shell&&getComputedStyle(shell);
      return {present:!!shell,revision:shell?.dataset.revision,width:rect?.width||0,height:rect?.height||0,display:style?.display,brand:document.getElementById('clink-r358-brand')?.textContent||'',navCount:sidebar?.querySelectorAll('[data-view]').length||0,gridVisible:!!grid&&grid.getBoundingClientRect().width>100,cardCount:grid?.querySelectorAll('.cl-card').length||0,ready:window.__CLINK_R358_READY__===true,deckVisible:!!deck&&!deck.hidden};
    })()`,true);
    record('renderer-checked');
   }catch(error){details={error:String(error)};record('probe-error');}
  };
  record('window-created');win.on('show',()=>{record('window-shown');setTimeout(check,700);});
  win.webContents.on('did-finish-load',()=>{loaded=true;let attempts=0;const timer=setInterval(()=>{check();if(++attempts>=17)clearInterval(timer);},600);});
  win.webContents.on('did-fail-load',(_event,code,description,url)=>{failed=true;details={code,description,url};record('renderer-load-failed');});
 });
}

try { require('electron').Menu.setApplicationMenu(null); } catch (_err) {}

// R356 verification probe only when launched by the installer; no background service.
if (process.env.CLINK_R356_SMOKE_MARKER) {
  const smokeFS = require('node:fs');
  app.on('browser-window-created', (_evt, win) => {
    const file = process.env.CLINK_R356_SMOKE_MARKER;
    let loaded = false, failed = false;
    const save = (event, extra={}) => {
      try { smokeFS.writeFileSync(file, JSON.stringify({event, loaded, failed, visible:win.isVisible(), pid:process.pid, time:new Date().toISOString(), ...extra})); }
      catch (_err) { /* optional diagnostic */ }
    };
    save('window-created');
    win.on('show', () => save('window-shown'));
    win.webContents.on('did-finish-load', () => { loaded=true; save('renderer-loaded'); });
    win.webContents.on('did-fail-load', (_e, code, description, url) => { failed=true; save('renderer-load-failed',{code,description,url}); });
    win.on('closed', () => save('window-closed'));
  });
}

if (process.platform === 'linux' && typeof app.setDesktopName === 'function') app.setDesktopName(LINUX_DESKTOP_NAME);
if (process.platform === 'linux') app.commandLine.appendSwitch('class',LINUX_DESKTOP_ID);
app.setPath('userData', PROFILE_ROOT);
if (process.platform === 'win32') app.setAppUserModelId('PhantomTronix.Quin');
fs.mkdirSync(LOG_DIR, { recursive: true });
const COMPANION_CONTEXT_FILE = path.join(__dirname, 'context', 'COMPANION-CONTEXT.json');
const CANONICAL_COMPANION_CONTEXT = Object.freeze(JSON.parse(fs.readFileSync(COMPANION_CONTEXT_FILE, 'utf8')));
const QUAL_PROOF_FILE = path.join(__dirname,'context','R27A2-MESSAGE-QUALIFICATION.json');
const COMPANION_STORE_SEED_FILE = path.join(__dirname,'context','COMPANION-STORE-SEED.json');
const COMPANION_STORE_SEED = Object.freeze(JSON.parse(fs.readFileSync(COMPANION_STORE_SEED_FILE,'utf8')));
const API_R4_FIELD_FILE = path.join(__dirname,'context','API-R4-FIELD-EVIDENCE.json');
const API_R4_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R4_FIELD_FILE,'utf8')));
const API_R5_FIELD_FILE = path.join(__dirname,'context','API-R5-FIELD-EVIDENCE.json');
const API_R5_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R5_FIELD_FILE,'utf8')));
const API_R6_FIELD_FILE = path.join(__dirname,'context','API-R6-FIELD-EVIDENCE.json');
const API_R6_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R6_FIELD_FILE,'utf8')));
const API_R7_FIELD_FILE = path.join(__dirname,'context','API-R7-FIELD-EVIDENCE.json');
const API_R7_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R7_FIELD_FILE,'utf8')));
const API_R8_FIELD_FILE = path.join(__dirname,'context','API-R8-FIELD-EVIDENCE.json');
const API_R8_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R8_FIELD_FILE,'utf8')));
const HIVE_R7_RELEASE_FILE = path.join(__dirname,'context','HIVE-R7-RELEASE.json');
const HIVE_R7_RELEASE = Object.freeze(JSON.parse(fs.readFileSync(HIVE_R7_RELEASE_FILE,'utf8')));
const PROTECTED_QUALIFICATION = Object.freeze(JSON.parse(fs.readFileSync(QUAL_PROOF_FILE,'utf8')));
function restoredQualification(){
  const q=PROTECTED_QUALIFICATION;
  if(q.status!=='QUALIFIED'||q.samples!==9||q.passes!==9||q.failures!==0||q.knownSafeMaxChars!==131072||q.recommendedFutureChunkChars!==98304)throw new Error('R27A2_PROTECTED_QUALIFICATION_EVIDENCE_INVALID');
  return {...q,restoredByBuild:BUILD,restoredAt:new Date().toISOString(),detail:'R27A2 FIELD PROOF RESTORED: 9/9 text passes; known safe >= 131072 chars; operational chunk target 98304; attachments unqualified; MESSAGE BATCH rerun disabled.'};
}

function boot(text) { try { fs.appendFileSync(BOOT_LOG, `${new Date().toISOString()} | ${text}\n`); } catch (_) {} }
boot(`PROFILE_ROOT_SOURCE=${PROFILE_ROOT_OVERRIDE?'CLINK_FIELD_TEST_OVERRIDE':'CANONICAL_APPDATA'} fieldTestMode=${FIELD_TEST_MODE} pid=${process.pid}`);
function log(event, data = {}) {
  try {
    fs.appendFileSync(LOG_FILE, JSON.stringify({ts:new Date().toISOString(),build:BUILD,mission:MISSION,sessionId:TERMINAL_SESSION_ID,event,...data}) + '\n');
  } catch (_) {}
}
function tail(file, count = 120) { try { return fs.readFileSync(file,'utf8').split(/\r?\n/).filter(Boolean).slice(-count); } catch (_) { return []; } }

function ensureLinuxDesktopIdentity(){
  if(process.platform!=='linux')return null;
  try{
    const dataHome=String(process.env.XDG_DATA_HOME||path.join(os.homedir(),'.local','share'));
    const appDir=path.join(dataHome,'applications');
    const iconThemeRoot=path.join(dataHome,'icons','hicolor');
    const iconDir=path.join(iconThemeRoot,'512x512','apps');
    const desktopPath=path.join(appDir,LINUX_DESKTOP_NAME);
    const stableIconPath=path.join(iconDir,`${LINUX_DESKTOP_ID}.png`);

    fs.mkdirSync(appDir,{recursive:true});
    fs.mkdirSync(iconDir,{recursive:true});
    fs.mkdirSync(path.dirname(LINUX_DURABLE_LAUNCHER),{recursive:true});

    let changed=false;
    const sourceIcon=fs.readFileSync(APP_ICON);
    let targetIcon=null;
    try{targetIcon=fs.readFileSync(stableIconPath);}catch(_){}
    if(!targetIcon||!targetIcon.equals(sourceIcon)){
      fs.writeFileSync(stableIconPath,sourceIcon);
      changed=true;
    }

    const upsert=(text,key,value)=>{
      const line=`${key}=${value}`;
      const escaped=key.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      const rx=new RegExp(`^${escaped}=.*$`,'m');
      return rx.test(text)?text.replace(rx,line):`${text.replace(/\s*$/,'')}\n${line}\n`;
    };

    let desktop='';
    try{desktop=fs.readFileSync(desktopPath,'utf8');}catch(_){}
    if(!desktop.includes('[Desktop Entry]'))desktop='[Desktop Entry]\n';
    const before=desktop;

    desktop=upsert(desktop,'Type','Application');
    desktop=upsert(desktop,'Version','1.0');
    desktop=upsert(desktop,'Name','Phantom-Tronix Quinquedent Browser (Quin)');
    desktop=upsert(desktop,'GenericName','Quin Browser and Plugins');
    desktop=upsert(desktop,'Comment','Quin — browser built from the IRIS/C.Link foundation');
    desktop=upsert(desktop,'Exec',`"${LINUX_DURABLE_LAUNCHER}"`);
    desktop=upsert(desktop,'TryExec',LINUX_DURABLE_LAUNCHER);
    desktop=upsert(desktop,'Icon',LINUX_DESKTOP_ID);
    desktop=upsert(desktop,'StartupWMClass',LINUX_DESKTOP_ID);
    desktop=upsert(desktop,'Terminal','false');
    desktop=upsert(desktop,'NoDisplay','false');
    desktop=upsert(desktop,'StartupNotify','true');
    desktop=upsert(desktop,'DBusActivatable','false');
    desktop=upsert(desktop,'Categories','Development;Utility;');
    desktop=upsert(desktop,'Keywords','Quin;Quinquedent;Robot Rock;Phantom-Tronix;');

    if(desktop!==before){
      fs.writeFileSync(desktopPath,desktop);
      changed=true;
    }

    if(changed){
      try{cp.spawnSync('update-desktop-database',[appDir],{stdio:'ignore',timeout:3000});}catch(_){}
      try{cp.spawnSync('gtk-update-icon-cache',['-f','-t',iconThemeRoot],{stdio:'ignore',timeout:4000});}catch(_){}
    }

    const result={
      desktopId:LINUX_DESKTOP_ID,
      desktopName:LINUX_DESKTOP_NAME,
      desktopPath,
      durableLauncher:LINUX_DURABLE_LAUNCHER,
      durableAppDir:LINUX_DURABLE_APP_DIR,
      runtimeCache:LINUX_RUNTIME_CACHE,
      stableIconPath,
      sourceIconSha256:crypto.createHash('sha256').update(sourceIcon).digest('hex').toUpperCase(),
      searchable:true,
      changed
    };
    log('desktop.identity.ready',result);
    return result;
  }catch(error){
    log('desktop.identity.error',{error:String(error.message||error)});
    return null;
  }
}

function readProviderAuthState(){
  try{return JSON.parse(fs.readFileSync(PROVIDER_AUTH_STATE_FILE,'utf8'));}catch(_){return{};}
}
function writeProviderAuthState(patch={}){
  try{
    fs.mkdirSync(PROVIDER_AUTH_DIR,{recursive:true});
    const current=readProviderAuthState();
    const next={schema:'CLINK_PROVIDER_AUTH_STATE_V1',...current,...patch,updatedAt:new Date().toISOString()};
    const tmp=`${PROVIDER_AUTH_STATE_FILE}.tmp-${process.pid}`;
    fs.writeFileSync(tmp,JSON.stringify(next,null,2)+'\n');
    fs.renameSync(tmp,PROVIDER_AUTH_STATE_FILE);
    return next;
  }catch(error){
    log('provider.session.state-write.error',{error:String(error.message||error)});
    return null;
  }
}
async function flushProviderSession(reason='UNSPECIFIED'){
  if(!browserRuntime)return{ok:false,reason:'BROWSER_RUNTIME_NOT_READY'};
  const started=Date.now();
  try{
    const ses=browserRuntime.getSession();
    let cookieResult='PASS';
    try{
      await Promise.race([
        ses.cookies.flushStore(),
        new Promise((_,reject)=>setTimeout(()=>reject(new Error('COOKIE_FLUSH_TIMEOUT')),1800))
      ]);
    }catch(error){cookieResult=String(error.message||error);}
    try{ses.flushStorageData();}catch(error){
      log('provider.session.storage-flush.error',{reason,error:String(error.message||error)});
    }
    const state=writeProviderAuthState({
      canonicalSessionPath:browserRuntime.sessionPath,
      lastFlushAt:new Date().toISOString(),
      lastFlushReason:reason,
      lastFlushCookieResult:cookieResult
    });
    log('provider.session.flush',{
      reason,cookieResult,elapsedMs:Date.now()-started,
      sessionPath:browserRuntime.sessionPath,
      stateStatus:state?.status||'UNKNOWN'
    });
    return{ok:cookieResult==='PASS',cookieResult};
  }catch(error){
    log('provider.session.flush.error',{reason,error:String(error.message||error)});
    return{ok:false,error:String(error.message||error)};
  }
}

let windowMain = null;
let cartridgeVoiceHost=null;
let webPluginView=null;let webPluginId=null;let webPluginSession=null;let activeWebService=null;
let restrictedBrowserCartridge = null;
let companionChatGPTBridge = null;
let panels = null;
let browserRuntime = null;
let broadcastTimer = null;
let lifecycleSyncPromise = null;


const companionZipIntake = new CompanionZipIntake({profileRoot:PROFILE_ROOT});
const commandStationSeats = new CommandStationSeats({profileRoot:PROFILE_ROOT,intake:companionZipIntake});
const companionActivationRecovery = new CompanionActivationRecovery({activeFile:companionZipIntake.activeFile,logger:log});
// Reconcile any interrupted activation BEFORE binding initial Companion identity.
let activationColdRecovery={ok:true,action:'NONE'};
try{activationColdRecovery=companionActivationRecovery.recover();}
catch(error){
  activationColdRecovery={ok:false,error:String(error?.message||error)};
  log('companion.activation.startup_recovery_blocked',{error:activationColdRecovery.error});
}
// Recovery-only boot does not call the legacy manager, which could otherwise
// silently reseed an invalid CURRENT.json to a hardcoded historical Companion.
const companionPreflight = checkCompanionStartup({activeFile:companionZipIntake.activeFile});
let backpackManager=null;
let bootstrapBackpackState=null;
let companionStartupError=!activationColdRecovery.ok ? 'ACTIVATION_JOURNAL_RECOVERY_FAILED' :
  (!companionPreflight.ok ? companionPreflight.reason : null);
if(!companionStartupError){
  try{
    backpackManager = new BackpackManager({profileRoot:PROFILE_ROOT,appRoot:__dirname,logger:log});
    const backpackState = backpackManager.initialize();
    bootstrapBackpackState=backpackState;
    if(!backpackState?.systemControl)throw Error('SYSTEM_CONTROL_INITIAL_STATE_INCOMPLETE'); // Empty Companion is allowed.
  }catch(error){companionStartupError='BACKPACK_INITIALIZATION_FAILED';log('companion.recovery.bootstrap_blocked',{error:String(error?.message||error)});}
}
if(companionStartupError){
  log('companion.recovery.safe_shell_start',{reason:companionStartupError});
  createRecoveryShell({app,BrowserWindow,ipcMain,clipboard,profileRoot:PROFILE_ROOT,reason:companionStartupError,logger:log});
}else{
const companionOrchestrator = new CompanionOrchestrator({profileRoot:PROFILE_ROOT,logger:log});
companionOrchestrator.initialize(bootstrapBackpackState);
const providerSecrets = new ProviderSecretStore({profileRoot:PROFILE_ROOT,safeStorage,logger:log});
// R378 opt-in one-time native credential decryptability check. No value, length,
// ciphertext or full exception is logged. No API calls are performed.
if(process.env.CLINK_R378_PROBE_ON_START==='1'){
  const report={};
  for(const p of ['openai','xai']){
    try{
      const current=providerSecrets.status(p);
      if(!current.configured){report[p]='NOT_CONFIGURED';}
      else if(!providerSecrets.secureStorageAvailable()){report[p]='SECURE_STORAGE_UNAVAILABLE';}
      else{
        const ephemeral=providerSecrets.getForMainProcess(p);
        report[p]=ephemeral?'DECRYPT_OK':'EMPTY_AFTER_DECRYPT';
      }
    }catch(error){
      const label=String(error?.message||'');
      report[p]=label==='SECURE_STORAGE_DECRYPT_FAILED'?'SECURE_STORAGE_DECRYPT_FAILED':label==='SECURE_STORAGE_UNAVAILABLE'?'SECURE_STORAGE_UNAVAILABLE':'OTHER_STORE_ERROR';
    }
  }
  process.stdout.write('CLINK_R378_CREDENTIAL_PROBE='+JSON.stringify(report)+'\n');
}

const apiUsage = new ApiUsageLedger({profileRoot:PROFILE_ROOT,logger:log});
function dh017Modules(){
const factories={"./development_live_gate_011.cjs":function(module,exports,require){
'use strict';
// DH011: one provider decision reservation per explicitly approved experiment.
// Not a billing cap. The native transport must independently enforce its
// verified token/request bounds and no retries before this can be enabled.
const fs = require('node:fs');
const path = require('node:path');
function createOneShotGate({stateDir, approval, now=Date.now}) {
  if (!path.isAbsolute(stateDir)) throw Error('DH_STATE_PATH');
  if (!approval || approval.workflow !== 'development.smoke.v1' ||
      approval.maxDecisions !== 1 || !Number.isSafeInteger(approval.expiresAt) ||
      approval.transportBoundsVerified !== true ||
      approval.humanAuthorized !== true) throw Error('DH_NOT_AUTHORIZED');
  const st=fs.lstatSync(stateDir);
  if (!st.isDirectory() || st.isSymbolicLink() || (st.mode & 0o077) ||
      st.uid!==process.getuid()) throw Error('DH_STATE_PERMISSIONS');
  const file=path.join(stateDir,'live-decision-reserved.json');
  async function decideOnce(decide,prompt) {
    if(now() >= approval.expiresAt) throw Error('DH_APPROVAL_EXPIRED');
    let fd;
    try { fd=fs.openSync(file,'wx',0o600); }
    catch(e) { if(e.code==='EEXIST') throw Error('DH_DECISION_ALREADY_RESERVED'); throw e; }
    try {
      fs.writeFileSync(fd,JSON.stringify({workflow:approval.workflow,reservedAt:now(),maxDecisions:1}));
      fs.fsyncSync(fd);
    } finally {fs.closeSync(fd);}
    const dir=fs.openSync(stateDir,'r');
    try {fs.fsyncSync(dir);} finally {fs.closeSync(dir);}
    // A rejected/unknown call consumes the reservation. No retry.
    return await decide(prompt);
  }
  return Object.freeze({decideOnce});
}
module.exports={createOneShotGate};
if(require.main===module){
  const assert=require('node:assert/strict'),os=require('node:os');
  const base=fs.mkdtempSync(path.join(os.tmpdir(),'dh011-'));
  const a={workflow:'development.smoke.v1',maxDecisions:1,expiresAt:100,
    transportBoundsVerified:true,humanAuthorized:true};
  (async()=>{
    let n=0;
    try {
      assert.throws(()=>createOneShotGate({stateDir:base,approval:{...a,humanAuthorized:false}}),/NOT_AUTHORIZED/);
      assert.throws(()=>createOneShotGate({stateDir:base,approval:{...a,transportBoundsVerified:false}}),/NOT_AUTHORIZED/);
      const expired=createOneShotGate({stateDir:base,approval:a,now:()=>100});
      await assert.rejects(expired.decideOnce(()=>{n++;},'x'),/EXPIRED/);
      const gate=createOneShotGate({stateDir:base,approval:a,now:()=>1});
      const call=async()=>{n++;throw Error('unknown transport outcome');};
      await assert.rejects(gate.decideOnce(call,'x'),/unknown transport/);
      const reopened=createOneShotGate({stateDir:base,approval:a,now:()=>2});
      await assert.rejects(reopened.decideOnce(call,'x'),/ALREADY_RESERVED/);
      assert.equal(n,1);
      console.log('DH011 gate: 5 checks passed; zero provider calls');
    }finally{fs.rmSync(base,{recursive:true,force:true});}
  })().catch(e=>{console.error(e);process.exitCode=1;});
}

},
"./development_bounded_transport_012.cjs":function(module,exports,require){
'use strict';
// DH012: use existing native provider transport only within the accepted tool decision.
// No key handling, provider replacement, retry, or billing guarantee.
const {AsyncLocalStorage}=require('node:async_hooks');
const {createOneShotGate}=require('./development_live_gate_011.cjs');
const MAX_BYTES=65536, MAX_OUTPUT=256;
function createAcceptance({stateDir,approval,transport,now=Date.now}){
  const scope=new AsyncLocalStorage();
  const gate=createOneShotGate({stateDir,approval,now});
  let busy=false;
  async function decide(decideNative,prompt){
    if(busy)throw Error('DH_BUSY');
    busy=true;
    const context={active:true,used:false};
    try{return await scope.run(context,()=>decideNative(prompt));}
    finally{context.active=false;busy=false;}
  }
  async function boundedTransport(req){
    const ctx=scope.getStore(),p=req?.payload;
    if(!ctx?.active||ctx.used)throw Error('DH_TRANSPORT_SCOPE');
    if(req.provider!=='openai'||p?.model!=='gpt-5.6-luna'||
       typeof p.input!=='string'||typeof p.instructions!=='string'||
       !Number.isInteger(p.max_output_tokens)||p.max_output_tokens<16||
       p.max_output_tokens>MAX_OUTPUT||p.store!==false||
       Object.keys(p).some(k=>!['model','input','instructions','max_output_tokens','store'].includes(k))||
       Buffer.byteLength(JSON.stringify(p),'utf8')>MAX_BYTES)throw Error('DH_TRANSPORT_BOUNDS');
    ctx.used=true;
    return gate.decideOnce(()=>transport(req),'');
  }
  return Object.freeze({decide,transport:boundedTransport});
}
module.exports={createAcceptance,MAX_BYTES,MAX_OUTPUT};
if(require.main===module){
  const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
  const stateDir=fs.mkdtempSync(path.join(os.tmpdir(),'dh012-'));
  const approval={workflow:'development.smoke.v1',maxDecisions:1,expiresAt:100,transportBoundsVerified:true,humanAuthorized:true};
  let calls=0;
  const options={stateDir,approval,now:()=>1,transport:async()=>{calls++;return {statusCode:200};}};
  const a=createAcceptance(options);
  const req={provider:'openai',payload:{model:'gpt-5.6-luna',input:'x',instructions:'y',max_output_tokens:256,store:false}};
  (async()=>{
    try{
      await assert.rejects(a.transport(req),/SCOPE/);
      for(const bad of [{...req,provider:'xai'}, {...req,payload:{...req.payload,max_output_tokens:257}}, {...req,payload:{...req.payload,input:'x'.repeat(65537)}}, {...req,payload:{...req.payload,previous_response_id:'x'}}, {...req,payload:{...req.payload,model:'other'}}]){
        await assert.rejects(a.decide(()=>a.transport(bad),'test'),/BOUNDS/);
      }
      assert.equal(calls,0);
      await a.decide(async()=>{assert.equal((await a.transport(req)).statusCode,200);await assert.rejects(a.transport(req),/SCOPE/);},'test');
      const b=createAcceptance(options);
      await assert.rejects(b.decide(()=>b.transport(req),'test'),/ALREADY_RESERVED/);
      assert.equal(calls,1);
      console.log('DH012: bounded transport fixture PASS; no real provider calls');
    }finally{fs.rmSync(stateDir,{recursive:true,force:true});}
  })().catch(e=>{console.error(e);process.exitCode=1;});
}

},
"./development_tool.cjs":function(module,exports,require){
'use strict';
// Host-owned, explicitly enabled registered workflow. No renderer paths, commands or budgets.
const {spawn}=require('node:child_process');
const path=require('node:path');
const WORKFLOW='development.smoke.v1';
const REQUEST='{"tool":"development.smoke.v1"}';
function eligible(text){
  return typeof text==='string' && text.length<=300 &&
    /^(?:please,?\s+)?(?:miss flower,?\s+)?(?:please,?\s+)?(?:create|build|write|make)\s+(?:and test\s+)?(?:a\s+)?(?:small\s+|simple\s+)?python calculator(?:\s+and test it)?[.!]?$/i.test(text.trim()) && /\btest\b/i.test(text);
}
function createDevelopmentTool({run}){
  if(typeof run!=='function')throw Error('DEVELOPMENT_RUNNER_REQUIRED');
  let busy=false;
  async function handle({text,decide,authorize}){
    if(!eligible(text))return null;
    if(busy)throw Error('DEVELOPMENT_BUSY');
    busy=true;
    try{
      authorize();
      const decision=await decide('The human requested this exact fixed offline assignment: '+text+'\nIf you choose to invoke the registered tool, reply ONLY with '+REQUEST+'. Otherwise decline. Do not invent execution evidence.');
      authorize();
      if(decision?.complete!==true||decision.text!==REQUEST)return {text:'C.Link: No development tool was invoked. No execution receipt exists.'};
      const result=await run();
      authorize();
      if(result?.status!=='PASS'||!/^[a-f0-9]{64}$/.test(result.artifact_sha256||'')||result.provider_calls!==0)
        return {text:'C.Link: Development execution did not pass. Inspect the machine receipt.'};
      return {text:'C.Link verified development receipt: '+WORKFLOW+'\nTwo checks passed. Artifact SHA-256: '+result.artifact_sha256+'\nExecution provider calls: 0.',receipt:result};
    }finally{busy=false;}
  }
  return Object.freeze({handle});
}
// Reuse accepted guest runner. Only trusted native code supplies an absolute bundle path.
function createVmRunner(bundle,progress=()=>{}){
  const script=path.join(path.resolve(bundle),'development_guest_008.py');
  let child=null;
  function signal(p,sig){try{process.kill(-p.pid,sig);}catch(e){if(e.code!=='ESRCH')throw e;}}
  function cancel(){if(!child)return false;signal(child,'SIGINT');return true;}
  function run(){
    if(child)throw Error('DEVELOPMENT_RUNNER_BUSY');
    return new Promise((resolve,reject)=>{
      const p=spawn('/usr/bin/python3',['-B',script],{cwd:path.dirname(script),env:{PATH:'/usr/bin:/bin',HOME:require('node:os').homedir(),LANG:'C.UTF-8'},stdio:['ignore','pipe','pipe'],shell:false,detached:true});
      child=p;let output='',err='',over=false;
      const timer=setTimeout(()=>{over=true;signal(p,'SIGINT');},620000);
      const force=setTimeout(()=>{if(child===p)signal(p,'SIGKILL');},640000);
      p.stdout.on('data',b=>{if(over)return;output+=b.toString();if(output.length>65536){over=true;signal(p,'SIGINT');}else progress(b.toString());});
      p.stderr.on('data',b=>{err=(err+b.toString()).slice(-4096);});
      p.on('error',e=>{clearTimeout(timer);clearTimeout(force);child=null;const code=/^[A-Z0-9_]{1,20}$/.test(String(e.code||''))?e.code:'UNKNOWN';reject(Error('DEVELOPMENT_START_FAILED_'+code));});
      p.on('close',(code,sig)=>{clearTimeout(timer);clearTimeout(force);child=null;try{
        if(over)throw Error('DEVELOPMENT_PROCESS_LIMIT');if(code!==0)throw Error('DEVELOPMENT_PROCESS_FAILED_'+(Number.isInteger(code)?String(Math.abs(code)):String(sig||'UNKNOWN').replace(/[^A-Z0-9_]/g,'')));
        const lines=output.split(/\r?\n/).filter(l=>l.startsWith('CLINK_HOST_RECEIPT='));
        if(lines.length!==1)throw Error('DEVELOPMENT_RECEIPT_MISSING');
        resolve(JSON.parse(lines[0].slice('CLINK_HOST_RECEIPT='.length)));
      }catch(e){reject(e);}});
    });
  }
  return Object.freeze({run,cancel});
}
module.exports={createDevelopmentTool,createVmRunner,eligible,WORKFLOW};

},
"./development_installed_integration_017.cjs":function(module,exports,require){
'use strict';
// Real installed terminal; no replacement profile, key handling or separate provider.
const fs=require('node:fs'),path=require('node:path');
const {AsyncLocalStorage}=require('node:async_hooks');
const {createResponsesTransport}=require('./provider-transport');
const {createAcceptance}=require('./development_bounded_transport_012.cjs');
const {createDevelopmentTool,createVmRunner,eligible}=require('./development_tool.cjs');
function createInstalledIntegration({stateDir,bundle,approve,transport=createResponsesTransport(),progress=()=>{},publish=()=>{},runnerFactory=createVmRunner}){
  const routing=new AsyncLocalStorage();
  let active=null;
  function providerTransport(req){
    const route=routing.getStore();
    return route?route.gate.transport(req):transport(req);
  }
  function persist(name,value){
    const p=path.join(stateDir,name),fd=fs.openSync(p,'wx',0o600);
    try{fs.writeFileSync(fd,JSON.stringify(value)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
    const dir=fs.openSync(stateDir,'r');try{fs.fsyncSync(dir);}finally{fs.closeSync(dir);}
  }
  const developmentTool=Object.freeze({handle:async request=>{
    if(!eligible(request.text))return null;
    if(request.provider!=='openai')return {text:'C.Link: Select OpenAI for this acceptance assignment. No provider request occurred.'};
    if(active)return {text:'C.Link: A development acceptance is already active.'};
    if(fs.existsSync(stateDir))return {text:'C.Link: This one-use acceptance has already been reserved. No new provider request occurred.'};
    const job={cancelled:false,handle:null,vm:null,owned:false};
    active=job;
    function check(){if(job.cancelled)throw Error('DEVELOPMENT_CANCELLED');request.authorize();}
    try{
      check();
      if(!await approve())return {text:'C.Link: Development acceptance declined. No provider request occurred.'};
      check();
      // Fixed path, exclusive creation; no rearming on crash or unknown dispatch.
      fs.mkdirSync(stateDir,{mode:0o700});job.owned=true;
      progress('Development authorization accepted. Ctrl+Shift+X cancels.');
      const a={workflow:'development.smoke.v1',maxDecisions:1,expiresAt:Date.now()+600000,transportBoundsVerified:true,humanAuthorized:true};
      persist('approval.json',{...a,provider:'openai',estimatedUsd:0.02});
      const gate=createAcceptance({stateDir,approval:a,transport:async req=>{
        check();
        persist('dispatch.json',{provider:req.provider,model:req.payload.model,bytes:Buffer.byteLength(JSON.stringify(req.payload)),maxOutputTokens:req.payload.max_output_tokens});
        try{
          const result=await transport({...req,onHandle:h=>{job.handle=h;req.onHandle?.(h);if(job.cancelled)h?.cancel();}});
          const u=result.body?.usage||{};
          persist('provider-result.json',{statusCode:result.statusCode,inputTokens:Number(u.input_tokens)||0,outputTokens:Number(u.output_tokens)||0});
          return result;
        }finally{job.handle=null;}
      }});
      job.vm=runnerFactory(bundle,progress);
      const tool=createDevelopmentTool({run:async()=>{
        check();
        const result=await job.vm.run();
        persist('machine-result.json',{status:result.status,artifact_sha256:result.artifact_sha256,provider_calls:result.provider_calls,receipt_path:result.receipt_path});
        return result;
      }});
      const result=await tool.handle({...request,authorize:check,decide:prompt=>routing.run({gate},()=>gate.decide(async p=>{
        check();
        const d=await request.decide(p);
        persist('decision.json',{complete:d?.complete===true,invoked:d?.text==='{"tool":"development.smoke.v1"}'});
        return d;
      },prompt))});
      persist('tool-result.json',{receiptReturned:!!result?.receipt,artifact_sha256:result?.receipt?.artifact_sha256||null});
      return result;
    }catch(e){
      if(job.owned){try{persist('failure.json',{code:job.cancelled?'DEVELOPMENT_CANCELLED':'DEVELOPMENT_FAILED'});}catch(_){}}
      return {text:job.cancelled?'C.Link: Development cancelled. No success is claimed.':'C.Link: Development acceptance failed. Inspect the local machine receipt. No automatic retry.'};
    }finally{
      if(job.owned){try{await publish(stateDir);}catch(_){progress('Development receipt export failed; local evidence preserved.');}}
      active=null;progress('Development acceptance finished.');
    }
  }});
  function cancel(){
    if(!active)return false;
    active.cancelled=true;
    try{active.handle?.cancel();}catch(_){}
    try{active.vm?.cancel();}catch(_){}
    return true;
  }
  return Object.freeze({developmentTool,transport:providerTransport,cancel});
}
module.exports={createInstalledIntegration};

}};
const cache={};
function load(id){
 if(id==='./provider-transport')return require('./core/provider-transport');
 if(!Object.prototype.hasOwnProperty.call(factories,id)){
   if(!['node:fs','node:path','node:os','node:child_process','node:async_hooks'].includes(id))throw Error('DH017_MODULE_DENIED');
   return require(id);
 }
 if(cache[id])return cache[id].exports;
 const m={exports:{}};cache[id]=m;
 const r=name=>load(name);r.main=null;
 factories[id](m,m.exports,r);
 return m.exports;
}
return {integration:load('./development_installed_integration_017.cjs'),tool:load('./development_tool.cjs')};
}

const dh017=dh017Modules();
const dh017State=path.join(PROFILE_ROOT,'development-acceptance-0.4.22');
const dh017Runner=path.join(dh017State,'runner');
const dh017OriginalTitle='Phantom-Tronix Quinquedent Browser';
const dh017Embedded={"development_guest_008.py": "IiIiREgwMDg6IGhvc3Qtb3duZWQgb2ZmbGluZSBWTSBleGVjdXRpb24gb2YgdGhlIGV4aXN0aW5nIGRldGVybWluaXN0aWMgdGFzayBlbmdpbmUuIiIiCmltcG9ydCBiYXNlNjQKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAppbXBvcnQgc2h1dGlsCmltcG9ydCBzdWJwcm9jZXNzCmltcG9ydCBzeXMKaW1wb3J0IHRlbXBmaWxlCmltcG9ydCB0aW1lCmltcG9ydCB6aXBmaWxlCmZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGV0aW1lLCB0aW1lem9uZQpmcm9tIHNlZWQgaW1wb3J0IHNlZWRfaXNvCmZyb20gZGV2ZWxvcG1lbnRfc21va2UgaW1wb3J0IFNPVVJDRSwgVEVTVCwgU1BFQywgV09SS0ZMT1cKCkJBU0VfU0hBID0gIjA0ZThmMjQ2MWExNmE0NGU3OGEzNzAyODQ0NzFmMjk2MTZjZGQ5YmFmMTg5M2RmMjU4MDdiNzFmOTg1YjZjOTQiClBSRUZJWCA9ICJDTElOS19ESDAwNj0iCkdVRVNUID0gcicnJwppbXBvcnQgaGFzaGxpYiwganNvbiwgb3MsIHN1YnByb2Nlc3MsIHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKZnJvbSBkZXZlbG9wbWVudF9zbW9rZSBpbXBvcnQgcnVuX2pvdXJuYWxlZApyb290PVBhdGgoIi9ob21lL3VidW50dS9jbGluay1zbW9rZSIpCnJvb3QubWtkaXIobW9kZT0wbzcwMCwgZXhpc3Rfb2s9VHJ1ZSkKaWYgc3lzLmFyZ3ZbMV0gIT0gImNvbGxlY3QiOgogICAgcHJpbnQoanNvbi5kdW1wcyhydW5fam91cm5hbGVkKHJvb3Qsc3lzLmFyZ3ZbMV0pKSkKZWxzZToKICAgIGFzc2VydCBzb3J0ZWQocC5uYW1lIGZvciBwIGluIFBhdGgoIi9zeXMvY2xhc3MvbmV0IikuaXRlcmRpcigpKSA9PSBbImxvIl0KICAgIGFzc2VydCBvcy5nZXRldWlkKCkgIT0gMAogICAgcm93cz1bXQogICAgZm9yIHRhc2sgaW4gKCJzbW9rZS1vcmlnaW5hbCIsInNtb2tlLW9yaWdpbmFsIiwic21va2UtcmVwbGF5Iik6CiAgICAgICAgcD1zdWJwcm9jZXNzLnJ1bihbc3lzLmV4ZWN1dGFibGUsX19maWxlX18sdGFza10sY2FwdHVyZV9vdXRwdXQ9VHJ1ZSx0ZXh0PVRydWUsY2hlY2s9VHJ1ZSx0aW1lb3V0PTI1KQogICAgICAgIHJvd3MuYXBwZW5kKGpzb24ubG9hZHMocC5zdGRvdXQpKQogICAgYSxiLGM9cm93cwogICAgYXNzZXJ0IGE9PWIgYW5kIGFbInN0YXRlIl09PWNbInN0YXRlIl09PSJzdWNjZWVkZWQiCiAgICBhc3NlcnQgYVsicmVjZWlwdCJdWyJhcnRpZmFjdF9yZWYiXT09Y1sicmVjZWlwdCJdWyJhcnRpZmFjdF9yZWYiXQogICAgYXNzZXJ0IGFbInJlY2VpcHQiXVsicHJvdmlkZXJfY2FsbHMiXT09Y1sicmVjZWlwdCJdWyJwcm92aWRlcl9jYWxscyJdPT0wCiAgICBzaGE9YVsicmVjZWlwdCJdWyJhcnRpZmFjdF9yZWYiXS5zcGxpdCgiOiIpWzFdCiAgICBkYXRhPShyb290LyhzaGErIi5qc29uIikpLnJlYWRfYnl0ZXMoKQogICAgYXNzZXJ0IGhhc2hsaWIuc2hhMjU2KGRhdGEpLmhleGRpZ2VzdCgpPT1zaGEKICAgIHByaW50KCJDTElOS19ESDAwNj0iK2pzb24uZHVtcHMoeyJpbnRlcmZhY2VzIjpbImxvIl0sInVpZCI6b3MuZ2V0ZXVpZCgpLCJvcmlnaW5hbCI6YSwicmVvcGVuZWQiOmIsInJlcGxheSI6YywiYXJ0aWZhY3QiOmRhdGEuZGVjb2RlKCl9LHNlcGFyYXRvcnM9KCIsIiwiOiIpKSxmbHVzaD1UcnVlKQonJycKIyBGaXhlZCBwcml2aWxlZ2VkIHByb3Zpc2lvbmluZyBvbmx5LiBXb3JrZmxvdyBydW5zIHVuZGVyIHRoZSBndWVzdCdzIHVidW50dSB1c2VyLgpXUkFQUEVSID0gcicnJwppbXBvcnQgc3VicHJvY2VzcyxzeXMKd2l0aCBvcGVuKCIvZGV2L3R0eVMwIiwidyIpIGFzIGY6CiAgICBwPXN1YnByb2Nlc3MucnVuKFsicnVudXNlciIsIi11IiwidWJ1bnR1IiwiLS0iLCJweXRob24zIiwiL29wdC9jbGluay1zbW9rZS9ndWVzdC5weSIsImNvbGxlY3QiXSxjYXB0dXJlX291dHB1dD1UcnVlLHRleHQ9VHJ1ZSx0aW1lb3V0PTEwMCkKICAgIGYud3JpdGUoIlxuIitwLnN0ZG91dCsiXG4iKQogICAgaWYgcC5yZXR1cm5jb2RlOgogICAgICAgIGYud3JpdGUoIkNMSU5LX0RIMDA2X0VSUk9SPSIrcmVwcihwLnN0ZGVyclstMjAwMDpdKSsiXG4iKQogICAgZi5mbHVzaCgpCiAgICBzeXMuZXhpdChwLnJldHVybmNvZGUpCicnJwoKZGVmIHNoYShwKToKICAgIHdpdGggcC5vcGVuKCJyYiIpIGFzIGY6CiAgICAgICAgcmV0dXJuIGhhc2hsaWIuZmlsZV9kaWdlc3QoZiwic2hhMjU2IikuaGV4ZGlnZXN0KCkKCmRlZiB2ZXJpZnkocHJvb2YpOgogICAgaWYgcHJvb2ZbImludGVyZmFjZXMiXSAhPSBbImxvIl0gb3IgdHlwZShwcm9vZlsidWlkIl0pIGlzIG5vdCBpbnQgb3IgcHJvb2ZbInVpZCJdIDw9IDA6CiAgICAgICAgcmFpc2UgVmFsdWVFcnJvcigiZ3Vlc3QgaXNvbGF0aW9uL3VzZXIgZXZpZGVuY2UgaW52YWxpZCIpCiAgICBhLGIsYz0ocHJvb2Zba10gZm9yIGsgaW4gKCJvcmlnaW5hbCIsInJlb3BlbmVkIiwicmVwbGF5IikpCiAgICBpZiBhIT1iOgogICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoImpvdXJuYWwgcmVvcGVuIG1pc21hdGNoIikKICAgIGFydGlmYWN0PXByb29mWyJhcnRpZmFjdCJdLmVuY29kZSgpCiAgICBleHBlY3RlZD1qc29uLmR1bXBzKHsiY2FsY3VsYXRvci5weSI6U09VUkNFLmRlY29kZSgpLCJjaGVjay5weSI6VEVTVC5kZWNvZGUoKSwKICAgICAgICAgICAgICAgICAgICAgICAgICJzdGRvdXQiOiIyIGNoZWNrcyBwYXNzZWRcbiJ9LHNvcnRfa2V5cz1UcnVlLHNlcGFyYXRvcnM9KCIsIiwiOiIpKS5lbmNvZGUoKQogICAgaWYgYXJ0aWZhY3QhPWV4cGVjdGVkOgogICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoInVuZXhwZWN0ZWQgYXJ0aWZhY3QgY29udGVudCIpCiAgICByZWY9InNoYTI1NjoiK2hhc2hsaWIuc2hhMjU2KGFydGlmYWN0KS5oZXhkaWdlc3QoKQogICAgZm9yIHJvdyx0aWQgaW4gKChhLCJzbW9rZS1vcmlnaW5hbCIpLChjLCJzbW9rZS1yZXBsYXkiKSk6CiAgICAgICAgcj1yb3dbInJlY2VpcHQiXQogICAgICAgIGlmIChyb3dbImlkIl0hPXRpZCBvciByb3dbInN0YXRlIl0hPSJzdWNjZWVkZWQiIG9yIHJvd1siYXR0ZW1wdHMiXSE9MSBvcgogICAgICAgICAgICByb3dbInNwZWMiXSE9U1BFQyBvciByWyJ3b3JrZmxvdyJdIT1XT1JLRkxPVyBvciByWyJleGl0X2NvZGUiXSE9MCBvcgogICAgICAgICAgICByWyJ0ZXN0X3Jlc3VsdCJdIT0iMiBjaGVja3MgcGFzc2VkIiBvciByWyJwcm92aWRlcl9jYWxscyJdIT0wIG9yIHJbImFydGlmYWN0X3JlZiJdIT1yZWYpOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCJ1bmV4cGVjdGVkIHRhc2sgcmVjZWlwdCIpCiAgICByZXR1cm4gYXJ0aWZhY3QKCmRlZiBjbG91ZF9jb25maWcoc291cmNlX2Rpcik6CiAgICBmaWxlcz17bjooc291cmNlX2Rpci9uKS5yZWFkX2J5dGVzKCkgZm9yIG4gaW4gKCJ0YXNrX2VuZ2luZS5weSIsImRldmVsb3BtZW50X3Ntb2tlLnB5Iil9CiAgICBmaWxlcy51cGRhdGUoeyJndWVzdC5weSI6R1VFU1QuZW5jb2RlKCksIndyYXBwZXIucHkiOldSQVBQRVIuZW5jb2RlKCl9KQogICAgbGluZXM9WyIjY2xvdWQtY29uZmlnIiwic3NoX3B3YXV0aDogZmFsc2UiLCJwYWNrYWdlX3VwZGF0ZTogZmFsc2UiLCJwYWNrYWdlX3VwZ3JhZGU6IGZhbHNlIiwid3JpdGVfZmlsZXM6Il0KICAgIGZvciBuYW1lLGRhdGEgaW4gZmlsZXMuaXRlbXMoKToKICAgICAgICBsaW5lcy5leHRlbmQoWyIgIC0gcGF0aDogL29wdC9jbGluay1zbW9rZS8iK25hbWUsIiAgICBwZXJtaXNzaW9uczogJzA2NDQnIiwKICAgICAgICAgICAgICAgICAgICAgICIgICAgZW5jb2Rpbmc6IGI2NCIsIiAgICBjb250ZW50OiAiK2Jhc2U2NC5iNjRlbmNvZGUoZGF0YSkuZGVjb2RlKCldKQogICAgbGluZXMuZXh0ZW5kKFsicnVuY21kOiIsIiAgLSBbcHl0aG9uMywgL29wdC9jbGluay1zbW9rZS93cmFwcGVyLnB5XSIsCiAgICAgICAgICAgICAgICAgICJwb3dlcl9zdGF0ZToiLCIgIG1vZGU6IHBvd2Vyb2ZmIiwiICB0aW1lb3V0OiA2MCIsIiAgY29uZGl0aW9uOiB0cnVlIl0pCiAgICByZXR1cm4gKCJcbiIuam9pbihsaW5lcykrIlxuIikuZW5jb2RlKCkKCmRlZiBtYWluKCk6CiAgICBvcy51bWFzaygwbzA3NykKICAgIHN0YW1wPWRhdGV0aW1lLm5vdyh0aW1lem9uZS51dGMpLnN0cmZ0aW1lKCIlWSVtJWRUJUglTSVTJWZaIikKICAgIHJvb3Q9UGF0aC5ob21lKCkvIi5sb2NhbC9zaGFyZS9waGFudG9tdHJvbml4LWRldmVsb3BtZW50LWhvc3QiCiAgICBkb3dubG9hZHM9cm9vdC8icmVjZWlwdHMiCiAgICBkb3dubG9hZHMubWtkaXIobW9kZT0wbzcwMCxwYXJlbnRzPVRydWUsZXhpc3Rfb2s9VHJ1ZSkKICAgIHJlY2VpcHQ9eyJyb3VuZCI6IjAwOCIsInN0YXR1cyI6IkJMT0NLRUQiLCJ0aW1lc3RhbXAiOnN0YW1wLCJwcm92aWRlcl9jYWxscyI6MCwicHJvZHVjdGlvbl9tb2RpZmllZCI6RmFsc2V9CiAgICBmaWxlcz17fQogICAgc2VyaWFsPU5vbmUKICAgIHRyeToKICAgICAgICBiYXNlPXJvb3QvInVidW50dS0yNC4wNC1zZXJ2ZXItY2xvdWRpbWctYW1kNjQuaW1nIgogICAgICAgIHByaW50KCJWZXJpZnlpbmcgY2FjaGVkIFVidW50dSBpbWFnZSAobm8gZG93bmxvYWQpLi4uIixmbHVzaD1UcnVlKQogICAgICAgIGlmIG5vdCBiYXNlLmlzX2ZpbGUoKSBvciBzaGEoYmFzZSkhPUJBU0VfU0hBOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoImFjY2VwdGVkIGJhc2UgaW1hZ2UgdW5hdmFpbGFibGUgb3IgY2hlY2tzdW0gbWlzbWF0Y2giKQogICAgICAgIHJlY2VpcHRbImltYWdlX3NoYTI1NiJdPUJBU0VfU0hBCiAgICAgICAgaWYgc2h1dGlsLmRpc2tfdXNhZ2Uocm9vdCkuZnJlZSA8IDIqMTAyNCoqMzoKICAgICAgICAgICAgcmFpc2UgUnVudGltZUVycm9yKCJpbnN1ZmZpY2llbnQgZnJlZSBkaXNrIHNwYWNlIikKICAgICAgICB3b3JrPVBhdGgodGVtcGZpbGUubWtkdGVtcChwcmVmaXg9ImpvYi0wMDgtIixkaXI9cm9vdCkpCiAgICAgICAgZGlzaz13b3JrLyJkZXZlbG9wbWVudC5xY293MiIKICAgICAgICBzdWJwcm9jZXNzLnJ1bihbInFlbXUtaW1nIiwiY3JlYXRlIiwiLWYiLCJxY293MiIsIi1GIiwicWNvdzIiLCItYiIsc3RyKGJhc2UpLHN0cihkaXNrKSwiOEciXSxjaGVjaz1UcnVlLHRpbWVvdXQ9NjApCiAgICAgICAgc2VlZD13b3JrLyJzZWVkLmlzbyIKICAgICAgICBzZWVkLndyaXRlX2J5dGVzKHNlZWRfaXNvKGNsb3VkX2NvbmZpZyhQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50KSwKICAgICAgICAgICAgKCJpbnN0YW5jZS1pZDogZGgwMDYtIitzdGFtcCsiXG5sb2NhbC1ob3N0bmFtZTogcGhhbnRvbXRyb25peC1kZXZcbiIpLmVuY29kZSgpKSkKICAgICAgICByZWNlaXB0WyJzZWVkX3NoYTI1NiJdPXNoYShzZWVkKQogICAgICAgIHNlcmlhbD13b3JrLyJzZXJpYWwubG9nIgogICAgICAgIGFyZ3Y9WyJxZW11LXN5c3RlbS14ODZfNjQiLCItbWFjaGluZSIsInEzNSxhY2NlbD1rdm0iLCItY3B1IiwiaG9zdCIsIi1zbXAiLCIyIiwiLW0iLCIyMDQ4IiwKICAgICAgICAgICAgICAiLW5vZGVmYXVsdHMiLCItbm8tdXNlci1jb25maWciLCItbmljIiwibm9uZSIsIi1kaXNwbGF5Iiwibm9uZSIsIi1tb25pdG9yIiwibm9uZSIsCiAgICAgICAgICAgICAgIi1zZXJpYWwiLCJmaWxlOiIrc3RyKHNlcmlhbCksIi1uby1yZWJvb3QiLCItZHJpdmUiLCJmaWxlPSIrc3RyKGRpc2spKyIsaWY9dmlydGlvLGZvcm1hdD1xY293MiIsCiAgICAgICAgICAgICAgIi1kcml2ZSIsImZpbGU9IitzdHIoc2VlZCkrIixpZj12aXJ0aW8sZm9ybWF0PXJhdyxyZWFkb25seT1vbiJdCiAgICAgICAgcHJpbnQoIlN0YXJ0aW5nIGlzb2xhdGVkIGd1ZXN0OyBDdHJsK0MgY2FuY2VscyB0aGlzIGpvYi4iLGZsdXNoPVRydWUpCiAgICAgICAgd2l0aCAod29yay8icWVtdS5zdGRlcnIiKS5vcGVuKCJ3YiIpIGFzIGVycjoKICAgICAgICAgICAgcD1zdWJwcm9jZXNzLlBvcGVuKGFyZ3Ysc3Rkb3V0PXN1YnByb2Nlc3MuREVWTlVMTCxzdGRlcnI9ZXJyKQogICAgICAgICAgICBzdGFydGVkPXRpbWUubW9ub3RvbmljKCkKICAgICAgICAgICAgdHJ5OgogICAgICAgICAgICAgICAgd2hpbGUgcC5wb2xsKCkgaXMgTm9uZToKICAgICAgICAgICAgICAgICAgICBlbGFwc2VkPWludCh0aW1lLm1vbm90b25pYygpLXN0YXJ0ZWQpCiAgICAgICAgICAgICAgICAgICAgaWYgZWxhcHNlZD49NjAwOiByYWlzZSBUaW1lb3V0RXJyb3IoImd1ZXN0IHRpbWVvdXQiKQogICAgICAgICAgICAgICAgICAgIHByaW50KCJHdWVzdCBhY3RpdmU6IixlbGFwc2VkLCJzZWNvbmRzIixmbHVzaD1UcnVlKQogICAgICAgICAgICAgICAgICAgIHRyeTogcC53YWl0KHRpbWVvdXQ9MTUpCiAgICAgICAgICAgICAgICAgICAgZXhjZXB0IHN1YnByb2Nlc3MuVGltZW91dEV4cGlyZWQ6IHBhc3MKICAgICAgICAgICAgZmluYWxseToKICAgICAgICAgICAgICAgIGlmIHAucG9sbCgpIGlzIE5vbmU6CiAgICAgICAgICAgICAgICAgICAgcC50ZXJtaW5hdGUoKQogICAgICAgICAgICAgICAgICAgIHRyeTogcC53YWl0KHRpbWVvdXQ9MTApCiAgICAgICAgICAgICAgICAgICAgZXhjZXB0IHN1YnByb2Nlc3MuVGltZW91dEV4cGlyZWQ6IHAua2lsbCgpOyBwLndhaXQoKQogICAgICAgIHJlY2VpcHRbImV4aXRfY29kZSJdPXAucmV0dXJuY29kZQogICAgICAgIHJlY2VpcHRbInN0ZGVyciJdPSh3b3JrLyJxZW11LnN0ZGVyciIpLnJlYWRfYnl0ZXMoKVstODAwMDpdLmRlY29kZShlcnJvcnM9InJlcGxhY2UiKQogICAgICAgIGlmIHAucmV0dXJuY29kZSE9MDogcmFpc2UgUnVudGltZUVycm9yKCJRRU1VIGZhaWxlZCIpCiAgICAgICAgd2l0aCBzZXJpYWwub3BlbigicmIiKSBhcyBmOgogICAgICAgICAgICBmLnNlZWsobWF4KDAsc2VyaWFsLnN0YXQoKS5zdF9zaXplLTI2MjE0NCkpCiAgICAgICAgICAgIGxpbmVzPWYucmVhZCgpLmRlY29kZShlcnJvcnM9InJlcGxhY2UiKS5zcGxpdGxpbmVzKCkKICAgICAgICBtYXRjaGVzPVtsaW5lW2xlbihQUkVGSVgpOl0gZm9yIGxpbmUgaW4gbGluZXMgaWYgbGluZS5zdGFydHN3aXRoKFBSRUZJWCldCiAgICAgICAgaWYgbGVuKG1hdGNoZXMpIT0xOiByYWlzZSBSdW50aW1lRXJyb3IoImV4cGVjdGVkIGV4YWN0bHkgb25lIGd1ZXN0IHByb29mIikKICAgICAgICBwcm9vZj1qc29uLmxvYWRzKG1hdGNoZXNbMF0pCiAgICAgICAgYXJ0aWZhY3Q9dmVyaWZ5KHByb29mKQogICAgICAgIGZpbGVzWyJBUlRJRkFDVC5qc29uIl09YXJ0aWZhY3QKICAgICAgICBmaWxlc1siR1VFU1QuUFJPT0YuanNvbiJdPWpzb24uZHVtcHMocHJvb2YsaW5kZW50PTIpLmVuY29kZSgpCiAgICAgICAgKHdvcmsvIkFSVElGQUNULmpzb24iKS53cml0ZV9ieXRlcyhhcnRpZmFjdCkKICAgICAgICByZWNlaXB0WyJhcnRpZmFjdF9zaGEyNTYiXT1oYXNobGliLnNoYTI1NihhcnRpZmFjdCkuaGV4ZGlnZXN0KCkKICAgICAgICByZWNlaXB0WyJzdGF0dXMiXT0iUEFTUyIKICAgIGV4Y2VwdCBLZXlib2FyZEludGVycnVwdDoKICAgICAgICByZWNlaXB0WyJzdGF0dXMiXT0iQ0FOQ0VMTEVEIgogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOgogICAgICAgIHJlY2VpcHRbImVycm9yIl09c3RyKGUpWzo0MDAwXQogICAgaWYgc2VyaWFsIGFuZCBzZXJpYWwuaXNfZmlsZSgpOgogICAgICAgIHdpdGggc2VyaWFsLm9wZW4oInJiIikgYXMgZjoKICAgICAgICAgICAgZi5zZWVrKG1heCgwLHNlcmlhbC5zdGF0KCkuc3Rfc2l6ZS02NTUzNikpCiAgICAgICAgICAgIGZpbGVzWyJHVUVTVC5TRVJJQUwubG9nIl09Zi5yZWFkKCkKICAgIGZpbGVzWyJSRUNFSVBULmpzb24iXT1qc29uLmR1bXBzKHJlY2VpcHQsaW5kZW50PTIpLmVuY29kZSgpCiAgICBvdXQ9ZG93bmxvYWRzL2YiQ0xJTksuUkVUVVJOLkRFVkVMT1BNRU5ULUhPU1QuMDA4LntzdGFtcH0uemlwIgogICAgd2l0aCB6aXBmaWxlLlppcEZpbGUob3V0LCJ4Iix6aXBmaWxlLlpJUF9ERUZMQVRFRCkgYXMgejoKICAgICAgICBmb3Iga2V5LGRhdGEgaW4gZmlsZXMuaXRlbXMoKTogei53cml0ZXN0cihrZXksZGF0YSkKICAgICAgICB6LndyaXRlc3RyKCJTSEEyNTZTVU1TIiwiIi5qb2luKGhhc2hsaWIuc2hhMjU2KGRhdGEpLmhleGRpZ2VzdCgpKyIgICIra2V5KyJcbiIgZm9yIGtleSxkYXRhIGluIGZpbGVzLml0ZW1zKCkpKQogICAgcHJpbnQoIkRFVkVMT1BNRU5UIEhPU1QgMDA4OiIscmVjZWlwdFsic3RhdHVzIl0sZmx1c2g9VHJ1ZSkKICAgIHByaW50KCJDTElOS19IT1NUX1JFQ0VJUFQ9Iitqc29uLmR1bXBzKHsqKnJlY2VpcHQsInJlY2VpcHRfcGF0aCI6c3RyKG91dCl9LHNlcGFyYXRvcnM9KCIsIiwiOiIpKSxmbHVzaD1UcnVlKQoKaWYgX19uYW1lX189PSJfX21haW5fXyI6CiAgICBtYWluKCkK", "development_smoke.py": "IiIiRml4ZWQgb2ZmbGluZSBEZXZlbG9wbWVudCBIb3N0IHdvcmtmbG93OyBpbnZva2Ugb25seSBpbiBhcHByb3ZlZCBpc29sYXRlZCBydW50aW1lLgpObyBhcmJpdHJhcnkgY29tbWFuZHMsIHBhdGhzIG9yIG1vZGVsLWdlbmVyYXRlZCBjb2RlLiBTdGF0ZSByb290IGlzIGhvc3Qtb3duZWQuCiIiIgppbXBvcnQgZmNudGwKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAppbXBvcnQgc3VicHJvY2VzcwppbXBvcnQgc3lzCmltcG9ydCB0ZW1wZmlsZQoKV09SS0ZMT1cgPSAnZGV2ZWxvcG1lbnQuc21va2UudjEnClNPVVJDRSA9IGInZGVmIGFkZChhLCBiKTpcbiAgICByZXR1cm4gYSArIGJcbicKVEVTVCA9IGInZnJvbSBjYWxjdWxhdG9yIGltcG9ydCBhZGRcbmFzc2VydCBhZGQoMiwgMykgPT0gNVxuYXNzZXJ0IGFkZCgtNCwgNCkgPT0gMFxucHJpbnQoIjIgY2hlY2tzIHBhc3NlZCIpXG4nCgpkZWYgZGlnZXN0KGRhdGEpOgogICAgcmV0dXJuIGhhc2hsaWIuc2hhMjU2KGRhdGEpLmhleGRpZ2VzdCgpCgpTUEVDID0geydvYmplY3RpdmUnOiAnQ3JlYXRlIGNhbGN1bGF0b3IucHkgYW5kIHRlc3QgYWRkaXRpb24nLAogICAgICAgICdhY2NlcHRhbmNlJzogJ1R3byBmaXhlZCBjaGVja3MgcGFzcycsCiAgICAgICAgJ2lucHV0X3JlZic6ICdzaGEyNTY6JyArIGRpZ2VzdChTT1VSQ0UgKyBiJ1wwJyArIFRFU1QpLAogICAgICAgICd3b3JrZmxvdyc6IFdPUktGTE9XfQoKCmRlZiBleGVjdXRlKHJvb3QpOgogICAgIiIiVHJ1c3RlZCBmaXh0dXJlIG9ubHk7IHRoaXMgZnVuY3Rpb24gaXMgTk9UIGFuIE9TIGlzb2xhdGlvbiBib3VuZGFyeS4iIiIKICAgIHJvb3QgPSBQYXRoKHJvb3QpLnJlc29sdmUoc3RyaWN0PVRydWUpCiAgICB3aXRoIHRlbXBmaWxlLlRlbXBvcmFyeURpcmVjdG9yeShwcmVmaXg9J3Ntb2tlLScsIGRpcj1yb290KSBhcyB0bXA6CiAgICAgICAgd29yayA9IFBhdGgodG1wKQogICAgICAgICh3b3JrIC8gJ2NhbGN1bGF0b3IucHknKS53cml0ZV9ieXRlcyhTT1VSQ0UpCiAgICAgICAgKHdvcmsgLyAnY2hlY2sucHknKS53cml0ZV9ieXRlcyhURVNUKQogICAgICAgICMgSXNvbGF0ZWQgUHl0aG9uIGltcG9ydCBtb2RlOyBleHBsaWNpdCB0cnVzdGVkIGZpeHR1cmUgZGlyZWN0b3J5IG9ubHkuCiAgICAgICAgYXJndiA9IFtzeXMuZXhlY3V0YWJsZSwgJy1JJywgJy1CJywgJy1jJywKICAgICAgICAgICAgICAgICdpbXBvcnQgc3lzLHJ1bnB5O3N5cy5wYXRoLmluc2VydCgwLCIuIik7cnVucHkucnVuX3BhdGgoImNoZWNrLnB5IixydW5fbmFtZT0iX19tYWluX18iKSddCiAgICAgICAgcmVzdWx0ID0gc3VicHJvY2Vzcy5ydW4oYXJndiwgY3dkPXdvcmssIGVudj17J1BBVEgnOiAnL3Vzci9iaW46L2JpbicsICdIT01FJzogdG1wLCAnTENfQUxMJzogJ0MnfSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGRpbj1zdWJwcm9jZXNzLkRFVk5VTEwsIGNhcHR1cmVfb3V0cHV0PVRydWUsIHRpbWVvdXQ9MTAsIGNoZWNrPUZhbHNlKQogICAgICAgIGlmIHJlc3VsdC5yZXR1cm5jb2RlICE9IDAgb3IgcmVzdWx0LnN0ZG91dCAhPSBiJzIgY2hlY2tzIHBhc3NlZFxuJyBvciByZXN1bHQuc3RkZXJyOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoJ2ZpeGVkIHZhbGlkYXRvciBmYWlsZWQnKQogICAgICAgIGFydGlmYWN0ID0ganNvbi5kdW1wcyh7J2NhbGN1bGF0b3IucHknOiBTT1VSQ0UuZGVjb2RlKCksICdjaGVjay5weSc6IFRFU1QuZGVjb2RlKCksCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc3Rkb3V0JzogcmVzdWx0LnN0ZG91dC5kZWNvZGUoKX0sIHNvcnRfa2V5cz1UcnVlLCBzZXBhcmF0b3JzPSgnLCcsICc6JykpLmVuY29kZSgpCiAgICAgICAgc2hhID0gZGlnZXN0KGFydGlmYWN0KQogICAgICAgIGRlc3QgPSByb290IC8gKHNoYSArICcuanNvbicpCiAgICAgICAgIyBBdG9taWMgaW1tdXRhYmxlIHB1YmxpY2F0aW9uOyBleGlzdGluZyBvYmplY3QgbXVzdCBtYXRjaC4KICAgICAgICBmZCwgc3RhZ2luZyA9IHRlbXBmaWxlLm1rc3RlbXAocHJlZml4PScuYXJ0aWZhY3QtJywgZGlyPXJvb3QpCiAgICAgICAgdHJ5OgogICAgICAgICAgICB3aXRoIG9zLmZkb3BlbihmZCwgJ3diJykgYXMgZjoKICAgICAgICAgICAgICAgIGYud3JpdGUoYXJ0aWZhY3QpOyBmLmZsdXNoKCk7IG9zLmZzeW5jKGYuZmlsZW5vKCkpCiAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAgIG9zLmxpbmsoc3RhZ2luZywgZGVzdCkKICAgICAgICAgICAgZXhjZXB0IEZpbGVFeGlzdHNFcnJvcjoKICAgICAgICAgICAgICAgIGlmIGRlc3QuaXNfc3ltbGluaygpIG9yIGRlc3QucmVhZF9ieXRlcygpICE9IGFydGlmYWN0OgogICAgICAgICAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcignYXJ0aWZhY3QgbWlzbWF0Y2gnKQogICAgICAgIGZpbmFsbHk6CiAgICAgICAgICAgIG9zLnVubGluayhzdGFnaW5nKQogICAgICAgIHJldHVybiB7J3dvcmtmbG93JzogV09SS0ZMT1csICd0ZXN0X2NvbW1hbmQnOiAncHl0aG9uIC1JIC1CIDxmaXhlZCBjaGVjayBydW5uZXI+JywKICAgICAgICAgICAgICAgICd0ZXN0X3Jlc3VsdCc6IHJlc3VsdC5zdGRvdXQuZGVjb2RlKCkuc3RyaXAoKSwgJ2V4aXRfY29kZSc6IHJlc3VsdC5yZXR1cm5jb2RlLAogICAgICAgICAgICAgICAgJ2FydGlmYWN0X3JlZic6ICdzaGEyNTY6JyArIHNoYSwgJ3Byb3ZpZGVyX2NhbGxzJzogMH0KCgpkZWYgcnVuX2pvdXJuYWxlZChyb290LCB0YXNrX2lkKToKICAgICIiIlVzZSBleGlzdGluZyBFbmdpbmUgaW4gYSBkZWRpY2F0ZWQgaG9zdC1vd25lZCBqb3VybmFsOyBuZXZlciBkaXNwYXRjaCBhIHByb3ZpZGVyLiIiIgogICAgZnJvbSB0YXNrX2VuZ2luZSBpbXBvcnQgRW5naW5lCiAgICBpZiB0YXNrX2lkIG5vdCBpbiAoJ3Ntb2tlLW9yaWdpbmFsJywgJ3Ntb2tlLXJlcGxheScpOgogICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoJ3VucmVnaXN0ZXJlZCB0YXNrJykKICAgIHJvb3QgPSBQYXRoKHJvb3QpLnJlc29sdmUoc3RyaWN0PVRydWUpCiAgICB3aXRoIChyb290IC8gJ2RldmVsb3BtZW50LXNtb2tlLmxvY2snKS5vcGVuKCdhJykgYXMgbG9jazoKICAgICAgICBmY250bC5mbG9jayhsb2NrLCBmY250bC5MT0NLX0VYIHwgZmNudGwuTE9DS19OQikKICAgICAgICByZXR1cm4gX3J1bl9sb2NrZWQocm9vdCwgdGFza19pZCwgRW5naW5lKQoKCmRlZiBfcnVuX2xvY2tlZChyb290LCB0YXNrX2lkLCBFbmdpbmUpOgogICAgZW5naW5lID0gRW5naW5lKHJvb3QgLyAnZGV2ZWxvcG1lbnQtc21va2Uuc3FsaXRlJykKICAgIHRyeToKICAgICAgICBlbmdpbmUuZW5xdWV1ZSh0YXNrX2lkLCBTUEVDLCBtYXhfYXR0ZW1wdHM9MSkKICAgICAgICByb3cgPSBlbmdpbmUuZ2V0KHRhc2tfaWQpCiAgICAgICAgaWYgcm93WydzdGF0ZSddID09ICdzdWNjZWVkZWQnOgogICAgICAgICAgICByZWNlaXB0ID0gcm93WydyZWNlaXB0J10KICAgICAgICAgICAgYXJ0aWZhY3QgPSByb290IC8gKHJlY2VpcHRbJ2FydGlmYWN0X3JlZiddLnNwbGl0KCc6JywgMSlbMV0gKyAnLmpzb24nKQogICAgICAgICAgICBpZiBhcnRpZmFjdC5pc19zeW1saW5rKCkgb3IgZGlnZXN0KGFydGlmYWN0LnJlYWRfYnl0ZXMoKSkgIT0gcmVjZWlwdFsnYXJ0aWZhY3RfcmVmJ10uc3BsaXQoJzonLCAxKVsxXToKICAgICAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcignc3RvcmVkIGFydGlmYWN0IG1pc21hdGNoJykKICAgICAgICAgICAgcmV0dXJuIHJvdwogICAgICAgICMgRGVkaWNhdGVkIGpvdXJuYWw7IGRvIG5vdCBjbGFpbSBhbm90aGVyIHF1ZXVlZCB0YXNrLgogICAgICAgIHBlbmRpbmcgPSBlbmdpbmUuZGIuZXhlY3V0ZSgiU0VMRUNUIGlkIEZST00gdGFza3MgV0hFUkUgc3RhdGU9J3F1ZXVlZCcgT1JERVIgQlkgY3JlYXRlZCxpZCBMSU1JVCAxIikuZmV0Y2hvbmUoKQogICAgICAgIGlmIHBlbmRpbmcgaXMgTm9uZSBvciBwZW5kaW5nWydpZCddICE9IHRhc2tfaWQ6CiAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcigncmVxdWVzdGVkIHRhc2sgbm90IHF1ZXVlZCBmaXJzdCcpCiAgICAgICAgcm93ID0gZW5naW5lLmNsYWltKFdPUktGTE9XLCBzZWNvbmRzPTMwKQogICAgICAgIGlmIHJvdyBpcyBOb25lIG9yIHJvd1snaWQnXSAhPSB0YXNrX2lkOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoJ2NsYWltIHVuYXZhaWxhYmxlJykKICAgICAgICB0cnk6CiAgICAgICAgICAgIHJlY2VpcHQgPSBleGVjdXRlKHJvb3QpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgZW5naW5lLmZhaWwodGFza19pZCwgcm93Wyd0b2tlbiddLCAnZml4ZWQgZXhlY3V0aW9uIGZhaWxlZCcpCiAgICAgICAgICAgIHJhaXNlCiAgICAgICAgZW5naW5lLmZpbmlzaCh0YXNrX2lkLCByb3dbJ3Rva2VuJ10sIHJlY2VpcHQpCiAgICAgICAgcmV0dXJuIGVuZ2luZS5nZXQodGFza19pZCkKICAgIGZpbmFsbHk6CiAgICAgICAgZW5naW5lLmNsb3NlKCkK", "task_engine.py": "IiIiT2ZmbGluZSBkdXJhYmxlIHRhc2sgZW5naW5lLiBObyBzaGVsbCwgbmV0d29yaywgb3IgbW9kZWwgZXhlY3V0aW9uLiIiIgppbXBvcnQganNvbgppbXBvcnQgbWF0aAppbXBvcnQgcmUKaW1wb3J0IHNlY3JldHMKaW1wb3J0IHNxbGl0ZTMKaW1wb3J0IHRpbWUKZnJvbSBjb250ZXh0bGliIGltcG9ydCBjb250ZXh0bWFuYWdlcgoKCmNsYXNzIENvbmZsaWN0KFJ1bnRpbWVFcnJvcik6CiAgICBwYXNzCgoKY2xhc3MgRW5naW5lOgogICAgZGVmIF9faW5pdF9fKHNlbGYsIHBhdGgsIGNsb2NrPXRpbWUudGltZSk6CiAgICAgICAgc2VsZi5jbG9jayA9IGNsb2NrCiAgICAgICAgc2VsZi5kYiA9IHNxbGl0ZTMuY29ubmVjdChwYXRoLCB0aW1lb3V0PTEwLCBpc29sYXRpb25fbGV2ZWw9Tm9uZSkKICAgICAgICBzZWxmLmRiLnJvd19mYWN0b3J5ID0gc3FsaXRlMy5Sb3cKICAgICAgICBzZWxmLmRiLmV4ZWN1dGUoJ1BSQUdNQSBqb3VybmFsX21vZGU9V0FMJykKICAgICAgICBzZWxmLmRiLmV4ZWN1dGUoJ1BSQUdNQSBzeW5jaHJvbm91cz1GVUxMJykKICAgICAgICBzZWxmLmRiLmV4ZWN1dGVzY3JpcHQoJycnCiAgICAgICAgQ1JFQVRFIFRBQkxFIElGIE5PVCBFWElTVFMgdGFza3MoCiAgICAgICAgICAgIGlkIFRFWFQgUFJJTUFSWSBLRVksIHNwZWMgVEVYVCBOT1QgTlVMTCwgbWF4X2F0dGVtcHRzIElOVEVHRVIgTk9UIE5VTEwsCiAgICAgICAgICAgIGF0dGVtcHRzIElOVEVHRVIgTk9UIE5VTEwgREVGQVVMVCAwLCBzdGF0ZSBURVhUIE5PVCBOVUxMIERFRkFVTFQgJ3F1ZXVlZCcsCiAgICAgICAgICAgIHRva2VuIFRFWFQsIHdvcmtlciBURVhULCBleHBpcmVzIFJFQUwsIHJlY2VpcHQgVEVYVCwgY3JlYXRlZCBSRUFMIE5PVCBOVUxMKTsKICAgICAgICBDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyBldmVudHMoCiAgICAgICAgICAgIHNlcSBJTlRFR0VSIFBSSU1BUlkgS0VZLCB0YXNrX2lkIFRFWFQsIGtpbmQgVEVYVCBOT1QgTlVMTCwKICAgICAgICAgICAgYXQgUkVBTCBOT1QgTlVMTCwgZGV0YWlsIFRFWFQgTk9UIE5VTEwpOwogICAgICAgIENSRUFURSBUQUJMRSBJRiBOT1QgRVhJU1RTIGNvbnRyb2woaWQgSU5URUdFUiBQUklNQVJZIEtFWSwgcGF1c2VkIElOVEVHRVIgTk9UIE5VTEwpOwogICAgICAgIElOU0VSVCBPUiBJR05PUkUgSU5UTyBjb250cm9sIFZBTFVFUygxLDApOwogICAgICAgICcnJykKCiAgICBkZWYgY2xvc2Uoc2VsZik6CiAgICAgICAgc2VsZi5kYi5jbG9zZSgpCgogICAgQGNvbnRleHRtYW5hZ2VyCiAgICBkZWYgdHgoc2VsZik6CiAgICAgICAgc2VsZi5kYi5leGVjdXRlKCdCRUdJTiBJTU1FRElBVEUnKQogICAgICAgIHRyeToKICAgICAgICAgICAgeWllbGQKICAgICAgICAgICAgc2VsZi5kYi5jb21taXQoKQogICAgICAgIGV4Y2VwdCBCYXNlRXhjZXB0aW9uOgogICAgICAgICAgICBzZWxmLmRiLnJvbGxiYWNrKCkKICAgICAgICAgICAgcmFpc2UKCiAgICBkZWYgZXZlbnQoc2VsZiwgdGFza19pZCwga2luZCwgZGV0YWlsPU5vbmUpOgogICAgICAgIHNlbGYuZGIuZXhlY3V0ZSgnSU5TRVJUIElOVE8gZXZlbnRzKHRhc2tfaWQsa2luZCxhdCxkZXRhaWwpIFZBTFVFUyg/LD8sPyw/KScsCiAgICAgICAgICAgICAgICAgICAgICAgICh0YXNrX2lkLCBraW5kLCBzZWxmLmNsb2NrKCksIGpzb24uZHVtcHMoZGV0YWlsKSkpCgogICAgZGVmIGdldChzZWxmLCB0YXNrX2lkKToKICAgICAgICByb3cgPSBzZWxmLmRiLmV4ZWN1dGUoJ1NFTEVDVCAqIEZST00gdGFza3MgV0hFUkUgaWQ9PycsICh0YXNrX2lkLCkpLmZldGNob25lKCkKICAgICAgICBpZiByb3cgaXMgTm9uZToKICAgICAgICAgICAgcmFpc2UgS2V5RXJyb3IodGFza19pZCkKICAgICAgICByZXN1bHQgPSBkaWN0KHJvdykKICAgICAgICBmb3Iga2V5IGluICgnc3BlYycsICdyZWNlaXB0Jyk6CiAgICAgICAgICAgIHJlc3VsdFtrZXldID0ganNvbi5sb2FkcyhyZXN1bHRba2V5XSkgaWYgcmVzdWx0W2tleV0gaXMgbm90IE5vbmUgZWxzZSBOb25lCiAgICAgICAgcmV0dXJuIHJlc3VsdAoKICAgIGRlZiBlbnF1ZXVlKHNlbGYsIHRhc2tfaWQsIHNwZWMsIG1heF9hdHRlbXB0cz0zKToKICAgICAgICBmb3Iga2V5IGluICgnb2JqZWN0aXZlJywgJ2FjY2VwdGFuY2UnLCAnaW5wdXRfcmVmJyk6CiAgICAgICAgICAgIGlmIG5vdCBpc2luc3RhbmNlKHNwZWMuZ2V0KGtleSksIHN0cikgb3Igbm90IHNwZWNba2V5XS5zdHJpcCgpOgogICAgICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcihrZXkpCiAgICAgICAgaWYgbm90IHJlLmZ1bGxtYXRjaChyJ3NoYTI1NjpbMC05YS1mXXs2NH18Z2l0OlswLTlhLWZdezQwfScsIHNwZWNbJ2lucHV0X3JlZiddKToKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignaW1tdXRhYmxlIGlucHV0X3JlZiByZXF1aXJlZCcpCiAgICAgICAgaWYgbm90IGlzaW5zdGFuY2UodGFza19pZCwgc3RyKSBvciBub3QgdGFza19pZC5zdHJpcCgpIG9yIHR5cGUobWF4X2F0dGVtcHRzKSBpcyBub3QgaW50IG9yIG5vdCAxIDw9IG1heF9hdHRlbXB0cyA8PSAxMDoKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignaW52YWxpZCB0YXNrIGlkIG9yIGF0dGVtcHQgY2VpbGluZycpCiAgICAgICAgcGF5bG9hZCA9IGpzb24uZHVtcHMoc3BlYywgc29ydF9rZXlzPVRydWUsIGFsbG93X25hbj1GYWxzZSkKICAgICAgICB3aXRoIHNlbGYudHgoKToKICAgICAgICAgICAgb2xkID0gc2VsZi5kYi5leGVjdXRlKCdTRUxFQ1Qgc3BlYyxtYXhfYXR0ZW1wdHMgRlJPTSB0YXNrcyBXSEVSRSBpZD0/JywgKHRhc2tfaWQsKSkuZmV0Y2hvbmUoKQogICAgICAgICAgICBpZiBvbGQ6CiAgICAgICAgICAgICAgICBpZiB0dXBsZShvbGQpICE9IChwYXlsb2FkLCBtYXhfYXR0ZW1wdHMpOgogICAgICAgICAgICAgICAgICAgIHJhaXNlIENvbmZsaWN0KCd0YXNrIGlkIGFscmVhZHkgaGFzIGRpZmZlcmVudCBpbnB1dHMnKQogICAgICAgICAgICAgICAgcmV0dXJuCiAgICAgICAgICAgIHNlbGYuZGIuZXhlY3V0ZSgnSU5TRVJUIElOVE8gdGFza3MoaWQsc3BlYyxtYXhfYXR0ZW1wdHMsY3JlYXRlZCkgVkFMVUVTKD8sPyw/LD8pJywKICAgICAgICAgICAgICAgICAgICAgICAgICAgICh0YXNrX2lkLCBwYXlsb2FkLCBtYXhfYXR0ZW1wdHMsIHNlbGYuY2xvY2soKSkpCiAgICAgICAgICAgIHNlbGYuZXZlbnQodGFza19pZCwgJ3F1ZXVlZCcpCgogICAgZGVmIF9yZWNvdmVyKHNlbGYsIG5vdyk6CiAgICAgICAgZm9yIHJvdyBpbiBzZWxmLmRiLmV4ZWN1dGUoIlNFTEVDVCAqIEZST00gdGFza3MgV0hFUkUgc3RhdGU9J3J1bm5pbmcnIEFORCBleHBpcmVzPD0/IiwgKG5vdywpKS5mZXRjaGFsbCgpOgogICAgICAgICAgICBzdGF0ZSA9ICdmYWlsZWQnIGlmIHJvd1snYXR0ZW1wdHMnXSA+PSByb3dbJ21heF9hdHRlbXB0cyddIGVsc2UgJ3F1ZXVlZCcKICAgICAgICAgICAgc2VsZi5fcmVsZWFzZShyb3dbJ2lkJ10sIHN0YXRlKQogICAgICAgICAgICBzZWxmLmV2ZW50KHJvd1snaWQnXSwgJ2xlYXNlX2V4cGlyZWQnLCB7J25leHQnOiBzdGF0ZSwgJ2F0dGVtcHQnOiByb3dbJ2F0dGVtcHRzJ119KQoKICAgIGRlZiByZWNvdmVyKHNlbGYpOgogICAgICAgIHdpdGggc2VsZi50eCgpOgogICAgICAgICAgICBzZWxmLl9yZWNvdmVyKHNlbGYuY2xvY2soKSkKCiAgICBkZWYgX3JlbGVhc2Uoc2VsZiwgdGFza19pZCwgc3RhdGUsIHJlY2VpcHQ9Tm9uZSk6CiAgICAgICAgc2VsZi5kYi5leGVjdXRlKCdVUERBVEUgdGFza3MgU0VUIHN0YXRlPT8sdG9rZW49TlVMTCx3b3JrZXI9TlVMTCxleHBpcmVzPU5VTEwscmVjZWlwdD0/IFdIRVJFIGlkPT8nLAogICAgICAgICAgICAgICAgICAgICAgICAoc3RhdGUsIGpzb24uZHVtcHMocmVjZWlwdCkgaWYgcmVjZWlwdCBpcyBub3QgTm9uZSBlbHNlIE5vbmUsIHRhc2tfaWQpKQoKICAgIEBzdGF0aWNtZXRob2QKICAgIGRlZiBfZHVyYXRpb24oc2Vjb25kcyk6CiAgICAgICAgaWYgdHlwZShzZWNvbmRzKSBub3QgaW4gKGludCwgZmxvYXQpIG9yIG5vdCBtYXRoLmlzZmluaXRlKHNlY29uZHMpIG9yIG5vdCAwIDwgc2Vjb25kcyA8PSAzNjAwOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCdpbnZhbGlkIGxlYXNlIGR1cmF0aW9uJykKCiAgICBkZWYgY2xhaW0oc2VsZiwgd29ya2VyLCBzZWNvbmRzPTYwKToKICAgICAgICBzZWxmLl9kdXJhdGlvbihzZWNvbmRzKQogICAgICAgIGlmIG5vdCBpc2luc3RhbmNlKHdvcmtlciwgc3RyKSBvciBub3Qgd29ya2VyLnN0cmlwKCk6CiAgICAgICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoJ3dvcmtlciByZXF1aXJlZCcpCiAgICAgICAgd2l0aCBzZWxmLnR4KCk6CiAgICAgICAgICAgIG5vdyA9IHNlbGYuY2xvY2soKQogICAgICAgICAgICBzZWxmLl9yZWNvdmVyKG5vdykKICAgICAgICAgICAgaWYgc2VsZi5kYi5leGVjdXRlKCdTRUxFQ1QgcGF1c2VkIEZST00gY29udHJvbCBXSEVSRSBpZD0xJykuZmV0Y2hvbmUoKVswXToKICAgICAgICAgICAgICAgIHJldHVybiBOb25lCiAgICAgICAgICAgIHJvdyA9IHNlbGYuZGIuZXhlY3V0ZSgiU0VMRUNUIGlkIEZST00gdGFza3MgV0hFUkUgc3RhdGU9J3F1ZXVlZCcgT1JERVIgQlkgY3JlYXRlZCxpZCBMSU1JVCAxIikuZmV0Y2hvbmUoKQogICAgICAgICAgICBpZiByb3cgaXMgTm9uZToKICAgICAgICAgICAgICAgIHJldHVybiBOb25lCiAgICAgICAgICAgIHRhc2tfaWQgPSByb3dbJ2lkJ10KICAgICAgICAgICAgdG9rZW4gPSBzZWNyZXRzLnRva2VuX2hleCgzMikKICAgICAgICAgICAgc2VsZi5kYi5leGVjdXRlKCJVUERBVEUgdGFza3MgU0VUIHN0YXRlPSdydW5uaW5nJyxhdHRlbXB0cz1hdHRlbXB0cysxLHRva2VuPT8sd29ya2VyPT8sZXhwaXJlcz0/IFdIRVJFIGlkPT8iLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgKHRva2VuLCB3b3JrZXIsIG5vdytzZWNvbmRzLCB0YXNrX2lkKSkKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAnY2xhaW1lZCcsIHsnd29ya2VyJzogd29ya2VyfSkKICAgICAgICAgICAgcmV0dXJuIHNlbGYuZ2V0KHRhc2tfaWQpCgogICAgZGVmIF9vd25lZChzZWxmLCB0YXNrX2lkLCB0b2tlbik6CiAgICAgICAgcm93ID0gc2VsZi5nZXQodGFza19pZCkKICAgICAgICBpZiBub3QgdG9rZW4gb3Igcm93WydzdGF0ZSddICE9ICdydW5uaW5nJyBvciByb3dbJ3Rva2VuJ10gIT0gdG9rZW4gb3Igcm93WydleHBpcmVzJ10gPD0gc2VsZi5jbG9jaygpOgogICAgICAgICAgICByYWlzZSBDb25mbGljdCgnaW52YWxpZCBvciBleHBpcmVkIGxlYXNlJykKICAgICAgICByZXR1cm4gcm93CgogICAgZGVmIHJlbmV3KHNlbGYsIHRhc2tfaWQsIHRva2VuLCBzZWNvbmRzPTYwKToKICAgICAgICBzZWxmLl9kdXJhdGlvbihzZWNvbmRzKQogICAgICAgIHdpdGggc2VsZi50eCgpOgogICAgICAgICAgICBzZWxmLl9vd25lZCh0YXNrX2lkLCB0b2tlbikKICAgICAgICAgICAgc2VsZi5kYi5leGVjdXRlKCdVUERBVEUgdGFza3MgU0VUIGV4cGlyZXM9PyBXSEVSRSBpZD0/JywgKHNlbGYuY2xvY2soKStzZWNvbmRzLCB0YXNrX2lkKSkKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAncmVuZXdlZCcpCgogICAgZGVmIGZpbmlzaChzZWxmLCB0YXNrX2lkLCB0b2tlbiwgcmVjZWlwdCk6CiAgICAgICAgZm9yIGtleSBpbiAoJ3Rlc3RfY29tbWFuZCcsICd0ZXN0X3Jlc3VsdCcsICdhcnRpZmFjdF9yZWYnKToKICAgICAgICAgICAgaWYgbm90IGlzaW5zdGFuY2UocmVjZWlwdC5nZXQoa2V5KSwgc3RyKSBvciBub3QgcmVjZWlwdFtrZXldLnN0cmlwKCk6CiAgICAgICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKGtleSkKICAgICAgICBpZiBub3QgcmUuZnVsbG1hdGNoKHInc2hhMjU2OlswLTlhLWZdezY0fXxnaXQ6WzAtOWEtZl17NDB9JywgcmVjZWlwdFsnYXJ0aWZhY3RfcmVmJ10pOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCdpbW11dGFibGUgYXJ0aWZhY3RfcmVmIHJlcXVpcmVkJykKICAgICAgICBpZiB0eXBlKHJlY2VpcHQuZ2V0KCdleGl0X2NvZGUnKSkgaXMgbm90IGludCBvciByZWNlaXB0WydleGl0X2NvZGUnXSAhPSAwOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCdzdWNjZXNzZnVsIHRlc3QgZXhpdCBjb2RlIHJlcXVpcmVkJykKICAgICAgICB3aXRoIHNlbGYudHgoKToKICAgICAgICAgICAgcm93ID0gc2VsZi5fb3duZWQodGFza19pZCwgdG9rZW4pCiAgICAgICAgICAgIHJlY29yZGVkID0geyoqcmVjZWlwdCwgJ2lucHV0X3JlZic6IHJvd1snc3BlYyddWydpbnB1dF9yZWYnXSwgJ2F0dGVtcHQnOiByb3dbJ2F0dGVtcHRzJ10sICd3b3JrZXInOiByb3dbJ3dvcmtlciddfQogICAgICAgICAgICBzZWxmLl9yZWxlYXNlKHRhc2tfaWQsICdzdWNjZWVkZWQnLCByZWNvcmRlZCkKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAnc3VjY2VlZGVkJywgcmVjb3JkZWQpCgogICAgZGVmIGZhaWwoc2VsZiwgdGFza19pZCwgdG9rZW4sIHJlYXNvbik6CiAgICAgICAgaWYgbm90IGlzaW5zdGFuY2UocmVhc29uLCBzdHIpIG9yIG5vdCByZWFzb24uc3RyaXAoKToKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignZmFpbHVyZSByZWFzb24gcmVxdWlyZWQnKQogICAgICAgIHdpdGggc2VsZi50eCgpOgogICAgICAgICAgICByb3cgPSBzZWxmLl9vd25lZCh0YXNrX2lkLCB0b2tlbikKICAgICAgICAgICAgc3RhdGUgPSAnZmFpbGVkJyBpZiByb3dbJ2F0dGVtcHRzJ10gPj0gcm93WydtYXhfYXR0ZW1wdHMnXSBlbHNlICdxdWV1ZWQnCiAgICAgICAgICAgIHNlbGYuX3JlbGVhc2UodGFza19pZCwgc3RhdGUpCiAgICAgICAgICAgIHNlbGYuZXZlbnQodGFza19pZCwgJ2F0dGVtcHRfZmFpbGVkJywgeydyZWFzb24nOiByZWFzb24sICduZXh0Jzogc3RhdGV9KQoKICAgIGRlZiBjYW5jZWwoc2VsZiwgdGFza19pZCk6CiAgICAgICAgd2l0aCBzZWxmLnR4KCk6CiAgICAgICAgICAgIGlmIHNlbGYuZ2V0KHRhc2tfaWQpWydzdGF0ZSddIG5vdCBpbiAoJ3F1ZXVlZCcsICdydW5uaW5nJyk6CiAgICAgICAgICAgICAgICByZXR1cm4gRmFsc2UKICAgICAgICAgICAgc2VsZi5fcmVsZWFzZSh0YXNrX2lkLCAnY2FuY2VsbGVkJykKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAnY2FuY2VsbGVkJykKICAgICAgICAgICAgcmV0dXJuIFRydWUKCiAgICBkZWYgcGF1c2Uoc2VsZiwgcGF1c2VkPVRydWUpOgogICAgICAgIGlmIHR5cGUocGF1c2VkKSBpcyBub3QgYm9vbDoKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignYm9vbCByZXF1aXJlZCcpCiAgICAgICAgd2l0aCBzZWxmLnR4KCk6CiAgICAgICAgICAgIHNlbGYuZGIuZXhlY3V0ZSgnVVBEQVRFIGNvbnRyb2wgU0VUIHBhdXNlZD0/IFdIRVJFIGlkPTEnLCAoaW50KHBhdXNlZCksKSkKICAgICAgICAgICAgc2VsZi5ldmVudChOb25lLCAncGF1c2VkJyBpZiBwYXVzZWQgZWxzZSAncmVzdW1lZCcpCgogICAgZGVmIGhpc3Rvcnkoc2VsZiwgdGFza19pZCk6CiAgICAgICAgcmV0dXJuIFtkaWN0KHJvdykgZm9yIHJvdyBpbiBzZWxmLmRiLmV4ZWN1dGUoJ1NFTEVDVCAqIEZST00gZXZlbnRzIFdIRVJFIHRhc2tfaWQ9PyBPUkRFUiBCWSBzZXEnLCAodGFza19pZCwpKV0K", "seed.py": "aW1wb3J0IHN0cnVjdAoKZGVmIHNlZWRfaXNvKHVzZXIsIG1ldGEpOgogICAgIiIiQnVpbGQgYSBzbWFsbCBmaXhlZCBJU085NjYwL1JvY2sgUmlkZ2UgTm9DbG91ZCBpbWFnZSwgbm8gZXh0ZXJuYWwgdG9vbHMuIiIiCiAgICBibG9jayA9IDIwNDgKICAgIGRlZiBib3RoKG4sIHNpemUpOgogICAgICAgIHJldHVybiBuLnRvX2J5dGVzKHNpemUsICdsaXR0bGUnKSArIG4udG9fYnl0ZXMoc2l6ZSwgJ2JpZycpCiAgICBkZWYgcmVjb3JkKG5hbWUsIGV4dGVudCwgbGVuZ3RoLCBkaXJlY3Rvcnk9RmFsc2UsIHN1PWInJyk6CiAgICAgICAgZGF0YSA9IChiJ1wwXDAnICsgYm90aChleHRlbnQsIDQpICsgYm90aChsZW5ndGgsIDQpICsKICAgICAgICAgICAgICAgIGJ5dGVzKFsxMjYsIDEsIDEsIDAsIDAsIDAsIDAsIDIgaWYgZGlyZWN0b3J5IGVsc2UgMCwgMCwgMF0pICsKICAgICAgICAgICAgICAgIGJvdGgoMSwgMikgKyBieXRlcyhbbGVuKG5hbWUpXSkgKyBuYW1lKQogICAgICAgIGlmIGxlbihuYW1lKSAlIDIgPT0gMDoKICAgICAgICAgICAgZGF0YSArPSBiJ1wwJwogICAgICAgIGRhdGEgKz0gc3UKICAgICAgICByZXR1cm4gYnl0ZXMoW2xlbihkYXRhKV0pICsgZGF0YVsxOl0KICAgIGRlZiBubShuYW1lKToKICAgICAgICByZXR1cm4gYidOTScgKyBieXRlcyhbNSArIGxlbihuYW1lKSwgMSwgMF0pICsgbmFtZQogICAgZmlsZXMgPSBbKGInTUVUQV9EQVQuOzEnLCBiJ21ldGEtZGF0YScsIG1ldGEpLCAoYidVU0VSX0RBVC47MScsIGIndXNlci1kYXRhJywgdXNlcildCiAgICBlbnRyaWVzID0gW10KICAgIGVuZCA9IDIxCiAgICBmb3IgaXNvLCByciwgZGF0YSBpbiBmaWxlczoKICAgICAgICBlbnRyaWVzLmFwcGVuZCgoaXNvLCByciwgZGF0YSwgZW5kKSkKICAgICAgICBlbmQgKz0gbWF4KDEsIChsZW4oZGF0YSkgKyBibG9jayAtIDEpIC8vIGJsb2NrKQogICAgZW5kID0gbWF4KGVuZCwgMTUwKQogICAgaW1hZ2UgPSBieXRlYXJyYXkoZW5kICogYmxvY2spCiAgICBkZWYgcHV0KGxiYSwgZGF0YSk6CiAgICAgICAgaW1hZ2VbbGJhKmJsb2NrOmxiYSpibG9jaytsZW4oZGF0YSldID0gZGF0YQogICAgcm9vdCA9IHJlY29yZChiJ1wwJywgMjAsIGJsb2NrLCBUcnVlKQogICAgcHZkID0gYnl0ZWFycmF5KGJsb2NrKQogICAgcHZkWzo3XSA9IGInXHgwMUNEMDAxXHgwMScKICAgIHB2ZFs4OjQwXSA9IGInUEhBTlRPTVRST05JWCcubGp1c3QoMzIsIGInICcpCiAgICBwdmRbNDA6NzJdID0gYidDSURBVEEnLmxqdXN0KDMyLCBiJyAnKQogICAgcHZkWzgwOjg4XSA9IGJvdGgoZW5kLCA0KQogICAgcHZkWzEyMDoxMjRdID0gYm90aCgxLCAyKQogICAgcHZkWzEyNDoxMjhdID0gYm90aCgxLCAyKQogICAgcHZkWzEyODoxMzJdID0gYm90aChibG9jaywgMikKICAgIHB2ZFsxMzI6MTQwXSA9IGJvdGgoMTAsIDQpCiAgICBwdmRbMTQwOjE0NF0gPSBzdHJ1Y3QucGFjaygnPEknLCAxOCkKICAgIHB2ZFsxNDg6MTUyXSA9IHN0cnVjdC5wYWNrKCc+SScsIDE5KQogICAgcHZkWzE1NjoxOTBdID0gcm9vdAogICAgcHZkWzE5MDo4MTNdID0gYicgJyAqIDYyMwogICAgZm9yIG9mZnNldCBpbiAoODEzLCA4MzAsIDg0NywgODY0KToKICAgICAgICBwdmRbb2Zmc2V0Om9mZnNldCsxN10gPSBiJzAnKjE2ICsgYidcMCcKICAgIHB2ZFs4ODFdID0gMQogICAgcHV0KDE2LCBwdmQpCiAgICBwdXQoMTcsIGInXHhmZkNEMDAxXHgwMScpCiAgICBwdXQoMTgsIHN0cnVjdC5wYWNrKCc8QkJJSEJCJywgMSwgMCwgMjAsIDEsIDAsIDApKQogICAgcHV0KDE5LCBzdHJ1Y3QucGFjaygnPkJCSUhCQicsIDEsIDAsIDIwLCAxLCAwLCAwKSkKICAgIHNwID0gYidTUFx4MDdceDAxXHhiZVx4ZWZceDAwJwogICAgZXIgPSBiJ0VSXHgxMlx4MDFceDBhXHgwMFx4MDBceDAxUlJJUF8xOTkxQScKICAgIGRpcmVjdG9yeSA9IHJlY29yZChiJ1wwJywgMjAsIGJsb2NrLCBUcnVlLCBzcCtlcikgKyByZWNvcmQoYidcMScsIDIwLCBibG9jaywgVHJ1ZSkKICAgIGZvciBpc28sIHJyLCBkYXRhLCBsYmEgaW4gZW50cmllczoKICAgICAgICBkaXJlY3RvcnkgKz0gcmVjb3JkKGlzbywgbGJhLCBsZW4oZGF0YSksIHN1PW5tKHJyKSkKICAgICAgICBwdXQobGJhLCBkYXRhKQogICAgYXNzZXJ0IGxlbihkaXJlY3RvcnkpIDw9IGJsb2NrCiAgICBwdXQoMjAsIGRpcmVjdG9yeSkKICAgIHJldHVybiBieXRlcyhpbWFnZSkK"};
const dh017ReceiptSource="\nimport hashlib,json,sys,zipfile\nfrom pathlib import Path\nfrom datetime import datetime,timezone\nstate=Path(sys.argv[1]);out=Path(sys.argv[2]);files={}\nfor n in ('approval.json','live-decision-reserved.json','dispatch.json','provider-result.json','decision.json','machine-result.json','tool-result.json','failure.json'):\n p=state/n\n if p.is_file() and not p.is_symlink() and p.stat().st_size<=65536:files[n]=p.read_bytes()\nif 'machine-result.json' in files:\n j=json.loads(files['machine-result.json'])\n p=Path(j.get('receipt_path') or '/nonexistent').resolve()\n root=(Path.home()/'.local/share/phantomtronix-development-host/receipts').resolve()\n if p.parent==root and p.is_file() and p.stat().st_size<1048576:\n  with zipfile.ZipFile(p) as z:\n   assert z.testzip() is None\n   rows=z.read('SHA256SUMS').decode().splitlines()\n   for row in rows:\n    h,n=row.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h\n  files['MACHINE.zip']=p.read_bytes()\nfiles['RECEIPT.json']=json.dumps({'round':'017-LIVE','status':'REVIEW_REQUIRED','provider_dispatch_recorded':'dispatch.json' in files,'machine_receipt_present':'MACHINE.zip' in files}).encode()\nfiles['SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\\n' for n,b in sorted(files.items())).encode()\nout.mkdir(exist_ok=True)\np=out/('CLINK.RETURN.DEVELOPMENT-HOST.LIVE.'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.zip')\nwith zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:\n for n,b in files.items():z.writestr(n,b)\nprint(p)\n";
const developmentAcceptance=dh017.integration.createInstalledIntegration({
 stateDir:dh017State,bundle:dh017Runner,
 approve:async()=>{
   if(!windowMain||windowMain.isDestroyed())return false;
   const r=await dialog.showMessageBox(windowMain,{type:'question',title:'Development Host — one-use acceptance',
     message:'Allow Miss Flower to create and test the Python calculator?',
     detail:'One OpenAI request, estimated maximum $0.02 (not a provider billing cap). No automatic retry. The isolated Development Host VM executes the fixed calculator workflow. Ctrl+Shift+X cancels.',
     buttons:['Cancel','Authorize once'],defaultId:0,cancelId:0,noLink:true});
   return r.response===1;
 },
 runnerFactory:(dir,progress)=>{
   fs.mkdirSync(dir,{mode:0o700});
   for(const [name,data] of Object.entries(dh017Embedded))fs.writeFileSync(path.join(dir,name),Buffer.from(data,'base64'),{mode:0o600,flag:'wx'});
   return dh017.tool.createVmRunner(dir,progress);
 },
 progress:message=>{
   try{
     log('development.acceptance.progress',{message:String(message).slice(0,160)});
     if(windowMain&&!windowMain.isDestroyed()){
       const done=message==='Development acceptance finished.';
       windowMain.setProgressBar(done?-1:2);
       windowMain.setTitle(done?dh017OriginalTitle:'C.Link — Development Host active (Ctrl+Shift+X cancels)');
     }
   }catch(_){}
 },
 publish:dir=>new Promise((resolve,reject)=>{
   cp.execFile('/usr/bin/python3',['-B','-c',dh017ReceiptSource,dir,app.getPath('downloads')],{timeout:20000,env:{PATH:'/usr/bin:/bin',HOME:os.homedir(),LANG:'C.UTF-8'}},(err,stdout)=>{
     if(err)return reject(Error('DEVELOPMENT_RECEIPT_EXPORT_FAILED'));
     log('development.acceptance.receipt',{path:String(stdout).trim()});resolve();
   });
 })
});


const dh025Module=(()=>{const module={exports:{}};const exports=module.exports;
'use strict';
// DH025: exact prior live decision recovery, no provider call or synthetic model reply.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os');
const PRIOR=Object.freeze({
 'approval.json':'3eeec7ec07093986cf2f53e7cf661ce3d3dcfc98103e557c46712c417786e2a9',
 'decision.json':'0fbd4943b58d0d2885f10e8d74ddd2b4fd72df9bfee9f795385dd73a36110df3',
 'dispatch.json':'36ea9fd312d07532093d52daee72f4e4cbbc97eade601d38594ffa9650edc250',
 'failure.json':'a0ac6ab353cd085ae16f77ab9f66a8eadbd68dc93e6de861e3a1abd56c562679',
 'live-decision-reserved.json':'b5b09b4d2fe7d8c80a71db769b9081cfbdcc936dd726aa4cf351afb1d03fab73',
 'provider-result.json':'3f7c91b5ae6cc05376791b6c2148582313786e9a21405a280eb8657cf6231b80'
});
const RUNNER=Object.freeze({
 'development_guest_008.py':'24db50fb9d7c493740067f9dd72dd9d07fe39b285d26d5da74b131c1a8b2d633',
 'development_smoke.py':'7e7ed93df0ae9c63f8e888b9cf63a3978c0cf7c36172a41461bfeccba1d90842',
 'task_engine.py':'f5b80ae5c1fa284bf5fc95f8b33b2f0fb77a6a6be1d2ec878522ce6c5add53bd',
 'seed.py':'32b8ccb44e16b8b4c816187572d9ce40a3accc52219c90972370b5dfbc166cf0'
});
function need(ok,code){if(!ok)throw Error(code);}
function privateDir(p){const s=fs.lstatSync(p);need(s.isDirectory()&&!s.isSymbolicLink()&&s.uid===process.getuid()&&!(s.mode&0o077),'DH025_UNSAFE_DIRECTORY');}
function verify(p,h){const s=fs.lstatSync(p);need(s.isFile()&&!s.isSymbolicLink()&&s.nlink===1&&s.uid===process.getuid()&&!(s.mode&0o077)&&s.size<65536,'DH025_UNSAFE_FILE');need(crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')===h,'DH025_EVIDENCE_DRIFT');}
function syncdir(p){const fd=fs.openSync(p,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
function write(p,v){const fd=fs.openSync(p,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(v)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}syncdir(path.dirname(p));}
function safeCode(e){const m=String(e?.message||'');return /^[A-Z][A-Z0-9_]{1,80}$/.test(m)?m:'DH025_UNCLASSIFIED';}
const CANCELLED=Object.freeze({"approval.json": "1b5fcf3166dd1470e4e86e15e2974e02573fa232c8321683e97fc7ca3766b1a3", "decision.json": "ac7f6340381ae502ec97f187f410040507e35cd74936a89ab149b4ad2fdfb2bd", "machine-result.json": "7beae09b14f42c75e6e7f49f3a8dcfd9ff791b15ba819d3aa87f2d04457eceab", "failure.json": "9e561720c9d6d4794b1cf4527ed78f183fdc41abc67426fe782c90f0b914f85b"});
const MACHINE_PIN='b786320f5d169e6987659e20ab2f6972dd64d40c3b5369ea7ab925b91ab4c51d';
const CANCELLED_MACHINE='CLINK.RETURN.DEVELOPMENT-HOST.008.20261126T052417055256Z.zip';
function assertNoGuest(runner,root){
 // Conservative process inventory: no second known Development Host runner or guest.
 for(const name of fs.readdirSync('/proc')){
  if(!/^\d+$/.test(name)||Number(name)===process.pid)continue;
  const p=path.join('/proc',name);
  try{
   if(fs.statSync(p).uid!==process.getuid())continue;
   const argv=fs.readFileSync(path.join(p,'cmdline')).toString().split('\0');
   const exe=path.basename(argv[0]||'');
   const isRunner=argv.some(a=>a===path.join(runner,'development_guest_008.py')||path.basename(a)==='development_guest_008.py');
   const isGuest=/^qemu-system-/.test(exe)&&argv.some(a=>a.includes(root+'/job-008-'));
   need(!isRunner&&!isGuest,'DH039_GUEST_STILL_ACTIVE');
  }catch(e){if(e.code==='ENOENT'||e.code==='ESRCH')continue;throw e;}
 }
}
function createRecovery({prior,normal,eligible,approve,runnerFactory,progress=()=>{},publish,guestRoot=path.join(os.homedir(),'.local/share/phantomtronix-development-host'),checkGuest=assertNoGuest}){
 const previous=path.join(prior,'resume-025'),runner=path.join(prior,'runner');let active=null;
 async function handle(req){
  const text=typeof req.text==='string'?req.text.trim():'';
  const explicit=/^\/development retry$/i.test(text)||/^Miss Flower,? please retry the cancelled calculator assignment[.!]?$/i.test(text);
    if(!explicit&&!/^\/development resume$/i.test(text)&&(!eligible(req.text)||!fs.existsSync(prior)))return normal.handle(req);
  const dir=explicit?path.join(prior,'retry-039'):previous;
  if(active)return {text:'C.Link: Offline recovery already active.'};
  if(fs.existsSync(dir))return {text:'C.Link: Offline recovery already reserved. Inspect its receipt; no provider request occurred.'};
  if(!fs.existsSync(prior))return {text:'C.Link: No prior accepted development decision exists. No provider request occurred.'};
  const job={cancelled:false,owned:false,vm:null,cancelReason:null,dir};active=job;let stage='VERIFY_PRIOR';
  function check(){need(!job.cancelled,'DEVELOPMENT_CANCELLED');req.authorize();}
  try{
   privateDir(prior);privateDir(runner);
   for(const [n,h] of Object.entries(PRIOR))verify(path.join(prior,n),h);
   for(const [n,h] of Object.entries(RUNNER))verify(path.join(runner,n),h);
   need(!fs.existsSync(path.join(prior,'machine-result.json'))&&!fs.existsSync(path.join(prior,'tool-result.json')),'DH025_PRIOR_OUTCOME_EXISTS');
   if(explicit){stage='VERIFY_CANCELLED_ATTEMPT';privateDir(previous);
   for(const [n,h] of Object.entries(CANCELLED))verify(path.join(previous,n),h);
   need(!fs.existsSync(path.join(previous,'tool-result.json')),'DH039_PRIOR_SUCCESS_EXISTS');
   const priorMachine=JSON.parse(fs.readFileSync(path.join(previous,'machine-result.json'),'utf8'));
   const receipt=path.join(guestRoot,'receipts',CANCELLED_MACHINE);
   need(priorMachine.status==='CANCELLED'&&priorMachine.provider_calls===0&&priorMachine.artifact_sha256===null&&priorMachine.receipt_path===receipt,'DH039_CANCELLED_RECEIPT_MISMATCH');
   privateDir(guestRoot);privateDir(path.join(guestRoot,'receipts'));verify(receipt,MACHINE_PIN);}
   stage='CHECK_NO_SURVIVING_GUEST';checkGuest(runner,guestRoot);
   stage='INITIAL_SCOPE';check();
   stage='LOCAL_APPROVAL';if(!await approve(explicit))return {text:'C.Link: Offline recovery declined. No provider request occurred.'};
   stage='POST_APPROVAL_SCOPE';check();
   stage='CHECK_NO_SURVIVING_GUEST';checkGuest(runner,guestRoot);
   stage='RESERVE_RETRY';fs.mkdirSync(dir,{mode:0o700});job.owned=true;syncdir(prior);
   write(path.join(dir,'approval.json'),{workflow:'development.smoke.v1',mode:explicit?'offline-cancelled-retry':'offline-recovery',...(explicit?{cancelledReceiptSha256:MACHINE_PIN}:{}),priorDecisionSha256:PRIOR['decision.json'],priorReservationSha256:PRIOR['live-decision-reserved.json'],humanAuthorized:true,provider_calls:0});
   stage='CREATE_RUNNER';job.vm=runnerFactory(runner,progress);
   stage='PRE_EXECUTION_SCOPE';check();
   stage='CHECK_NO_SURVIVING_GUEST';checkGuest(runner,guestRoot);
   stage='RUN_VM';write(path.join(dir,'decision.json'),{priorDecisionVerified:true,providerCallsThisAttempt:0,executionStarted:true});
   progress('Offline recovery executing the previously approved calculator workflow.');
   const result=await job.vm.run();
   write(path.join(dir,'machine-result.json'),{status:result.status,artifact_sha256:result.artifact_sha256||null,provider_calls:result.provider_calls,receipt_path:result.receipt_path||null});
   if(result.status==='CANCELLED'){stage='RUN_VM';throw Error('DEVELOPMENT_CANCELLED');}
   stage='VERIFY_RESULT';need(result.status==='PASS'&&/^[a-f0-9]{64}$/.test(result.artifact_sha256||'')&&result.provider_calls===0,'DH025_MACHINE_NOT_ACCEPTED');
   stage='FINAL_SCOPE';check();
   write(path.join(dir,'tool-result.json'),{receiptReturned:true,artifact_sha256:result.artifact_sha256});
   return {text:'C.Link verified offline recovery: Two checks passed. Artifact SHA-256: '+result.artifact_sha256+'. New provider calls: 0.',receipt:result};
  }catch(e){
   const code=safeCode(e);
   if(job.owned){try{write(path.join(dir,'failure.json'),{stage,code,cancellationReason:job.cancelReason||(code==='DEVELOPMENT_CANCELLED'?'EXTERNAL_OR_UNOBSERVED':null)});}catch(_){}}
   return {text:'C.Link: Offline recovery stopped at '+stage+' ('+code+'). No new provider request occurred.'};
  }finally{
   if(job.owned){try{await publish(dir);}catch(_){progress('Offline recovery receipt export failed; local evidence preserved.');}}
   active=null;progress('Development acceptance finished.');
  }
 }
 function cancel(reason='UNSPECIFIED_NATIVE_CANCEL'){
  if(!active)return false;
  if(!active.cancelled){
   active.cancelled=true;active.cancelReason=['KEYBOARD_CANCEL','CARTRIDGE_CLOSED','APPLICATION_QUIT','OS_SIGTERM','OS_SIGINT','UNSPECIFIED_NATIVE_CANCEL'].includes(reason)?reason:'UNSPECIFIED_NATIVE_CANCEL';
   if(active.owned){try{write(path.join(active.dir,'cancellation-request.json'),{reason:active.cancelReason,at:new Date().toISOString()});}catch(_){}}
   progress('Cancellation requested: '+active.cancelReason+'. Waiting for the guest to stop.');
   try{active.vm?.cancel();}catch(_){}
  }
  return true;
 }
 return Object.freeze({handle,cancel});
}
module.exports={createRecovery,assertNoGuest};

return module.exports;})();
const dh039RenderProgress=(text,done)=>{
 const id='clink-native-development-progress-039';let el=document.getElementById(id);
 if(done){if(el)el.remove();return;}
 if(!el){el=document.createElement('div');el.id=id;el.setAttribute('role','status');el.setAttribute('aria-live','polite');
 Object.assign(el.style,{position:'fixed',top:'3px',left:'180px',right:'8px',height:'52px',boxSizing:'border-box',zIndex:'2147483647',background:'#102922',border:'1px solid #86f7b2',color:'#d6ffe3',padding:'5px 10px',font:'bold 12px monospace',lineHeight:'18px',whiteSpace:'normal',overflow:'hidden',pointerEvents:'none'});
 document.body.appendChild(el);}
 el.textContent=text;
};
let dh039ProgressTimer=null,dh039Started=0,dh039Status='';
const dh025Progress=message=>{
 try{
 const raw=String(message);const done=raw==='Development acceptance finished.';
 log('development.acceptance.progress',{message:raw.slice(0,160)});
 if(done){if(dh039ProgressTimer)clearInterval(dh039ProgressTimer);dh039ProgressTimer=null;dh039Started=0;}
 else{
 if(!dh039Started)dh039Started=Date.now();
 if(/Cancellation requested:/.test(raw))dh039Status='Cancelling — waiting for guest shutdown';
 else if(/Guest active:/.test(raw))dh039Status='Isolated Ubuntu guest running — allow up to 10 minutes';
 else if(/Starting isolated guest/.test(raw))dh039Status='Starting isolated Ubuntu guest';
 else if(/Verifying cached Ubuntu image/.test(raw))dh039Status='Verifying cached Ubuntu image';
 else if(/DEVELOPMENT HOST 008:/.test(raw))dh039Status='Guest returned — verifying result and exporting receipt';
 else if(!dh039Status)dh039Status='Preparing offline calculator assignment';
 }
 const render=()=>{
  if(!windowMain||windowMain.isDestroyed())return;
  const wc=windowMain.webContents,local=require('node:url').pathToFileURL(path.join(__dirname,'renderer','index.html')).href;
  if(wc.isDestroyed()||wc.getURL().split(/[?#]/)[0]!==local)return;
  const elapsed=Math.floor((Date.now()-dh039Started)/1000);
  const text='DEVELOPMENT HOST · '+dh039Status+' · '+elapsed+'s · No API request · Ctrl+Shift+X cancels';
  void wc.executeJavaScript('('+dh039RenderProgress.toString()+')('+JSON.stringify(text)+','+JSON.stringify(done)+')',false).catch(()=>{});
 };
 if(windowMain&&!windowMain.isDestroyed()){windowMain.setProgressBar(done?-1:2);windowMain.setTitle(done?dh017OriginalTitle:'C.Link — Offline Development Host active');}
 render();if(done)dh039Status='';else if(!dh039ProgressTimer)dh039ProgressTimer=setInterval(render,1000);
 }catch(_){}
};
const dh025Recovery=dh025Module.createRecovery({
 prior:dh017State,normal:developmentAcceptance.developmentTool,eligible:dh017.tool.eligible,
 approve:async(retry)=>{
   if(!windowMain||windowMain.isDestroyed())return false;
   const r=await dialog.showMessageBox(windowMain,{type:'question',title:'Development Host — offline recovery',
    message:retry?'Retry the confirmed cancelled calculator assignment?':'Resume the previously accepted calculator assignment?',
    detail:'This is one offline execution of the recorded decision. Keep Command open; progress appears in the top bar. Allow up to 10 minutes. No new API request. Ctrl+Shift+X cancels.',
    buttons:['Cancel',retry?'Retry offline':'Resume offline'],defaultId:0,cancelId:0,noLink:true});
   return r.response===1;
 },
 runnerFactory:(dir,progress)=>dh017.tool.createVmRunner(dir,progress),
 progress:dh025Progress,
 publish:dir=>new Promise((resolve,reject)=>{
   const source=dh017ReceiptSource.replace("'017-LIVE'","'039-RETRY'").replace("'tool-result.json','failure.json'","'tool-result.json','failure.json','cancellation-request.json'");
   cp.execFile('/usr/bin/python3',['-B','-c',source,dir,app.getPath('downloads')],{timeout:20000,env:{PATH:'/usr/bin:/bin',HOME:os.homedir(),LANG:'C.UTF-8'}},(err,stdout)=>{
      if(err)return reject(Error('DEVELOPMENT_RECEIPT_EXPORT_FAILED'));
      log('development.acceptance.receipt',{path:String(stdout).trim()});resolve();
   });
 })
});

const providerAdapters = new ProviderAdapterRegistry({transport:developmentAcceptance.transport,secretStore:providerSecrets,usageLedger:apiUsage,defaultUsageContext:{companionId:'clink-system',missionId:MISSION,workerId:null,purpose:'api_request'},logger:log});
const universalCompanion = new UniversalCompanionPrimary({adapterRegistry:providerAdapters,backpackManager,missionId:MISSION,logger:log});
const companionTurnSeat = new CompanionTurnSeat({primary:universalCompanion,backpackManager});
if(!activationColdRecovery.ok)companionTurnSeat.disable('STARTUP_ACTIVATION_RECOVERY_FAILED');
const contextBuilder = new CompanionContextBuilder({profileRoot:PROFILE_ROOT,seed:COMPANION_STORE_SEED,bootId:TERMINAL_SESSION_ID,logger:log});
const contextBuilderBootState = contextBuilder.initialize();
function alphaShadowRunner(){return new AlphaShadowRunner({adapterRegistry:providerAdapters,context:contextBuilder.build(),usageContext:{companionId:'alpha007',missionId:MISSION,workerId:null,purpose:'alpha_reasoning'},logger:log});}
function alphaPrimaryRunner(){return new AlphaPrimaryRunner({adapterRegistry:providerAdapters,contextBuilder,bootId:TERMINAL_SESSION_ID,missionId:MISSION,logger:log});}
const apiPrimarySoak = new ApiPrimarySoak({profileRoot:PROFILE_ROOT,bootId:TERMINAL_SESSION_ID,contextFingerprint:contextBuilderBootState.contextFingerprint,logger:log});
const readOnlyWorkers = new ReadOnlyWorkerExperiment({profileRoot:PROFILE_ROOT,adapterRegistry:providerAdapters,contextBuilder,usageLedger:apiUsage,missionId:R8_MISSION,logger:log});
const round9 = new Round9Reconciliation({profileRoot:PROFILE_ROOT,adapterRegistry:providerAdapters,contextBuilder,usageLedger:apiUsage,r8Experiment:readOnlyWorkers,bootId:TERMINAL_SESSION_ID,missionId:MISSION,logger:log});
let alphaRecentTurns=[];
function primaryTransportReady(){
  const status=providerSecrets.status('openai');
  return status.configured===true&&status.storage==='SECURE_OS_USER';
}
function grokUserCompanionReady(){
  const status=providerSecrets.status('xai');
  return status.configured===true&&status.storage==='SECURE_OS_USER'&&status.state==='READY';
}
function grokUserCompanionSnapshot(extra={}){
  return {
    schema:'CLINK_GROK_USER_COMPANION_SHADOW_V1',
    status:grokUserCompanionReady()?'READY':'NOT_CONFIGURED',
    mode:'EXPLICIT_SHADOW_COMMAND',provider:'xai',model:'grok-4.3',
    companionId:String(backpackManager.snapshot()?.userCompanion?.id||''),
    continuityAuthority:'USER_COMPANION_BACKPACK',providerConversationAuthority:false,persistProviderSessionIds:false,
    technicalRelay:'HOSTED_SPECIALIST_TABS',repairExecution:'OFF',defaultRoutingChanged:false,
    ...extra
  };
}
function apiPrimarySnapshot(extra={}){
  const status=primaryTransportReady()?'READY':'NOT_CONFIGURED';
  return {
    schema:'CLINK_API_PRIMARY_STATE_V1',status,mode:'API_PRIMARY',provider:'openai',model:'gpt-5.6-luna',
    continuityAuthority:'CLINK_BACKPACK',providerConversationAuthority:false,persistProviderSessionIds:false,
    humanSurface:'CLINK_TERMINAL',hostedBrowser:'FALLBACK',repairExecution:'OFF',bootId:TERMINAL_SESSION_ID,
    contextFingerprint:contextBuilder.snapshot().contextFingerprint,soak:apiPrimarySoak.snapshot(),...extra
  };
}

const packageStore = new RelayPackageStore({ profileRoot:PROFILE_ROOT, logger:log });
function relayLog(event, data = {}) {
  log(event,data);
  clearTimeout(broadcastTimer);
  broadcastTimer = setTimeout(() => broadcast(), 25);
}
const relay = new AgentRelay({ admissionGate:admitRepairProposal, packageStore, logger:relayLog });

let a007HostedFieldProbeStarted=false;
const A007_HOSTED_FIELD_PROBE=process.env.CLINK_A007_HOSTED_FIELD_PROBE==='1';
let a007GrokFieldProbeStarted=false;
const A007_GROK_FIELD_PROBE=process.env.CLINK_A007_GROK_FIELD_PROBE==='1';

const coreState = {
  build:BUILD,
  mission:MISSION,
  core:{status:'BOOTING',detail:'Vanilla Terminal core is starting.'},
  repair:{status:'READY',detail:'Browser-owned reasoning is active; repair execution is OFF.',mode:'BROWSER_CONTROL_EXECUTION_DISABLED'},
  panels:{
    status:'NOT_STARTED',attempt:0,quarantined:false,detail:'PANELS OS has not started.',plugins:[],
    providerProbe:{status:'R28B_PRIMARY_OPERATING_SURFACE',detail:'R27A2 field-proven browser/auth baseline preserved; Core owns provider workspace/chat lifecycle and six canonical slots.'},
    providerRuntime:{}
  },
  companion:bootstrapBackpackState.userCompanion?{status:'DISCOVERED',detail:'Companion is waiting for lifecycle.'}:{status:'NO_COMPANION_LOADED',detail:'Load and activate a canonical backpack in Settings > Companions.'},
  companionCore:companionOrchestrator.snapshot(),
  providerLifecycle:{status:'NOT_STARTED',detail:'C.LINK REASONING provider workspace lifecycle has not synchronized yet.',progress:null,lastError:''},
  inlineAuth:{status:'IDLE',detail:'Hosted provider authentication is not active.',url:'',title:''},
  messageQualification:restoredQualification(),
  apiProviders:{mode:'API_PRIMARY_OPENAI_WITH_HOSTED_FALLBACK',round:9,storage:'MAIN_PROCESS_SAFE_STORAGE',primaryProvider:'openai',browserFallback:'HOSTED_CHATGPT_WEB_MANUAL',rounds1to8Field:'PASS',adapters:providerAdapters.defaults()},
  apiPrimary:apiPrimarySnapshot({fieldStatus:'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status}),
  apiWorkers:{...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD},
  round9:round9.snapshot(),
  apiShadow:{status:'FIELD_PROVEN_R4D',detail:API_R4_FIELD.detail,provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null},
  grokUserCompanion:grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:null}),
  apiContext:{...contextBuilderBootState,fieldEvidence:API_R5_FIELD,reconstruction:{status:'FIELD_PROVEN_R5',detail:'Round 5 restart and reconstruction are field-proven.',...API_R5_FIELD.reconstruction}},
  apiUsage:apiUsage.summary(),
  relay:relay.snapshot()
};

function snapshot() {
  coreState.dualBackpacks=backpackManager.snapshot();
  coreState.relay = relay.snapshot();
  coreState.companionCore = companionOrchestrator.snapshot();
  coreState.apiUsage = apiUsage.summary();
  coreState.apiWorkers = {...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD};
  coreState.round9 = round9.snapshot();
  coreState.apiPrimary = apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null,fieldStatus:coreState.apiPrimary?.fieldStatus||'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status});
  coreState.grokUserCompanion = grokUserCompanionSnapshot({fieldStatus:coreState.grokUserCompanion?.fieldStatus||'SHADOW_FIELD_PENDING',lastTurn:coreState.grokUserCompanion?.lastTurn||null});
  return JSON.parse(JSON.stringify(coreState));
}
function broadcast() {
  if (windowMain && !windowMain.isDestroyed()) windowMain.webContents.send('clink:state-changed', snapshot());
}
function refreshCompanionState() {
  const apiReady=primaryTransportReady();
  const hostedProvider=(coreState.panels.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  coreState.apiPrimary=apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null,fieldStatus:coreState.apiPrimary?.fieldStatus||'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status});
  const hostedReady=coreState.providerLifecycle?.status==='READY';
  coreState.companion={
    status:(apiReady||hostedReady)?'READY':'DEGRADED',
    detail:apiReady
      ? `Companion API PRIMARY is ready through OpenAI; hosted browser is FALLBACK. Hosted lifecycle=${coreState.providerLifecycle?.status||'NOT_STARTED'}; repair execution OFF.`
      : (hostedReady
        ? 'Hosted ChatGPT reasoning is READY on this seat; API PRIMARY is not configured, so ordinary turns use the persistent hosted provider.'
        : 'No reasoning transport is ready yet. API PRIMARY is not configured and hosted browser lifecycle is not READY.')
  };
  coreState.apiPrimary.hostedBrowserStatus=hostedProvider?.status==='READY'?'AVAILABLE':'STANDBY';
}

function setPanels(state) {
  coreState.panels = state;
  refreshCompanionState();
  broadcast();
  const provider=(state.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  // Quin fork: no automatic provider authentication probing on initial boot.
  // Only an explicit Human action starts the inherited provider lifecycle.

}


function layoutWebPlugin(){
  if(!webPluginView||!windowMain||windowMain.isDestroyed())return;
  const [width,height]=windowMain.getContentSize();
  webPluginView.setBounds({x:0,y:60,width:Math.max(1,width),height:Math.max(1,height-60)});
}
function closeWebPlugin(){
  dh025Recovery.cancel('CARTRIDGE_CLOSED');developmentAcceptance.cancel();
  cartridgeVoiceHost?.revoke();
  if(activeWebService){servicePlugins.stop(activeWebService);activeWebService=null;}
  if(!webPluginView)return;
  try{windowMain?.contentView.removeChildView(webPluginView);}catch(_){}
  try{webPluginView.webContents.close();}catch(_){}
  webPluginView=null;webPluginId=null;
}
function layoutInlineAuthView(){
  if(!windowMain||windowMain.isDestroyed()||!inlineAuthView)return;
  const [width,height]=windowMain.getContentSize();
  const left=Math.round(width*0.385)+12;
  const top=190;
  const rightPad=12;
  const bottomPad=72;
  inlineAuthView.setBounds({
    x:left,
    y:top,
    width:Math.max(520,width-left-rightPad),
    height:Math.max(320,height-top-bottomPad)
  });
}
function removeInlineAuthView(){
  if(inlineAuthPoll){clearInterval(inlineAuthPoll);inlineAuthPoll=null;}
  if(!inlineAuthView)return;
  try{if(windowMain&&!windowMain.isDestroyed())windowMain.contentView.removeChildView(inlineAuthView);}catch(_){}
  try{inlineAuthView.webContents.close();}catch(_){}
  inlineAuthView=null;inlineAuthActive=false;
}
async function inlineAuthSnapshot(){
  if(!inlineAuthView)return null;
  try{return await inlineAuthView.webContents.executeJavaScript(`(() => {
    const visible=el=>{if(!el)return false;const s=getComputedStyle(el),r=el.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;};
    const prompt=[document.querySelector('#prompt-textarea'),...document.querySelectorAll('div.ProseMirror[contenteditable="true"],textarea,[contenteditable="true"]')].find(visible)||null;
    const loginSignals=(/\\/auth\\/login/i.test(location.pathname)?3:0)+([...document.querySelectorAll('button,a')].filter(visible).filter(el=>/log in|sign up|continue with google|continue with apple|continue with phone/i.test(String(el.innerText||el.textContent||el.getAttribute('aria-label')||''))).length);
    return {url:location.href,title:document.title||'',path:location.pathname||'',promptVisible:!!prompt,loginSignals};
  })()`,true);}catch(_){return null;}
}
async function finishInlineAuthSuccess(snapshot){
  if(!inlineAuthActive)return;
  writeProviderAuthState({
    status:'AUTHENTICATED',
    lastAuthSuccessAt:new Date().toISOString(),
    lastAuthSuccessUrl:snapshot?.url||'',
    lastAuthSuccessTitle:snapshot?.title||'',
    loginPolicy:'HUMAN_EXPLICIT_ONLY'
  });
  await flushProviderSession('AUTH_SUCCESS');
  log('provider.inline-auth.success',{url:snapshot?.url||'',title:snapshot?.title||'',persistent:true});
  coreState.inlineAuth={status:'PASS',detail:'Hosted ChatGPT authentication restored and persisted inside C.Link.',url:snapshot?.url||'',title:snapshot?.title||''};
  removeInlineAuthView();refreshCompanionState();broadcast();
  setTimeout(()=>syncProviderLifecycle(true).catch(error=>log('provider.inline-auth.resync.error',{error:String(error.message||error)})),900);
}
async function startInlineAuthRecovery(reason='AUTH_REQUIRED'){
  if(inlineAuthActive||!windowMain||windowMain.isDestroyed()||!browserRuntime)return;
  inlineAuthActive=true;
  writeProviderAuthState({
    status:'AUTH_IN_PROGRESS',
    lastAuthAttemptAt:new Date().toISOString(),
    lastAuthAttemptReason:reason,
    loginPolicy:'HUMAN_EXPLICIT_ONLY'
  });
  const ses=browserRuntime.getSession();
  inlineAuthView=new WebContentsView({webPreferences:{session:ses,contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
  inlineAuthView.setBackgroundColor('#111111');
  windowMain.contentView.addChildView(inlineAuthView);layoutInlineAuthView();
  inlineAuthView.webContents.setWindowOpenHandler(({url})=>{
    try{const u=new URL(url);if(u.protocol==='https:')setTimeout(()=>{try{inlineAuthView?.webContents.loadURL(url);}catch(_){}},0);}catch(_){}
    return{action:'deny'};
  });
  const report=async()=>{
    const snap=await inlineAuthSnapshot();if(!snap)return;
    coreState.inlineAuth={status:'ACTIVE',detail:'ChatGPT inside Quin. Sign in here only if the existing persistent session requires it.',url:snap.url||'',title:snap.title||''};
    refreshCompanionState();broadcast();
    const ok=String(snap.url||'').startsWith('https://chatgpt.com/')&&!String(snap.url||'').includes('/auth/login')&&snap.promptVisible&&Number(snap.loginSignals||0)===0;
    if(ok)await finishInlineAuthSuccess(snap);
  };
  inlineAuthView.webContents.on('dom-ready',()=>report().catch(()=>{}));
  // For manual opening, probe the inherited persistent session FIRST.
  // Do not force a new authentication or repeatedly visit /auth/login.
  const loginUrl=reason==='HUMAN_EXPLICIT'?'https://chatgpt.com/':'https://chatgpt.com/auth/login';
  coreState.inlineAuth={status:'ACTIVE',detail:'ChatGPT open inside Quin. Using existing persistent session; sign in only if required.',url:loginUrl,title:''};
  if(reason!=='HUMAN_EXPLICIT') coreState.providerLifecycle={...coreState.providerLifecycle,status:'AUTH_REQUIRED',detail:`Hosted provider authentication required: ${reason}`,lastError:reason};
  log('provider.inline-auth.opened',{reason,mode:'INLINE_MAIN_WINDOW',popup:false,targetUrl:loginUrl});refreshCompanionState();broadcast();
  inlineAuthView.webContents.on('did-navigate',(_event,url)=>{log('provider.inline-auth.navigation',{url:String(url||''),kind:'DOCUMENT'});report().catch(()=>{});});
  inlineAuthView.webContents.on('did-navigate-in-page',(_event,url)=>{log('provider.inline-auth.navigation',{url:String(url||''),kind:'IN_PAGE'});report().catch(()=>{});});
  await inlineAuthView.webContents.loadURL(loginUrl);
  inlineAuthPoll=setInterval(()=>report().catch(()=>{}),1000);
}

async function syncProviderLifecycle(force=false){
  // Do not start hosted provider lifecycle or hydration without a real Companion.
  if(!backpackManager.snapshot()?.userCompanion)return{ok:false,error:'NO_COMPANION_LOADED',providerInvoked:false};
  if(lifecycleSyncPromise&&!force)return lifecycleSyncPromise;
  if(!providerReady())throw new Error('COMPANION_PROVIDER_NOT_READY');
  lifecycleSyncPromise=(async()=>{
    const bags=backpackManager.refresh();
    companionOrchestrator.initialize(bags);
    coreState.companionCore=companionOrchestrator.snapshot();
    const startedAt=new Date().toISOString();
    coreState.providerLifecycle={status:'RUNNING',detail:'Locating/creating C.LINK REASONING and synchronizing six canonical chats.',progress:null,lastError:'',startedAt};refreshCompanionState();broadcast();
    try{
      const plan=companionOrchestrator.lifecyclePlan();
      const hydration={userCompanion:backpackManager.hydrationPacket('userCompanion'),systemControl:backpackManager.hydrationPacket('systemControl')};
      const result=await panels.requestLifecycle(plan,{stallTimeoutMs:120000,hydration,onProgress:progress=>{
        if(progress?.stage==='WORKSPACE_READY'&&progress?.data?.projectId&&progress?.data?.projectUrl){
          companionOrchestrator.recordWorkspace({
            projectId:progress.data.projectId,
            projectUrl:progress.data.projectUrl,
            status:'READY',
            health:'HEALTHY'
          });
          log('provider.lifecycle.workspace.persisted',{
            projectId:progress.data.projectId,
            projectUrl:progress.data.projectUrl,
            phase:'WORKSPACE_READY'
          });
        }
        coreState.providerLifecycle={...coreState.providerLifecycle,status:'RUNNING',progress,detail:progress?.detail||'Synchronizing provider lifecycle.',lastEventAt:new Date().toISOString()};refreshCompanionState();log('provider.lifecycle.progress',progress||{});broadcast();
      }});
      companionOrchestrator.applyLifecycleResult(result||{});
      for(const item of Array.isArray(result?.scratch)?result.scratch:[])if(item?.ok&&item?.id&&item?.conversationUrl)companionOrchestrator.recordScratchConversation(item.id,item.conversationUrl,{providerConversationId:item.conversationId,projectId:item.projectId,projectUrl:item.projectUrl});
      const registry=companionOrchestrator.snapshot();
      const allReady=Object.values(registry.chats||{}).length===6&&Object.values(registry.chats||{}).every(chat=>chat.status==='READY'&&chat.health==='HEALTHY');
      coreState.providerLifecycle={status:allReady&&result?.status==='READY'?'READY':'DEGRADED',detail:allReady?'C.LINK REASONING and all six canonical chats are READY.':'Provider lifecycle completed with one or more degraded canonical chats.',progress:null,lastError:'',result,startedAt,completedAt:new Date().toISOString()};
      coreState.companionCore=registry;refreshCompanionState();log('provider.lifecycle.complete',{status:coreState.providerLifecycle.status,result});broadcast();
      if(A007_HOSTED_FIELD_PROBE&&coreState.providerLifecycle.status==='READY'&&!a007HostedFieldProbeStarted){
        a007HostedFieldProbeStarted=true;
        setTimeout(async()=>{
          log('a007.hosted.field-probe.start',{round:288,prompt:'Hello. Who are you?'});
          let probe;
          try{probe=await hostedCompanionMessage('Hello. Who are you?');}
          catch(error){probe={ok:false,error:String(error.message||error)};}
          log('a007.hosted.field-probe.complete',{
            round:288,ok:probe?.ok===true,mode:String(probe?.mode||''),
            reply:String(probe?.reply||'').slice(0,2000),error:String(probe?.error||'')
          });
        },350);
      }
      if(A007_GROK_FIELD_PROBE&&coreState.providerLifecycle.status==='READY'&&grokUserCompanionReady()&&!a007GrokFieldProbeStarted){
        a007GrokFieldProbeStarted=true;
        setTimeout(async()=>{
          const prompt='I want to know whether Grok is ready to become my everyday User Companion in C.Link. This is a technical decision, so do not decide it alone. Use your specialist tabs to challenge the migration, protect Alice\'s continuity and authority, reduce my operator steps, and then give me one final recommendation. Do not change anything on the machine.';
          log('a007.grok.field-probe.start',{round:306,promptChars:prompt.length,provider:'xai',model:'grok-4.3',repairExecution:'OFF'});
          let probe;
          try{probe=await grokUserCompanionMessage(prompt);}
          catch(error){probe={ok:false,error:String(error.message||error)};}
          log('a007.grok.field-probe.complete',{
            round:306,ok:probe?.ok===true,mode:String(probe?.mode||''),
            reply:String(probe?.reply||'').slice(0,3000),error:String(probe?.error||''),
            conclusion:probe?.conclusion||null,resolutionState:probe?.resolutionState||null
          });
          broadcast();
        },700);
      }
      return{ok:coreState.providerLifecycle.status==='READY',result,registry};
    }catch(error){
      const message=String(error.message||error);
      if(/AUTH_REUSE_INDETERMINATE|REAUTH_FORBIDDEN|AUTH_REUSE_CHALLENGE_TIMEOUT/.test(message)){
        const authState=readProviderAuthState();
        const persistenceFault=!!authState.lastAuthSuccessAt;
        writeProviderAuthState({
          status:persistenceFault?'SESSION_PERSISTENCE_FAULT':'AUTH_REQUIRED',
          lastAuthRequiredAt:new Date().toISOString(),
          lastAuthRequiredReason:message,
          persistenceFault,
          loginPolicy:'HUMAN_EXPLICIT_ONLY'
        });
        coreState.providerLifecycle={
          status:'AUTH_REQUIRED',
          detail:persistenceFault
            ? 'The persistent hosted session unexpectedly requires authentication. C.Link will not retry automatically.'
            : 'Hosted ChatGPT sign-in is required inside C.Link.',
          progress:null,lastError:message,startedAt,completedAt:new Date().toISOString(),
          persistenceFault
        };
        refreshCompanionState();
        log('provider.lifecycle.auth-required',{
          error:message,mode:'INLINE_MAIN_WINDOW',activation:'HUMAN_EXPLICIT',
          persistenceFault,lastAuthSuccessAt:authState.lastAuthSuccessAt||null
        });
        broadcast();
        return{ok:false,error:'INLINE_AUTH_REQUIRED',registry:companionOrchestrator.snapshot()};
      }
      coreState.providerLifecycle={status:'FAIL',detail:message,progress:null,lastError:message,startedAt,completedAt:new Date().toISOString()};refreshCompanionState();log('provider.lifecycle.fail',{error:message});broadcast();return{ok:false,error:message,registry:companionOrchestrator.snapshot()};
    }finally{lifecycleSyncPromise=null;}
  })();
  return lifecycleSyncPromise;
}


function companionContextSnapshot() {
  const relayPackage = packageStore.snapshot();
  return {
    schema: 'CLINK_COMPANION_TURN_CONTEXT_V1',
    canonical: CANONICAL_COMPANION_CONTEXT,
    runtime: {
      build: BUILD,
      mission: MISSION,
      coreStatus: coreState.core.status,
      panelsStatus: coreState.panels.status,
      companionStatus: coreState.companion.status,
      repairExecution: 'OFF',
      browserControl: 'ON',
      activeRelayPackage: relayPackage?.relayId ? relayPackage : { status: 'NONE' },
      dualBackpacks: backpackManager.snapshot(),
      reasoningRegistry: companionOrchestrator.snapshot(),
      providerLifecycle: coreState.providerLifecycle,
      messageQualification: coreState.messageQualification
    }
  };
}

function providerReady() {
  const provider=(coreState.panels.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  return coreState.panels.status==='READY' && provider?.status==='READY';
}

function normalizeIncident(value, fallbackText='') {
  const source=value&&typeof value==='object'?value:{};
  const cleanList=v=>Array.isArray(v)?v.map(x=>String(x||'').slice(0,1800)).slice(0,32):[];
  return {
    summary:String(source.summary || fallbackText || 'Human requested specialist problem-solving relay.').slice(0,5000),
    failureFingerprint:String(source.failureFingerprint || `HUMAN_PROBLEM_${Date.now()}`).slice(0,240),
    evidence:cleanList(source.evidence),
    allowedChange:cleanList(source.allowedChange),
    forbiddenChange:cleanList(source.forbiddenChange),
    baselineId:String(source.baselineId || BUILD).slice(0,240),
    systemControlBackpack:backpackManager.snapshot().systemControl
  };
}

async function runRelayForIncident(incident, userHandoff = null) {
  const augmented={...incident,systemControlBackpack:backpackManager.snapshot().systemControl,userHandoff:userHandoff||null};
  const state=await relay.runProblem({
    incident:augmented,
    ownerFrame:null,
    field:true,
    reasoner:async(request,onProgress)=>{
      const chat=companionOrchestrator.descriptor(request.station);
      const runRequest=async req=>{
        const result=await panels.requestReasoning(req,{stallTimeoutMs:70000,onProgress,chat});
        if(result?.conversationUrl)companionOrchestrator.recordConversation(req.station,result.conversationUrl);
        return result;
      };
      try {
        return await runRequest(request);
      } catch (error) {
        const message=String(error.message||error);
        if(!message.startsWith('RELAY_FRESH_RECEIPT_INVALID:RESPONSE_JSON_INVALID:')) throw error;
        const retryMarker=`${String(request.marker||'CLINK_RELAY')}-FORMAT-RETRY-${Date.now()}`;
        const retryPrompt=[
          String(request.prompt||''),
          '',
          'C.LINK STRICT FORMAT RECOVERY:',
          'Your immediately previous response for this same station and phase reached C.Link, but its JSON syntax was malformed.',
          'Do not add new analysis and do not change your substantive conclusion.',
          'Re-emit the immediately previous receipt only, using the exact required CLINK_RECEIPT_JSON_BEGIN / CLINK_RECEIPT_JSON_END contract.',
          'Inside those markers use strict JSON: double-quoted property names, double-quoted string values, no trailing commas, no comments, no prose outside the markers.'
        ].join('\n');
        log('relay.reason.format-retry',{
          station:String(request.station||''),
          phase:String(request.phase||''),
          firstError:message,
          action:'ONE_STRICT_FORMAT_RETRY'
        });
        if(typeof onProgress==='function'){
          onProgress({
            station:String(request.station||''),
            stage:'FORMAT_RETRY',
            detail:'Fresh specialist analysis arrived with malformed JSON; asking the same specialist once to re-emit it as strict JSON.'
          });
        }
        return await runRequest({...request,marker:retryMarker,prompt:retryPrompt});
      }
    }
  });
  coreState.relay=state;coreState.companionCore=companionOrchestrator.snapshot();
  broadcast();
  return state;
}

// Canonical Companion wins the human-facing seat. Existing OpenAI API-primary transport remains unchanged.
async function universalCompanionMessage(input,{technical=false}={}){
  const text=String(input||'').trim();if(!text)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!primaryTransportReady())return{ok:false,error:'API_PRIMARY_OPENAI_NOT_CONFIGURED'};
  try{
    const result=await companionTurnSeat.reply(text,{technical});
    if(result.ok){
      coreState.apiPrimary=apiPrimarySnapshot({lastTurn:{status:'PASS',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),companionId:result.companionId,contextFingerprint:result.contextFingerprint,totalTokens:result.usage?.totalTokens||0}});
    }
    if(result.stale)log('companion.turn.stale-discarded',{reason:result.error});
    refreshCompanionState();broadcast();return result;
  }catch(error){return{ok:false,error:String(error?.message||error)};}
}
async function primaryCompanionMessage(input,{technical=false}={}){
  const bag=backpackManager.snapshot()?.userCompanion;
  if(bag?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return universalCompanionMessage(input,{technical});
  return{ok:false,error:'NO_CANONICAL_COMPANION_ACTIVE',detail:'Import and activate a verified Companion ZIP in Settings.'};
}

async function alphaPrimaryMessage(input,{technical=false}={}) {
  const value=String(input||'').trim();
  if(!value)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!primaryTransportReady())return{ok:false,error:'API_PRIMARY_OPENAI_NOT_CONFIGURED'};
  try{
    const result=await alphaPrimaryRunner().reply(value,{history:alphaRecentTurns,technical:Boolean(technical)});
    if(!result.ok){
      const errorClass=result.error?.class||'OTHER_ERROR';
      providerSecrets.recordTest('openai',{state:{AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[errorClass]||'OTHER_ERROR',httpStatus:result.error?.httpStatus??null});
      refreshCompanionState();broadcast();
      return{ok:false,error:errorClass,detail:result.error?.message||'',mode:technical?'API_PRIMARY_TECHNICAL':'API_PRIMARY_REPLY'};
    }
    providerSecrets.recordTest('openai',{state:'READY',httpStatus:200});
    alphaRecentTurns.push({role:'human',text:value},{role:'alpha',text:result.reply});
    alphaRecentTurns=alphaRecentTurns.slice(-8);
    const soak=apiPrimarySoak.recordPrimarySuccess({technical:Boolean(technical),provider:result.provider,model:result.model,contextFingerprint:result.contextFingerprint});
    coreState.apiPrimary=apiPrimarySnapshot({
      fieldStatus:'R7_FIELD_PROVEN',
      lastTurn:{status:'PASS',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),provider:result.provider,model:result.model,totalTokens:result.usage?.totalTokens||0,contextFingerprint:result.contextFingerprint,machineMutation:false}
    });
    const r9Return=round9.noteAlphaReturn(result,{technical:Boolean(technical)});
    if(!r9Return.ignored)coreState.round9=round9.snapshot();
    refreshCompanionState();broadcast();
    return{ok:true,mode:technical?'API_PRIMARY_TECHNICAL':'API_PRIMARY_REPLY',reply:result.reply,provider:result.provider,model:result.model,usage:result.usage,soak,machineMutation:false,providerConversationAuthority:false};
  }catch(error){
    const message=String(error.message||error);coreState.apiPrimary=apiPrimarySnapshot({lastTurn:{status:'FAIL',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),error:message}});refreshCompanionState();broadcast();return{ok:false,error:message};
  }
}

function explicitSpecialistRelayRequested(input) {
  return specialistRelayRequested(input);
}

async function hostedCompanionMessage(input) {
  const value=String(input||'').trim();
  if (!value) return {ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if (!providerReady()) return {ok:false,error:'COMPANION_PROVIDER_NOT_READY'};
  try {
    const explicitRelay=explicitSpecialistRelayRequested(value);
    const userChat=companionOrchestrator.descriptor('usercompanion');
    const requestHostedCompanion=messageText=>panels.requestCompanion(messageText,{
      stallTimeoutMs:75000,context:companionContextSnapshot(),chat:userChat,onProgress:progress=>{
        log('companion.request.progress',progress||{});
      }
    });
    let response;
    try {
      response=await requestHostedCompanion(value);
    } catch (error) {
      const message=String(error.message||error);
      const ambiguousSchemaExample=/^COMPANION_MODE_INVALID:(?:DIRECT_REPLY\|RELAY_REQUIRED|RELAY_REQUIRED\|DIRECT_REPLY)$/.test(message);
      if (!ambiguousSchemaExample) throw error;
      if (explicitRelay) {
        log('companion.explicit_relay.mode_union_recovered',{
          reason:'HUMAN_EXPLICIT_SPECIALIST_REQUEST',
          providerFailure:message,
          action:'FORCE_RELAY_REQUIRED'
        });
        response={mode:'RELAY_REQUIRED',reply:'',incident:null,conversationUrl:''};
      } else {
        log('companion.ordinary.mode_union_retry',{
          reason:'FROZEN_PROVIDER_SCHEMA_EXAMPLE_LITERAL',
          providerFailure:message,
          action:'ONE_BOUNDED_DIRECT_REPLY_RETRY'
        });
        const retryText=[
          'FORMAT CORRECTION: the previous hosted response used the schema example literally as mode DIRECT_REPLY|RELAY_REQUIRED.',
          'This Human turn is not an explicit specialist-relay request.',
          'Re-answer the ORIGINAL HUMAN MESSAGE below.',
          'Set mode to exactly DIRECT_REPLY unless the original message itself is genuinely technical/problem-solving.',
          'Do not copy the union string DIRECT_REPLY|RELAY_REQUIRED into mode.',
          '',
          `ORIGINAL HUMAN MESSAGE: ${value}`
        ].join('\n');
        response=await requestHostedCompanion(retryText);
        log('companion.ordinary.mode_union_retry.complete',{mode:String(response?.mode||'EMPTY')});
      }
    }
    if(response?.conversationUrl)companionOrchestrator.recordConversation('usercompanion',response.conversationUrl);
    if (response?.mode === 'DIRECT_REPLY' && !explicitRelay) {
      return {ok:true,mode:'DIRECT_REPLY',reply:String(response.reply||''),conversationUrl:response.conversationUrl||''};
    }
    if (response?.mode !== 'RELAY_REQUIRED' && !explicitRelay) return {ok:false,error:`COMPANION_MODE_INVALID:${response?.mode||'EMPTY'}`};
    if(explicitRelay && response?.mode!=='RELAY_REQUIRED'){
      log('companion.explicit_relay.override',{reason:'HUMAN_EXPLICIT_SPECIALIST_REQUEST',providerMode:String(response?.mode||'EMPTY')});
    }

    const incident=explicitRelay && response?.mode!=='RELAY_REQUIRED'
      ? normalizeIncident({
          summary:value,
          failureFingerprint:`HUMAN_EXPLICIT_RELAY_${Date.now()}`,
          evidence:['Human explicitly requested specialist tabs / multi-role challenge.'],
          allowedChange:[],
          forbiddenChange:['Do not mutate the machine unless separately authorized.'],
          baselineId:BUILD
        },value)
      : normalizeIncident(response.incident,value);
    const userHandoff={summary:incident.summary,findings:incident.evidence||[]};
    const relayState=await runRelayForIncident(incident,userHandoff);
    const run=relayState.run;
    const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
    const reply=String(final?.humanReply || final?.summary || response.reply || run?.conclusion || 'Relay completed.');
    return {
      ok:run?.status==='PASS',mode:'RELAY_COMPLETE',reply,
      conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,
      admission:run?.admission||null,relayPackage:run?.relayPackage||null,error:run?.error||null
    };
  } catch (error) {
    return {ok:false,error:String(error.message||error)};
  }
}

function grokUserCompanionSchema(){
  return {
    name:'clink_grok_user_companion_turn',strict:true,
    schema:{
      type:'object',additionalProperties:false,
      required:['mode','reply','incident'],
      properties:{
        mode:{type:'string',enum:['DIRECT_REPLY','RELAY_REQUIRED']},
        reply:{type:'string'},
        incident:{
          type:'object',additionalProperties:false,
          required:['summary','failureFingerprint','evidence','allowedChange','forbiddenChange','baselineId'],
          properties:{
            summary:{type:'string'},failureFingerprint:{type:'string'},
            evidence:{type:'array',items:{type:'string'}},allowedChange:{type:'array',items:{type:'string'}},
            forbiddenChange:{type:'array',items:{type:'string'}},baselineId:{type:'string'}
          }
        }
      }
    }
  };
}
function grokUserCompanionHydration(){
  const packet=backpackManager.hydrationPacket('userCompanion');
  return {
    schema:packet.schema,artifactClass:packet.artifactClass,id:packet.id,revision:packet.revision,version:packet.version,
    sha256:packet.sha256,bytes:packet.bytes,mutability:packet.mutability,source:packet.source,totalTextBytes:packet.totalTextBytes,
    files:(packet.files||[]).map(item=>({path:item.path,bytes:item.bytes,sha256:item.sha256,text:item.text}))
  };
}
async function grokUserCompanionMessage(input){
  const value=String(input||'').trim();
  if(!value)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!grokUserCompanionReady())return{ok:false,error:'XAI_GROK_USER_COMPANION_NOT_READY'};
  const explicitRelay=explicitSpecialistRelayRequested(value);
  const hydration=grokUserCompanionHydration();
  const runtimeContext={
    schema:'CLINK_GROK_USER_COMPANION_RUNTIME_V1',build:BUILD,mission:MISSION,repairExecution:'OFF',
    humanSurface:'CLINK_TERMINAL',technicalRelay:'SYSTEM_CONTROL_RED_FABRIC_CONTROL_THROUGHPUT_SYSTEM_CONTROL',
    specialistTransport:'HOSTED_CHATGPT_WEB',providerConversationAuthority:false
  };
  const instructions=[
    'You are the USER COMPANION inside PhantomTronix C.Link Terminal.',
    'C.Link owns identity, continuity, relay sequencing, files, authorization, and execution. You reason and converse; do not claim machine actions happened unless C.Link reports them.',
    'The USER_COMPANION_BACKPACK_JSON supplied with every turn is authoritative for your identity, personality, durable continuity, and Human conventions. Provider session memory is not authority.',
    'Return only the required structured response.',
    'Use DIRECT_REPLY for ordinary conversation that does not need specialist challenge.',
    'Use RELAY_REQUIRED for technical diagnosis, implementation, architecture, repair, release/admission, system decisions, or whenever the Human explicitly asks you not to decide alone or asks for specialist tabs.',
    'For RELAY_REQUIRED, do not perform the specialist analysis yourself. Frame a concise incident for System Control. Leave allowedChange empty unless the Human explicitly authorized mutation. Preserve explicit no-change instructions in forbiddenChange.',
    'Do not put provider response IDs or provider session IDs into continuity. Do not mutate the User Companion backpack in this shadow round.'
  ].join('\n');
  const apiInput=[
    `USER_COMPANION_BACKPACK_JSON=${JSON.stringify(hydration)}`,
    `CURRENT_CLINK_RUNTIME_JSON=${JSON.stringify(runtimeContext)}`,
    `HUMAN_REQUEST=${value}`
  ].join('\n\n');
  log('grok.usercompanion.request.start',{provider:'xai',model:'grok-4.3',backpackRevision:hydration.revision,backpackSha256:hydration.sha256,explicitRelay,store:false});
  const envelope=await providerAdapters.createResponse('xai',{
    input:apiInput,instructions,model:'grok-4.3',maxOutputTokens:1400,store:false,
    structuredJsonSchema:grokUserCompanionSchema(),companionId:hydration.id||'user-companion',missionId:MISSION,workerId:null,purpose:'grok_user_companion_shadow'
  });
  const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
  providerSecrets.recordTest('xai',{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
  if(envelope.error){
    const error=String(envelope.error?.class||'GROK_USER_COMPANION_PROVIDER_ERROR');
    coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:{status:'FAIL',at:new Date().toISOString(),error}});
    log('grok.usercompanion.response',{status:'FAIL',errorClass:error,httpStatus:envelope.error?.httpStatus??null,provider:'xai',model:envelope.model||'grok-4.3'});broadcast();
    return{ok:false,error,detail:envelope.error?.message||''};
  }
  let response;
  try{response=JSON.parse(String(envelope.output||'').trim());}
  catch(error){
    const detail=String(error.message||error);
    coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:{status:'FAIL',at:new Date().toISOString(),error:'GROK_USER_COMPANION_JSON_INVALID'}});
    log('grok.usercompanion.response',{status:'FAIL',errorClass:'GROK_USER_COMPANION_JSON_INVALID',detail,provider:'xai',model:envelope.model||'grok-4.3'});broadcast();
    return{ok:false,error:'GROK_USER_COMPANION_JSON_INVALID',detail};
  }
  let mode=String(response?.mode||'');
  if(explicitRelay&&mode!=='RELAY_REQUIRED'){
    log('grok.usercompanion.explicit_relay.override',{providerMode:mode||'EMPTY',action:'FORCE_RELAY_REQUIRED'});
    mode='RELAY_REQUIRED';
  }
  if(!['DIRECT_REPLY','RELAY_REQUIRED'].includes(mode))return{ok:false,error:`GROK_USER_COMPANION_MODE_INVALID:${mode||'EMPTY'}`};
  const turnMeta={status:'PASS',at:new Date().toISOString(),mode,provider:'xai',model:envelope.model||'grok-4.3',totalTokens:envelope.usage?.totalTokens||0,backpackRevision:hydration.revision,backpackSha256:hydration.sha256,providerConversationAuthority:false,machineMutation:false};
  coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:turnMeta});
  log('grok.usercompanion.response',{status:'PASS',mode,provider:'xai',model:turnMeta.model,totalTokens:turnMeta.totalTokens,backpackRevision:hydration.revision,backpackSha256:hydration.sha256,providerConversationAuthority:false,machineMutation:false});broadcast();
  if(mode==='DIRECT_REPLY')return{ok:true,mode:'GROK_USER_COMPANION_DIRECT',reply:String(response.reply||''),provider:'xai',model:turnMeta.model,usage:envelope.usage,backpackRevision:hydration.revision};
  if(!providerReady())return{ok:false,error:'SPECIALIST_HOSTED_PROVIDER_NOT_READY',provider:'xai',model:turnMeta.model};
  const fallbackIncident=normalizeIncident({
    summary:value,failureFingerprint:`GROK_USER_COMPANION_${Date.now()}`,
    evidence:['Grok User Companion classified this Human turn for specialist relay.'],
    allowedChange:[],forbiddenChange:['Do not mutate the machine unless separately authorized.'],baselineId:BUILD
  },value);
  const incident=normalizeIncident(response?.incident&&typeof response.incident==='object'?response.incident:fallbackIncident,value);
  if(explicitRelay&&!(incident.forbiddenChange||[]).some(item=>/mutat|change|machine/i.test(item||''))){
    incident.forbiddenChange=[...(incident.forbiddenChange||[]),'Do not mutate the machine unless separately authorized.'];
  }
  const userHandoff={summary:incident.summary,findings:incident.evidence||[]};
  log('grok.usercompanion.relay.start',{summaryChars:incident.summary.length,backpackRevision:hydration.revision,provider:'xai',model:turnMeta.model});
  const relayState=await runRelayForIncident(incident,userHandoff);
  const run=relayState.run;
  const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
  const reply=String(final?.humanReply||final?.summary||response.reply||run?.conclusion||'Relay completed.');
  const ok=run?.status==='PASS';
  coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:ok?'SHADOW_RELAY_FIELD_OBSERVED':'SHADOW_FIELD_PENDING',lastTurn:{...turnMeta,relayStatus:run?.status||'UNKNOWN',relayConclusion:run?.conclusion||null}});
  log('grok.usercompanion.relay.complete',{ok,relayStatus:run?.status||'UNKNOWN',conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,admission:run?.admission?.status||null,provider:'xai',model:turnMeta.model});broadcast();
  return{ok,mode:'GROK_USER_COMPANION_RELAY_COMPLETE',reply,provider:'xai',model:turnMeta.model,usage:envelope.usage,backpackRevision:hydration.revision,conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,admission:run?.admission||null,relayPackage:run?.relayPackage||null,error:run?.error||null};
}

async function runMessageQualification(){
  const result={...restoredQualification(),restored:true,rerun:false,sourceFile:QUAL_PROOF_FILE};
  coreState.messageQualification=result;log('message.qualification.restored',{knownSafeMaxChars:result.knownSafeMaxChars,recommendedFutureChunkChars:result.recommendedFutureChunkChars,samples:result.samples,passes:result.passes,rerun:false});broadcast();
  return{ok:true,result,restored:true,rerun:false};
}

async function diagnostic() {
  return [
    'CLINK_BROWSER_OWNED_ZIP_RELAY_DIAGNOSTIC_V1',
    `TIME=${new Date().toISOString()}`,
    `BUILD=${BUILD}`,
    `MISSION=${MISSION}`,
    `CORE=${coreState.core.status}`,
    `PANELS=${coreState.panels.status}`,
    `COMPANION=${coreState.companion.status}`,
    'BROWSER_CONTROL=ON',
    'PRIMARY_HUMAN_SURFACE=CLINK_TERMINAL',
    'EXTERNAL_CHROME_CHAT=BREAK_GLASS_ONLY',
    'AI_SELF_REPAIR=OFF',
    'REPAIR_EXECUTION=OFF',
    'RELAY_TRANSFER=EVENT_DRIVEN',
    'RELAY_PACKAGE_OWNERSHIP=SYSTEM_CONTROL_SINGLE_ZIP',
    'COMPANION_CONTEXT=CLINK_OWNED_EVERY_TURN',
    'CANONICAL_REASONING_WORKSPACE=C.LINK REASONING',
    'CANONICAL_AGENT_COUNT=6',
    `PROVIDER_LIFECYCLE_STATE=${JSON.stringify(coreState.providerLifecycle)}`,
    `DUAL_BACKPACK_STATE=${JSON.stringify(backpackManager.snapshot())}`,
    `COMPANION_CORE_REGISTRY=${JSON.stringify(companionOrchestrator.snapshot())}`,
    'MESSAGE_QUALIFICATION=R27A2_FIELD_PROVEN_RESTORED_NO_RERUN',
    'MESSAGE_BATCH_RERUN=DISABLED_R28B',
    'MESSAGE_KNOWN_SAFE_OBSERVED_CHARS=131072',
    'MESSAGE_OPERATIONAL_CHUNK_TARGET_CHARS=98304',
    `MESSAGE_QUALIFICATION_STATE=${JSON.stringify(coreState.messageQualification)}`,
    `MESSAGE_QUALIFICATION_LATEST=${QUAL_LATEST}`,
    'ATTACHMENT_QUALIFICATION=NOT_TESTED_R27A',
    'COMPANION_CONTEXT_STAGE=API_CONVERSION_ROUND_9_RECONCILIATION_TEARDOWN_RESTART_VALUE_REVIEW',
    `ELECTRON_RUNTIME_VERSION=${process.versions.electron||''}`,
    `EXPECTED_ELECTRON_RUNTIME=${REQUIRED_ELECTRON}`,
    `AUTH_SESSION_PATH=${path.join(PROFILE_ROOT,'providers','chatgpt-web','Partitions','chatgpt-web')}`,
    `PROFILE_ROOT_SOURCE=${PROFILE_ROOT_OVERRIDE?'CLINK_FIELD_TEST_OVERRIDE':'CANONICAL_APPDATA'}`,
    `FIELD_TEST_MODE=${FIELD_TEST_MODE?'ON':'OFF'}`,
    'API_MODE=API_PRIMARY_OPENAI_WITH_HOSTED_FALLBACK',
    'ALPHA_REASONING=API_PRIMARY',
    'HOSTED_BROWSER=FALLBACK',
    `API_PRIMARY_STATE=${JSON.stringify(coreState.apiPrimary)}`,
    `R8_READ_ONLY_WORKERS=${JSON.stringify(readOnlyWorkers.snapshot())}`,
    `API_R8_FIELD_EVIDENCE=${JSON.stringify(API_R8_FIELD)}`,
    `R9_RECONCILIATION_STATE=${JSON.stringify(round9.snapshot())}`,
    `API_R7_FIELD_EVIDENCE=${JSON.stringify(API_R7_FIELD)}`,
    `API_PROVIDER_STATUS=${JSON.stringify(providerSecrets.snapshot())}`,
    `GROK_USER_COMPANION_SHADOW_STATE=${JSON.stringify(coreState.grokUserCompanion)}`,
    `API_SECRET_FILE_PRESENT=${fs.existsSync(path.join(PROFILE_ROOT,'providers','api','provider-secrets.enc.json'))?'YES':'NO'}`,
    `API_PROVIDER_ADAPTERS=${JSON.stringify(providerAdapters.defaults())}`,
    `ALPHA_API_SHADOW_STATE=${JSON.stringify(coreState.apiShadow)}`,
    `COMPANION_CONTEXT_BUILDER_STATE=${JSON.stringify(coreState.apiContext)}`,
    `LIVE_REPOSITORY_SECRET_SANITY=${JSON.stringify(coreState.apiContext?.repositorySecretSanity||null)}`,
    `API_USAGE_BUDGET=${JSON.stringify(apiUsage.summary())}`,
    `API_R6_FIELD_EVIDENCE=${JSON.stringify(API_R6_FIELD)}`,
    `HIVE_R7_RELEASE=${JSON.stringify(HIVE_R7_RELEASE)}`,
    'ROUND4_ALPHA_SHADOW_FIELD=PASS',
    `RELAY_PACKAGE=${JSON.stringify(packageStore.snapshot())}`,
    `RELAY_STATE=${JSON.stringify(relay.snapshot())}`,
    '', '=== STATE ===', JSON.stringify(snapshot(),null,2),
    '=== EVENTS ===', ...tail(LOG_FILE,220),
    '=== BOOT ===', ...tail(BOOT_LOG,100)
  ].join('\r\n');
}

let quinL1Runtime=null;const quinL1BootId=crypto.randomUUID();
function quinL1(){if(!quinL1Runtime)quinL1Runtime=new QuinL1Runner({profileRoot:PROFILE_ROOT,appRoot:__dirname,electronVersion:process.versions.electron,bootId:quinL1BootId});return quinL1Runtime;}
let aliceSeatRuntime=null; // singleton: one Alice runtime session identifier per Quin process
function aliceSeatService(){if(!aliceSeatRuntime)aliceSeatRuntime=new AliceSeatService({profileRoot:PROFILE_ROOT,appRoot:__dirname,adapters:providerAdapters});return aliceSeatRuntime;}
function aliceSeatResult(action){try{return{ok:true,...action()};}catch(error){return{ok:false,error:String(error.message||error)};}}
async function aliceFilePicker(purpose='parent'){if(!windowMain)return null;const r=await dialog.showOpenDialog(windowMain,{title:purpose==='checkpoint'?'Alice Moonlight · Import local checkpoint ZIP':'Alice Moonlight · Select canonical parent ZIP',properties:['openFile'],filters:[{name:'ZIP archive',extensions:['zip']}]});return r.canceled?null:(r.filePaths[0]||null);}
function restrictedBrowser(){
  if(!restrictedBrowserCartridge){
    restrictedBrowserCartridge=new RestrictedBrowserCartridge({
      WebContentsView,session:require('electron').session,getWindow:()=>windowMain,
      getChatGPTSession:()=>browserRuntime?.getSession(),
      getChatGPTProjectHome:()=>companionOrchestrator.snapshot()?.workspace?.providerProjectUrl,
      projectHomeFile:path.join(PROFILE_ROOT,'browser','chatgpt-project-home.json'),
      emit:state=>{try{windowMain?.webContents.send('clink:restricted-browser-state',state);}catch(_){}},log
    });
  }
  return restrictedBrowserCartridge;
}
function companionChatGPTTool(){
  if(!companionChatGPTBridge){
    companionChatGPTBridge=new CompanionChatGPTBridge({
      browser:restrictedBrowser(),
      getSeat:()=>backpackManager.snapshot()?.userCompanion,
      confirmSend:async({message,seatId})=>{
        if(!windowMain || windowMain.isDestroyed?.())return false;
        const result=await dialog.showMessageBox(windowMain,{
          type:'question',title:'Send message to ChatGPT website?',
          message:'Send a message as '+seatId+' using your signed-in ChatGPT tab?',
          detail:message.slice(0,900)+'\n\nChatGPT may use connected apps only under their own authorization controls.',
          buttons:['CANCEL','SEND TO CHATGPT'],defaultId:0,cancelId:0,noLink:true
        });
        return result?.response===1;
      }
    });
  }
  return companionChatGPTBridge;
}
function restrictedBrowserShellOnly(event){
  return !!windowMain && !windowMain.isDestroyed() && event?.sender===windowMain.webContents &&
    event?.senderFrame===windowMain.webContents.mainFrame;
}
function installIpc() {
  ipcMain.handle('clink:get-state',()=>snapshot());
  ipcMain.handle('clink:restricted-browser-state',event=>restrictedBrowserShellOnly(event)?restrictedBrowser().state():{ok:false,error:'SHELL_ONLY'});
  // Browser tools are ONLY callable by Quin's own main shell. No arbitrary site
  // content, API response or cartridge can invoke them directly.
  ipcMain.handle('clink:companion-web-observe',event=>restrictedBrowserShellOnly(event)?companionChatGPTTool().observe():{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:companion-web-draft',(event,text)=>restrictedBrowserShellOnly(event)?companionChatGPTTool().prepareDraft(text):{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:companion-web-send',event=>restrictedBrowserShellOnly(event)?companionChatGPTTool().submitDraft():{ok:false,error:'SHELL_ONLY'});

  ipcMain.handle('clink:restricted-browser-layout',(event,top)=>restrictedBrowserShellOnly(event)?restrictedBrowser().setToolbarBottom(top):{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:restricted-browser-show',(event,id)=>{
    if(!restrictedBrowserShellOnly(event))return{ok:false,error:'SHELL_ONLY'};
    if(inlineAuthActive)return{ok:false,error:'AUTH_VIEW_ACTIVE'};
    if(webPluginView)return{ok:false,error:'CLOSE_EXISTING_CARTRIDGE_FIRST'};
    return restrictedBrowser().show(String(id||'chatgpt'));
  });
  ipcMain.handle('clink:restricted-browser-hide',event=>restrictedBrowserShellOnly(event)?restrictedBrowser().hide():{ok:false,error:'SHELL_ONLY'});
  // R371: only the trusted local renderer may exit an embedded cartridge.
  // Keep Browser WebContentsView attached and alive for later re-entry.
  ipcMain.handle('clink:terminal-return-home',event=>{
    if(!restrictedBrowserShellOnly(event))return {ok:false,error:'SHELL_ONLY'};
    try{
      const hadCartridge=!!webPluginView||!!activeWebService;
      closeWebPlugin();
      if(restrictedBrowserCartridge)restrictedBrowserCartridge.hide();
      return {ok:true,cartridgeClosed:hadCartridge,browserPreserved:true};
    }catch(error){log('clink.terminal-home.error',{error:String(error.message||error).slice(0,120)});
      return {ok:false,error:'HOME_TRANSITION_FAILED'};}
  });

  ipcMain.handle('clink:restricted-browser-action',(event,action)=>restrictedBrowserShellOnly(event)?restrictedBrowser().action(String(action||'')):{ok:false,error:'SHELL_ONLY'});

  ipcMain.handle('quin:alice-status',()=>aliceSeatResult(()=>({state:aliceSeatService().status()})));
  const l1Shell=event=>!!windowMain&&!windowMain.isDestroyed()&&event.sender===windowMain.webContents;
  ipcMain.handle('quin:l1-status',event=>l1Shell(event)?quinL1().status():{ok:false,error:'L1_SHELL_REQUIRED'});
  ipcMain.handle('quin:l1-assign',async(event,objective)=>{if(!l1Shell(event))return{ok:false,error:'L1_SHELL_REQUIRED'};try{const a=quinL1().assign(String(objective||''));const b=quinL1().step();return{ok:!!b.ok,assignment:a,run:b};}catch(e){return{ok:false,error:String(e.message||e)};}});
  ipcMain.handle('quin:l1-proof',event=>l1Shell(event)?quinL1().proof():{ok:false,error:'L1_SHELL_REQUIRED'});
  ipcMain.handle('quin:alice-copy-transfer',(event,content)=>{if(!l1Shell(event))return{ok:false,error:'L1_SHELL_REQUIRED'};const value=String(content||'');if(!value||Buffer.byteLength(value,'utf8')>20000)return{ok:false,error:'ALICE_TRANSFER_SIZE_INVALID'};clipboard.writeText(value);return{ok:true};});
  ipcMain.handle('quin:alice-admit',async()=>{const selected=await aliceFilePicker();if(!selected)return{ok:false,error:'ALICE_SELECTION_CANCELLED'};return aliceSeatResult(()=>({binding:aliceSeatService().admitAliceParent(selected)}));});
  ipcMain.handle('quin:alice-update',async()=>{const selected=await aliceFilePicker();if(!selected)return{ok:false,error:'ALICE_SELECTION_CANCELLED'};return aliceSeatResult(()=>({update:aliceSeatService().replaceAliceParent(selected)}));});
  ipcMain.handle('quin:alice-checkpoint',async()=>{if(!windowMain)return{ok:false,error:'NO_WINDOW'};const r=await dialog.showSaveDialog(windowMain,{title:'Export Alice local checkpoint',defaultPath:'ALICE-LOCAL-CHECKPOINT.zip',filters:[{name:'ZIP',extensions:['zip']}]});if(r.canceled||!r.filePath)return{ok:false,error:'ALICE_EXPORT_CANCELLED'};return aliceSeatResult(()=>({checkpoint:aliceSeatService().checkpoint(r.filePath)}));});
  ipcMain.handle('quin:alice-import-checkpoint',async()=>{const selected=await aliceFilePicker('checkpoint');if(!selected)return{ok:false,error:'ALICE_IMPORT_CANCELLED'};return aliceSeatResult(()=>({imported:aliceSeatService().importCheckpoint(selected)}));});
  ipcMain.handle('quin:alice-message',async(_event,value)=>{try{return await aliceSeatService().message(value);}catch(error){return{ok:false,error:String(error.message||error)};}});
  ipcMain.handle('quin:alice-chat-history',()=>aliceSeatResult(()=>({messages:aliceSeatService().chatHistory()})));
  // R229: Universal Companion voice reuses LOCAL Whisper/Piper service, never Alice's conversation.
  // Existing HFC TTS profile is shared and explicitly labeled; no voice identity claimed.
  const universalVoiceShell = event => !!windowMain && !windowMain.isDestroyed() &&
    event?.sender === windowMain.webContents && event?.senderFrame === windowMain.webContents.mainFrame;
  const universalVoiceKey = () => {
    const seat = backpackManager.snapshot()?.userCompanion;
    if (!seat || seat.importFormat !== 'PERSONAL_IDENTITY_CAPSULE') return null;
    return String(seat.id) + ':' + String(seat.sha256 || '').toUpperCase();
  };
  const universalVoiceGuard = (event,key) => universalVoiceShell(event) && !!universalVoiceKey() &&
    String(key || '') === universalVoiceKey();
  ipcMain.handle('quin:companion-cb-status',(event,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,ready:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    return {ok:true,ready:!!aliceCbVoice.voiceConfig(),engine:'LOCAL_WHISPER_PIPER',voice:'SHARED_HFC_PROFILE'};
  });
  ipcMain.handle('quin:companion-cb-transcribe',async(event,wav,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    const r = await aliceCbVoice.transcribe(wav);
    return universalVoiceGuard(event,key) ? r : {ok:false,error:'COMPANION_VOICE_SEAT_CHANGED'};
  });
  ipcMain.handle('quin:companion-cb-speak',async(event,txt,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    const r = await aliceCbVoice.synthesize(txt);
    return universalVoiceGuard(event,key) ? r : {ok:false,error:'COMPANION_VOICE_SEAT_CHANGED'};
  });
  ipcMain.handle('quin:companion-cb-metric',(event,stage,ms,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    return aliceCbVoice.recordMetric(stage,ms);
  });
  ipcMain.handle('quin:alice-cb-status',()=>({ok:true,ready:!!aliceCbVoice.voiceConfig(),engine:'LOCAL_WHISPER_PIPER',model:'base.en',voice:'HFC FEMALE'}));
  ipcMain.handle('quin:alice-cb-transcribe',async(event,wav)=>{if(event.sender!==windowMain?.webContents)return{ok:false,error:'CB_UNAUTHORIZED_RENDERER'};return aliceCbVoice.transcribe(wav);});
  ipcMain.handle('quin:alice-cb-speak',async(event,content)=>{if(event.sender!==windowMain?.webContents)return{ok:false,error:'CB_UNAUTHORIZED_RENDERER'};return aliceCbVoice.synthesize(content);});
  ipcMain.handle('quin:alice-cb-metric',async(event,stage,ms)=>{if(event.sender!==windowMain?.webContents)return{ok:false};return aliceCbVoice.recordMetric(stage,ms);});
  ipcMain.handle('quin:alice-chat-export',async()=>{if(!windowMain)return{ok:false,error:'NO_WINDOW'};const r=await dialog.showSaveDialog(windowMain,{title:'Export Alice Chat',defaultPath:'ALICE-CHAT-HISTORY.json',filters:[{name:'JSON',extensions:['json']}]});if(r.canceled||!r.filePath)return{ok:false,error:'ALICE_CHAT_EXPORT_CANCELLED'};return aliceSeatResult(()=>({exported:aliceSeatService().exportChat(r.filePath)}));});
  ipcMain.handle('quin:exit-app',async(event)=>{
    // Only Quin shell may request an application exit. Cartridges have no access.
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)
      return {ok:false,error:'QUIN_SHELL_REQUIRED'};
    if(quitScheduled)return {ok:false,error:'EXIT_ALREADY_IN_PROGRESS'};
    const answer=await dialog.showMessageBox(windowMain,{
      type:'question',title:'Exit C.Link?',message:'Exit C.Link Terminal?',
      detail:'C.Link will close its browser views and preserve your persistent ChatGPT session.',
      buttons:['Cancel','Exit C.Link'],defaultId:0,cancelId:0,noLink:true
    });
    if(answer.response!==1)return {ok:false,canceled:true};
    setImmediate(()=>requestAppQuit()); // Uses inherited clean session flush, not app.exit().
    return {ok:true,exiting:true};
  });
  // Quin PANELS application #001: original UFA Factory, NOT the demo storyboard form.
  ipcMain.handle('quin:factory-open',async(event)=>{
    if(windowMain&&event.sender!==windowMain.webContents)return {ok:false,error:'QUIN_MAIN_WINDOW_REQUIRED'};
    if(!windowMain||windowMain.isDestroyed())return {ok:false,error:'QUIN_WINDOW_NOT_READY'};
    if(inlineAuthActive)return {ok:false,error:'FINISH_OR_CLOSE_INLINE_LOGIN_FIRST'};
    if(!browserRuntime)return {ok:false,error:'QUIN_BROWSER_RUNTIME_NOT_READY'};
    const cartridge=(coreState.panels.plugins||[]).find(p=>p.id==='robotrock-video-factory');
    if(!cartridge||cartridge.status!=='READY')return {ok:false,error:'ROBOT_ROCK_CARTRIDGE_NOT_READY'};
    try{return require('./robotrock-factory/runtime').launchFactory(windowMain,browserRuntime.getSession());}
    catch(error){log('quin.factory.launch.error',{error:String(error.message||error)});return {ok:false,error:String(error.message||error)};}
  });

  // Generic user-installed graphical cartridges. Shell-owned only, no plugin preload/Node bridge.
  let cartridgeUpdateHost;
  const clinkOpenCart=async(event,id,nativeReopen=false)=>{
    if(!nativeReopen&&cartridgeUpdateHost?.isActive())return {ok:false,error:'CARTRIDGE_UPDATE_IN_PROGRESS'};
    if(clinkCartridgeBusy)return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)return {ok:false,error:'QUIN_SHELL_REQUIRED'};
    if(inlineAuthActive)return {ok:false,error:'FINISH_INLINE_LOGIN_FIRST'};
    try{
      const cleanId=String(id||'');
      if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(cleanId))return {ok:false,error:'INVALID_PLUGIN_ID'};
      if(!nativeReopen&&cartridgeUpdateHost?.openBlocked(cleanId))return {ok:false,error:'CARTRIDGE_RECOVERY_REQUIRED'};
      const builtins=path.join(PANELS_ROOT,'plugins');
      const installed=path.join(PROFILE_ROOT,'panels','installed-plugins');
      const candidate=[builtins,installed].map(r=>path.join(r,cleanId,'manifest.json')).find(f=>fs.existsSync(f));
      if(!candidate)return {ok:false,error:'PLUGIN_NOT_INSTALLED'};
      const isService=JSON.parse(fs.readFileSync(candidate,'utf8')).runtime==='web-service';
      const rec=isService?servicePlugins.verify(cleanId,builtins,installed):webPlugins.verify(cleanId,builtins,installed);
      if(!webPlugins.pluginEnabled(rec.manifest,rec.id,PROFILE_ROOT))return {ok:false,error:'WEB_PLUGIN_DISABLED'};
      restrictedBrowserCartridge?.hide();
      closeWebPlugin();
      if(isService)activeWebService=await servicePlugins.start(rec,PROFILE_ROOT);
      webPluginId=rec.id;
      const origin=isService?`quinservice://${rec.id}`:`quinplugin://${rec.id}`;
      const view=new WebContentsView({webPreferences:{session:webPluginSession,preload:path.join(__dirname,'clink-cartridge-updates','cartridge-preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true,webviewTag:false}});
      webPluginView=view;view.setBackgroundColor('#101016');
      if (!isService && rec.id==='phantomtronix-command') {
        const wc=view.webContents;
        wc.on('before-input-event',(event,input)=>{
          if(input.type==='keyDown'&&input.control&&input.shift&&String(input.key).toLowerCase()==='x'&&(dh025Recovery.cancel('KEYBOARD_CANCEL')||developmentAcceptance.cancel()))event.preventDefault();
        });
        const isCommandUrl=value=>{try{const u=new URL(value);return u.protocol==='quinplugin:'&&u.hostname==='phantomtronix-command'&&!u.username&&!u.password&&!u.port;}catch(_){return false;}};
        attachNativeEditMenu(wc, params=>Boolean(windowMain&&!windowMain.isDestroyed()&&webPluginView===view&&webPluginId===rec.id&&isCommandUrl(wc.getURL())&&isCommandUrl(params.frameURL)));
      }
      view.webContents.on('did-start-navigation',()=>cartridgeVoiceHost?.revoke());
      view.webContents.setWindowOpenHandler(({url})=>{
        // R433_MIXCLOUD_ONLY: allow official Mixcloud branding clickthrough
        // in a trusted external browser, never an Electron child window.
        if(rec.id==='conveyor-club'){
          try{
            const target=new URL(url);
            if(target.protocol==='https:' &&
               (target.hostname==='mixcloud.com'||target.hostname==='www.mixcloud.com')){
              Promise.resolve(require('electron').shell.openExternal(url)).catch(()=>{});
            }
          }catch(_){}
        }
        return {action:'deny'};
      });
      // Custom Electron schemes have opaque origins in Node's URL API.
      // Compare the authority tuple explicitly; never allow another cartridge.
      const navigationURL=(event,value)=>typeof value==='string'?value:
        typeof value?.url==='string'?value.url:event?.url;
      const sameCartridgeURL=value=>{try{
        const u=new URL(value);
        return u.protocol===(isService?'quinservice:':'quinplugin:') &&
          u.hostname===rec.id && !u.username && !u.password && !u.port;
      }catch(_){return false;}};
      view.webContents.on('will-navigate',(e,url)=>{
        if(!sameCartridgeURL(navigationURL(e,url)))e.preventDefault();
      });
      view.webContents.on('will-redirect',(e,url)=>{try{
        // R437: ONLY the official Mixcloud SUBFRAME redirect in the existing
        // signed Conveyor Club. Main-frame navigation remains restricted.
        const targetURL=navigationURL(e,url);
        if(rec.id==='conveyor-club' && (url?.isMainFrame??e.isMainFrame)===false){
          const target=new URL(targetURL);
          if(target.origin==='https://player-widget.mixcloud.com' &&
             !target.username && !target.password)return;
        }
        if(!sameCartridgeURL(targetURL))e.preventDefault();
      }catch(_){e.preventDefault();}});
      windowMain.contentView.addChildView(view);layoutWebPlugin();
      await view.webContents.loadURL(isService?origin+'/':origin+'/'+rec.entry);
      if(!isService&&!nativeReopen&&webPluginView===view){
        void cartridgeUpdateHost.onOpen(rec.id,view.webContents).then(result=>{
          log('cartridge.update.open',{id:rec.id,code:result?.code|| (result?.ok?'OK':'UNKNOWN')});
        }).catch(()=>{});
      }
      return {ok:true,id:rec.id,mode:isService?'MANAGED_WEB_SERVICE':'STATIC_WEB_VIEW'};
    }catch(err){closeWebPlugin();log('web-plugin.open.error',{error:String(err.message||err)});return{ok:false,error:String(err.message||err)};}
  };
  ipcMain.handle('quin:web-plugin-open',(event,id)=>clinkOpenCart(event,id));
  // R381_CARTRIDGE_UPDATE: trusted native service; CART preload only gets fixed requests.
  cartridgeUpdateHost=require('./clink-cartridge-updates/host.cjs').makeHost({
    ipcMain,dialog,profileRoot:PROFILE_ROOT,
    builtinsRoot:path.join(PANELS_ROOT,'plugins'),
    installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
    terminalVersion:(app.getVersion().split('-')[0]||'0.0.0'),
    getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')),
    launch:id=>clinkOpenCart({sender:windowMain.webContents},id,true),
    suspend:async(id,wc)=>{if(webPluginId!==id||webPluginView?.webContents!==wc)return false;closeWebPlugin();return true;},
    getShellWebContents:()=>windowMain?.webContents
  });
  cartridgeUpdateHost.register();
  // R385_SHARED_LLM_BROKER — trusted, permission-scoped CART LLM bridge.
  require('./clink-cartridge-llm/host.cjs').makeHost({
    ipcMain, dialog, getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')),
    builtinsRoot:path.join(PANELS_ROOT,'plugins'),
    installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
    secretStore:providerSecrets,adapterRegistry:providerAdapters,companionSeat:companionTurnSeat,stationSeats:commandStationSeats,clipboard,developmentTool:dh025Recovery
  }).register();
  cartridgeVoiceHost=require('./clink-cartridge-voice/host.cjs').makeVoiceHost({
    ipcMain,dialog,voice:aliceCbVoice,
    getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins'))
  });
  cartridgeVoiceHost.register();
  ipcMain.handle('quin:web-plugin-close',event=>{
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)return{ok:false,error:'QUIN_SHELL_REQUIRED'};
    closeWebPlugin();return{ok:true};
  });
  ipcMain.handle('quin:plugin-list',()=>{
    const base=path.join(PROFILE_ROOT,'panels');
    const disabledFile=path.join(base,'disabled-plugins.json');
    let disabled=[];try{disabled=JSON.parse(fs.readFileSync(disabledFile,'utf8'));if(!Array.isArray(disabled))disabled=[];}catch(_){}
    const roots=[path.join(PANELS_ROOT,'plugins'),path.join(base,'installed-plugins')];
    const result=[];for(const root of roots){
      if(!fs.existsSync(root))continue;
      for(const entry of fs.readdirSync(root,{withFileTypes:true})){
        if(!entry.isDirectory()||entry.isSymbolicLink())continue;
        try{const manifest=JSON.parse(fs.readFileSync(path.join(root,entry.name,'manifest.json'),'utf8'));
          const id=String(manifest.id||'');if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(id))continue;
          const live=(coreState.panels.plugins||[]).find(x=>x.id===id);
          let webReady=false;
          if(manifest.runtime==='web')try{webPlugins.verify(id,roots[0],roots[1]);webReady=true;}catch(_){}
          if(manifest.runtime==='web-service')try{servicePlugins.verify(id,roots[0],roots[1]);webReady=true;}catch(_){}
          const legacyRobot=id==='robotrock-video-factory'&&fs.existsSync(path.join(__dirname,'robotrock-factory','runtime.js'));
          result.push({id,name:String(manifest.name||id),version:String(manifest.version||''),enabled:webPlugins.pluginEnabled(manifest,id,PROFILE_ROOT),status:['web','web-service'].includes(manifest.runtime)?(webReady?'READY':'INVALID'):(legacyRobot?'READY':(live?.status||'NOT_LOADED')),runtime:String(manifest.runtime||'node'),launchable:webReady||legacyRobot,builtin:root===roots[0]});
        }catch(_){}
      }
    }
    return{ok:true,plugins:result};
  });
  // C.Link R343: user-installed web cartridges only. Never touch bundled services.
  let clinkCartridgeBusy=false;
  const clinkManagerCaller=event=>Boolean(windowMain&&!windowMain.isDestroyed()&&event.sender===windowMain.webContents);
  const clinkManager=()=>{
    const {CartridgeManager}=require('./clink-cartridge-manager.cjs');
    return new CartridgeManager({
      bundledRoot:path.join(PANELS_ROOT,'plugins'),
      installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
      quarantineRoot:path.join(PROFILE_ROOT,'panels','quarantined-cartridges')
    });
  };
  const clinkManagerStopped=id=>{
    if(webPluginId||activeWebService)return false;
    if((coreState.panels.plugins||[]).some(p=>p.id===id))return false;
    return true;
  };
  ipcMain.handle('quin:cartridge-manager-list',event=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    try{return{ok:true,...clinkManager().list()};}
    catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
  });
  ipcMain.handle('quin:cartridge-manager-preview',(event,id)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    try{return{ok:true,preview:clinkManager().preview(id)};}
    catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
  });
  ipcMain.handle('quin:cartridge-manager-remove',async(event,input)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'MANAGER_BUSY'};
    clinkCartridgeBusy=true;
    try{
      const id=typeof input?.id==='string'?input.id:'';
      const confirmation=typeof input?.confirmation==='string'?input.confirmation:'';
      const manifestSha256=typeof input?.manifestSha256==='string'?input.manifestSha256:'';
      const manager=clinkManager();
      const preview=manager.preview(id);
      if(confirmation!==id||manifestSha256!==preview.manifestSha256)return{ok:false,error:'PREVIEW_OR_CONFIRMATION_CHANGED'};
      if(!clinkManagerStopped(id))return{ok:false,error:'CLOSE_RUNNING_CARTRIDGES_FIRST'};
      const choice=await dialog.showMessageBox(windowMain,{type:'warning',title:'C.Link Cartridge Uninstall',
        message:`Quarantine ${preview.name} (${id})?`,
        detail:'Only this separately installed web cartridge will be moved to recoverable quarantine. User data, bundled cartridges, sessions and profiles are preserved. Restore is available from Settings.',
        buttons:['CANCEL','QUARANTINE CARTRIDGE'],defaultId:0,cancelId:0,noLink:true});
      if(choice.response!==1)return{ok:false,error:'CANCELLED'};
      if(cartridgeUpdateHost?.isActive()||!clinkManagerStopped(id))return{ok:false,error:'CARTRIDGE_BECAME_ACTIVE'};
      const result=await manager.uninstall({id,confirmation,manifestSha256,stopped:clinkManagerStopped});
      return{ok:true,...result,restartRequired:true};
    }catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
    finally{clinkCartridgeBusy=false;}
  });
  ipcMain.handle('quin:cartridge-manager-restore',async(event,receiptId)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'MANAGER_BUSY'};
    clinkCartridgeBusy=true;
    try{
      const manager=clinkManager();
      if(!manager.list().quarantined.some(r=>r.receiptId===receiptId))return{ok:false,error:'RECEIPT_NOT_FOUND'};
      const choice=await dialog.showMessageBox(windowMain,{type:'question',title:'Restore cartridge?',
        message:'Restore quarantined cartridge?',detail:'Restores package code only. Existing files cannot be overwritten.',
        buttons:['CANCEL','RESTORE CARTRIDGE'],defaultId:0,cancelId:0,noLink:true});
      if(choice.response!==1)return{ok:false,error:'CANCELLED'};
      if(cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_UPDATE_IN_PROGRESS'};
      return{ok:true,...manager.restore(receiptId),restartRequired:true};
    }catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
    finally{clinkCartridgeBusy=false;}
  });
  ipcMain.handle('quin:plugin-toggle',(_event,id,enable)=>{
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    const clean=String(id||'');if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(clean))return{ok:false,error:'INVALID_ID'};
    if(clean==='reasoning-provider-chatgpt-web')return{ok:false,error:'BROWSER_PROVIDER_PROTECTED'};
    const roots=[path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')];
    if(!roots.some(root=>fs.existsSync(path.join(root,clean,'manifest.json'))))return{ok:false,error:'PLUGIN_NOT_FOUND'};
    const base=path.join(PROFILE_ROOT,'panels');fs.mkdirSync(base,{recursive:true});
    const config=path.join(base,'disabled-plugins.json');let disabled=[];
    try{disabled=JSON.parse(fs.readFileSync(config,'utf8'));if(!Array.isArray(disabled))disabled=[];}catch(_){}
    disabled=disabled.filter(x=>x!==clean);if(enable!==true)disabled.push(clean);
    const overrideFile=path.join(base,'enabled-plugins.json');let enabledOverrides=[];
    try{enabledOverrides=JSON.parse(fs.readFileSync(overrideFile,'utf8'));if(!Array.isArray(enabledOverrides))enabledOverrides=[];}catch(_){}
    enabledOverrides=enabledOverrides.filter(x=>x!==clean);if(enable===true)enabledOverrides.push(clean);
    fs.writeFileSync(overrideFile,JSON.stringify(enabledOverrides,null,2)+'\n',{mode:0o600});
    fs.writeFileSync(config,JSON.stringify(disabled,null,2)+'\n',{mode:0o600});
    return{ok:true,enabled:enable===true,restartRequired:true};
  });
  ipcMain.handle('quin:plugin-install',async()=>{
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    const selection=await dialog.showOpenDialog(windowMain,{title:'Install C.Link Cartridge ZIP (code runs locally)',properties:['openFile'],filters:[{name:'C.Link Cartridge ZIP',extensions:['zip']}]});
    if(selection.canceled||!selection.filePaths.length)return{ok:false,error:'CANCELLED'};
    const choice=await dialog.showMessageBox(windowMain,{type:'warning',title:'Install C.Link cartridge?',message:'Cartridges contain executable code. Only install cartridges you trust.',detail:`Selected cartridge: ${path.basename(selection.filePaths[0])}\nThis installs in the current C.Link profile only. Other applications are unchanged.`,buttons:['Cancel','Install Cartridge'],defaultId:0,cancelId:0});
    if(choice.response!==1)return{ok:false,error:'CANCELLED'};
    const installed=path.join(PROFILE_ROOT,'panels','installed-plugins');
    if(cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_UPDATE_IN_PROGRESS'};
    const result=cp.spawnSync('python3',['-I',path.join(__dirname,'tools','install-plugin.py'),selection.filePaths[0],installed,path.join(PANELS_ROOT,'plugins')],{encoding:'utf8',timeout:15000,windowsHide:true,maxBuffer:65536});
    try{return JSON.parse(String(result.stdout||'').trim());}
    catch(_){return{ok:false,error:String(result.error?.message||result.stderr||'INSTALLER_UNAVAILABLE').slice(0,240)};}
  });
  ipcMain.handle('quin:plugin-command',async(_event,input)=>{
    if(!panels||coreState.panels.status!=='READY')return{ok:false,error:'PANELS_NOT_READY'};
    const command=String(input?.command||'');
    if(!['storyboard.plan','storyboard.summary','worker.prepare'].includes(command))return{ok:false,error:'PLUGIN_COMMAND_DENIED'};
    try{return{ok:true,result:await panels.videoFactoryCommand(command,input||{})};}catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:copy-diagnostics',async()=>{const payload=await diagnostic();clipboard.writeText(payload);return{ok:true,bytes:Buffer.byteLength(payload)};});
  ipcMain.handle('clink:retry-panels',async()=>{if(!panels)return{ok:false,error:'PANELS_SUPERVISOR_NOT_READY'};panels.retryFromQuarantine();return{ok:true};});
  ipcMain.handle('clink:inline-auth-start',async()=>{
    // Explicit Human request must work even while hosted lifecycle is STARTING.
    // Inherit IRIS WebContentsView/session.fromPath; do not create an auth subsystem.
    if(!browserRuntime)return{ok:false,error:'QUIN_BROWSER_INITIALIZING_TRY_AGAIN'};
    if(inlineAuthActive)return{ok:true,alreadyOpen:true};
    try{
      const reason=coreState.providerLifecycle?.status==='AUTH_REQUIRED'
        ? (coreState.providerLifecycle?.lastError||'AUTH_REQUIRED') : 'HUMAN_EXPLICIT';
      await startInlineAuthRecovery(reason);
      return{ok:true};
    }catch(error){
      const message=String(error.message||error);
      log('provider.inline-auth.error',{error:message});
      return{ok:false,error:message};
    }
  });
  ipcMain.handle('clink:inline-auth-cancel',async()=>{
    const wasAuthRequired=coreState.providerLifecycle?.status==='AUTH_REQUIRED';
    removeInlineAuthView();
    writeProviderAuthState({
      status:wasAuthRequired?'AUTH_REQUIRED':'HUMAN_DISMISSED',
      lastAuthDismissedAt:new Date().toISOString(),
      loginPolicy:'HUMAN_EXPLICIT_ONLY'
    });
    coreState.inlineAuth={status:'IDLE',detail:'Hosted sign-in dismissed by Human. No automatic retry will occur.',url:'',title:''};
    refreshCompanionState();broadcast();
    return{ok:true};
  });

  ipcMain.handle('clink:provider-key-status',async(_event,provider)=>{
    try{return{ok:true,status:providerSecrets.status(provider)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-key-save',async(_event,provider,value)=>{
    try{return{ok:true,status:providerSecrets.save(provider,value)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-key-clear',async(_event,provider)=>{
    try{return{ok:true,status:providerSecrets.clear(provider)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-test',async(_event,provider)=>{
    try{
      const status=providerSecrets.status(provider);
      if(!status.configured)return{ok:true,status:{...status,state:'NOT_CONFIGURED'}};
      const key=providerSecrets.getForMainProcess(provider);
      const result=await testProviderKey(provider,key,{timeoutMs:10000});
      const tested=providerSecrets.recordTest(provider,result);refreshCompanionState();broadcast();return{ok:true,status:tested};
    }catch(error){
      // R378: classify native credential failure without exposing error text or API keys.
      const known=new Set(['SECURE_STORAGE_DECRYPT_FAILED','SECURE_STORAGE_UNAVAILABLE','PROVIDER_UNSUPPORTED']);
      const raw=String(error?.message||'');
      const category=known.has(raw)?raw:'PROVIDER_TEST_HANDLER_ERROR';
      const state=category==='SECURE_STORAGE_DECRYPT_FAILED'?'CREDENTIAL_UNREADABLE':category==='SECURE_STORAGE_UNAVAILABLE'?'SECURE_STORAGE_UNAVAILABLE':'PROVIDER_HANDLER_ERROR';
      log('api.provider.test.failure.safe',{provider:String(provider||'').toLowerCase(),errorClass:category});
      try{return{ok:true,status:providerSecrets.recordTest(provider,{state,httpStatus:null})};}
      catch(_){return{ok:false,error:'PROVIDER_TEST_UNAVAILABLE'};}
    }
  });

  ipcMain.handle('clink:provider-response-test',async(_event,provider)=>{
    const id=String(provider||'').toLowerCase();
    const tests={
      openai:{input:'Reply with exactly: CLINK API OK',model:'gpt-5.6-luna'},
      xai:{input:'Reply with exactly: CLINK XAI OK',model:'grok-4.3'}
    };
    const test=tests[id];
    if(!test)return{ok:false,error:'PROVIDER_ADAPTER_NOT_IMPLEMENTED'};
    const envelope=await providerAdapters.createResponse(id,{...test,maxOutputTokens:32,store:false,companionId:'system-control',missionId:MISSION,workerId:null,purpose:'provider_response_test'});
    const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
    providerSecrets.recordTest(id,{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
    log('api.provider.response.test',{
      provider:id,status:envelope.status,model:envelope.model,responseId:envelope.responseId||'',
      errorClass:envelope.error?.class||null,httpStatus:envelope.error?.httpStatus??null,usage:envelope.usage
    });
    coreState.apiUsage=apiUsage.summary();refreshCompanionState();broadcast();
    return {ok:!envelope.error,envelope,status:providerSecrets.status(id),usage:coreState.apiUsage};
  });

  ipcMain.handle('clink:api-usage-snapshot',async()=>{try{return{ok:true,usage:apiUsage.summary()};}catch(error){return{ok:false,error:String(error.message||error)};}});
  ipcMain.handle('clink:api-budget-save',async(_event,value)=>{
    try{const budget=apiUsage.setBudget({monthlyBudgetUsd:value});coreState.apiUsage=apiUsage.summary();broadcast();return{ok:true,budget,usage:coreState.apiUsage};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:api-usage-proof',async()=>{
    const tests=[['openai',{input:'Reply with exactly: USAGE OK',model:'gpt-5.6-luna'}],['xai',{input:'Reply with exactly: USAGE OK',model:'grok-4.3'}]];
    const results=[];
    for(const [provider,test] of tests){
      const envelope=await providerAdapters.createResponse(provider,{...test,maxOutputTokens:24,store:false,companionId:'alpha007',missionId:MISSION,workerId:null,purpose:'round6_usage_proof'});
      results.push({provider,ok:!envelope.error,status:envelope.status,model:envelope.model,requestId:envelope.requestId,errorClass:envelope.error?.class||null,usage:envelope.usage});
      const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
      providerSecrets.recordTest(provider,{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
    }
    coreState.apiUsage=apiUsage.summary();log('api.usage.proof.complete',{status:results.every(r=>r.ok)?'PASS':'FAIL',providers:results.map(r=>({provider:r.provider,ok:r.ok,model:r.model,requestId:r.requestId,totalTokens:r.usage?.totalTokens||0}))});broadcast();
    return{ok:results.every(r=>r.ok),results,usage:coreState.apiUsage};
  });

  ipcMain.handle('clink:alpha-shadow-test',async()=>{
    if(coreState.apiShadow.status==='RUNNING')return{ok:false,error:'ALPHA_SHADOW_ALREADY_RUNNING'};
    coreState.apiShadow={status:'RUNNING',detail:'Running two fresh disposable OpenAI shadow sessions from the Round 5 context builder.',provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null};broadcast();
    try{
      const proof=await alphaShadowRunner().run();
      coreState.apiShadow={status:proof.status,detail:proof.status==='PASS'?'Two fresh API sessions reconstructed Alpha from the deterministic C.Link context builder.':'Alpha shadow proof failed; no promotion authorized.',provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:proof};
      const transportReady=Boolean(proof.session1?.responseId&&proof.session2?.responseId&&!proof.session1?.error&&!proof.session2?.error);
      providerSecrets.recordTest('openai',{state:transportReady?'READY':'OTHER_ERROR',httpStatus:transportReady?200:null});
      broadcast();
      return{ok:proof.status==='PASS',proof};
    }catch(error){
      const message=String(error.message||error);
      coreState.apiShadow={status:'FAIL',detail:message,provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null};broadcast();
      return{ok:false,error:message};
    }
  });

  ipcMain.handle('clink:context-restart-proof',async()=>{
    try{
      const proof=contextBuilder.armRestartProof();
      coreState.apiContext={...contextBuilder.snapshot(),reconstruction:{status:'WAITING_FOR_RESTART',detail:'C.Link will relaunch and compare the independently reconstructed context fingerprint.'}};
      broadcast();
      setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
      return{ok:true,proof,relaunch:true};
    }catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:context-reconstruction-test',async()=>{
    const state=contextBuilder.snapshot();
    if(state.restartProof?.status!=='PASS')return{ok:false,error:'CONTEXT_RESTART_PROOF_REQUIRED',context:state};
    try{
      const built=contextBuilder.build();
      const result=await alphaShadowRunner().one(5);
      const pass=result.status==='PASS';
      const reconstruction={status:pass?'PASS':'FAIL',detail:pass?'Fresh OpenAI reasoning reconstructed Alpha from the post-restart deterministic context.':'Post-restart Alpha reconstruction failed semantic invariants.',contextFingerprint:built.builder.contextFingerprint,sourceMapHash:built.builder.sourceMapHash,sourceCount:built.builder.sourceOrder.length,archiveBulkIncluded:false,provider:'openai',model:result.model||'gpt-5.6-luna',requestId:result.requestId,responseId:result.responseId,providerConversationAuthority:false,persistProviderSessionIds:false,machineMutation:false,verification:result.verification,usage:result.usage||{},completedAt:new Date().toISOString()};
      coreState.apiContext={...contextBuilder.snapshot(),reconstruction};
      const transportReady=Boolean(result.responseId&&!result.error);
      providerSecrets.recordTest('openai',{state:transportReady?'READY':'OTHER_ERROR',httpStatus:transportReady?200:null});
      log('api.context.reconstruction.complete',{status:reconstruction.status,contextFingerprint:reconstruction.contextFingerprint,sourceMapHash:reconstruction.sourceMapHash,sourceCount:reconstruction.sourceCount,archiveBulkIncluded:false,responseId:result.responseId||'',checks:result.verification?.checks||{},persistProviderSessionIds:false,machineMutation:false});
      broadcast();return{ok:pass,reconstruction};
    }catch(error){
      const message=String(error.message||error);coreState.apiContext={...contextBuilder.snapshot(),reconstruction:{status:'FAIL',detail:message}};broadcast();return{ok:false,error:message};
    }
  });

  ipcMain.handle('clink:system-command',async(_event,input)=>{
    const value=String(input||'').trim().replace(/^\//,'');
    if(!value)return{ok:false,error:'EMPTY_COMMAND'};
    if(!panels||coreState.panels.status!=='READY')return{ok:false,error:'PANELS_NOT_READY'};
    try{const result=await panels.sendIntent(value,['TORTURE','SELFTEST'].includes(value.toUpperCase())?120000:12000);return{ok:true,text:result.text||'',command:result.command||null};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });

  // R203 candidate: ZIP import is an offline staging operation, not companion activation.
  // Local terminal renderer only; untrusted pages never receive this IPC surface.
  // R208: central, shell-only, single-flight ZIP import/activation IPC controller.
  const companionZipIpc = createCompanionActivationIpc({
    getWindow:()=>windowMain,
    dialog,
    intake:companionZipIntake,
    backpacks:backpackManager,
    seat:companionTurnSeat,
    recovery:companionActivationRecovery,
    onActivated:()=>{alphaRecentTurns=[];companionOrchestrator.initialize(backpackManager.snapshot());refreshCompanionState();broadcast();},
    logger:log
  });
  ipcMain.handle('clink:companion-zip-pick',companionZipIpc.pick);
  ipcMain.handle('clink:companion-zip-stage',companionZipIpc.stage);
  ipcMain.handle('clink:companion-zip-roster',companionZipIpc.roster);
  ipcMain.handle('clink:companion-zip-activate',companionZipIpc.activate);
  // Miss Spock R315: keep the Companion roster in sync with ~/PhantomTronix/AgentShelf and ~/Downloads, automatically.
  // New capsules are verified and staged; a newer revision of the ACTIVE Companion is activated through the same transaction.
  try{
    const agentShelf=createAgentShelf({intake:companionZipIntake,backpacks:backpackManager,seat:companionTurnSeat,recovery:companionActivationRecovery,
      onActivated:()=>{alphaRecentTurns=[];companionOrchestrator.initialize(backpackManager.snapshot());refreshCompanionState();broadcast();},logger:log});
    agentShelf.start();
  }catch(error){log('agent_shelf.start_failed',{message:String(error?.message||error)});}
  ipcMain.handle('clink:companion-message',async(event,input)=>{
    if(!windowMain||event.sender!==windowMain.webContents||event.senderFrame!==windowMain.webContents.mainFrame)return{ok:false,error:'SHELL_ONLY'};
    return primaryCompanionMessage(input,{technical:false});
  });
  ipcMain.handle('clink:grok-companion-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'NONCANONICAL_GROK_COMPANION_ROUTE_DISABLED'};
    return grokUserCompanionMessage(input);
  });
  ipcMain.handle('clink:alpha-technical-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'ALPHA_TECHNICAL_ROUTE_NOT_UNIVERSAL'};
    return alphaPrimaryMessage(input,{technical:true});
  });
  ipcMain.handle('clink:hosted-companion-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'HOSTED_COMPANION_ROUTE_NOT_UNIVERSAL'};
    apiPrimarySoak.noteHostedFallbackInvocation();coreState.apiPrimary=apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null});broadcast();
    return hostedCompanionMessage(input);
  });
  ipcMain.handle('clink:r8-worker-state',async()=>({ok:true,state:{...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD}}));
  ipcMain.handle('clink:r8-run-workers',async()=>({ok:false,error:'R8_FIELD_PROVEN_CLOSED_NO_RERUN',state:readOnlyWorkers.snapshot()}));
  ipcMain.handle('clink:r9-state',async()=>({ok:true,state:round9.snapshot()}));
  ipcMain.handle('clink:r9-run-reconciliation',async()=>{
    const result=await round9.run();coreState.round9=round9.snapshot();coreState.apiUsage=apiUsage.summary();broadcast();return result;
  });
  ipcMain.handle('clink:r9-restart',async()=>{
    const armed=round9.armRestart();coreState.round9=round9.snapshot();broadcast();
    if(!armed.ok)return armed;
    setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
    return{ok:true,relaunch:true,state:round9.snapshot()};
  });

  ipcMain.handle('clink:r7-restart',async()=>{
    coreState.apiPrimary=apiPrimarySnapshot({fieldStatus:'R7_RESTARTING',lastTurn:coreState.apiPrimary?.lastTurn||null});broadcast();
    setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
    return{ok:true,relaunch:true,soak:apiPrimarySoak.snapshot()};
  });

  ipcMain.handle('clink:force-relay',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'LEGACY_SPECIALIST_RELAY_NOT_UNIVERSAL'};
    const value=String(input||'').trim();
    if(!value)return{ok:false,error:'EMPTY_RELAY_PROBLEM'};
    if(!providerReady())return{ok:false,error:'COMPANION_PROVIDER_NOT_READY'};
    const incident=normalizeIncident({summary:value,evidence:[`Human explicitly requested relay: ${value}`]},value);
    const state=await runRelayForIncident(incident,null);
    const run=state.run;
    const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
    return{ok:run?.status==='PASS',reply:String(final?.humanReply||final?.summary||run?.conclusion||''),state,error:run?.error||null};
  });

  ipcMain.handle('clink:relay-selftest',async()=>{
    try{
      companionOrchestrator.assertInvariant();
      const bags=backpackManager.snapshot();
      if(bags.systemControl?.mutability!=='READ_ONLY'||!bags.systemControl?.sha256)throw new Error('SYSTEM_CONTROL_BACKPACK_NOT_VERIFIED');
      if(!bags.userCompanion?.sha256)throw new Error('USER_COMPANION_BACKPACK_NOT_VERIFIED');
      const registry=companionOrchestrator.snapshot();for(const id of ['redteam','fabric','control','throughput'])if(registry.chats?.[id]?.backpack!==null)throw new Error(`SPECIALIST_BACKPACK_FORBIDDEN:${id}`);
      const state=await relay.dryRun({field:true});coreState.relay=state;coreState.companionCore=companionOrchestrator.snapshot();broadcast();
      return{ok:true,state,companionCore:coreState.companionCore,backpacks:bags};
    }catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:sync-lifecycle',async()=>syncProviderLifecycle(true));

  ipcMain.handle('clink:message-qualification',async()=>runMessageQualification());

  ipcMain.handle('clink:about-boundary',async()=>{
    await dialog.showMessageBox(windowMain,{
      type:'info',title:'Quin Browser — IRIS-derived Foundation',
      message:'Round 9 reconciles the field-proven two-worker experiment, tears worker sessions down, restarts C.Link, and proves Alpha returns without worker-session persistence.',
      detail:'Rounds 1-8 are field-proven. Round 9 adds no worker authority and no concurrency increase. Alpha compares the two-worker result against a single-Alpha baseline, explicitly adopts/adapts/rejects/defers each worker finding, preserves disagreement, keeps usage/cost evidence, and remains API PRIMARY after restart. Repair execution stays OFF.'
    });
    return{ok:true};
  });
}

// BEGIN CLINK_NATIVE_EDIT_MENU_015
function attachNativeEditMenu(wc, isAllowed) {
  // Native user-initiated editing only: no clipboard IPC or renderer permission.
  wc.on('context-menu', (_event, params) => {
    if (wc.isDestroyed() || !isAllowed(params)) return;
    const flags = params.editFlags || {};
    const editable = params.isEditable === true;
    const selected = Boolean(params.selectionText);
    const item = (label, method, enabled) => ({ label, enabled: Boolean(enabled), click: () => {
      if (!enabled || wc.isDestroyed() || !isAllowed(params)) return;
      wc.focus();
      wc[method]();
    }});
    const sep = {type:'separator'};
    const template = editable ? [
      item('Undo','undo',flags.canUndo), item('Redo','redo',flags.canRedo), sep,
      item('Cut','cut',flags.canCut), item('Copy','copy',flags.canCopy),
      item('Paste','paste',flags.canPaste), item('Delete','delete',flags.canDelete), sep,
      item('Select All','selectAll',flags.canSelectAll)
    ] : [item('Copy','copy',selected && flags.canCopy), item('Select All','selectAll',flags.canSelectAll)];
    // Do not intercept game mouse controls or remote browser contexts.
    if (!editable && !selected) return;
    require('electron').Menu.buildFromTemplate(template).popup({window:windowMain});
  });
}
// END CLINK_NATIVE_EDIT_MENU_015

// R044: read-only native version and transaction visibility. No new IPC or permissions.
function clinkNativeStatus(root) {
  const version = v => typeof v === 'string' && /^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(v);
  const digest = v => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);
  function read(relative) {
    let fd;
    try {
      const file = path.join(root, relative);
      if (fs.realpathSync(file) !== file) return null;
      fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      const s = fs.fstatSync(fd);
      if (!s.isFile() || s.size > 4096 || s.nlink !== 1 || (s.mode & 0o022) || (process.getuid && s.uid !== process.getuid())) return null;
      return JSON.parse(fs.readFileSync(fd, 'utf8'));
    } catch (_) { return null; } finally { if (fd !== undefined) fs.closeSync(fd); }
  }
  const p = read('package.json'), a = read('.clink-native-update/last-attempt.json'), r = read('.clink-native-update/last-result.json');
  const installed = version(p?.clinkNativeVersion) ? p.clinkNativeVersion : 'UNKNOWN';
  const attempt = version(a?.version) && version(a?.fromVersion) && digest(a?.sha256) ? a : null;
  const receipt = version(r?.version) && version(r?.fromVersion) && digest(r?.archiveSha256) && ['COMMITTED','ROLLED_BACK'].includes(r?.status) ? r : null;
  const pending = fs.existsSync(path.join(root,'.clink-native-update','transaction'));
  return {installed, target: attempt?.version || receipt?.version || 'UNKNOWN',
    status: pending ? 'TRIAL / RECOVERY PENDING' : receipt ? `${receipt.version} — ${receipt.status}` : 'NO COMPLETED TRANSACTION',
    availability: 'LATEST STABLE: NOT VERIFIED YET'};
}
// Select the highest independently verified offer for display only.
function clinkLatestVerifiedOffer(w, doc, policy, approval, arch) {
  const rows = doc?.schema === w.SCHEMA ? [doc] :
    doc?.schema === 'clink.native-discovery.v1' && Object.keys(doc).sort().join(',') === 'releases,schema' ? doc.releases : null;
  if (!Array.isArray(rows) || rows.length > 64) throw Error('DISPLAY_FEED_SCHEMA');
  const valid = [];
  for (const e of rows) {
    try { valid.push(w.verify(e, policy, approval, e?.release?.fromVersion, arch)); } catch (_) {}
  }
  const cmp = (a,b) => { const x=a.split('.').map(Number), y=b.split('.').map(Number); for(let i=0;i<3;i++) if(x[i]!==y[i]) return x[i]-y[i]; return 0; };
  valid.sort((a,b)=>cmp(b.version,a.version));
  if (!valid.length) throw Error('DISPLAY_NO_VERIFIED_OFFER');
  const top=valid[0];
  if(valid.some(r=>r.version===top.version && w.canonical(r)!==w.canonical(top))) throw Error('DISPLAY_CONFLICTING_OFFERS');
  return top;
}
// Check the same signed stable feed using the existing pinned transport/verifier.
// This is display-only; never stages, installs, or changes a trust decision.
async function clinkCheckNativeFeed(root) {
  const helper = path.join(path.dirname(root),'native-updater');
  const checked = (name, pin, limit=65536) => {
    const file = path.join(helper,name), st = fs.lstatSync(file);
    if (fs.realpathSync(file)!==file || !st.isFile() || st.nlink!==1 || st.size>limit || (st.mode&0o077) || (process.getuid && st.uid!==process.getuid())) throw Error('DISPLAY_HELPER_UNSAFE');
    const b=fs.readFileSync(file);
    if(pin && crypto.createHash('sha256').update(b).digest('hex')!==pin) throw Error('DISPLAY_HELPER_DRIFT');
    return b;
  };
  let temp;
  try {
    checked('native-startup.py','d4b4a257f4a9c3a86a4cd3db82628d85a8edd859a86c3764570772be16570a89');
    checked('native-release-wire.cjs','91255daeb80cf7e3457d3584489a89515c71e609694e8c26335deb8f93bbe5b0');
    const c=JSON.parse(checked('config.json',null));
    const w=require(path.join(helper,'native-release-wire.cjs'));
    if(c.approval!=='a7e3ac417559677e0e5b453897b6b685a37719e8085601d5b76af6d806b4c7e6' || w.trustFingerprint(c.policy)!==c.approval || c.arch!=='x64')throw Error('DISPLAY_TRUST_MISMATCH');
    temp=fs.mkdtempSync(path.join(os.tmpdir(),'clink-status-'));
    const dest=path.join(temp,'manifest.json');
    await new Promise((resolve,reject)=>cp.execFile('/usr/bin/python3',[path.join(helper,'native-startup.py'),'--fetch',w.FEED,dest,'65536','8'],{timeout:10000,maxBuffer:4096},e=>e?reject(e):resolve()));
    const st=fs.lstatSync(dest); if(!st.isFile()||st.size>65536)throw Error('DISPLAY_FEED_SIZE');
    const doc=JSON.parse(fs.readFileSync(dest,'utf8'));
    const r=clinkLatestVerifiedOffer(w,doc,c.policy,c.approval,c.arch);
    return `LATEST VERIFIED STABLE: ${r.version} (checked this startup)`;
  } catch (_) {return 'LATEST STABLE: VERIFICATION UNAVAILABLE';}
  finally {if(temp)try{fs.rmSync(temp,{recursive:true,force:true});}catch(_){}}
}
function clinkRenderNativeStatus(data, expectedUrl) {
  if (location.href !== expectedUrl) return false;
  const foot = document.getElementById('clink-r358-foot')?.querySelector('span');
  if (foot) {
    const label = `C.LINK / VERSION ${data.installed}`;
    if (foot.textContent !== label) foot.textContent = label;
  }
  const anchor = document.getElementById('diagnosticsCopyStatus');
  if (anchor && anchor.closest('#settingsPanel')) {
    let box = document.getElementById('clink-native-version-status');
    if (!box) {
      box = document.createElement('div'); box.id = 'clink-native-version-status';
      box.className = 'settings-note'; box.setAttribute('role','status');
      anchor.before(box);
    }
    const label = `INSTALLED: ${data.installed} · LAST VERIFIED TARGET: ${data.target}\nUPDATE: ${data.status}\n${data.availability}`;
    box.style.whiteSpace = 'pre-line';
    if (box.textContent !== label) box.textContent = label;
  }
  return Boolean(foot && anchor);
}
function clinkAttachNativeStatus(win, localUrl) {
  const wc = win.webContents;
  let timer, busy = false, checked = false, availability = 'LATEST STABLE: CHECKING';
  async function refresh() {
    if (busy || win.isDestroyed() || wc.isDestroyed() || wc.getURL() !== localUrl) return;
    busy = true;
    try {
      const data = clinkNativeStatus(path.resolve(__dirname,'..'));
      data.availability = availability;
      await wc.executeJavaScript(`(${clinkRenderNativeStatus.toString()})(${JSON.stringify(data)},${JSON.stringify(localUrl)})`,false);
    } catch (_) { /* Display failure cannot interfere with startup or rollback. */ }
    finally { busy = false; }
  }
  wc.on('did-finish-load', () => {
    if(wc.getURL()!==localUrl)return;
    void refresh();
    if (!timer) timer = setInterval(refresh, 2000);
    if (!checked) {checked=true;void clinkCheckNativeFeed(path.resolve(__dirname,'..')).then(value=>{availability=value;void refresh();});}
  });
  win.once('closed', () => { if (timer) clearInterval(timer); });
}
// END R044

function createWindow() {
  const isLinux=process.platform==='linux';
  const windowOptions={width:1024,height:768,minWidth:720,minHeight:520,show:false,autoHideMenuBar:true,backgroundColor:'#111111',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}};
  if(isLinux){windowOptions.fullscreen=true;windowOptions.icon=APP_ICON;windowOptions.title='Phantom-Tronix Quinquedent Browser';}
  windowMain=new BrowserWindow(windowOptions);
  // Only Quin's local top-level UI may use the microphone. Remote provider
  // surfaces and embedded web pages have no microphone permission.
  const localFileUrl=require('url').pathToFileURL(path.join(__dirname,'renderer','index.html')).href;
  const shellContents = windowMain.webContents;
  attachNativeEditMenu(shellContents, params => Boolean(windowMain && !windowMain.isDestroyed() &&
    windowMain.webContents===shellContents && shellContents.getURL().split(/[?#]/)[0]===localFileUrl &&
    String(params.frameURL||'').split(/[?#]/)[0]===localFileUrl));
  const canUseMicrophone=(wc,permission,requestingUrl)=>Boolean(
    permission==='media'&&wc&&wc.id===windowMain?.webContents?.id&&
    windowMain.webContents.getURL().split(/[?#]/)[0]===localFileUrl&&
    typeof requestingUrl==='string'&&(requestingUrl.split(/[?#]/)[0]===localFileUrl||requestingUrl==='file://'));
  const localSession=windowMain.webContents.session;
  localSession.setPermissionRequestHandler((wc,permission,callback,details)=>{
    if(permission==='media')return callback(canUseMicrophone(wc,permission,details?.requestingUrl));
    callback(false);
  });
  localSession.setPermissionCheckHandler((wc,permission,origin,details)=>{
    if(permission==='media')return canUseMicrophone(wc,permission,details?.requestingUrl||origin);
    return false;
  });
  clinkAttachNativeStatus(windowMain, localFileUrl);
  windowMain.loadFile(path.join(__dirname,'renderer','index.html'));
  windowMain.on('resize',()=>{layoutInlineAuthView();layoutWebPlugin();restrictedBrowserCartridge?.resize();});
  if(isLinux){
    // Own shutdown at the WM close request, before the native X11 surface disappears.
    windowMain.on('close',()=>{
      boot('MAIN_WINDOW_CLOSE_EVENT platform=linux');
      requestAppQuit();
    });
  }
  windowMain.on('closed',()=>{closeWebPlugin();try{restrictedBrowserCartridge?.destroy();}catch(_){} restrictedBrowserCartridge=null;
    boot(`MAIN_WINDOW_CLOSED_EVENT platform=${process.platform}`);
    try{restrictedBrowserCartridge?.destroy();}catch(_){}
    restrictedBrowserCartridge=null;
    windowMain=null;
    requestAppQuit();
  });
  windowMain.once('ready-to-show',()=>{
    if(isLinux)windowMain.setFullScreen(true);else windowMain.maximize();
    windowMain.show();
    coreState.core={status:'HEALTHY',detail:'Quin: IRIS-derived browser core ready; PANELS plugin management enabled.'};
    log('core.ready',coreState.core);broadcast();
    setTimeout(()=>{
      browserRuntime=new CLinkBrowserRuntime({profileRoot:QUIN_PROFILE_ROOT,logger:log});
      writeProviderAuthState({
        canonicalSessionPath:browserRuntime.sessionPath,
        sessionPolicy:'ONE_PERSISTENT_QUIN_SESSION_ACROSS_BUILDS',
        loginPolicy:'HUMAN_EXPLICIT_ONLY'
      });
      panels=new PanelsSupervisor({
        panelsRoot:PANELS_ROOT,
        profileRoot:PROFILE_ROOT,
        logger:log,
        browserRuntime,
        workspaceBindingResolver:()=>companionOrchestrator.snapshot()?.workspace||null
      });
      panels.on('state',setPanels);
      panels.start().then(async(state)=>{
        if(!process.env.CLINK_UPDATE_HEALTH||state?.status!=='READY'||panels.snapshot().status!=='READY')return;
        try{
          await require(path.join(__dirname,'..','..','native-updater','native-health.cjs')).acknowledge({window:windowMain,root:path.resolve(__dirname,'..'),panelsReady:true});
        }catch(error){log('native.update.health.error',{error:String(error.message||error).slice(0,120)});}
      }).catch(error=>log('panels.bootstrap.error',{error:String(error.message||error)}));
    },150);
  });
}

// R371 launch proof: read-only shell/bridge check; no browser navigation.
if(process.env.CLINK_R371_SMOKE_MARKER){
 const fs371=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let wrote=false;
  win.webContents.on('did-finish-load',()=>setTimeout(async()=>{
   if(wrote||win.isDestroyed())return;
   let details={ok:false};
   try{details=await win.webContents.executeJavaScript(`(()=>{
     const c=typeof window.__CLINK_R371_CHECK__==='function'
      ?window.__CLINK_R371_CHECK__():null;
     return {ok:!!c?.installed&&!!c.logoAccessible&&!!c.nativeBridge&&!!c.shell,
       navigationReadOnly:true,cartNotOpened:true,browserNotOpened:true,checks:c};
   })()`,true);}catch(error){details={ok:false,error:String(error)};}
   const record={loaded:true,visible:win.isVisible(),details,pid:process.pid};
   try{fs371.writeFileSync(process.env.CLINK_R371_SMOKE_MARKER,JSON.stringify(record));wrote=true;}catch(_){ }
  },2000));
 });
}

const gotLock=app.requestSingleInstanceLock();
boot(`PROCESS_START pid=${process.pid} exec=${process.execPath} electron=${process.versions.electron||''}`);
if(!gotLock){boot('SINGLE_INSTANCE_LOCK=DENIED');app.quit();}
else{
  boot('SINGLE_INSTANCE_LOCK=ACQUIRED');
  app.on('second-instance',()=>{if(windowMain){if(windowMain.isMinimized())windowMain.restore();windowMain.focus();}});
  require(path.join(__dirname,'..','..','native-updater','native-focus.cjs')).start(path.join(__dirname,'..','..','native-updater'),()=>windowMain);
  installIpc();
  app.whenReady().then(()=>{
    // Miss Spock R317: dark everywhere. Sites that follow the system theme (ChatGPT, YouTube) load dark, no white screens.
    try{nativeTheme.themeSource='dark';}catch(_){}
    webPluginSession=session.fromPartition('persist:quin-graphical-cartridges');
    cartridgeVoiceHost.permissions(webPluginSession);
    webPluginSession.protocol.handle('quinplugin',async req=>{
      try{
        const parsed=new URL(req.url);const id=parsed.hostname;
        const rec=webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins'));
        if(!webPlugins.pluginEnabled(rec.manifest,id,PROFILE_ROOT))return new Response('Disabled',{status:403});
        const asset=webPlugins.resolveAsset(rec,req.url);
        return new Response(fs.readFileSync(asset.file),{status:200,headers:{'Content-Type':asset.type,'Content-Security-Policy':webPlugins.cspFor(id),'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'}});
      }catch(_){return new Response('Not found',{status:404});}
    });
    webPluginSession.protocol.handle('quinservice',async req=>{
      try{return await servicePlugins.proxy(activeWebService,req);}
      catch(_){return new Response('Service request rejected',{status:502});}
    });
    boot('APP_WHEN_READY');ensureLinuxDesktopIdentity();createWindow();
  // L1 recovery is invoked only on real Quin boot. No new assignments are generated here.
  setTimeout(()=>{try{const r=quinL1().resumeAfterBoot();boot('L1_RESUME '+String(r?.task?.status||r?.error||'IDLE'));}catch(e){boot('L1_RESUME_BLOCKED '+String(e.message||e).slice(0,90));}},1300);
});
}
function shutdownRuntime(){
  if(shutdownPromise)return shutdownPromise;
  shutdownStarted=true;
  shutdownPromise=(async()=>{
    removeInlineAuthView();
    closeWebPlugin();
    await flushProviderSession('CLEAN_SHUTDOWN');
    if(panels){try{panels.stop();}catch(_){}}
    if(browserRuntime){try{browserRuntime.shutdown();}catch(_){}}
  })();
  return shutdownPromise;
}
function requestAppQuit(reason='APPLICATION_QUIT'){
  dh025Recovery.cancel(typeof reason==='string'?reason:'APPLICATION_QUIT');developmentAcceptance.cancel();
  if(quitScheduled)return;
  quitScheduled=true;
  boot(`QUIT_REQUESTED platform=${process.platform}`);
  shutdownRuntime().finally(()=>{
  if(process.platform==='linux'){
    setTimeout(()=>{
      boot('LINUX_EXIT_AFTER_CLEANUP');
      try{app.exit(0);}catch(_){}
    },900);
  }else{
    setTimeout(()=>{try{app.quit();}catch(_){}},700);
  }
  });
}
app.on('window-all-closed',()=>{requestAppQuit();});
app.on('before-quit',()=>{shutdownRuntime().catch(()=>{});});
process.on('SIGTERM',()=>{requestAppQuit('OS_SIGTERM');});
process.on('SIGINT',()=>{requestAppQuit('OS_SIGINT');});

module.exports={BUILD,MISSION};

} // End normal Quin initialization (else branch when Companion recovery is safe).
