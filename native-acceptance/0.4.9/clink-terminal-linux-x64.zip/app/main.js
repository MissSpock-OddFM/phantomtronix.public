'use strict';
const { app, BrowserWindow, WebContentsView, ipcMain, clipboard, dialog, safeStorage, protocol, session, nativeTheme } = require('electron');
const fs = require('fs');
const webPlugins=require('./core/quin-web-plugins');
const servicePlugins=require('./core/quin-service-plugins');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const cp = require('child_process');
const { PanelsSupervisor } = require('./core/panels-supervisor');
const { AgentRelay } = require('./core/agent-relay');
const { RelayPackageStore } = require('./core/relay-package');
const { admitRepairProposal } = require('./core/repair-admission');
const { CLinkBrowserRuntime, REQUIRED_ELECTRON } = require('./core/browser-runtime');
const { TEST_SIZES } = require('./core/message-qualification');
const { BackpackManager } = require('./core/backpack-manager');
const { AliceSeatService } = require('./core/alice-seat-service');
const {QuinL1Runner,OBJECTIVE: L1_OBJECTIVE}=require('./core/quin-l1-runner');
const aliceCbVoice = require('./core/alice-cb-voice');
const { CompanionZipIntake } = require('./core/companion-zip-intake.cjs');
const { createAgentShelf } = require('./core/agent-shelf.cjs'); // Miss Spock R315: automatic agent shelf sync
const { CompanionActivationRecovery } = require('./core/companion-activation-recovery.cjs');
const { checkCompanionStartup } = require('./core/companion-startup-preflight.cjs');
const { createRecoveryShell } = require('./core/companion-recovery-shell.cjs');
const { UniversalCompanionPrimary } = require('./core/universal-companion-primary.cjs');
const { CompanionTurnSeat, CommandStationSeats } = require('./core/companion-turn-seat.cjs');
const { createCompanionActivationIpc } = require('./core/companion-activation-ipc.cjs');
const { RestrictedBrowserCartridge } = require('./core/restricted-browser-cartridge.cjs');
const { CompanionChatGPTBridge } = require('./core/companion-chatgpt-bridge.cjs');
const { CompanionOrchestrator } = require('./core/companion-orchestrator');
const { ProviderSecretStore } = require('./core/provider-secret-store');
const { testProviderKey } = require('./core/provider-connectivity');
const { ProviderAdapterRegistry } = require('./core/provider-adapter-registry');
const { AlphaShadowRunner } = require('./core/alpha-shadow-runner');
const { CompanionContextBuilder } = require('./core/companion-context-builder');
const { ApiUsageLedger } = require('./core/api-usage-ledger');
const { AlphaPrimaryRunner } = require('./core/alpha-primary-runner');
const { ApiPrimarySoak } = require('./core/api-primary-soak');
const { ReadOnlyWorkerExperiment } = require('./core/read-only-worker-experiment');
const { Round9Reconciliation } = require('./core/round9-reconciliation');
const { explicitSpecialistRelayRequested: specialistRelayRequested } = require('./core/relay-intent');

const BUILD = 'Quin-0.1.0-alpha-c42-fork';
const MISSION = 'QUIN_FORK_002_Browser_PANELS_RobotRock';
const R8_MISSION = 'AM-032R8A_WORKER_STRUCTURED_REPORT_HOTFIX';
const FIELD_TEST_MODE = process.env.CLINK_FIELD_TEST_MODE === '1';
const PROFILE_ROOT_OVERRIDE = FIELD_TEST_MODE ? String(process.env.CLINK_PROFILE_ROOT||'').trim() : '';
if (FIELD_TEST_MODE && !PROFILE_ROOT_OVERRIDE) throw new Error('CLINK_FIELD_TEST_PROFILE_ROOT_REQUIRED');
const PROFILE_ROOT = PROFILE_ROOT_OVERRIDE ? path.resolve(PROFILE_ROOT_OVERRIDE) : path.join(app.getPath('appData'), 'PhantomTronix', 'Quin');
const QUIN_PROFILE_ROOT = path.join(app.getPath('appData'), 'PhantomTronix', 'Quin');
const PROVIDER_AUTH_DIR = path.join(QUIN_PROFILE_ROOT,'providers','chatgpt-web');
const PROVIDER_AUTH_STATE_FILE = path.join(PROVIDER_AUTH_DIR,'auth-state.json');
const APP_ICON = path.join(__dirname, 'assets', 'clink-icon.png');
const LINUX_DESKTOP_ID = 'com.phantomtronix.clink';
const LINUX_DESKTOP_NAME = `${LINUX_DESKTOP_ID}.desktop`;
const LINUX_DURABLE_APP_DIR = path.join(os.homedir(),'.local','share','phantomtronix','quin','current');
const LINUX_DURABLE_LAUNCHER = path.join(os.homedir(),'.local','bin','phantomtronix-quin');
const LINUX_RUNTIME_CACHE = path.join(QUIN_PROFILE_ROOT,'runtime','electron-path');
let shutdownStarted=false;
let shutdownPromise=null;
let quitScheduled=false;
let inlineAuthView=null;
let inlineAuthPoll=null;
let inlineAuthActive=false;
const PANELS_ROOT = path.join(__dirname, 'panels-os');
const LOG_DIR = path.join(PROFILE_ROOT, 'logs', 'vanilla-core');
const LOG_FILE = path.join(LOG_DIR, 'AM027R28B.jsonl');
const BOOT_LOG = path.join(LOG_DIR, 'AM027R28B-BOOT.txt');
const QUAL_DIR = path.join(PROFILE_ROOT,'qualification');
const QUAL_LATEST = path.join(QUAL_DIR,'browser-message-throughput-latest.json');
const QUAL_HISTORY = path.join(QUAL_DIR,'browser-message-throughput-history.jsonl');
const TERMINAL_SESSION_ID = `TERM-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

protocol.registerSchemesAsPrivileged(['quinplugin','quinservice'].map(scheme=>({scheme,privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true}})));
app.setName('PhantomTronix C.Link Terminal');

// R365: read-only GUI acceptance. Never navigate Browser during installation.
if(process.env.CLINK_R365_SMOKE_MARKER){
 const fs365=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let wrote=false;
  win.webContents.on('did-finish-load',()=>setTimeout(async()=>{
   if(wrote||win.isDestroyed())return;
   let details={ok:false};
   try{details=await win.webContents.executeJavaScript(`(()=>{
    const shell=document.getElementById('clink-r358-shell');
    const d=typeof window.__CLINK_R365_DIAGNOSTICS__==='function'
     ?window.__CLINK_R365_DIAGNOSTICS__():null;
    return {ok:!!shell&&!!d&&d.hasExit&&d.hasReopen,
     nativeBrowserButton:!!d?.nativeBrowserButton,readOnly:true,
     browserInteraction:'NOT_ATTEMPTED'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const proof={loaded:true,visible:win.isVisible(),details,
                timestamp:new Date().toISOString(),pid:process.pid};
   try{fs365.writeFileSync(process.env.CLINK_R365_SMOKE_MARKER,JSON.stringify(proof));wrote=true;}catch(_){}
  },1800));
 });
}


// R363 real Electron smoke: verifies the one-stop manager without mutating packages.
if(process.env.CLINK_R363_SMOKE_MARKER){
 const fs363=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let loaded=false,failed=false,done=false;
  const probe=async()=>{
   if(!loaded||done||win.isDestroyed())return;
   let details={ok:false,error:'NOT_LOADED'};
   try {details=await win.webContents.executeJavaScript(`(async()=>{
     return typeof window.__CLINK_R363_TEST__==='function' ? await window.__CLINK_R363_TEST__() : {ok:false,error:'R363_TEST_MISSING'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const event={loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()};
   try{fs363.writeFileSync(process.env.CLINK_R363_SMOKE_MARKER,JSON.stringify(event));}catch(_e){}
   if(details.ok)done=true;
  };
  win.webContents.on('did-finish-load',()=>{loaded=true;setTimeout(probe,2500);setTimeout(probe,6500);setTimeout(probe,11000);});
  win.webContents.on('did-fail-load',()=>{failed=true;});
 });
}


// R362 GUI verification: tests Alice and Companion Home controls without sending messages.
if (process.env.CLINK_R362_SMOKE_MARKER) {
 const fs362=require('node:fs');
 app.on('browser-window-created',(_ev,w)=>{
  let loaded=false,failed=false,once=false;
  const check=async()=>{
   if(w.isDestroyed()||!loaded||once)return;
   let details={};
   try {details=await w.webContents.executeJavaScript(`(async()=>{
     return typeof window.__CLINK_R362_TEST__==='function'?await window.__CLINK_R362_TEST__():{ok:false,error:'R362_TEST_UNAVAILABLE'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const event={loaded,failed,visible:w.isVisible(),details,pid:process.pid,time:new Date().toISOString()};
   try{fs362.writeFileSync(process.env.CLINK_R362_SMOKE_MARKER,JSON.stringify(event));}catch(_e){}
   if(details.ok)once=true;
  };
  w.webContents.on('did-finish-load',()=>{loaded=true;setTimeout(check,3000);setTimeout(check,6500);setTimeout(check,10000);});
  w.webContents.on('did-fail-load',()=>{failed=true;});
 });
}


// R361 independent GUI verification (one-shot, triggered only by relay).
if (process.env.CLINK_R361_SMOKE_MARKER) {
 const fs361=require('node:fs');
 app.on('browser-window-created', (_evt, win) => {
  let loaded=false,failed=false;
  const inspect=async()=>{
   if(win.isDestroyed()||!loaded)return;
   let details={};
   try {details=await win.webContents.executeJavaScript(`(()=>{
     const s=window.__CLINK_R361_DIAGNOSTICS__;
     return typeof s==='function'?s():{ready:false,error:'R361_DIAGNOSTICS_NOT_MOUNTED'};
   })()`,true);} catch(err){details={error:String(err)};}
   try {fs361.writeFileSync(process.env.CLINK_R361_SMOKE_MARKER,
    JSON.stringify({loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}
   catch(_err){}
  };
  win.webContents.on('did-finish-load',()=>{loaded=true;[500,1500,3000,5000,7500].forEach(ms=>setTimeout(inspect,ms));});
  win.webContents.on('did-fail-load',()=>{failed=true;void inspect();});
 });
}


// R360: visible, Home-start, Alice blank UI smoke when explicitly requested by relay.
if (process.env.CLINK_R360_SMOKE_MARKER) {
 const fs360=require('node:fs');
 app.on('browser-window-created',(_event,w)=>{
  let loaded=false,failed=false;
  const run=async()=>{
   if(w.isDestroyed()||!loaded)return;
   let details={};
   try {details=await w.webContents.executeJavaScript(`(()=>{
     const alice=document.getElementById('aliceSeatPanel');
     const transcript=document.getElementById('aliceSeatTranscript');
     const home=document.getElementById('quinHome');
     return {ready:window.__CLINK_R360_READY__===true,
       homeVisible:!!home&&!home.hidden,
       aliceHidden:!!alice&&alice.hidden,
       aliceEscape:!!alice?.querySelector('.clink-r360-return'),
       companionEscape:!!document.getElementById('companionSeatPanel')?.querySelector('.clink-r360-return'),
       transcriptChildren:transcript?.childElementCount??-1,
       appTitle:document.title,
       cLinkShell:!!document.getElementById('clink-r358-shell')};
   })()`,true);}
   catch(e){details={error:String(e)};}
   try{fs360.writeFileSync(process.env.CLINK_R360_SMOKE_MARKER,JSON.stringify({loaded,failed,visible:w.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}catch(_e){}
  };
  w.webContents.on('did-finish-load',()=>{loaded=true;[250,750,1500,2900,5200,8000].forEach(ms=>setTimeout(run,ms));});
  w.webContents.on('did-fail-load',()=>{failed=true;void run();});
 });
}


// R358 smoke: actual visible C.Link desktop AND working 8-slot application grid.
if (process.env.CLINK_R358_SMOKE_MARKER) {
 const smokeFs=require('node:fs');
 app.on('browser-window-created', (_evt,win)=>{
  let loaded=false,failed=false,details={};
  const record=event=>{try{smokeFs.writeFileSync(process.env.CLINK_R358_SMOKE_MARKER,JSON.stringify({event,loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}catch(_e){}};
  const check=async()=>{
   if(!loaded||win.isDestroyed())return;
   try{
    details=await win.webContents.executeJavaScript(`(()=>{
      const shell=document.getElementById('clink-r358-shell');const deck=document.getElementById('clink-r358-deck');const grid=document.getElementById('clink-r358-card-grid');const sidebar=document.getElementById('clink-r358-side');
      const rect=shell?.getBoundingClientRect();const style=shell&&getComputedStyle(shell);
      return {present:!!shell,revision:shell?.dataset.revision,width:rect?.width||0,height:rect?.height||0,display:style?.display,brand:document.getElementById('clink-r358-brand')?.textContent||'',navCount:sidebar?.querySelectorAll('[data-view]').length||0,gridVisible:!!grid&&grid.getBoundingClientRect().width>100,cardCount:grid?.querySelectorAll('.cl-card').length||0,ready:window.__CLINK_R358_READY__===true,deckVisible:!!deck&&!deck.hidden};
    })()`,true);
    record('renderer-checked');
   }catch(error){details={error:String(error)};record('probe-error');}
  };
  record('window-created');win.on('show',()=>{record('window-shown');setTimeout(check,700);});
  win.webContents.on('did-finish-load',()=>{loaded=true;let attempts=0;const timer=setInterval(()=>{check();if(++attempts>=17)clearInterval(timer);},600);});
  win.webContents.on('did-fail-load',(_event,code,description,url)=>{failed=true;details={code,description,url};record('renderer-load-failed');});
 });
}

try { require('electron').Menu.setApplicationMenu(null); } catch (_err) {}

// R356 verification probe only when launched by the installer; no background service.
if (process.env.CLINK_R356_SMOKE_MARKER) {
  const smokeFS = require('node:fs');
  app.on('browser-window-created', (_evt, win) => {
    const file = process.env.CLINK_R356_SMOKE_MARKER;
    let loaded = false, failed = false;
    const save = (event, extra={}) => {
      try { smokeFS.writeFileSync(file, JSON.stringify({event, loaded, failed, visible:win.isVisible(), pid:process.pid, time:new Date().toISOString(), ...extra})); }
      catch (_err) { /* optional diagnostic */ }
    };
    save('window-created');
    win.on('show', () => save('window-shown'));
    win.webContents.on('did-finish-load', () => { loaded=true; save('renderer-loaded'); });
    win.webContents.on('did-fail-load', (_e, code, description, url) => { failed=true; save('renderer-load-failed',{code,description,url}); });
    win.on('closed', () => save('window-closed'));
  });
}

if (process.platform === 'linux' && typeof app.setDesktopName === 'function') app.setDesktopName(LINUX_DESKTOP_NAME);
if (process.platform === 'linux') app.commandLine.appendSwitch('class',LINUX_DESKTOP_ID);
app.setPath('userData', PROFILE_ROOT);
if (process.platform === 'win32') app.setAppUserModelId('PhantomTronix.Quin');
fs.mkdirSync(LOG_DIR, { recursive: true });
const COMPANION_CONTEXT_FILE = path.join(__dirname, 'context', 'COMPANION-CONTEXT.json');
const CANONICAL_COMPANION_CONTEXT = Object.freeze(JSON.parse(fs.readFileSync(COMPANION_CONTEXT_FILE, 'utf8')));
const QUAL_PROOF_FILE = path.join(__dirname,'context','R27A2-MESSAGE-QUALIFICATION.json');
const COMPANION_STORE_SEED_FILE = path.join(__dirname,'context','COMPANION-STORE-SEED.json');
const COMPANION_STORE_SEED = Object.freeze(JSON.parse(fs.readFileSync(COMPANION_STORE_SEED_FILE,'utf8')));
const API_R4_FIELD_FILE = path.join(__dirname,'context','API-R4-FIELD-EVIDENCE.json');
const API_R4_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R4_FIELD_FILE,'utf8')));
const API_R5_FIELD_FILE = path.join(__dirname,'context','API-R5-FIELD-EVIDENCE.json');
const API_R5_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R5_FIELD_FILE,'utf8')));
const API_R6_FIELD_FILE = path.join(__dirname,'context','API-R6-FIELD-EVIDENCE.json');
const API_R6_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R6_FIELD_FILE,'utf8')));
const API_R7_FIELD_FILE = path.join(__dirname,'context','API-R7-FIELD-EVIDENCE.json');
const API_R7_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R7_FIELD_FILE,'utf8')));
const API_R8_FIELD_FILE = path.join(__dirname,'context','API-R8-FIELD-EVIDENCE.json');
const API_R8_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R8_FIELD_FILE,'utf8')));
const HIVE_R7_RELEASE_FILE = path.join(__dirname,'context','HIVE-R7-RELEASE.json');
const HIVE_R7_RELEASE = Object.freeze(JSON.parse(fs.readFileSync(HIVE_R7_RELEASE_FILE,'utf8')));
const PROTECTED_QUALIFICATION = Object.freeze(JSON.parse(fs.readFileSync(QUAL_PROOF_FILE,'utf8')));
function restoredQualification(){
  const q=PROTECTED_QUALIFICATION;
  if(q.status!=='QUALIFIED'||q.samples!==9||q.passes!==9||q.failures!==0||q.knownSafeMaxChars!==131072||q.recommendedFutureChunkChars!==98304)throw new Error('R27A2_PROTECTED_QUALIFICATION_EVIDENCE_INVALID');
  return {...q,restoredByBuild:BUILD,restoredAt:new Date().toISOString(),detail:'R27A2 FIELD PROOF RESTORED: 9/9 text passes; known safe >= 131072 chars; operational chunk target 98304; attachments unqualified; MESSAGE BATCH rerun disabled.'};
}

function boot(text) { try { fs.appendFileSync(BOOT_LOG, `${new Date().toISOString()} | ${text}\n`); } catch (_) {} }
boot(`PROFILE_ROOT_SOURCE=${PROFILE_ROOT_OVERRIDE?'CLINK_FIELD_TEST_OVERRIDE':'CANONICAL_APPDATA'} fieldTestMode=${FIELD_TEST_MODE} pid=${process.pid}`);
function log(event, data = {}) {
  try {
    fs.appendFileSync(LOG_FILE, JSON.stringify({ts:new Date().toISOString(),build:BUILD,mission:MISSION,sessionId:TERMINAL_SESSION_ID,event,...data}) + '\n');
  } catch (_) {}
}
function tail(file, count = 120) { try { return fs.readFileSync(file,'utf8').split(/\r?\n/).filter(Boolean).slice(-count); } catch (_) { return []; } }

function ensureLinuxDesktopIdentity(){
  if(process.platform!=='linux')return null;
  try{
    const dataHome=String(process.env.XDG_DATA_HOME||path.join(os.homedir(),'.local','share'));
    const appDir=path.join(dataHome,'applications');
    const iconThemeRoot=path.join(dataHome,'icons','hicolor');
    const iconDir=path.join(iconThemeRoot,'512x512','apps');
    const desktopPath=path.join(appDir,LINUX_DESKTOP_NAME);
    const stableIconPath=path.join(iconDir,`${LINUX_DESKTOP_ID}.png`);

    fs.mkdirSync(appDir,{recursive:true});
    fs.mkdirSync(iconDir,{recursive:true});
    fs.mkdirSync(path.dirname(LINUX_DURABLE_LAUNCHER),{recursive:true});

    let changed=false;
    const sourceIcon=fs.readFileSync(APP_ICON);
    let targetIcon=null;
    try{targetIcon=fs.readFileSync(stableIconPath);}catch(_){}
    if(!targetIcon||!targetIcon.equals(sourceIcon)){
      fs.writeFileSync(stableIconPath,sourceIcon);
      changed=true;
    }

    const upsert=(text,key,value)=>{
      const line=`${key}=${value}`;
      const escaped=key.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      const rx=new RegExp(`^${escaped}=.*$`,'m');
      return rx.test(text)?text.replace(rx,line):`${text.replace(/\s*$/,'')}\n${line}\n`;
    };

    let desktop='';
    try{desktop=fs.readFileSync(desktopPath,'utf8');}catch(_){}
    if(!desktop.includes('[Desktop Entry]'))desktop='[Desktop Entry]\n';
    const before=desktop;

    desktop=upsert(desktop,'Type','Application');
    desktop=upsert(desktop,'Version','1.0');
    desktop=upsert(desktop,'Name','Phantom-Tronix Quinquedent Browser (Quin)');
    desktop=upsert(desktop,'GenericName','Quin Browser and Plugins');
    desktop=upsert(desktop,'Comment','Quin — browser built from the IRIS/C.Link foundation');
    desktop=upsert(desktop,'Exec',`"${LINUX_DURABLE_LAUNCHER}"`);
    desktop=upsert(desktop,'TryExec',LINUX_DURABLE_LAUNCHER);
    desktop=upsert(desktop,'Icon',LINUX_DESKTOP_ID);
    desktop=upsert(desktop,'StartupWMClass',LINUX_DESKTOP_ID);
    desktop=upsert(desktop,'Terminal','false');
    desktop=upsert(desktop,'NoDisplay','false');
    desktop=upsert(desktop,'StartupNotify','true');
    desktop=upsert(desktop,'DBusActivatable','false');
    desktop=upsert(desktop,'Categories','Development;Utility;');
    desktop=upsert(desktop,'Keywords','Quin;Quinquedent;Robot Rock;Phantom-Tronix;');

    if(desktop!==before){
      fs.writeFileSync(desktopPath,desktop);
      changed=true;
    }

    if(changed){
      try{cp.spawnSync('update-desktop-database',[appDir],{stdio:'ignore',timeout:3000});}catch(_){}
      try{cp.spawnSync('gtk-update-icon-cache',['-f','-t',iconThemeRoot],{stdio:'ignore',timeout:4000});}catch(_){}
    }

    const result={
      desktopId:LINUX_DESKTOP_ID,
      desktopName:LINUX_DESKTOP_NAME,
      desktopPath,
      durableLauncher:LINUX_DURABLE_LAUNCHER,
      durableAppDir:LINUX_DURABLE_APP_DIR,
      runtimeCache:LINUX_RUNTIME_CACHE,
      stableIconPath,
      sourceIconSha256:crypto.createHash('sha256').update(sourceIcon).digest('hex').toUpperCase(),
      searchable:true,
      changed
    };
    log('desktop.identity.ready',result);
    return result;
  }catch(error){
    log('desktop.identity.error',{error:String(error.message||error)});
    return null;
  }
}

function readProviderAuthState(){
  try{return JSON.parse(fs.readFileSync(PROVIDER_AUTH_STATE_FILE,'utf8'));}catch(_){return{};}
}
function writeProviderAuthState(patch={}){
  try{
    fs.mkdirSync(PROVIDER_AUTH_DIR,{recursive:true});
    const current=readProviderAuthState();
    const next={schema:'CLINK_PROVIDER_AUTH_STATE_V1',...current,...patch,updatedAt:new Date().toISOString()};
    const tmp=`${PROVIDER_AUTH_STATE_FILE}.tmp-${process.pid}`;
    fs.writeFileSync(tmp,JSON.stringify(next,null,2)+'\n');
    fs.renameSync(tmp,PROVIDER_AUTH_STATE_FILE);
    return next;
  }catch(error){
    log('provider.session.state-write.error',{error:String(error.message||error)});
    return null;
  }
}
async function flushProviderSession(reason='UNSPECIFIED'){
  if(!browserRuntime)return{ok:false,reason:'BROWSER_RUNTIME_NOT_READY'};
  const started=Date.now();
  try{
    const ses=browserRuntime.getSession();
    let cookieResult='PASS';
    try{
      await Promise.race([
        ses.cookies.flushStore(),
        new Promise((_,reject)=>setTimeout(()=>reject(new Error('COOKIE_FLUSH_TIMEOUT')),1800))
      ]);
    }catch(error){cookieResult=String(error.message||error);}
    try{ses.flushStorageData();}catch(error){
      log('provider.session.storage-flush.error',{reason,error:String(error.message||error)});
    }
    const state=writeProviderAuthState({
      canonicalSessionPath:browserRuntime.sessionPath,
      lastFlushAt:new Date().toISOString(),
      lastFlushReason:reason,
      lastFlushCookieResult:cookieResult
    });
    log('provider.session.flush',{
      reason,cookieResult,elapsedMs:Date.now()-started,
      sessionPath:browserRuntime.sessionPath,
      stateStatus:state?.status||'UNKNOWN'
    });
    return{ok:cookieResult==='PASS',cookieResult};
  }catch(error){
    log('provider.session.flush.error',{reason,error:String(error.message||error)});
    return{ok:false,error:String(error.message||error)};
  }
}

let windowMain = null;
let cartridgeVoiceHost=null;
let webPluginView=null;let webPluginId=null;let webPluginSession=null;let activeWebService=null;
let restrictedBrowserCartridge = null;
let companionChatGPTBridge = null;
let panels = null;
let browserRuntime = null;
let broadcastTimer = null;
let lifecycleSyncPromise = null;


const companionZipIntake = new CompanionZipIntake({profileRoot:PROFILE_ROOT});
const commandStationSeats = new CommandStationSeats({profileRoot:PROFILE_ROOT,intake:companionZipIntake});
const companionActivationRecovery = new CompanionActivationRecovery({activeFile:companionZipIntake.activeFile,logger:log});
// Reconcile any interrupted activation BEFORE binding initial Companion identity.
let activationColdRecovery={ok:true,action:'NONE'};
try{activationColdRecovery=companionActivationRecovery.recover();}
catch(error){
  activationColdRecovery={ok:false,error:String(error?.message||error)};
  log('companion.activation.startup_recovery_blocked',{error:activationColdRecovery.error});
}
// Recovery-only boot does not call the legacy manager, which could otherwise
// silently reseed an invalid CURRENT.json to a hardcoded historical Companion.
const companionPreflight = checkCompanionStartup({activeFile:companionZipIntake.activeFile});
let backpackManager=null;
let bootstrapBackpackState=null;
let companionStartupError=!activationColdRecovery.ok ? 'ACTIVATION_JOURNAL_RECOVERY_FAILED' :
  (!companionPreflight.ok ? companionPreflight.reason : null);
if(!companionStartupError){
  try{
    backpackManager = new BackpackManager({profileRoot:PROFILE_ROOT,appRoot:__dirname,logger:log});
    const backpackState = backpackManager.initialize();
    bootstrapBackpackState=backpackState;
    if(!backpackState?.systemControl)throw Error('SYSTEM_CONTROL_INITIAL_STATE_INCOMPLETE'); // Empty Companion is allowed.
  }catch(error){companionStartupError='BACKPACK_INITIALIZATION_FAILED';log('companion.recovery.bootstrap_blocked',{error:String(error?.message||error)});}
}
if(companionStartupError){
  log('companion.recovery.safe_shell_start',{reason:companionStartupError});
  createRecoveryShell({app,BrowserWindow,ipcMain,clipboard,profileRoot:PROFILE_ROOT,reason:companionStartupError,logger:log});
}else{
const companionOrchestrator = new CompanionOrchestrator({profileRoot:PROFILE_ROOT,logger:log});
companionOrchestrator.initialize(bootstrapBackpackState);
const providerSecrets = new ProviderSecretStore({profileRoot:PROFILE_ROOT,safeStorage,logger:log});
// R378 opt-in one-time native credential decryptability check. No value, length,
// ciphertext or full exception is logged. No API calls are performed.
if(process.env.CLINK_R378_PROBE_ON_START==='1'){
  const report={};
  for(const p of ['openai','xai']){
    try{
      const current=providerSecrets.status(p);
      if(!current.configured){report[p]='NOT_CONFIGURED';}
      else if(!providerSecrets.secureStorageAvailable()){report[p]='SECURE_STORAGE_UNAVAILABLE';}
      else{
        const ephemeral=providerSecrets.getForMainProcess(p);
        report[p]=ephemeral?'DECRYPT_OK':'EMPTY_AFTER_DECRYPT';
      }
    }catch(error){
      const label=String(error?.message||'');
      report[p]=label==='SECURE_STORAGE_DECRYPT_FAILED'?'SECURE_STORAGE_DECRYPT_FAILED':label==='SECURE_STORAGE_UNAVAILABLE'?'SECURE_STORAGE_UNAVAILABLE':'OTHER_STORE_ERROR';
    }
  }
  process.stdout.write('CLINK_R378_CREDENTIAL_PROBE='+JSON.stringify(report)+'\n');
}

const apiUsage = new ApiUsageLedger({profileRoot:PROFILE_ROOT,logger:log});
const providerAdapters = new ProviderAdapterRegistry({secretStore:providerSecrets,usageLedger:apiUsage,defaultUsageContext:{companionId:'clink-system',missionId:MISSION,workerId:null,purpose:'api_request'},logger:log});
const universalCompanion = new UniversalCompanionPrimary({adapterRegistry:providerAdapters,backpackManager,missionId:MISSION,logger:log});
const companionTurnSeat = new CompanionTurnSeat({primary:universalCompanion,backpackManager});
if(!activationColdRecovery.ok)companionTurnSeat.disable('STARTUP_ACTIVATION_RECOVERY_FAILED');
const contextBuilder = new CompanionContextBuilder({profileRoot:PROFILE_ROOT,seed:COMPANION_STORE_SEED,bootId:TERMINAL_SESSION_ID,logger:log});
const contextBuilderBootState = contextBuilder.initialize();
function alphaShadowRunner(){return new AlphaShadowRunner({adapterRegistry:providerAdapters,context:contextBuilder.build(),usageContext:{companionId:'alpha007',missionId:MISSION,workerId:null,purpose:'alpha_reasoning'},logger:log});}
function alphaPrimaryRunner(){return new AlphaPrimaryRunner({adapterRegistry:providerAdapters,contextBuilder,bootId:TERMINAL_SESSION_ID,missionId:MISSION,logger:log});}
const apiPrimarySoak = new ApiPrimarySoak({profileRoot:PROFILE_ROOT,bootId:TERMINAL_SESSION_ID,contextFingerprint:contextBuilderBootState.contextFingerprint,logger:log});
const readOnlyWorkers = new ReadOnlyWorkerExperiment({profileRoot:PROFILE_ROOT,adapterRegistry:providerAdapters,contextBuilder,usageLedger:apiUsage,missionId:R8_MISSION,logger:log});
const round9 = new Round9Reconciliation({profileRoot:PROFILE_ROOT,adapterRegistry:providerAdapters,contextBuilder,usageLedger:apiUsage,r8Experiment:readOnlyWorkers,bootId:TERMINAL_SESSION_ID,missionId:MISSION,logger:log});
let alphaRecentTurns=[];
function primaryTransportReady(){
  const status=providerSecrets.status('openai');
  return status.configured===true&&status.storage==='SECURE_OS_USER';
}
function grokUserCompanionReady(){
  const status=providerSecrets.status('xai');
  return status.configured===true&&status.storage==='SECURE_OS_USER'&&status.state==='READY';
}
function grokUserCompanionSnapshot(extra={}){
  return {
    schema:'CLINK_GROK_USER_COMPANION_SHADOW_V1',
    status:grokUserCompanionReady()?'READY':'NOT_CONFIGURED',
    mode:'EXPLICIT_SHADOW_COMMAND',provider:'xai',model:'grok-4.3',
    companionId:String(backpackManager.snapshot()?.userCompanion?.id||''),
    continuityAuthority:'USER_COMPANION_BACKPACK',providerConversationAuthority:false,persistProviderSessionIds:false,
    technicalRelay:'HOSTED_SPECIALIST_TABS',repairExecution:'OFF',defaultRoutingChanged:false,
    ...extra
  };
}
function apiPrimarySnapshot(extra={}){
  const status=primaryTransportReady()?'READY':'NOT_CONFIGURED';
  return {
    schema:'CLINK_API_PRIMARY_STATE_V1',status,mode:'API_PRIMARY',provider:'openai',model:'gpt-5.6-luna',
    continuityAuthority:'CLINK_BACKPACK',providerConversationAuthority:false,persistProviderSessionIds:false,
    humanSurface:'CLINK_TERMINAL',hostedBrowser:'FALLBACK',repairExecution:'OFF',bootId:TERMINAL_SESSION_ID,
    contextFingerprint:contextBuilder.snapshot().contextFingerprint,soak:apiPrimarySoak.snapshot(),...extra
  };
}

const packageStore = new RelayPackageStore({ profileRoot:PROFILE_ROOT, logger:log });
function relayLog(event, data = {}) {
  log(event,data);
  clearTimeout(broadcastTimer);
  broadcastTimer = setTimeout(() => broadcast(), 25);
}
const relay = new AgentRelay({ admissionGate:admitRepairProposal, packageStore, logger:relayLog });

let a007HostedFieldProbeStarted=false;
const A007_HOSTED_FIELD_PROBE=process.env.CLINK_A007_HOSTED_FIELD_PROBE==='1';
let a007GrokFieldProbeStarted=false;
const A007_GROK_FIELD_PROBE=process.env.CLINK_A007_GROK_FIELD_PROBE==='1';

const coreState = {
  build:BUILD,
  mission:MISSION,
  core:{status:'BOOTING',detail:'Vanilla Terminal core is starting.'},
  repair:{status:'READY',detail:'Browser-owned reasoning is active; repair execution is OFF.',mode:'BROWSER_CONTROL_EXECUTION_DISABLED'},
  panels:{
    status:'NOT_STARTED',attempt:0,quarantined:false,detail:'PANELS OS has not started.',plugins:[],
    providerProbe:{status:'R28B_PRIMARY_OPERATING_SURFACE',detail:'R27A2 field-proven browser/auth baseline preserved; Core owns provider workspace/chat lifecycle and six canonical slots.'},
    providerRuntime:{}
  },
  companion:bootstrapBackpackState.userCompanion?{status:'DISCOVERED',detail:'Companion is waiting for lifecycle.'}:{status:'NO_COMPANION_LOADED',detail:'Load and activate a canonical backpack in Settings > Companions.'},
  companionCore:companionOrchestrator.snapshot(),
  providerLifecycle:{status:'NOT_STARTED',detail:'C.LINK REASONING provider workspace lifecycle has not synchronized yet.',progress:null,lastError:''},
  inlineAuth:{status:'IDLE',detail:'Hosted provider authentication is not active.',url:'',title:''},
  messageQualification:restoredQualification(),
  apiProviders:{mode:'API_PRIMARY_OPENAI_WITH_HOSTED_FALLBACK',round:9,storage:'MAIN_PROCESS_SAFE_STORAGE',primaryProvider:'openai',browserFallback:'HOSTED_CHATGPT_WEB_MANUAL',rounds1to8Field:'PASS',adapters:providerAdapters.defaults()},
  apiPrimary:apiPrimarySnapshot({fieldStatus:'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status}),
  apiWorkers:{...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD},
  round9:round9.snapshot(),
  apiShadow:{status:'FIELD_PROVEN_R4D',detail:API_R4_FIELD.detail,provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null},
  grokUserCompanion:grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:null}),
  apiContext:{...contextBuilderBootState,fieldEvidence:API_R5_FIELD,reconstruction:{status:'FIELD_PROVEN_R5',detail:'Round 5 restart and reconstruction are field-proven.',...API_R5_FIELD.reconstruction}},
  apiUsage:apiUsage.summary(),
  relay:relay.snapshot()
};

function snapshot() {
  coreState.dualBackpacks=backpackManager.snapshot();
  coreState.relay = relay.snapshot();
  coreState.companionCore = companionOrchestrator.snapshot();
  coreState.apiUsage = apiUsage.summary();
  coreState.apiWorkers = {...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD};
  coreState.round9 = round9.snapshot();
  coreState.apiPrimary = apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null,fieldStatus:coreState.apiPrimary?.fieldStatus||'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status});
  coreState.grokUserCompanion = grokUserCompanionSnapshot({fieldStatus:coreState.grokUserCompanion?.fieldStatus||'SHADOW_FIELD_PENDING',lastTurn:coreState.grokUserCompanion?.lastTurn||null});
  return JSON.parse(JSON.stringify(coreState));
}
function broadcast() {
  if (windowMain && !windowMain.isDestroyed()) windowMain.webContents.send('clink:state-changed', snapshot());
}
function refreshCompanionState() {
  const apiReady=primaryTransportReady();
  const hostedProvider=(coreState.panels.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  coreState.apiPrimary=apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null,fieldStatus:coreState.apiPrimary?.fieldStatus||'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status});
  const hostedReady=coreState.providerLifecycle?.status==='READY';
  coreState.companion={
    status:(apiReady||hostedReady)?'READY':'DEGRADED',
    detail:apiReady
      ? `Companion API PRIMARY is ready through OpenAI; hosted browser is FALLBACK. Hosted lifecycle=${coreState.providerLifecycle?.status||'NOT_STARTED'}; repair execution OFF.`
      : (hostedReady
        ? 'Hosted ChatGPT reasoning is READY on this seat; API PRIMARY is not configured, so ordinary turns use the persistent hosted provider.'
        : 'No reasoning transport is ready yet. API PRIMARY is not configured and hosted browser lifecycle is not READY.')
  };
  coreState.apiPrimary.hostedBrowserStatus=hostedProvider?.status==='READY'?'AVAILABLE':'STANDBY';
}

function setPanels(state) {
  coreState.panels = state;
  refreshCompanionState();
  broadcast();
  const provider=(state.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  // Quin fork: no automatic provider authentication probing on initial boot.
  // Only an explicit Human action starts the inherited provider lifecycle.

}


function layoutWebPlugin(){
  if(!webPluginView||!windowMain||windowMain.isDestroyed())return;
  const [width,height]=windowMain.getContentSize();
  webPluginView.setBounds({x:0,y:60,width:Math.max(1,width),height:Math.max(1,height-60)});
}
function closeWebPlugin(){
  cartridgeVoiceHost?.revoke();
  if(activeWebService){servicePlugins.stop(activeWebService);activeWebService=null;}
  if(!webPluginView)return;
  try{windowMain?.contentView.removeChildView(webPluginView);}catch(_){}
  try{webPluginView.webContents.close();}catch(_){}
  webPluginView=null;webPluginId=null;
}
function layoutInlineAuthView(){
  if(!windowMain||windowMain.isDestroyed()||!inlineAuthView)return;
  const [width,height]=windowMain.getContentSize();
  const left=Math.round(width*0.385)+12;
  const top=190;
  const rightPad=12;
  const bottomPad=72;
  inlineAuthView.setBounds({
    x:left,
    y:top,
    width:Math.max(520,width-left-rightPad),
    height:Math.max(320,height-top-bottomPad)
  });
}
function removeInlineAuthView(){
  if(inlineAuthPoll){clearInterval(inlineAuthPoll);inlineAuthPoll=null;}
  if(!inlineAuthView)return;
  try{if(windowMain&&!windowMain.isDestroyed())windowMain.contentView.removeChildView(inlineAuthView);}catch(_){}
  try{inlineAuthView.webContents.close();}catch(_){}
  inlineAuthView=null;inlineAuthActive=false;
}
async function inlineAuthSnapshot(){
  if(!inlineAuthView)return null;
  try{return await inlineAuthView.webContents.executeJavaScript(`(() => {
    const visible=el=>{if(!el)return false;const s=getComputedStyle(el),r=el.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;};
    const prompt=[document.querySelector('#prompt-textarea'),...document.querySelectorAll('div.ProseMirror[contenteditable="true"],textarea,[contenteditable="true"]')].find(visible)||null;
    const loginSignals=(/\\/auth\\/login/i.test(location.pathname)?3:0)+([...document.querySelectorAll('button,a')].filter(visible).filter(el=>/log in|sign up|continue with google|continue with apple|continue with phone/i.test(String(el.innerText||el.textContent||el.getAttribute('aria-label')||''))).length);
    return {url:location.href,title:document.title||'',path:location.pathname||'',promptVisible:!!prompt,loginSignals};
  })()`,true);}catch(_){return null;}
}
async function finishInlineAuthSuccess(snapshot){
  if(!inlineAuthActive)return;
  writeProviderAuthState({
    status:'AUTHENTICATED',
    lastAuthSuccessAt:new Date().toISOString(),
    lastAuthSuccessUrl:snapshot?.url||'',
    lastAuthSuccessTitle:snapshot?.title||'',
    loginPolicy:'HUMAN_EXPLICIT_ONLY'
  });
  await flushProviderSession('AUTH_SUCCESS');
  log('provider.inline-auth.success',{url:snapshot?.url||'',title:snapshot?.title||'',persistent:true});
  coreState.inlineAuth={status:'PASS',detail:'Hosted ChatGPT authentication restored and persisted inside C.Link.',url:snapshot?.url||'',title:snapshot?.title||''};
  removeInlineAuthView();refreshCompanionState();broadcast();
  setTimeout(()=>syncProviderLifecycle(true).catch(error=>log('provider.inline-auth.resync.error',{error:String(error.message||error)})),900);
}
async function startInlineAuthRecovery(reason='AUTH_REQUIRED'){
  if(inlineAuthActive||!windowMain||windowMain.isDestroyed()||!browserRuntime)return;
  inlineAuthActive=true;
  writeProviderAuthState({
    status:'AUTH_IN_PROGRESS',
    lastAuthAttemptAt:new Date().toISOString(),
    lastAuthAttemptReason:reason,
    loginPolicy:'HUMAN_EXPLICIT_ONLY'
  });
  const ses=browserRuntime.getSession();
  inlineAuthView=new WebContentsView({webPreferences:{session:ses,contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
  inlineAuthView.setBackgroundColor('#111111');
  windowMain.contentView.addChildView(inlineAuthView);layoutInlineAuthView();
  inlineAuthView.webContents.setWindowOpenHandler(({url})=>{
    try{const u=new URL(url);if(u.protocol==='https:')setTimeout(()=>{try{inlineAuthView?.webContents.loadURL(url);}catch(_){}},0);}catch(_){}
    return{action:'deny'};
  });
  const report=async()=>{
    const snap=await inlineAuthSnapshot();if(!snap)return;
    coreState.inlineAuth={status:'ACTIVE',detail:'ChatGPT inside Quin. Sign in here only if the existing persistent session requires it.',url:snap.url||'',title:snap.title||''};
    refreshCompanionState();broadcast();
    const ok=String(snap.url||'').startsWith('https://chatgpt.com/')&&!String(snap.url||'').includes('/auth/login')&&snap.promptVisible&&Number(snap.loginSignals||0)===0;
    if(ok)await finishInlineAuthSuccess(snap);
  };
  inlineAuthView.webContents.on('dom-ready',()=>report().catch(()=>{}));
  // For manual opening, probe the inherited persistent session FIRST.
  // Do not force a new authentication or repeatedly visit /auth/login.
  const loginUrl=reason==='HUMAN_EXPLICIT'?'https://chatgpt.com/':'https://chatgpt.com/auth/login';
  coreState.inlineAuth={status:'ACTIVE',detail:'ChatGPT open inside Quin. Using existing persistent session; sign in only if required.',url:loginUrl,title:''};
  if(reason!=='HUMAN_EXPLICIT') coreState.providerLifecycle={...coreState.providerLifecycle,status:'AUTH_REQUIRED',detail:`Hosted provider authentication required: ${reason}`,lastError:reason};
  log('provider.inline-auth.opened',{reason,mode:'INLINE_MAIN_WINDOW',popup:false,targetUrl:loginUrl});refreshCompanionState();broadcast();
  inlineAuthView.webContents.on('did-navigate',(_event,url)=>{log('provider.inline-auth.navigation',{url:String(url||''),kind:'DOCUMENT'});report().catch(()=>{});});
  inlineAuthView.webContents.on('did-navigate-in-page',(_event,url)=>{log('provider.inline-auth.navigation',{url:String(url||''),kind:'IN_PAGE'});report().catch(()=>{});});
  await inlineAuthView.webContents.loadURL(loginUrl);
  inlineAuthPoll=setInterval(()=>report().catch(()=>{}),1000);
}

async function syncProviderLifecycle(force=false){
  // Do not start hosted provider lifecycle or hydration without a real Companion.
  if(!backpackManager.snapshot()?.userCompanion)return{ok:false,error:'NO_COMPANION_LOADED',providerInvoked:false};
  if(lifecycleSyncPromise&&!force)return lifecycleSyncPromise;
  if(!providerReady())throw new Error('COMPANION_PROVIDER_NOT_READY');
  lifecycleSyncPromise=(async()=>{
    const bags=backpackManager.refresh();
    companionOrchestrator.initialize(bags);
    coreState.companionCore=companionOrchestrator.snapshot();
    const startedAt=new Date().toISOString();
    coreState.providerLifecycle={status:'RUNNING',detail:'Locating/creating C.LINK REASONING and synchronizing six canonical chats.',progress:null,lastError:'',startedAt};refreshCompanionState();broadcast();
    try{
      const plan=companionOrchestrator.lifecyclePlan();
      const hydration={userCompanion:backpackManager.hydrationPacket('userCompanion'),systemControl:backpackManager.hydrationPacket('systemControl')};
      const result=await panels.requestLifecycle(plan,{stallTimeoutMs:120000,hydration,onProgress:progress=>{
        if(progress?.stage==='WORKSPACE_READY'&&progress?.data?.projectId&&progress?.data?.projectUrl){
          companionOrchestrator.recordWorkspace({
            projectId:progress.data.projectId,
            projectUrl:progress.data.projectUrl,
            status:'READY',
            health:'HEALTHY'
          });
          log('provider.lifecycle.workspace.persisted',{
            projectId:progress.data.projectId,
            projectUrl:progress.data.projectUrl,
            phase:'WORKSPACE_READY'
          });
        }
        coreState.providerLifecycle={...coreState.providerLifecycle,status:'RUNNING',progress,detail:progress?.detail||'Synchronizing provider lifecycle.',lastEventAt:new Date().toISOString()};refreshCompanionState();log('provider.lifecycle.progress',progress||{});broadcast();
      }});
      companionOrchestrator.applyLifecycleResult(result||{});
      for(const item of Array.isArray(result?.scratch)?result.scratch:[])if(item?.ok&&item?.id&&item?.conversationUrl)companionOrchestrator.recordScratchConversation(item.id,item.conversationUrl,{providerConversationId:item.conversationId,projectId:item.projectId,projectUrl:item.projectUrl});
      const registry=companionOrchestrator.snapshot();
      const allReady=Object.values(registry.chats||{}).length===6&&Object.values(registry.chats||{}).every(chat=>chat.status==='READY'&&chat.health==='HEALTHY');
      coreState.providerLifecycle={status:allReady&&result?.status==='READY'?'READY':'DEGRADED',detail:allReady?'C.LINK REASONING and all six canonical chats are READY.':'Provider lifecycle completed with one or more degraded canonical chats.',progress:null,lastError:'',result,startedAt,completedAt:new Date().toISOString()};
      coreState.companionCore=registry;refreshCompanionState();log('provider.lifecycle.complete',{status:coreState.providerLifecycle.status,result});broadcast();
      if(A007_HOSTED_FIELD_PROBE&&coreState.providerLifecycle.status==='READY'&&!a007HostedFieldProbeStarted){
        a007HostedFieldProbeStarted=true;
        setTimeout(async()=>{
          log('a007.hosted.field-probe.start',{round:288,prompt:'Hello. Who are you?'});
          let probe;
          try{probe=await hostedCompanionMessage('Hello. Who are you?');}
          catch(error){probe={ok:false,error:String(error.message||error)};}
          log('a007.hosted.field-probe.complete',{
            round:288,ok:probe?.ok===true,mode:String(probe?.mode||''),
            reply:String(probe?.reply||'').slice(0,2000),error:String(probe?.error||'')
          });
        },350);
      }
      if(A007_GROK_FIELD_PROBE&&coreState.providerLifecycle.status==='READY'&&grokUserCompanionReady()&&!a007GrokFieldProbeStarted){
        a007GrokFieldProbeStarted=true;
        setTimeout(async()=>{
          const prompt='I want to know whether Grok is ready to become my everyday User Companion in C.Link. This is a technical decision, so do not decide it alone. Use your specialist tabs to challenge the migration, protect Alice\'s continuity and authority, reduce my operator steps, and then give me one final recommendation. Do not change anything on the machine.';
          log('a007.grok.field-probe.start',{round:306,promptChars:prompt.length,provider:'xai',model:'grok-4.3',repairExecution:'OFF'});
          let probe;
          try{probe=await grokUserCompanionMessage(prompt);}
          catch(error){probe={ok:false,error:String(error.message||error)};}
          log('a007.grok.field-probe.complete',{
            round:306,ok:probe?.ok===true,mode:String(probe?.mode||''),
            reply:String(probe?.reply||'').slice(0,3000),error:String(probe?.error||''),
            conclusion:probe?.conclusion||null,resolutionState:probe?.resolutionState||null
          });
          broadcast();
        },700);
      }
      return{ok:coreState.providerLifecycle.status==='READY',result,registry};
    }catch(error){
      const message=String(error.message||error);
      if(/AUTH_REUSE_INDETERMINATE|REAUTH_FORBIDDEN|AUTH_REUSE_CHALLENGE_TIMEOUT/.test(message)){
        const authState=readProviderAuthState();
        const persistenceFault=!!authState.lastAuthSuccessAt;
        writeProviderAuthState({
          status:persistenceFault?'SESSION_PERSISTENCE_FAULT':'AUTH_REQUIRED',
          lastAuthRequiredAt:new Date().toISOString(),
          lastAuthRequiredReason:message,
          persistenceFault,
          loginPolicy:'HUMAN_EXPLICIT_ONLY'
        });
        coreState.providerLifecycle={
          status:'AUTH_REQUIRED',
          detail:persistenceFault
            ? 'The persistent hosted session unexpectedly requires authentication. C.Link will not retry automatically.'
            : 'Hosted ChatGPT sign-in is required inside C.Link.',
          progress:null,lastError:message,startedAt,completedAt:new Date().toISOString(),
          persistenceFault
        };
        refreshCompanionState();
        log('provider.lifecycle.auth-required',{
          error:message,mode:'INLINE_MAIN_WINDOW',activation:'HUMAN_EXPLICIT',
          persistenceFault,lastAuthSuccessAt:authState.lastAuthSuccessAt||null
        });
        broadcast();
        return{ok:false,error:'INLINE_AUTH_REQUIRED',registry:companionOrchestrator.snapshot()};
      }
      coreState.providerLifecycle={status:'FAIL',detail:message,progress:null,lastError:message,startedAt,completedAt:new Date().toISOString()};refreshCompanionState();log('provider.lifecycle.fail',{error:message});broadcast();return{ok:false,error:message,registry:companionOrchestrator.snapshot()};
    }finally{lifecycleSyncPromise=null;}
  })();
  return lifecycleSyncPromise;
}


function companionContextSnapshot() {
  const relayPackage = packageStore.snapshot();
  return {
    schema: 'CLINK_COMPANION_TURN_CONTEXT_V1',
    canonical: CANONICAL_COMPANION_CONTEXT,
    runtime: {
      build: BUILD,
      mission: MISSION,
      coreStatus: coreState.core.status,
      panelsStatus: coreState.panels.status,
      companionStatus: coreState.companion.status,
      repairExecution: 'OFF',
      browserControl: 'ON',
      activeRelayPackage: relayPackage?.relayId ? relayPackage : { status: 'NONE' },
      dualBackpacks: backpackManager.snapshot(),
      reasoningRegistry: companionOrchestrator.snapshot(),
      providerLifecycle: coreState.providerLifecycle,
      messageQualification: coreState.messageQualification
    }
  };
}

function providerReady() {
  const provider=(coreState.panels.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  return coreState.panels.status==='READY' && provider?.status==='READY';
}

function normalizeIncident(value, fallbackText='') {
  const source=value&&typeof value==='object'?value:{};
  const cleanList=v=>Array.isArray(v)?v.map(x=>String(x||'').slice(0,1800)).slice(0,32):[];
  return {
    summary:String(source.summary || fallbackText || 'Human requested specialist problem-solving relay.').slice(0,5000),
    failureFingerprint:String(source.failureFingerprint || `HUMAN_PROBLEM_${Date.now()}`).slice(0,240),
    evidence:cleanList(source.evidence),
    allowedChange:cleanList(source.allowedChange),
    forbiddenChange:cleanList(source.forbiddenChange),
    baselineId:String(source.baselineId || BUILD).slice(0,240),
    systemControlBackpack:backpackManager.snapshot().systemControl
  };
}

async function runRelayForIncident(incident, userHandoff = null) {
  const augmented={...incident,systemControlBackpack:backpackManager.snapshot().systemControl,userHandoff:userHandoff||null};
  const state=await relay.runProblem({
    incident:augmented,
    ownerFrame:null,
    field:true,
    reasoner:async(request,onProgress)=>{
      const chat=companionOrchestrator.descriptor(request.station);
      const runRequest=async req=>{
        const result=await panels.requestReasoning(req,{stallTimeoutMs:70000,onProgress,chat});
        if(result?.conversationUrl)companionOrchestrator.recordConversation(req.station,result.conversationUrl);
        return result;
      };
      try {
        return await runRequest(request);
      } catch (error) {
        const message=String(error.message||error);
        if(!message.startsWith('RELAY_FRESH_RECEIPT_INVALID:RESPONSE_JSON_INVALID:')) throw error;
        const retryMarker=`${String(request.marker||'CLINK_RELAY')}-FORMAT-RETRY-${Date.now()}`;
        const retryPrompt=[
          String(request.prompt||''),
          '',
          'C.LINK STRICT FORMAT RECOVERY:',
          'Your immediately previous response for this same station and phase reached C.Link, but its JSON syntax was malformed.',
          'Do not add new analysis and do not change your substantive conclusion.',
          'Re-emit the immediately previous receipt only, using the exact required CLINK_RECEIPT_JSON_BEGIN / CLINK_RECEIPT_JSON_END contract.',
          'Inside those markers use strict JSON: double-quoted property names, double-quoted string values, no trailing commas, no comments, no prose outside the markers.'
        ].join('\n');
        log('relay.reason.format-retry',{
          station:String(request.station||''),
          phase:String(request.phase||''),
          firstError:message,
          action:'ONE_STRICT_FORMAT_RETRY'
        });
        if(typeof onProgress==='function'){
          onProgress({
            station:String(request.station||''),
            stage:'FORMAT_RETRY',
            detail:'Fresh specialist analysis arrived with malformed JSON; asking the same specialist once to re-emit it as strict JSON.'
          });
        }
        return await runRequest({...request,marker:retryMarker,prompt:retryPrompt});
      }
    }
  });
  coreState.relay=state;coreState.companionCore=companionOrchestrator.snapshot();
  broadcast();
  return state;
}

// Canonical Companion wins the human-facing seat. Existing OpenAI API-primary transport remains unchanged.
async function universalCompanionMessage(input,{technical=false}={}){
  const text=String(input||'').trim();if(!text)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!primaryTransportReady())return{ok:false,error:'API_PRIMARY_OPENAI_NOT_CONFIGURED'};
  try{
    const result=await companionTurnSeat.reply(text,{technical});
    if(result.ok){
      coreState.apiPrimary=apiPrimarySnapshot({lastTurn:{status:'PASS',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),companionId:result.companionId,contextFingerprint:result.contextFingerprint,totalTokens:result.usage?.totalTokens||0}});
    }
    if(result.stale)log('companion.turn.stale-discarded',{reason:result.error});
    refreshCompanionState();broadcast();return result;
  }catch(error){return{ok:false,error:String(error?.message||error)};}
}
async function primaryCompanionMessage(input,{technical=false}={}){
  const bag=backpackManager.snapshot()?.userCompanion;
  if(bag?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return universalCompanionMessage(input,{technical});
  return{ok:false,error:'NO_CANONICAL_COMPANION_ACTIVE',detail:'Import and activate a verified Companion ZIP in Settings.'};
}

async function alphaPrimaryMessage(input,{technical=false}={}) {
  const value=String(input||'').trim();
  if(!value)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!primaryTransportReady())return{ok:false,error:'API_PRIMARY_OPENAI_NOT_CONFIGURED'};
  try{
    const result=await alphaPrimaryRunner().reply(value,{history:alphaRecentTurns,technical:Boolean(technical)});
    if(!result.ok){
      const errorClass=result.error?.class||'OTHER_ERROR';
      providerSecrets.recordTest('openai',{state:{AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[errorClass]||'OTHER_ERROR',httpStatus:result.error?.httpStatus??null});
      refreshCompanionState();broadcast();
      return{ok:false,error:errorClass,detail:result.error?.message||'',mode:technical?'API_PRIMARY_TECHNICAL':'API_PRIMARY_REPLY'};
    }
    providerSecrets.recordTest('openai',{state:'READY',httpStatus:200});
    alphaRecentTurns.push({role:'human',text:value},{role:'alpha',text:result.reply});
    alphaRecentTurns=alphaRecentTurns.slice(-8);
    const soak=apiPrimarySoak.recordPrimarySuccess({technical:Boolean(technical),provider:result.provider,model:result.model,contextFingerprint:result.contextFingerprint});
    coreState.apiPrimary=apiPrimarySnapshot({
      fieldStatus:'R7_FIELD_PROVEN',
      lastTurn:{status:'PASS',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),provider:result.provider,model:result.model,totalTokens:result.usage?.totalTokens||0,contextFingerprint:result.contextFingerprint,machineMutation:false}
    });
    const r9Return=round9.noteAlphaReturn(result,{technical:Boolean(technical)});
    if(!r9Return.ignored)coreState.round9=round9.snapshot();
    refreshCompanionState();broadcast();
    return{ok:true,mode:technical?'API_PRIMARY_TECHNICAL':'API_PRIMARY_REPLY',reply:result.reply,provider:result.provider,model:result.model,usage:result.usage,soak,machineMutation:false,providerConversationAuthority:false};
  }catch(error){
    const message=String(error.message||error);coreState.apiPrimary=apiPrimarySnapshot({lastTurn:{status:'FAIL',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),error:message}});refreshCompanionState();broadcast();return{ok:false,error:message};
  }
}

function explicitSpecialistRelayRequested(input) {
  return specialistRelayRequested(input);
}

async function hostedCompanionMessage(input) {
  const value=String(input||'').trim();
  if (!value) return {ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if (!providerReady()) return {ok:false,error:'COMPANION_PROVIDER_NOT_READY'};
  try {
    const explicitRelay=explicitSpecialistRelayRequested(value);
    const userChat=companionOrchestrator.descriptor('usercompanion');
    const requestHostedCompanion=messageText=>panels.requestCompanion(messageText,{
      stallTimeoutMs:75000,context:companionContextSnapshot(),chat:userChat,onProgress:progress=>{
        log('companion.request.progress',progress||{});
      }
    });
    let response;
    try {
      response=await requestHostedCompanion(value);
    } catch (error) {
      const message=String(error.message||error);
      const ambiguousSchemaExample=/^COMPANION_MODE_INVALID:(?:DIRECT_REPLY\|RELAY_REQUIRED|RELAY_REQUIRED\|DIRECT_REPLY)$/.test(message);
      if (!ambiguousSchemaExample) throw error;
      if (explicitRelay) {
        log('companion.explicit_relay.mode_union_recovered',{
          reason:'HUMAN_EXPLICIT_SPECIALIST_REQUEST',
          providerFailure:message,
          action:'FORCE_RELAY_REQUIRED'
        });
        response={mode:'RELAY_REQUIRED',reply:'',incident:null,conversationUrl:''};
      } else {
        log('companion.ordinary.mode_union_retry',{
          reason:'FROZEN_PROVIDER_SCHEMA_EXAMPLE_LITERAL',
          providerFailure:message,
          action:'ONE_BOUNDED_DIRECT_REPLY_RETRY'
        });
        const retryText=[
          'FORMAT CORRECTION: the previous hosted response used the schema example literally as mode DIRECT_REPLY|RELAY_REQUIRED.',
          'This Human turn is not an explicit specialist-relay request.',
          'Re-answer the ORIGINAL HUMAN MESSAGE below.',
          'Set mode to exactly DIRECT_REPLY unless the original message itself is genuinely technical/problem-solving.',
          'Do not copy the union string DIRECT_REPLY|RELAY_REQUIRED into mode.',
          '',
          `ORIGINAL HUMAN MESSAGE: ${value}`
        ].join('\n');
        response=await requestHostedCompanion(retryText);
        log('companion.ordinary.mode_union_retry.complete',{mode:String(response?.mode||'EMPTY')});
      }
    }
    if(response?.conversationUrl)companionOrchestrator.recordConversation('usercompanion',response.conversationUrl);
    if (response?.mode === 'DIRECT_REPLY' && !explicitRelay) {
      return {ok:true,mode:'DIRECT_REPLY',reply:String(response.reply||''),conversationUrl:response.conversationUrl||''};
    }
    if (response?.mode !== 'RELAY_REQUIRED' && !explicitRelay) return {ok:false,error:`COMPANION_MODE_INVALID:${response?.mode||'EMPTY'}`};
    if(explicitRelay && response?.mode!=='RELAY_REQUIRED'){
      log('companion.explicit_relay.override',{reason:'HUMAN_EXPLICIT_SPECIALIST_REQUEST',providerMode:String(response?.mode||'EMPTY')});
    }

    const incident=explicitRelay && response?.mode!=='RELAY_REQUIRED'
      ? normalizeIncident({
          summary:value,
          failureFingerprint:`HUMAN_EXPLICIT_RELAY_${Date.now()}`,
          evidence:['Human explicitly requested specialist tabs / multi-role challenge.'],
          allowedChange:[],
          forbiddenChange:['Do not mutate the machine unless separately authorized.'],
          baselineId:BUILD
        },value)
      : normalizeIncident(response.incident,value);
    const userHandoff={summary:incident.summary,findings:incident.evidence||[]};
    const relayState=await runRelayForIncident(incident,userHandoff);
    const run=relayState.run;
    const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
    const reply=String(final?.humanReply || final?.summary || response.reply || run?.conclusion || 'Relay completed.');
    return {
      ok:run?.status==='PASS',mode:'RELAY_COMPLETE',reply,
      conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,
      admission:run?.admission||null,relayPackage:run?.relayPackage||null,error:run?.error||null
    };
  } catch (error) {
    return {ok:false,error:String(error.message||error)};
  }
}

function grokUserCompanionSchema(){
  return {
    name:'clink_grok_user_companion_turn',strict:true,
    schema:{
      type:'object',additionalProperties:false,
      required:['mode','reply','incident'],
      properties:{
        mode:{type:'string',enum:['DIRECT_REPLY','RELAY_REQUIRED']},
        reply:{type:'string'},
        incident:{
          type:'object',additionalProperties:false,
          required:['summary','failureFingerprint','evidence','allowedChange','forbiddenChange','baselineId'],
          properties:{
            summary:{type:'string'},failureFingerprint:{type:'string'},
            evidence:{type:'array',items:{type:'string'}},allowedChange:{type:'array',items:{type:'string'}},
            forbiddenChange:{type:'array',items:{type:'string'}},baselineId:{type:'string'}
          }
        }
      }
    }
  };
}
function grokUserCompanionHydration(){
  const packet=backpackManager.hydrationPacket('userCompanion');
  return {
    schema:packet.schema,artifactClass:packet.artifactClass,id:packet.id,revision:packet.revision,version:packet.version,
    sha256:packet.sha256,bytes:packet.bytes,mutability:packet.mutability,source:packet.source,totalTextBytes:packet.totalTextBytes,
    files:(packet.files||[]).map(item=>({path:item.path,bytes:item.bytes,sha256:item.sha256,text:item.text}))
  };
}
async function grokUserCompanionMessage(input){
  const value=String(input||'').trim();
  if(!value)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!grokUserCompanionReady())return{ok:false,error:'XAI_GROK_USER_COMPANION_NOT_READY'};
  const explicitRelay=explicitSpecialistRelayRequested(value);
  const hydration=grokUserCompanionHydration();
  const runtimeContext={
    schema:'CLINK_GROK_USER_COMPANION_RUNTIME_V1',build:BUILD,mission:MISSION,repairExecution:'OFF',
    humanSurface:'CLINK_TERMINAL',technicalRelay:'SYSTEM_CONTROL_RED_FABRIC_CONTROL_THROUGHPUT_SYSTEM_CONTROL',
    specialistTransport:'HOSTED_CHATGPT_WEB',providerConversationAuthority:false
  };
  const instructions=[
    'You are the USER COMPANION inside PhantomTronix C.Link Terminal.',
    'C.Link owns identity, continuity, relay sequencing, files, authorization, and execution. You reason and converse; do not claim machine actions happened unless C.Link reports them.',
    'The USER_COMPANION_BACKPACK_JSON supplied with every turn is authoritative for your identity, personality, durable continuity, and Human conventions. Provider session memory is not authority.',
    'Return only the required structured response.',
    'Use DIRECT_REPLY for ordinary conversation that does not need specialist challenge.',
    'Use RELAY_REQUIRED for technical diagnosis, implementation, architecture, repair, release/admission, system decisions, or whenever the Human explicitly asks you not to decide alone or asks for specialist tabs.',
    'For RELAY_REQUIRED, do not perform the specialist analysis yourself. Frame a concise incident for System Control. Leave allowedChange empty unless the Human explicitly authorized mutation. Preserve explicit no-change instructions in forbiddenChange.',
    'Do not put provider response IDs or provider session IDs into continuity. Do not mutate the User Companion backpack in this shadow round.'
  ].join('\n');
  const apiInput=[
    `USER_COMPANION_BACKPACK_JSON=${JSON.stringify(hydration)}`,
    `CURRENT_CLINK_RUNTIME_JSON=${JSON.stringify(runtimeContext)}`,
    `HUMAN_REQUEST=${value}`
  ].join('\n\n');
  log('grok.usercompanion.request.start',{provider:'xai',model:'grok-4.3',backpackRevision:hydration.revision,backpackSha256:hydration.sha256,explicitRelay,store:false});
  const envelope=await providerAdapters.createResponse('xai',{
    input:apiInput,instructions,model:'grok-4.3',maxOutputTokens:1400,store:false,
    structuredJsonSchema:grokUserCompanionSchema(),companionId:hydration.id||'user-companion',missionId:MISSION,workerId:null,purpose:'grok_user_companion_shadow'
  });
  const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
  providerSecrets.recordTest('xai',{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
  if(envelope.error){
    const error=String(envelope.error?.class||'GROK_USER_COMPANION_PROVIDER_ERROR');
    coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:{status:'FAIL',at:new Date().toISOString(),error}});
    log('grok.usercompanion.response',{status:'FAIL',errorClass:error,httpStatus:envelope.error?.httpStatus??null,provider:'xai',model:envelope.model||'grok-4.3'});broadcast();
    return{ok:false,error,detail:envelope.error?.message||''};
  }
  let response;
  try{response=JSON.parse(String(envelope.output||'').trim());}
  catch(error){
    const detail=String(error.message||error);
    coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:{status:'FAIL',at:new Date().toISOString(),error:'GROK_USER_COMPANION_JSON_INVALID'}});
    log('grok.usercompanion.response',{status:'FAIL',errorClass:'GROK_USER_COMPANION_JSON_INVALID',detail,provider:'xai',model:envelope.model||'grok-4.3'});broadcast();
    return{ok:false,error:'GROK_USER_COMPANION_JSON_INVALID',detail};
  }
  let mode=String(response?.mode||'');
  if(explicitRelay&&mode!=='RELAY_REQUIRED'){
    log('grok.usercompanion.explicit_relay.override',{providerMode:mode||'EMPTY',action:'FORCE_RELAY_REQUIRED'});
    mode='RELAY_REQUIRED';
  }
  if(!['DIRECT_REPLY','RELAY_REQUIRED'].includes(mode))return{ok:false,error:`GROK_USER_COMPANION_MODE_INVALID:${mode||'EMPTY'}`};
  const turnMeta={status:'PASS',at:new Date().toISOString(),mode,provider:'xai',model:envelope.model||'grok-4.3',totalTokens:envelope.usage?.totalTokens||0,backpackRevision:hydration.revision,backpackSha256:hydration.sha256,providerConversationAuthority:false,machineMutation:false};
  coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:turnMeta});
  log('grok.usercompanion.response',{status:'PASS',mode,provider:'xai',model:turnMeta.model,totalTokens:turnMeta.totalTokens,backpackRevision:hydration.revision,backpackSha256:hydration.sha256,providerConversationAuthority:false,machineMutation:false});broadcast();
  if(mode==='DIRECT_REPLY')return{ok:true,mode:'GROK_USER_COMPANION_DIRECT',reply:String(response.reply||''),provider:'xai',model:turnMeta.model,usage:envelope.usage,backpackRevision:hydration.revision};
  if(!providerReady())return{ok:false,error:'SPECIALIST_HOSTED_PROVIDER_NOT_READY',provider:'xai',model:turnMeta.model};
  const fallbackIncident=normalizeIncident({
    summary:value,failureFingerprint:`GROK_USER_COMPANION_${Date.now()}`,
    evidence:['Grok User Companion classified this Human turn for specialist relay.'],
    allowedChange:[],forbiddenChange:['Do not mutate the machine unless separately authorized.'],baselineId:BUILD
  },value);
  const incident=normalizeIncident(response?.incident&&typeof response.incident==='object'?response.incident:fallbackIncident,value);
  if(explicitRelay&&!(incident.forbiddenChange||[]).some(item=>/mutat|change|machine/i.test(item||''))){
    incident.forbiddenChange=[...(incident.forbiddenChange||[]),'Do not mutate the machine unless separately authorized.'];
  }
  const userHandoff={summary:incident.summary,findings:incident.evidence||[]};
  log('grok.usercompanion.relay.start',{summaryChars:incident.summary.length,backpackRevision:hydration.revision,provider:'xai',model:turnMeta.model});
  const relayState=await runRelayForIncident(incident,userHandoff);
  const run=relayState.run;
  const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
  const reply=String(final?.humanReply||final?.summary||response.reply||run?.conclusion||'Relay completed.');
  const ok=run?.status==='PASS';
  coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:ok?'SHADOW_RELAY_FIELD_OBSERVED':'SHADOW_FIELD_PENDING',lastTurn:{...turnMeta,relayStatus:run?.status||'UNKNOWN',relayConclusion:run?.conclusion||null}});
  log('grok.usercompanion.relay.complete',{ok,relayStatus:run?.status||'UNKNOWN',conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,admission:run?.admission?.status||null,provider:'xai',model:turnMeta.model});broadcast();
  return{ok,mode:'GROK_USER_COMPANION_RELAY_COMPLETE',reply,provider:'xai',model:turnMeta.model,usage:envelope.usage,backpackRevision:hydration.revision,conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,admission:run?.admission||null,relayPackage:run?.relayPackage||null,error:run?.error||null};
}

async function runMessageQualification(){
  const result={...restoredQualification(),restored:true,rerun:false,sourceFile:QUAL_PROOF_FILE};
  coreState.messageQualification=result;log('message.qualification.restored',{knownSafeMaxChars:result.knownSafeMaxChars,recommendedFutureChunkChars:result.recommendedFutureChunkChars,samples:result.samples,passes:result.passes,rerun:false});broadcast();
  return{ok:true,result,restored:true,rerun:false};
}

async function diagnostic() {
  return [
    'CLINK_BROWSER_OWNED_ZIP_RELAY_DIAGNOSTIC_V1',
    `TIME=${new Date().toISOString()}`,
    `BUILD=${BUILD}`,
    `MISSION=${MISSION}`,
    `CORE=${coreState.core.status}`,
    `PANELS=${coreState.panels.status}`,
    `COMPANION=${coreState.companion.status}`,
    'BROWSER_CONTROL=ON',
    'PRIMARY_HUMAN_SURFACE=CLINK_TERMINAL',
    'EXTERNAL_CHROME_CHAT=BREAK_GLASS_ONLY',
    'AI_SELF_REPAIR=OFF',
    'REPAIR_EXECUTION=OFF',
    'RELAY_TRANSFER=EVENT_DRIVEN',
    'RELAY_PACKAGE_OWNERSHIP=SYSTEM_CONTROL_SINGLE_ZIP',
    'COMPANION_CONTEXT=CLINK_OWNED_EVERY_TURN',
    'CANONICAL_REASONING_WORKSPACE=C.LINK REASONING',
    'CANONICAL_AGENT_COUNT=6',
    `PROVIDER_LIFECYCLE_STATE=${JSON.stringify(coreState.providerLifecycle)}`,
    `DUAL_BACKPACK_STATE=${JSON.stringify(backpackManager.snapshot())}`,
    `COMPANION_CORE_REGISTRY=${JSON.stringify(companionOrchestrator.snapshot())}`,
    'MESSAGE_QUALIFICATION=R27A2_FIELD_PROVEN_RESTORED_NO_RERUN',
    'MESSAGE_BATCH_RERUN=DISABLED_R28B',
    'MESSAGE_KNOWN_SAFE_OBSERVED_CHARS=131072',
    'MESSAGE_OPERATIONAL_CHUNK_TARGET_CHARS=98304',
    `MESSAGE_QUALIFICATION_STATE=${JSON.stringify(coreState.messageQualification)}`,
    `MESSAGE_QUALIFICATION_LATEST=${QUAL_LATEST}`,
    'ATTACHMENT_QUALIFICATION=NOT_TESTED_R27A',
    'COMPANION_CONTEXT_STAGE=API_CONVERSION_ROUND_9_RECONCILIATION_TEARDOWN_RESTART_VALUE_REVIEW',
    `ELECTRON_RUNTIME_VERSION=${process.versions.electron||''}`,
    `EXPECTED_ELECTRON_RUNTIME=${REQUIRED_ELECTRON}`,
    `AUTH_SESSION_PATH=${path.join(PROFILE_ROOT,'providers','chatgpt-web','Partitions','chatgpt-web')}`,
    `PROFILE_ROOT_SOURCE=${PROFILE_ROOT_OVERRIDE?'CLINK_FIELD_TEST_OVERRIDE':'CANONICAL_APPDATA'}`,
    `FIELD_TEST_MODE=${FIELD_TEST_MODE?'ON':'OFF'}`,
    'API_MODE=API_PRIMARY_OPENAI_WITH_HOSTED_FALLBACK',
    'ALPHA_REASONING=API_PRIMARY',
    'HOSTED_BROWSER=FALLBACK',
    `API_PRIMARY_STATE=${JSON.stringify(coreState.apiPrimary)}`,
    `R8_READ_ONLY_WORKERS=${JSON.stringify(readOnlyWorkers.snapshot())}`,
    `API_R8_FIELD_EVIDENCE=${JSON.stringify(API_R8_FIELD)}`,
    `R9_RECONCILIATION_STATE=${JSON.stringify(round9.snapshot())}`,
    `API_R7_FIELD_EVIDENCE=${JSON.stringify(API_R7_FIELD)}`,
    `API_PROVIDER_STATUS=${JSON.stringify(providerSecrets.snapshot())}`,
    `GROK_USER_COMPANION_SHADOW_STATE=${JSON.stringify(coreState.grokUserCompanion)}`,
    `API_SECRET_FILE_PRESENT=${fs.existsSync(path.join(PROFILE_ROOT,'providers','api','provider-secrets.enc.json'))?'YES':'NO'}`,
    `API_PROVIDER_ADAPTERS=${JSON.stringify(providerAdapters.defaults())}`,
    `ALPHA_API_SHADOW_STATE=${JSON.stringify(coreState.apiShadow)}`,
    `COMPANION_CONTEXT_BUILDER_STATE=${JSON.stringify(coreState.apiContext)}`,
    `LIVE_REPOSITORY_SECRET_SANITY=${JSON.stringify(coreState.apiContext?.repositorySecretSanity||null)}`,
    `API_USAGE_BUDGET=${JSON.stringify(apiUsage.summary())}`,
    `API_R6_FIELD_EVIDENCE=${JSON.stringify(API_R6_FIELD)}`,
    `HIVE_R7_RELEASE=${JSON.stringify(HIVE_R7_RELEASE)}`,
    'ROUND4_ALPHA_SHADOW_FIELD=PASS',
    `RELAY_PACKAGE=${JSON.stringify(packageStore.snapshot())}`,
    `RELAY_STATE=${JSON.stringify(relay.snapshot())}`,
    '', '=== STATE ===', JSON.stringify(snapshot(),null,2),
    '=== EVENTS ===', ...tail(LOG_FILE,220),
    '=== BOOT ===', ...tail(BOOT_LOG,100)
  ].join('\r\n');
}

let quinL1Runtime=null;const quinL1BootId=crypto.randomUUID();
function quinL1(){if(!quinL1Runtime)quinL1Runtime=new QuinL1Runner({profileRoot:PROFILE_ROOT,appRoot:__dirname,electronVersion:process.versions.electron,bootId:quinL1BootId});return quinL1Runtime;}
let aliceSeatRuntime=null; // singleton: one Alice runtime session identifier per Quin process
function aliceSeatService(){if(!aliceSeatRuntime)aliceSeatRuntime=new AliceSeatService({profileRoot:PROFILE_ROOT,appRoot:__dirname,adapters:providerAdapters});return aliceSeatRuntime;}
function aliceSeatResult(action){try{return{ok:true,...action()};}catch(error){return{ok:false,error:String(error.message||error)};}}
async function aliceFilePicker(purpose='parent'){if(!windowMain)return null;const r=await dialog.showOpenDialog(windowMain,{title:purpose==='checkpoint'?'Alice Moonlight · Import local checkpoint ZIP':'Alice Moonlight · Select canonical parent ZIP',properties:['openFile'],filters:[{name:'ZIP archive',extensions:['zip']}]});return r.canceled?null:(r.filePaths[0]||null);}
function restrictedBrowser(){
  if(!restrictedBrowserCartridge){
    restrictedBrowserCartridge=new RestrictedBrowserCartridge({
      WebContentsView,session:require('electron').session,getWindow:()=>windowMain,
      getChatGPTSession:()=>browserRuntime?.getSession(),
      getChatGPTProjectHome:()=>companionOrchestrator.snapshot()?.workspace?.providerProjectUrl,
      projectHomeFile:path.join(PROFILE_ROOT,'browser','chatgpt-project-home.json'),
      emit:state=>{try{windowMain?.webContents.send('clink:restricted-browser-state',state);}catch(_){}},log
    });
  }
  return restrictedBrowserCartridge;
}
function companionChatGPTTool(){
  if(!companionChatGPTBridge){
    companionChatGPTBridge=new CompanionChatGPTBridge({
      browser:restrictedBrowser(),
      getSeat:()=>backpackManager.snapshot()?.userCompanion,
      confirmSend:async({message,seatId})=>{
        if(!windowMain || windowMain.isDestroyed?.())return false;
        const result=await dialog.showMessageBox(windowMain,{
          type:'question',title:'Send message to ChatGPT website?',
          message:'Send a message as '+seatId+' using your signed-in ChatGPT tab?',
          detail:message.slice(0,900)+'\n\nChatGPT may use connected apps only under their own authorization controls.',
          buttons:['CANCEL','SEND TO CHATGPT'],defaultId:0,cancelId:0,noLink:true
        });
        return result?.response===1;
      }
    });
  }
  return companionChatGPTBridge;
}
function restrictedBrowserShellOnly(event){
  return !!windowMain && !windowMain.isDestroyed() && event?.sender===windowMain.webContents &&
    event?.senderFrame===windowMain.webContents.mainFrame;
}
function installIpc() {
  ipcMain.handle('clink:get-state',()=>snapshot());
  ipcMain.handle('clink:restricted-browser-state',event=>restrictedBrowserShellOnly(event)?restrictedBrowser().state():{ok:false,error:'SHELL_ONLY'});
  // Browser tools are ONLY callable by Quin's own main shell. No arbitrary site
  // content, API response or cartridge can invoke them directly.
  ipcMain.handle('clink:companion-web-observe',event=>restrictedBrowserShellOnly(event)?companionChatGPTTool().observe():{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:companion-web-draft',(event,text)=>restrictedBrowserShellOnly(event)?companionChatGPTTool().prepareDraft(text):{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:companion-web-send',event=>restrictedBrowserShellOnly(event)?companionChatGPTTool().submitDraft():{ok:false,error:'SHELL_ONLY'});

  ipcMain.handle('clink:restricted-browser-layout',(event,top)=>restrictedBrowserShellOnly(event)?restrictedBrowser().setToolbarBottom(top):{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:restricted-browser-show',(event,id)=>{
    if(!restrictedBrowserShellOnly(event))return{ok:false,error:'SHELL_ONLY'};
    if(inlineAuthActive)return{ok:false,error:'AUTH_VIEW_ACTIVE'};
    if(webPluginView)return{ok:false,error:'CLOSE_EXISTING_CARTRIDGE_FIRST'};
    return restrictedBrowser().show(String(id||'chatgpt'));
  });
  ipcMain.handle('clink:restricted-browser-hide',event=>restrictedBrowserShellOnly(event)?restrictedBrowser().hide():{ok:false,error:'SHELL_ONLY'});
  // R371: only the trusted local renderer may exit an embedded cartridge.
  // Keep Browser WebContentsView attached and alive for later re-entry.
  ipcMain.handle('clink:terminal-return-home',event=>{
    if(!restrictedBrowserShellOnly(event))return {ok:false,error:'SHELL_ONLY'};
    try{
      const hadCartridge=!!webPluginView||!!activeWebService;
      closeWebPlugin();
      if(restrictedBrowserCartridge)restrictedBrowserCartridge.hide();
      return {ok:true,cartridgeClosed:hadCartridge,browserPreserved:true};
    }catch(error){log('clink.terminal-home.error',{error:String(error.message||error).slice(0,120)});
      return {ok:false,error:'HOME_TRANSITION_FAILED'};}
  });

  ipcMain.handle('clink:restricted-browser-action',(event,action)=>restrictedBrowserShellOnly(event)?restrictedBrowser().action(String(action||'')):{ok:false,error:'SHELL_ONLY'});

  ipcMain.handle('quin:alice-status',()=>aliceSeatResult(()=>({state:aliceSeatService().status()})));
  const l1Shell=event=>!!windowMain&&!windowMain.isDestroyed()&&event.sender===windowMain.webContents;
  ipcMain.handle('quin:l1-status',event=>l1Shell(event)?quinL1().status():{ok:false,error:'L1_SHELL_REQUIRED'});
  ipcMain.handle('quin:l1-assign',async(event,objective)=>{if(!l1Shell(event))return{ok:false,error:'L1_SHELL_REQUIRED'};try{const a=quinL1().assign(String(objective||''));const b=quinL1().step();return{ok:!!b.ok,assignment:a,run:b};}catch(e){return{ok:false,error:String(e.message||e)};}});
  ipcMain.handle('quin:l1-proof',event=>l1Shell(event)?quinL1().proof():{ok:false,error:'L1_SHELL_REQUIRED'});
  ipcMain.handle('quin:alice-copy-transfer',(event,content)=>{if(!l1Shell(event))return{ok:false,error:'L1_SHELL_REQUIRED'};const value=String(content||'');if(!value||Buffer.byteLength(value,'utf8')>20000)return{ok:false,error:'ALICE_TRANSFER_SIZE_INVALID'};clipboard.writeText(value);return{ok:true};});
  ipcMain.handle('quin:alice-admit',async()=>{const selected=await aliceFilePicker();if(!selected)return{ok:false,error:'ALICE_SELECTION_CANCELLED'};return aliceSeatResult(()=>({binding:aliceSeatService().admitAliceParent(selected)}));});
  ipcMain.handle('quin:alice-update',async()=>{const selected=await aliceFilePicker();if(!selected)return{ok:false,error:'ALICE_SELECTION_CANCELLED'};return aliceSeatResult(()=>({update:aliceSeatService().replaceAliceParent(selected)}));});
  ipcMain.handle('quin:alice-checkpoint',async()=>{if(!windowMain)return{ok:false,error:'NO_WINDOW'};const r=await dialog.showSaveDialog(windowMain,{title:'Export Alice local checkpoint',defaultPath:'ALICE-LOCAL-CHECKPOINT.zip',filters:[{name:'ZIP',extensions:['zip']}]});if(r.canceled||!r.filePath)return{ok:false,error:'ALICE_EXPORT_CANCELLED'};return aliceSeatResult(()=>({checkpoint:aliceSeatService().checkpoint(r.filePath)}));});
  ipcMain.handle('quin:alice-import-checkpoint',async()=>{const selected=await aliceFilePicker('checkpoint');if(!selected)return{ok:false,error:'ALICE_IMPORT_CANCELLED'};return aliceSeatResult(()=>({imported:aliceSeatService().importCheckpoint(selected)}));});
  ipcMain.handle('quin:alice-message',async(_event,value)=>{try{return await aliceSeatService().message(value);}catch(error){return{ok:false,error:String(error.message||error)};}});
  ipcMain.handle('quin:alice-chat-history',()=>aliceSeatResult(()=>({messages:aliceSeatService().chatHistory()})));
  // R229: Universal Companion voice reuses LOCAL Whisper/Piper service, never Alice's conversation.
  // Existing HFC TTS profile is shared and explicitly labeled; no voice identity claimed.
  const universalVoiceShell = event => !!windowMain && !windowMain.isDestroyed() &&
    event?.sender === windowMain.webContents && event?.senderFrame === windowMain.webContents.mainFrame;
  const universalVoiceKey = () => {
    const seat = backpackManager.snapshot()?.userCompanion;
    if (!seat || seat.importFormat !== 'PERSONAL_IDENTITY_CAPSULE') return null;
    return String(seat.id) + ':' + String(seat.sha256 || '').toUpperCase();
  };
  const universalVoiceGuard = (event,key) => universalVoiceShell(event) && !!universalVoiceKey() &&
    String(key || '') === universalVoiceKey();
  ipcMain.handle('quin:companion-cb-status',(event,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,ready:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    return {ok:true,ready:!!aliceCbVoice.voiceConfig(),engine:'LOCAL_WHISPER_PIPER',voice:'SHARED_HFC_PROFILE'};
  });
  ipcMain.handle('quin:companion-cb-transcribe',async(event,wav,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    const r = await aliceCbVoice.transcribe(wav);
    return universalVoiceGuard(event,key) ? r : {ok:false,error:'COMPANION_VOICE_SEAT_CHANGED'};
  });
  ipcMain.handle('quin:companion-cb-speak',async(event,txt,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    const r = await aliceCbVoice.synthesize(txt);
    return universalVoiceGuard(event,key) ? r : {ok:false,error:'COMPANION_VOICE_SEAT_CHANGED'};
  });
  ipcMain.handle('quin:companion-cb-metric',(event,stage,ms,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    return aliceCbVoice.recordMetric(stage,ms);
  });
  ipcMain.handle('quin:alice-cb-status',()=>({ok:true,ready:!!aliceCbVoice.voiceConfig(),engine:'LOCAL_WHISPER_PIPER',model:'base.en',voice:'HFC FEMALE'}));
  ipcMain.handle('quin:alice-cb-transcribe',async(event,wav)=>{if(event.sender!==windowMain?.webContents)return{ok:false,error:'CB_UNAUTHORIZED_RENDERER'};return aliceCbVoice.transcribe(wav);});
  ipcMain.handle('quin:alice-cb-speak',async(event,content)=>{if(event.sender!==windowMain?.webContents)return{ok:false,error:'CB_UNAUTHORIZED_RENDERER'};return aliceCbVoice.synthesize(content);});
  ipcMain.handle('quin:alice-cb-metric',async(event,stage,ms)=>{if(event.sender!==windowMain?.webContents)return{ok:false};return aliceCbVoice.recordMetric(stage,ms);});
  ipcMain.handle('quin:alice-chat-export',async()=>{if(!windowMain)return{ok:false,error:'NO_WINDOW'};const r=await dialog.showSaveDialog(windowMain,{title:'Export Alice Chat',defaultPath:'ALICE-CHAT-HISTORY.json',filters:[{name:'JSON',extensions:['json']}]});if(r.canceled||!r.filePath)return{ok:false,error:'ALICE_CHAT_EXPORT_CANCELLED'};return aliceSeatResult(()=>({exported:aliceSeatService().exportChat(r.filePath)}));});
  ipcMain.handle('quin:exit-app',async(event)=>{
    // Only Quin shell may request an application exit. Cartridges have no access.
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)
      return {ok:false,error:'QUIN_SHELL_REQUIRED'};
    if(quitScheduled)return {ok:false,error:'EXIT_ALREADY_IN_PROGRESS'};
    const answer=await dialog.showMessageBox(windowMain,{
      type:'question',title:'Exit C.Link?',message:'Exit C.Link Terminal?',
      detail:'C.Link will close its browser views and preserve your persistent ChatGPT session.',
      buttons:['Cancel','Exit C.Link'],defaultId:0,cancelId:0,noLink:true
    });
    if(answer.response!==1)return {ok:false,canceled:true};
    setImmediate(()=>requestAppQuit()); // Uses inherited clean session flush, not app.exit().
    return {ok:true,exiting:true};
  });
  // Quin PANELS application #001: original UFA Factory, NOT the demo storyboard form.
  ipcMain.handle('quin:factory-open',async(event)=>{
    if(windowMain&&event.sender!==windowMain.webContents)return {ok:false,error:'QUIN_MAIN_WINDOW_REQUIRED'};
    if(!windowMain||windowMain.isDestroyed())return {ok:false,error:'QUIN_WINDOW_NOT_READY'};
    if(inlineAuthActive)return {ok:false,error:'FINISH_OR_CLOSE_INLINE_LOGIN_FIRST'};
    if(!browserRuntime)return {ok:false,error:'QUIN_BROWSER_RUNTIME_NOT_READY'};
    const cartridge=(coreState.panels.plugins||[]).find(p=>p.id==='robotrock-video-factory');
    if(!cartridge||cartridge.status!=='READY')return {ok:false,error:'ROBOT_ROCK_CARTRIDGE_NOT_READY'};
    try{return require('./robotrock-factory/runtime').launchFactory(windowMain,browserRuntime.getSession());}
    catch(error){log('quin.factory.launch.error',{error:String(error.message||error)});return {ok:false,error:String(error.message||error)};}
  });

  // Generic user-installed graphical cartridges. Shell-owned only, no plugin preload/Node bridge.
  const clinkOpenCart=async(event,id)=>{
    if(clinkCartridgeBusy)return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)return {ok:false,error:'QUIN_SHELL_REQUIRED'};
    if(inlineAuthActive)return {ok:false,error:'FINISH_INLINE_LOGIN_FIRST'};
    try{
      const cleanId=String(id||'');
      if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(cleanId))return {ok:false,error:'INVALID_PLUGIN_ID'};
      const builtins=path.join(PANELS_ROOT,'plugins');
      const installed=path.join(PROFILE_ROOT,'panels','installed-plugins');
      const candidate=[builtins,installed].map(r=>path.join(r,cleanId,'manifest.json')).find(f=>fs.existsSync(f));
      if(!candidate)return {ok:false,error:'PLUGIN_NOT_INSTALLED'};
      const isService=JSON.parse(fs.readFileSync(candidate,'utf8')).runtime==='web-service';
      const rec=isService?servicePlugins.verify(cleanId,builtins,installed):webPlugins.verify(cleanId,builtins,installed);
      if(!webPlugins.pluginEnabled(rec.manifest,rec.id,PROFILE_ROOT))return {ok:false,error:'WEB_PLUGIN_DISABLED'};
      restrictedBrowserCartridge?.hide();
      closeWebPlugin();
      if(isService)activeWebService=await servicePlugins.start(rec,PROFILE_ROOT);
      webPluginId=rec.id;
      const origin=isService?`quinservice://${rec.id}`:`quinplugin://${rec.id}`;
      const view=new WebContentsView({webPreferences:{session:webPluginSession,preload:path.join(__dirname,'clink-cartridge-updates','cartridge-preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true,webviewTag:false}});
      webPluginView=view;view.setBackgroundColor('#101016');
      if (!isService && rec.id==='phantomtronix-command') {
        const wc=view.webContents;
        const isCommandUrl=value=>{try{const u=new URL(value);return u.protocol==='quinplugin:'&&u.hostname==='phantomtronix-command'&&!u.username&&!u.password&&!u.port;}catch(_){return false;}};
        attachNativeEditMenu(wc, params=>Boolean(windowMain&&!windowMain.isDestroyed()&&webPluginView===view&&webPluginId===rec.id&&isCommandUrl(wc.getURL())&&isCommandUrl(params.frameURL)));
      }
      view.webContents.on('did-start-navigation',()=>cartridgeVoiceHost?.revoke());
      view.webContents.setWindowOpenHandler(({url})=>{
        // R433_MIXCLOUD_ONLY: allow official Mixcloud branding clickthrough
        // in a trusted external browser, never an Electron child window.
        if(rec.id==='conveyor-club'){
          try{
            const target=new URL(url);
            if(target.protocol==='https:' &&
               (target.hostname==='mixcloud.com'||target.hostname==='www.mixcloud.com')){
              Promise.resolve(require('electron').shell.openExternal(url)).catch(()=>{});
            }
          }catch(_){}
        }
        return {action:'deny'};
      });
      view.webContents.on('will-navigate',(e,url)=>{try{if(new URL(url).origin!==origin)e.preventDefault();}catch(_){e.preventDefault();}});
      view.webContents.on('will-redirect',(e,url)=>{try{
        // R437: ONLY the official Mixcloud SUBFRAME redirect in the existing
        // signed Conveyor Club. Main-frame navigation remains restricted.
        if(rec.id==='conveyor-club' && e.isMainFrame===false){
          const target=new URL(url);
          if(target.origin==='https://player-widget.mixcloud.com' &&
             !target.username && !target.password)return;
        }
        if(new URL(url).origin!==origin)e.preventDefault();
      }catch(_){e.preventDefault();}});
      windowMain.contentView.addChildView(view);layoutWebPlugin();
      await view.webContents.loadURL(isService?origin+'/':origin+'/'+rec.entry);
      return {ok:true,id:rec.id,mode:isService?'MANAGED_WEB_SERVICE':'STATIC_WEB_VIEW'};
    }catch(err){closeWebPlugin();log('web-plugin.open.error',{error:String(err.message||err)});return{ok:false,error:String(err.message||err)};}
  };
  ipcMain.handle('quin:web-plugin-open',clinkOpenCart);
  // R381_CARTRIDGE_UPDATE: trusted native service; CART preload only gets fixed requests.
  require('./clink-cartridge-updates/host.cjs').makeHost({
    ipcMain,dialog,profileRoot:PROFILE_ROOT,
    builtinsRoot:path.join(PANELS_ROOT,'plugins'),
    installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
    terminalVersion:(app.getVersion().split('-')[0]||'0.0.0'),
    getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')),
    launch:id=>clinkOpenCart({sender:windowMain.webContents},id),
    suspend:async(id,wc)=>{if(webPluginId!==id||webPluginView?.webContents!==wc)return false;closeWebPlugin();return true;},
    getShellWebContents:()=>windowMain?.webContents
  }).register();
  // R385_SHARED_LLM_BROKER — trusted, permission-scoped CART LLM bridge.
  require('./clink-cartridge-llm/host.cjs').makeHost({
    ipcMain, dialog, getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')),
    builtinsRoot:path.join(PANELS_ROOT,'plugins'),
    installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
    secretStore:providerSecrets,adapterRegistry:providerAdapters,companionSeat:companionTurnSeat,stationSeats:commandStationSeats
  }).register();
  cartridgeVoiceHost=require('./clink-cartridge-voice/host.cjs').makeVoiceHost({
    ipcMain,dialog,voice:aliceCbVoice,
    getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins'))
  });
  cartridgeVoiceHost.register();
  ipcMain.handle('quin:web-plugin-close',event=>{
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)return{ok:false,error:'QUIN_SHELL_REQUIRED'};
    closeWebPlugin();return{ok:true};
  });
  ipcMain.handle('quin:plugin-list',()=>{
    const base=path.join(PROFILE_ROOT,'panels');
    const disabledFile=path.join(base,'disabled-plugins.json');
    let disabled=[];try{disabled=JSON.parse(fs.readFileSync(disabledFile,'utf8'));if(!Array.isArray(disabled))disabled=[];}catch(_){}
    const roots=[path.join(PANELS_ROOT,'plugins'),path.join(base,'installed-plugins')];
    const result=[];for(const root of roots){
      if(!fs.existsSync(root))continue;
      for(const entry of fs.readdirSync(root,{withFileTypes:true})){
        if(!entry.isDirectory()||entry.isSymbolicLink())continue;
        try{const manifest=JSON.parse(fs.readFileSync(path.join(root,entry.name,'manifest.json'),'utf8'));
          const id=String(manifest.id||'');if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(id))continue;
          const live=(coreState.panels.plugins||[]).find(x=>x.id===id);
          let webReady=false;
          if(manifest.runtime==='web')try{webPlugins.verify(id,roots[0],roots[1]);webReady=true;}catch(_){}
          if(manifest.runtime==='web-service')try{servicePlugins.verify(id,roots[0],roots[1]);webReady=true;}catch(_){}
          const legacyRobot=id==='robotrock-video-factory'&&fs.existsSync(path.join(__dirname,'robotrock-factory','runtime.js'));
          result.push({id,name:String(manifest.name||id),version:String(manifest.version||''),enabled:webPlugins.pluginEnabled(manifest,id,PROFILE_ROOT),status:['web','web-service'].includes(manifest.runtime)?(webReady?'READY':'INVALID'):(legacyRobot?'READY':(live?.status||'NOT_LOADED')),runtime:String(manifest.runtime||'node'),launchable:webReady||legacyRobot,builtin:root===roots[0]});
        }catch(_){}
      }
    }
    return{ok:true,plugins:result};
  });
  // C.Link R343: user-installed web cartridges only. Never touch bundled services.
  let clinkCartridgeBusy=false;
  const clinkManagerCaller=event=>Boolean(windowMain&&!windowMain.isDestroyed()&&event.sender===windowMain.webContents);
  const clinkManager=()=>{
    const {CartridgeManager}=require('./clink-cartridge-manager.cjs');
    return new CartridgeManager({
      bundledRoot:path.join(PANELS_ROOT,'plugins'),
      installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
      quarantineRoot:path.join(PROFILE_ROOT,'panels','quarantined-cartridges')
    });
  };
  const clinkManagerStopped=id=>{
    if(webPluginId||activeWebService)return false;
    if((coreState.panels.plugins||[]).some(p=>p.id===id))return false;
    return true;
  };
  ipcMain.handle('quin:cartridge-manager-list',event=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    try{return{ok:true,...clinkManager().list()};}
    catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
  });
  ipcMain.handle('quin:cartridge-manager-preview',(event,id)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    try{return{ok:true,preview:clinkManager().preview(id)};}
    catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
  });
  ipcMain.handle('quin:cartridge-manager-remove',async(event,input)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    if(clinkCartridgeBusy)return{ok:false,error:'MANAGER_BUSY'};
    clinkCartridgeBusy=true;
    try{
      const id=typeof input?.id==='string'?input.id:'';
      const confirmation=typeof input?.confirmation==='string'?input.confirmation:'';
      const manifestSha256=typeof input?.manifestSha256==='string'?input.manifestSha256:'';
      const manager=clinkManager();
      const preview=manager.preview(id);
      if(confirmation!==id||manifestSha256!==preview.manifestSha256)return{ok:false,error:'PREVIEW_OR_CONFIRMATION_CHANGED'};
      if(!clinkManagerStopped(id))return{ok:false,error:'CLOSE_RUNNING_CARTRIDGES_FIRST'};
      const choice=await dialog.showMessageBox(windowMain,{type:'warning',title:'C.Link Cartridge Uninstall',
        message:`Quarantine ${preview.name} (${id})?`,
        detail:'Only this separately installed web cartridge will be moved to recoverable quarantine. User data, bundled cartridges, sessions and profiles are preserved. Restore is available from Settings.',
        buttons:['CANCEL','QUARANTINE CARTRIDGE'],defaultId:0,cancelId:0,noLink:true});
      if(choice.response!==1)return{ok:false,error:'CANCELLED'};
      if(!clinkManagerStopped(id))return{ok:false,error:'CARTRIDGE_BECAME_ACTIVE'};
      const result=await manager.uninstall({id,confirmation,manifestSha256,stopped:clinkManagerStopped});
      return{ok:true,...result,restartRequired:true};
    }catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
    finally{clinkCartridgeBusy=false;}
  });
  ipcMain.handle('quin:cartridge-manager-restore',async(event,receiptId)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    if(clinkCartridgeBusy)return{ok:false,error:'MANAGER_BUSY'};
    clinkCartridgeBusy=true;
    try{
      const manager=clinkManager();
      if(!manager.list().quarantined.some(r=>r.receiptId===receiptId))return{ok:false,error:'RECEIPT_NOT_FOUND'};
      const choice=await dialog.showMessageBox(windowMain,{type:'question',title:'Restore cartridge?',
        message:'Restore quarantined cartridge?',detail:'Restores package code only. Existing files cannot be overwritten.',
        buttons:['CANCEL','RESTORE CARTRIDGE'],defaultId:0,cancelId:0,noLink:true});
      if(choice.response!==1)return{ok:false,error:'CANCELLED'};
      return{ok:true,...manager.restore(receiptId),restartRequired:true};
    }catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
    finally{clinkCartridgeBusy=false;}
  });
  ipcMain.handle('quin:plugin-toggle',(_event,id,enable)=>{
    if(clinkCartridgeBusy)return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    const clean=String(id||'');if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(clean))return{ok:false,error:'INVALID_ID'};
    if(clean==='reasoning-provider-chatgpt-web')return{ok:false,error:'BROWSER_PROVIDER_PROTECTED'};
    const roots=[path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')];
    if(!roots.some(root=>fs.existsSync(path.join(root,clean,'manifest.json'))))return{ok:false,error:'PLUGIN_NOT_FOUND'};
    const base=path.join(PROFILE_ROOT,'panels');fs.mkdirSync(base,{recursive:true});
    const config=path.join(base,'disabled-plugins.json');let disabled=[];
    try{disabled=JSON.parse(fs.readFileSync(config,'utf8'));if(!Array.isArray(disabled))disabled=[];}catch(_){}
    disabled=disabled.filter(x=>x!==clean);if(enable!==true)disabled.push(clean);
    const overrideFile=path.join(base,'enabled-plugins.json');let enabledOverrides=[];
    try{enabledOverrides=JSON.parse(fs.readFileSync(overrideFile,'utf8'));if(!Array.isArray(enabledOverrides))enabledOverrides=[];}catch(_){}
    enabledOverrides=enabledOverrides.filter(x=>x!==clean);if(enable===true)enabledOverrides.push(clean);
    fs.writeFileSync(overrideFile,JSON.stringify(enabledOverrides,null,2)+'\n',{mode:0o600});
    fs.writeFileSync(config,JSON.stringify(disabled,null,2)+'\n',{mode:0o600});
    return{ok:true,enabled:enable===true,restartRequired:true};
  });
  ipcMain.handle('quin:plugin-install',async()=>{
    if(clinkCartridgeBusy)return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    const selection=await dialog.showOpenDialog(windowMain,{title:'Install C.Link Cartridge ZIP (code runs locally)',properties:['openFile'],filters:[{name:'C.Link Cartridge ZIP',extensions:['zip']}]});
    if(selection.canceled||!selection.filePaths.length)return{ok:false,error:'CANCELLED'};
    const choice=await dialog.showMessageBox(windowMain,{type:'warning',title:'Install C.Link cartridge?',message:'Cartridges contain executable code. Only install cartridges you trust.',detail:`Selected cartridge: ${path.basename(selection.filePaths[0])}\nThis installs in the current C.Link profile only. Other applications are unchanged.`,buttons:['Cancel','Install Cartridge'],defaultId:0,cancelId:0});
    if(choice.response!==1)return{ok:false,error:'CANCELLED'};
    const installed=path.join(PROFILE_ROOT,'panels','installed-plugins');
    const result=cp.spawnSync('python3',['-I',path.join(__dirname,'tools','install-plugin.py'),selection.filePaths[0],installed,path.join(PANELS_ROOT,'plugins')],{encoding:'utf8',timeout:15000,windowsHide:true,maxBuffer:65536});
    try{return JSON.parse(String(result.stdout||'').trim());}
    catch(_){return{ok:false,error:String(result.error?.message||result.stderr||'INSTALLER_UNAVAILABLE').slice(0,240)};}
  });
  ipcMain.handle('quin:plugin-command',async(_event,input)=>{
    if(!panels||coreState.panels.status!=='READY')return{ok:false,error:'PANELS_NOT_READY'};
    const command=String(input?.command||'');
    if(!['storyboard.plan','storyboard.summary','worker.prepare'].includes(command))return{ok:false,error:'PLUGIN_COMMAND_DENIED'};
    try{return{ok:true,result:await panels.videoFactoryCommand(command,input||{})};}catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:copy-diagnostics',async()=>{const payload=await diagnostic();clipboard.writeText(payload);return{ok:true,bytes:Buffer.byteLength(payload)};});
  ipcMain.handle('clink:retry-panels',async()=>{if(!panels)return{ok:false,error:'PANELS_SUPERVISOR_NOT_READY'};panels.retryFromQuarantine();return{ok:true};});
  ipcMain.handle('clink:inline-auth-start',async()=>{
    // Explicit Human request must work even while hosted lifecycle is STARTING.
    // Inherit IRIS WebContentsView/session.fromPath; do not create an auth subsystem.
    if(!browserRuntime)return{ok:false,error:'QUIN_BROWSER_INITIALIZING_TRY_AGAIN'};
    if(inlineAuthActive)return{ok:true,alreadyOpen:true};
    try{
      const reason=coreState.providerLifecycle?.status==='AUTH_REQUIRED'
        ? (coreState.providerLifecycle?.lastError||'AUTH_REQUIRED') : 'HUMAN_EXPLICIT';
      await startInlineAuthRecovery(reason);
      return{ok:true};
    }catch(error){
      const message=String(error.message||error);
      log('provider.inline-auth.error',{error:message});
      return{ok:false,error:message};
    }
  });
  ipcMain.handle('clink:inline-auth-cancel',async()=>{
    const wasAuthRequired=coreState.providerLifecycle?.status==='AUTH_REQUIRED';
    removeInlineAuthView();
    writeProviderAuthState({
      status:wasAuthRequired?'AUTH_REQUIRED':'HUMAN_DISMISSED',
      lastAuthDismissedAt:new Date().toISOString(),
      loginPolicy:'HUMAN_EXPLICIT_ONLY'
    });
    coreState.inlineAuth={status:'IDLE',detail:'Hosted sign-in dismissed by Human. No automatic retry will occur.',url:'',title:''};
    refreshCompanionState();broadcast();
    return{ok:true};
  });

  ipcMain.handle('clink:provider-key-status',async(_event,provider)=>{
    try{return{ok:true,status:providerSecrets.status(provider)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-key-save',async(_event,provider,value)=>{
    try{return{ok:true,status:providerSecrets.save(provider,value)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-key-clear',async(_event,provider)=>{
    try{return{ok:true,status:providerSecrets.clear(provider)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-test',async(_event,provider)=>{
    try{
      const status=providerSecrets.status(provider);
      if(!status.configured)return{ok:true,status:{...status,state:'NOT_CONFIGURED'}};
      const key=providerSecrets.getForMainProcess(provider);
      const result=await testProviderKey(provider,key,{timeoutMs:10000});
      const tested=providerSecrets.recordTest(provider,result);refreshCompanionState();broadcast();return{ok:true,status:tested};
    }catch(error){
      // R378: classify native credential failure without exposing error text or API keys.
      const known=new Set(['SECURE_STORAGE_DECRYPT_FAILED','SECURE_STORAGE_UNAVAILABLE','PROVIDER_UNSUPPORTED']);
      const raw=String(error?.message||'');
      const category=known.has(raw)?raw:'PROVIDER_TEST_HANDLER_ERROR';
      const state=category==='SECURE_STORAGE_DECRYPT_FAILED'?'CREDENTIAL_UNREADABLE':category==='SECURE_STORAGE_UNAVAILABLE'?'SECURE_STORAGE_UNAVAILABLE':'PROVIDER_HANDLER_ERROR';
      log('api.provider.test.failure.safe',{provider:String(provider||'').toLowerCase(),errorClass:category});
      try{return{ok:true,status:providerSecrets.recordTest(provider,{state,httpStatus:null})};}
      catch(_){return{ok:false,error:'PROVIDER_TEST_UNAVAILABLE'};}
    }
  });

  ipcMain.handle('clink:provider-response-test',async(_event,provider)=>{
    const id=String(provider||'').toLowerCase();
    const tests={
      openai:{input:'Reply with exactly: CLINK API OK',model:'gpt-5.6-luna'},
      xai:{input:'Reply with exactly: CLINK XAI OK',model:'grok-4.3'}
    };
    const test=tests[id];
    if(!test)return{ok:false,error:'PROVIDER_ADAPTER_NOT_IMPLEMENTED'};
    const envelope=await providerAdapters.createResponse(id,{...test,maxOutputTokens:32,store:false,companionId:'system-control',missionId:MISSION,workerId:null,purpose:'provider_response_test'});
    const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
    providerSecrets.recordTest(id,{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
    log('api.provider.response.test',{
      provider:id,status:envelope.status,model:envelope.model,responseId:envelope.responseId||'',
      errorClass:envelope.error?.class||null,httpStatus:envelope.error?.httpStatus??null,usage:envelope.usage
    });
    coreState.apiUsage=apiUsage.summary();refreshCompanionState();broadcast();
    return {ok:!envelope.error,envelope,status:providerSecrets.status(id),usage:coreState.apiUsage};
  });

  ipcMain.handle('clink:api-usage-snapshot',async()=>{try{return{ok:true,usage:apiUsage.summary()};}catch(error){return{ok:false,error:String(error.message||error)};}});
  ipcMain.handle('clink:api-budget-save',async(_event,value)=>{
    try{const budget=apiUsage.setBudget({monthlyBudgetUsd:value});coreState.apiUsage=apiUsage.summary();broadcast();return{ok:true,budget,usage:coreState.apiUsage};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:api-usage-proof',async()=>{
    const tests=[['openai',{input:'Reply with exactly: USAGE OK',model:'gpt-5.6-luna'}],['xai',{input:'Reply with exactly: USAGE OK',model:'grok-4.3'}]];
    const results=[];
    for(const [provider,test] of tests){
      const envelope=await providerAdapters.createResponse(provider,{...test,maxOutputTokens:24,store:false,companionId:'alpha007',missionId:MISSION,workerId:null,purpose:'round6_usage_proof'});
      results.push({provider,ok:!envelope.error,status:envelope.status,model:envelope.model,requestId:envelope.requestId,errorClass:envelope.error?.class||null,usage:envelope.usage});
      const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
      providerSecrets.recordTest(provider,{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
    }
    coreState.apiUsage=apiUsage.summary();log('api.usage.proof.complete',{status:results.every(r=>r.ok)?'PASS':'FAIL',providers:results.map(r=>({provider:r.provider,ok:r.ok,model:r.model,requestId:r.requestId,totalTokens:r.usage?.totalTokens||0}))});broadcast();
    return{ok:results.every(r=>r.ok),results,usage:coreState.apiUsage};
  });

  ipcMain.handle('clink:alpha-shadow-test',async()=>{
    if(coreState.apiShadow.status==='RUNNING')return{ok:false,error:'ALPHA_SHADOW_ALREADY_RUNNING'};
    coreState.apiShadow={status:'RUNNING',detail:'Running two fresh disposable OpenAI shadow sessions from the Round 5 context builder.',provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null};broadcast();
    try{
      const proof=await alphaShadowRunner().run();
      coreState.apiShadow={status:proof.status,detail:proof.status==='PASS'?'Two fresh API sessions reconstructed Alpha from the deterministic C.Link context builder.':'Alpha shadow proof failed; no promotion authorized.',provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:proof};
      const transportReady=Boolean(proof.session1?.responseId&&proof.session2?.responseId&&!proof.session1?.error&&!proof.session2?.error);
      providerSecrets.recordTest('openai',{state:transportReady?'READY':'OTHER_ERROR',httpStatus:transportReady?200:null});
      broadcast();
      return{ok:proof.status==='PASS',proof};
    }catch(error){
      const message=String(error.message||error);
      coreState.apiShadow={status:'FAIL',detail:message,provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null};broadcast();
      return{ok:false,error:message};
    }
  });

  ipcMain.handle('clink:context-restart-proof',async()=>{
    try{
      const proof=contextBuilder.armRestartProof();
      coreState.apiContext={...contextBuilder.snapshot(),reconstruction:{status:'WAITING_FOR_RESTART',detail:'C.Link will relaunch and compare the independently reconstructed context fingerprint.'}};
      broadcast();
      setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
      return{ok:true,proof,relaunch:true};
    }catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:context-reconstruction-test',async()=>{
    const state=contextBuilder.snapshot();
    if(state.restartProof?.status!=='PASS')return{ok:false,error:'CONTEXT_RESTART_PROOF_REQUIRED',context:state};
    try{
      const built=contextBuilder.build();
      const result=await alphaShadowRunner().one(5);
      const pass=result.status==='PASS';
      const reconstruction={status:pass?'PASS':'FAIL',detail:pass?'Fresh OpenAI reasoning reconstructed Alpha from the post-restart deterministic context.':'Post-restart Alpha reconstruction failed semantic invariants.',contextFingerprint:built.builder.contextFingerprint,sourceMapHash:built.builder.sourceMapHash,sourceCount:built.builder.sourceOrder.length,archiveBulkIncluded:false,provider:'openai',model:result.model||'gpt-5.6-luna',requestId:result.requestId,responseId:result.responseId,providerConversationAuthority:false,persistProviderSessionIds:false,machineMutation:false,verification:result.verification,usage:result.usage||{},completedAt:new Date().toISOString()};
      coreState.apiContext={...contextBuilder.snapshot(),reconstruction};
      const transportReady=Boolean(result.responseId&&!result.error);
      providerSecrets.recordTest('openai',{state:transportReady?'READY':'OTHER_ERROR',httpStatus:transportReady?200:null});
      log('api.context.reconstruction.complete',{status:reconstruction.status,contextFingerprint:reconstruction.contextFingerprint,sourceMapHash:reconstruction.sourceMapHash,sourceCount:reconstruction.sourceCount,archiveBulkIncluded:false,responseId:result.responseId||'',checks:result.verification?.checks||{},persistProviderSessionIds:false,machineMutation:false});
      broadcast();return{ok:pass,reconstruction};
    }catch(error){
      const message=String(error.message||error);coreState.apiContext={...contextBuilder.snapshot(),reconstruction:{status:'FAIL',detail:message}};broadcast();return{ok:false,error:message};
    }
  });

  ipcMain.handle('clink:system-command',async(_event,input)=>{
    const value=String(input||'').trim().replace(/^\//,'');
    if(!value)return{ok:false,error:'EMPTY_COMMAND'};
    if(!panels||coreState.panels.status!=='READY')return{ok:false,error:'PANELS_NOT_READY'};
    try{const result=await panels.sendIntent(value,['TORTURE','SELFTEST'].includes(value.toUpperCase())?120000:12000);return{ok:true,text:result.text||'',command:result.command||null};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });

  // R203 candidate: ZIP import is an offline staging operation, not companion activation.
  // Local terminal renderer only; untrusted pages never receive this IPC surface.
  // R208: central, shell-only, single-flight ZIP import/activation IPC controller.
  const companionZipIpc = createCompanionActivationIpc({
    getWindow:()=>windowMain,
    dialog,
    intake:companionZipIntake,
    backpacks:backpackManager,
    seat:companionTurnSeat,
    recovery:companionActivationRecovery,
    onActivated:()=>{alphaRecentTurns=[];companionOrchestrator.initialize(backpackManager.snapshot());refreshCompanionState();broadcast();},
    logger:log
  });
  ipcMain.handle('clink:companion-zip-pick',companionZipIpc.pick);
  ipcMain.handle('clink:companion-zip-stage',companionZipIpc.stage);
  ipcMain.handle('clink:companion-zip-roster',companionZipIpc.roster);
  ipcMain.handle('clink:companion-zip-activate',companionZipIpc.activate);
  // Miss Spock R315: keep the Companion roster in sync with ~/PhantomTronix/AgentShelf and ~/Downloads, automatically.
  // New capsules are verified and staged; a newer revision of the ACTIVE Companion is activated through the same transaction.
  try{
    const agentShelf=createAgentShelf({intake:companionZipIntake,backpacks:backpackManager,seat:companionTurnSeat,recovery:companionActivationRecovery,
      onActivated:()=>{alphaRecentTurns=[];companionOrchestrator.initialize(backpackManager.snapshot());refreshCompanionState();broadcast();},logger:log});
    agentShelf.start();
  }catch(error){log('agent_shelf.start_failed',{message:String(error?.message||error)});}
  ipcMain.handle('clink:companion-message',async(event,input)=>{
    if(!windowMain||event.sender!==windowMain.webContents||event.senderFrame!==windowMain.webContents.mainFrame)return{ok:false,error:'SHELL_ONLY'};
    return primaryCompanionMessage(input,{technical:false});
  });
  ipcMain.handle('clink:grok-companion-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'NONCANONICAL_GROK_COMPANION_ROUTE_DISABLED'};
    return grokUserCompanionMessage(input);
  });
  ipcMain.handle('clink:alpha-technical-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'ALPHA_TECHNICAL_ROUTE_NOT_UNIVERSAL'};
    return alphaPrimaryMessage(input,{technical:true});
  });
  ipcMain.handle('clink:hosted-companion-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'HOSTED_COMPANION_ROUTE_NOT_UNIVERSAL'};
    apiPrimarySoak.noteHostedFallbackInvocation();coreState.apiPrimary=apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null});broadcast();
    return hostedCompanionMessage(input);
  });
  ipcMain.handle('clink:r8-worker-state',async()=>({ok:true,state:{...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD}}));
  ipcMain.handle('clink:r8-run-workers',async()=>({ok:false,error:'R8_FIELD_PROVEN_CLOSED_NO_RERUN',state:readOnlyWorkers.snapshot()}));
  ipcMain.handle('clink:r9-state',async()=>({ok:true,state:round9.snapshot()}));
  ipcMain.handle('clink:r9-run-reconciliation',async()=>{
    const result=await round9.run();coreState.round9=round9.snapshot();coreState.apiUsage=apiUsage.summary();broadcast();return result;
  });
  ipcMain.handle('clink:r9-restart',async()=>{
    const armed=round9.armRestart();coreState.round9=round9.snapshot();broadcast();
    if(!armed.ok)return armed;
    setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
    return{ok:true,relaunch:true,state:round9.snapshot()};
  });

  ipcMain.handle('clink:r7-restart',async()=>{
    coreState.apiPrimary=apiPrimarySnapshot({fieldStatus:'R7_RESTARTING',lastTurn:coreState.apiPrimary?.lastTurn||null});broadcast();
    setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
    return{ok:true,relaunch:true,soak:apiPrimarySoak.snapshot()};
  });

  ipcMain.handle('clink:force-relay',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'LEGACY_SPECIALIST_RELAY_NOT_UNIVERSAL'};
    const value=String(input||'').trim();
    if(!value)return{ok:false,error:'EMPTY_RELAY_PROBLEM'};
    if(!providerReady())return{ok:false,error:'COMPANION_PROVIDER_NOT_READY'};
    const incident=normalizeIncident({summary:value,evidence:[`Human explicitly requested relay: ${value}`]},value);
    const state=await runRelayForIncident(incident,null);
    const run=state.run;
    const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
    return{ok:run?.status==='PASS',reply:String(final?.humanReply||final?.summary||run?.conclusion||''),state,error:run?.error||null};
  });

  ipcMain.handle('clink:relay-selftest',async()=>{
    try{
      companionOrchestrator.assertInvariant();
      const bags=backpackManager.snapshot();
      if(bags.systemControl?.mutability!=='READ_ONLY'||!bags.systemControl?.sha256)throw new Error('SYSTEM_CONTROL_BACKPACK_NOT_VERIFIED');
      if(!bags.userCompanion?.sha256)throw new Error('USER_COMPANION_BACKPACK_NOT_VERIFIED');
      const registry=companionOrchestrator.snapshot();for(const id of ['redteam','fabric','control','throughput'])if(registry.chats?.[id]?.backpack!==null)throw new Error(`SPECIALIST_BACKPACK_FORBIDDEN:${id}`);
      const state=await relay.dryRun({field:true});coreState.relay=state;coreState.companionCore=companionOrchestrator.snapshot();broadcast();
      return{ok:true,state,companionCore:coreState.companionCore,backpacks:bags};
    }catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:sync-lifecycle',async()=>syncProviderLifecycle(true));

  ipcMain.handle('clink:message-qualification',async()=>runMessageQualification());

  ipcMain.handle('clink:about-boundary',async()=>{
    await dialog.showMessageBox(windowMain,{
      type:'info',title:'Quin Browser — IRIS-derived Foundation',
      message:'Round 9 reconciles the field-proven two-worker experiment, tears worker sessions down, restarts C.Link, and proves Alpha returns without worker-session persistence.',
      detail:'Rounds 1-8 are field-proven. Round 9 adds no worker authority and no concurrency increase. Alpha compares the two-worker result against a single-Alpha baseline, explicitly adopts/adapts/rejects/defers each worker finding, preserves disagreement, keeps usage/cost evidence, and remains API PRIMARY after restart. Repair execution stays OFF.'
    });
    return{ok:true};
  });
}

// BEGIN CLINK_NATIVE_EDIT_MENU_015
function attachNativeEditMenu(wc, isAllowed) {
  // Native user-initiated editing only: no clipboard IPC or renderer permission.
  wc.on('context-menu', (_event, params) => {
    if (wc.isDestroyed() || !isAllowed(params)) return;
    const flags = params.editFlags || {};
    const editable = params.isEditable === true;
    const selected = Boolean(params.selectionText);
    const item = (label, method, enabled) => ({ label, enabled: Boolean(enabled), click: () => {
      if (!enabled || wc.isDestroyed() || !isAllowed(params)) return;
      wc.focus();
      wc[method]();
    }});
    const sep = {type:'separator'};
    const template = editable ? [
      item('Undo','undo',flags.canUndo), item('Redo','redo',flags.canRedo), sep,
      item('Cut','cut',flags.canCut), item('Copy','copy',flags.canCopy),
      item('Paste','paste',flags.canPaste), item('Delete','delete',flags.canDelete), sep,
      item('Select All','selectAll',flags.canSelectAll)
    ] : [item('Copy','copy',selected && flags.canCopy), item('Select All','selectAll',flags.canSelectAll)];
    // Do not intercept game mouse controls or remote browser contexts.
    if (!editable && !selected) return;
    require('electron').Menu.buildFromTemplate(template).popup({window:windowMain});
  });
}
// END CLINK_NATIVE_EDIT_MENU_015

// R044: read-only native version and transaction visibility. No new IPC or permissions.
function clinkNativeStatus(root) {
  const version = v => typeof v === 'string' && /^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(v);
  const digest = v => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);
  function read(relative) {
    let fd;
    try {
      const file = path.join(root, relative);
      if (fs.realpathSync(file) !== file) return null;
      fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      const s = fs.fstatSync(fd);
      if (!s.isFile() || s.size > 4096 || s.nlink !== 1 || (s.mode & 0o022) || (process.getuid && s.uid !== process.getuid())) return null;
      return JSON.parse(fs.readFileSync(fd, 'utf8'));
    } catch (_) { return null; } finally { if (fd !== undefined) fs.closeSync(fd); }
  }
  const p = read('package.json'), a = read('.clink-native-update/last-attempt.json'), r = read('.clink-native-update/last-result.json');
  const installed = version(p?.clinkNativeVersion) ? p.clinkNativeVersion : 'UNKNOWN';
  const attempt = version(a?.version) && version(a?.fromVersion) && digest(a?.sha256) ? a : null;
  const receipt = version(r?.version) && version(r?.fromVersion) && digest(r?.archiveSha256) && ['COMMITTED','ROLLED_BACK'].includes(r?.status) ? r : null;
  const pending = fs.existsSync(path.join(root,'.clink-native-update','transaction'));
  return {installed, target: attempt?.version || receipt?.version || 'UNKNOWN',
    status: pending ? 'TRIAL / RECOVERY PENDING' : receipt ? `${receipt.version} — ${receipt.status}` : 'NO COMPLETED TRANSACTION',
    availability: 'LATEST STABLE: NOT VERIFIED YET'};
}
// Select the highest independently verified offer for display only.
function clinkLatestVerifiedOffer(w, doc, policy, approval, arch) {
  const rows = doc?.schema === w.SCHEMA ? [doc] :
    doc?.schema === 'clink.native-discovery.v1' && Object.keys(doc).sort().join(',') === 'releases,schema' ? doc.releases : null;
  if (!Array.isArray(rows) || rows.length > 64) throw Error('DISPLAY_FEED_SCHEMA');
  const valid = [];
  for (const e of rows) {
    try { valid.push(w.verify(e, policy, approval, e?.release?.fromVersion, arch)); } catch (_) {}
  }
  const cmp = (a,b) => { const x=a.split('.').map(Number), y=b.split('.').map(Number); for(let i=0;i<3;i++) if(x[i]!==y[i]) return x[i]-y[i]; return 0; };
  valid.sort((a,b)=>cmp(b.version,a.version));
  if (!valid.length) throw Error('DISPLAY_NO_VERIFIED_OFFER');
  const top=valid[0];
  if(valid.some(r=>r.version===top.version && w.canonical(r)!==w.canonical(top))) throw Error('DISPLAY_CONFLICTING_OFFERS');
  return top;
}
// Check the same signed stable feed using the existing pinned transport/verifier.
// This is display-only; never stages, installs, or changes a trust decision.
async function clinkCheckNativeFeed(root) {
  const helper = path.join(path.dirname(root),'native-updater');
  const checked = (name, pin, limit=65536) => {
    const file = path.join(helper,name), st = fs.lstatSync(file);
    if (fs.realpathSync(file)!==file || !st.isFile() || st.nlink!==1 || st.size>limit || (st.mode&0o077) || (process.getuid && st.uid!==process.getuid())) throw Error('DISPLAY_HELPER_UNSAFE');
    const b=fs.readFileSync(file);
    if(pin && crypto.createHash('sha256').update(b).digest('hex')!==pin) throw Error('DISPLAY_HELPER_DRIFT');
    return b;
  };
  let temp;
  try {
    checked('native-startup.py','d4b4a257f4a9c3a86a4cd3db82628d85a8edd859a86c3764570772be16570a89');
    checked('native-release-wire.cjs','91255daeb80cf7e3457d3584489a89515c71e609694e8c26335deb8f93bbe5b0');
    const c=JSON.parse(checked('config.json',null));
    const w=require(path.join(helper,'native-release-wire.cjs'));
    if(c.approval!=='a7e3ac417559677e0e5b453897b6b685a37719e8085601d5b76af6d806b4c7e6' || w.trustFingerprint(c.policy)!==c.approval || c.arch!=='x64')throw Error('DISPLAY_TRUST_MISMATCH');
    temp=fs.mkdtempSync(path.join(os.tmpdir(),'clink-status-'));
    const dest=path.join(temp,'manifest.json');
    await new Promise((resolve,reject)=>cp.execFile('/usr/bin/python3',[path.join(helper,'native-startup.py'),'--fetch',w.FEED,dest,'65536','8'],{timeout:10000,maxBuffer:4096},e=>e?reject(e):resolve()));
    const st=fs.lstatSync(dest); if(!st.isFile()||st.size>65536)throw Error('DISPLAY_FEED_SIZE');
    const doc=JSON.parse(fs.readFileSync(dest,'utf8'));
    const r=clinkLatestVerifiedOffer(w,doc,c.policy,c.approval,c.arch);
    return `LATEST VERIFIED STABLE: ${r.version} (checked this startup)`;
  } catch (_) {return 'LATEST STABLE: VERIFICATION UNAVAILABLE';}
  finally {if(temp)try{fs.rmSync(temp,{recursive:true,force:true});}catch(_){}}
}
function clinkRenderNativeStatus(data, expectedUrl) {
  if (location.href !== expectedUrl) return false;
  const foot = document.getElementById('clink-r358-foot')?.querySelector('span');
  if (foot) {
    const label = `C.LINK / VERSION ${data.installed}`;
    if (foot.textContent !== label) foot.textContent = label;
  }
  const anchor = document.getElementById('diagnosticsCopyStatus');
  if (anchor && anchor.closest('#settingsPanel')) {
    let box = document.getElementById('clink-native-version-status');
    if (!box) {
      box = document.createElement('div'); box.id = 'clink-native-version-status';
      box.className = 'settings-note'; box.setAttribute('role','status');
      anchor.before(box);
    }
    const label = `INSTALLED: ${data.installed} · LAST VERIFIED TARGET: ${data.target}\nUPDATE: ${data.status}\n${data.availability}`;
    box.style.whiteSpace = 'pre-line';
    if (box.textContent !== label) box.textContent = label;
  }
  return Boolean(foot && anchor);
}
function clinkAttachNativeStatus(win, localUrl) {
  const wc = win.webContents;
  let timer, busy = false, checked = false, availability = 'LATEST STABLE: CHECKING';
  async function refresh() {
    if (busy || win.isDestroyed() || wc.isDestroyed() || wc.getURL() !== localUrl) return;
    busy = true;
    try {
      const data = clinkNativeStatus(path.resolve(__dirname,'..'));
      data.availability = availability;
      await wc.executeJavaScript(`(${clinkRenderNativeStatus.toString()})(${JSON.stringify(data)},${JSON.stringify(localUrl)})`,false);
    } catch (_) { /* Display failure cannot interfere with startup or rollback. */ }
    finally { busy = false; }
  }
  wc.on('did-finish-load', () => {
    if(wc.getURL()!==localUrl)return;
    void refresh();
    if (!timer) timer = setInterval(refresh, 2000);
    if (!checked) {checked=true;void clinkCheckNativeFeed(path.resolve(__dirname,'..')).then(value=>{availability=value;void refresh();});}
  });
  win.once('closed', () => { if (timer) clearInterval(timer); });
}
// END R044

function createWindow() {
  const isLinux=process.platform==='linux';
  const windowOptions={width:1024,height:768,minWidth:720,minHeight:520,show:false,autoHideMenuBar:true,backgroundColor:'#111111',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}};
  if(isLinux){windowOptions.fullscreen=true;windowOptions.icon=APP_ICON;windowOptions.title='Phantom-Tronix Quinquedent Browser';}
  windowMain=new BrowserWindow(windowOptions);
  // Only Quin's local top-level UI may use the microphone. Remote provider
  // surfaces and embedded web pages have no microphone permission.
  const localFileUrl=require('url').pathToFileURL(path.join(__dirname,'renderer','index.html')).href;
  const shellContents = windowMain.webContents;
  attachNativeEditMenu(shellContents, params => Boolean(windowMain && !windowMain.isDestroyed() &&
    windowMain.webContents===shellContents && shellContents.getURL().split(/[?#]/)[0]===localFileUrl &&
    String(params.frameURL||'').split(/[?#]/)[0]===localFileUrl));
  const canUseMicrophone=(wc,permission,requestingUrl)=>Boolean(
    permission==='media'&&wc&&wc.id===windowMain?.webContents?.id&&
    windowMain.webContents.getURL().split(/[?#]/)[0]===localFileUrl&&
    typeof requestingUrl==='string'&&(requestingUrl.split(/[?#]/)[0]===localFileUrl||requestingUrl==='file://'));
  const localSession=windowMain.webContents.session;
  localSession.setPermissionRequestHandler((wc,permission,callback,details)=>{
    if(permission==='media')return callback(canUseMicrophone(wc,permission,details?.requestingUrl));
    callback(false);
  });
  localSession.setPermissionCheckHandler((wc,permission,origin,details)=>{
    if(permission==='media')return canUseMicrophone(wc,permission,details?.requestingUrl||origin);
    return false;
  });
  clinkAttachNativeStatus(windowMain, localFileUrl);
  windowMain.loadFile(path.join(__dirname,'renderer','index.html'));
  windowMain.on('resize',()=>{layoutInlineAuthView();layoutWebPlugin();restrictedBrowserCartridge?.resize();});
  if(isLinux){
    // Own shutdown at the WM close request, before the native X11 surface disappears.
    windowMain.on('close',()=>{
      boot('MAIN_WINDOW_CLOSE_EVENT platform=linux');
      requestAppQuit();
    });
  }
  windowMain.on('closed',()=>{closeWebPlugin();try{restrictedBrowserCartridge?.destroy();}catch(_){} restrictedBrowserCartridge=null;
    boot(`MAIN_WINDOW_CLOSED_EVENT platform=${process.platform}`);
    try{restrictedBrowserCartridge?.destroy();}catch(_){}
    restrictedBrowserCartridge=null;
    windowMain=null;
    requestAppQuit();
  });
  windowMain.once('ready-to-show',()=>{
    if(isLinux)windowMain.setFullScreen(true);else windowMain.maximize();
    windowMain.show();
    coreState.core={status:'HEALTHY',detail:'Quin: IRIS-derived browser core ready; PANELS plugin management enabled.'};
    log('core.ready',coreState.core);broadcast();
    setTimeout(()=>{
      browserRuntime=new CLinkBrowserRuntime({profileRoot:QUIN_PROFILE_ROOT,logger:log});
      writeProviderAuthState({
        canonicalSessionPath:browserRuntime.sessionPath,
        sessionPolicy:'ONE_PERSISTENT_QUIN_SESSION_ACROSS_BUILDS',
        loginPolicy:'HUMAN_EXPLICIT_ONLY'
      });
      panels=new PanelsSupervisor({
        panelsRoot:PANELS_ROOT,
        profileRoot:PROFILE_ROOT,
        logger:log,
        browserRuntime,
        workspaceBindingResolver:()=>companionOrchestrator.snapshot()?.workspace||null
      });
      panels.on('state',setPanels);
      panels.start().then(async(state)=>{
        if(!process.env.CLINK_UPDATE_HEALTH||state?.status!=='READY'||panels.snapshot().status!=='READY')return;
        try{
          await require(path.join(__dirname,'..','..','native-updater','native-health.cjs')).acknowledge({window:windowMain,root:path.resolve(__dirname,'..'),panelsReady:true});
        }catch(error){log('native.update.health.error',{error:String(error.message||error).slice(0,120)});}
      }).catch(error=>log('panels.bootstrap.error',{error:String(error.message||error)}));
    },150);
  });
}

// R371 launch proof: read-only shell/bridge check; no browser navigation.
if(process.env.CLINK_R371_SMOKE_MARKER){
 const fs371=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let wrote=false;
  win.webContents.on('did-finish-load',()=>setTimeout(async()=>{
   if(wrote||win.isDestroyed())return;
   let details={ok:false};
   try{details=await win.webContents.executeJavaScript(`(()=>{
     const c=typeof window.__CLINK_R371_CHECK__==='function'
      ?window.__CLINK_R371_CHECK__():null;
     return {ok:!!c?.installed&&!!c.logoAccessible&&!!c.nativeBridge&&!!c.shell,
       navigationReadOnly:true,cartNotOpened:true,browserNotOpened:true,checks:c};
   })()`,true);}catch(error){details={ok:false,error:String(error)};}
   const record={loaded:true,visible:win.isVisible(),details,pid:process.pid};
   try{fs371.writeFileSync(process.env.CLINK_R371_SMOKE_MARKER,JSON.stringify(record));wrote=true;}catch(_){ }
  },2000));
 });
}

const gotLock=app.requestSingleInstanceLock();
boot(`PROCESS_START pid=${process.pid} exec=${process.execPath} electron=${process.versions.electron||''}`);
if(!gotLock){boot('SINGLE_INSTANCE_LOCK=DENIED');app.quit();}
else{
  boot('SINGLE_INSTANCE_LOCK=ACQUIRED');
  app.on('second-instance',()=>{if(windowMain){if(windowMain.isMinimized())windowMain.restore();windowMain.focus();}});
  require(path.join(__dirname,'..','..','native-updater','native-focus.cjs')).start(path.join(__dirname,'..','..','native-updater'),()=>windowMain);
  installIpc();
  app.whenReady().then(()=>{
    // Miss Spock R317: dark everywhere. Sites that follow the system theme (ChatGPT, YouTube) load dark, no white screens.
    try{nativeTheme.themeSource='dark';}catch(_){}
    webPluginSession=session.fromPartition('persist:quin-graphical-cartridges');
    cartridgeVoiceHost.permissions(webPluginSession);
    webPluginSession.protocol.handle('quinplugin',async req=>{
      try{
        const parsed=new URL(req.url);const id=parsed.hostname;
        const rec=webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins'));
        if(!webPlugins.pluginEnabled(rec.manifest,id,PROFILE_ROOT))return new Response('Disabled',{status:403});
        const asset=webPlugins.resolveAsset(rec,req.url);
        return new Response(fs.readFileSync(asset.file),{status:200,headers:{'Content-Type':asset.type,'Content-Security-Policy':webPlugins.cspFor(id),'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'}});
      }catch(_){return new Response('Not found',{status:404});}
    });
    webPluginSession.protocol.handle('quinservice',async req=>{
      try{return await servicePlugins.proxy(activeWebService,req);}
      catch(_){return new Response('Service request rejected',{status:502});}
    });
    boot('APP_WHEN_READY');ensureLinuxDesktopIdentity();createWindow();
  // L1 recovery is invoked only on real Quin boot. No new assignments are generated here.
  setTimeout(()=>{try{const r=quinL1().resumeAfterBoot();boot('L1_RESUME '+String(r?.task?.status||r?.error||'IDLE'));}catch(e){boot('L1_RESUME_BLOCKED '+String(e.message||e).slice(0,90));}},1300);
});
}
function shutdownRuntime(){
  if(shutdownPromise)return shutdownPromise;
  shutdownStarted=true;
  shutdownPromise=(async()=>{
    removeInlineAuthView();
    closeWebPlugin();
    await flushProviderSession('CLEAN_SHUTDOWN');
    if(panels){try{panels.stop();}catch(_){}}
    if(browserRuntime){try{browserRuntime.shutdown();}catch(_){}}
  })();
  return shutdownPromise;
}
function requestAppQuit(){
  if(quitScheduled)return;
  quitScheduled=true;
  boot(`QUIT_REQUESTED platform=${process.platform}`);
  shutdownRuntime().finally(()=>{
  if(process.platform==='linux'){
    setTimeout(()=>{
      boot('LINUX_EXIT_AFTER_CLEANUP');
      try{app.exit(0);}catch(_){}
    },900);
  }else{
    setTimeout(()=>{try{app.quit();}catch(_){}},700);
  }
  });
}
app.on('window-all-closed',()=>{requestAppQuit();});
app.on('before-quit',()=>{shutdownRuntime().catch(()=>{});});
process.on('SIGTERM',()=>{requestAppQuit();});
process.on('SIGINT',()=>{requestAppQuit();});

module.exports={BUILD,MISSION};

} // End normal Quin initialization (else branch when Companion recovery is safe).
