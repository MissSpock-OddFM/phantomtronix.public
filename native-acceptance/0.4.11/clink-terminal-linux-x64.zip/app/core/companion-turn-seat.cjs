'use strict';
// Quin R206: isolate the active Companion at the turn boundary. Offline-friendly;
// no provider calls, storage, or activation side effects here.
class CompanionTurnSeat {
  constructor({primary, backpackManager, maxHistory=8}={}) {
    if(!primary || !backpackManager)throw Error('COMPANION_SEAT_DEPENDENCIES_REQUIRED');
    this.primary=primary;this.bags=backpackManager;
    this.maxHistory=maxHistory;this.history=[];this.generation=0;
    this.seatedKey=null;this.pendingGeneration=null;this.disabledReason=null;
  }
  currentKey(){
    const b=this.bags.snapshot()?.userCompanion;
    if(b?.importFormat!=='PERSONAL_IDENTITY_CAPSULE')return null;
    if(!b.id || !/^[0-9a-f]{64}$/i.test(String(b.sha256||'')))throw Error('ACTIVE_CANONICAL_BINDING_INVALID');
    return `${b.id}:${String(b.sha256).toUpperCase()}`;
  }
  sync(){
    const current=this.currentKey();
    if(current!==this.seatedKey){this.seatedKey=current;this.history=[];this.generation++;}
    return current;
  }
  // Explicit after activation: invalidate any in-flight old-seat response.
  rotated(){this.seatedKey=null;this.history=[];this.generation++;this.sync();}
  disable(reason='UNSAFE_COMPANION_STATE'){this.disabledReason=String(reason);this.history=[];this.generation++;}
  snapshot(){return {disabledReason:this.disabledReason,companionKey:this.seatedKey,generation:this.generation,busy:this.pendingGeneration===this.generation,historyTurns:this.history.length};}
  async reply(text,{technical=false,provider,cartridgeTurn=false,commandContext=null,stationContext=null,proposalContext=null}={}){
    if(this.disabledReason)return {ok:false,error:'COMPANION_SEAT_LOCKED',reason:this.disabledReason};
    const value=String(text||'').trim();if(!value)return {ok:false,error:'EMPTY_COMPANION_MESSAGE'};
    const key=this.sync();if(!key)return {ok:false,error:'CANONICAL_COMPANION_NOT_ACTIVE'};
    if(this.pendingGeneration===this.generation)return {ok:false,error:'COMPANION_TURN_IN_PROGRESS'};
    const generation=this.generation;this.pendingGeneration=generation;
    const history=this.history.map(x=>({...x}));
    try{
      const result=await this.primary.reply(value,{history,technical,provider,cartridgeTurn,commandContext,stationContext,proposalContext});
      // A pending old request cannot become a reply from a newly seated agent.
      if(this.sync()!==key || this.generation!==generation)return {ok:false,error:'STALE_COMPANION_RESPONSE_DISCARDED',stale:true,providerWasInvoked:true};
      if(result?.companionId && result.companionId!==key.split(':')[0])return {ok:false,error:'COMPANION_RESPONSE_IDENTITY_MISMATCH'};
      if(result?.backpackSha256 && String(result.backpackSha256).toUpperCase()!==key.split(':')[1])return {ok:false,error:'COMPANION_RESPONSE_BACKPACK_MISMATCH'};
      if(result?.ok&&proposalContext===null){this.history.push({role:'human',text:value},{role:'companion',text:String(result.reply||'')});this.history=this.history.slice(-this.maxHistory);}
      return result;
    } finally {if(this.pendingGeneration===generation)this.pendingGeneration=null;}
  }
}
module.exports={CompanionTurnSeat};

// Command specialist seats: shared native intake, independent local bindings.
const stationFs=require('node:fs'), stationPath=require('node:path'), stationCrypto=require('node:crypto');
const {inspectFile:inspectStationCapsule}=require('./companion-zip-intake.cjs');
class CommandStationSeats {
  constructor({profileRoot,intake}){if(!profileRoot||!intake)throw Error('STATION_DEPENDENCIES_REQUIRED');this.intake=intake;this.turns=new Map();this.root=stationPath.join(profileRoot,'companions','command-stations');}
  file(id){if(typeof id!=='string'||!/^0[1-7]$/.test(id))throw Error('SPECIALIST_STATION_REQUIRED');return stationPath.join(this.root,id+'.json');}
  status(id){const f=this.file(id);let b;try{b=JSON.parse(stationFs.readFileSync(f,'utf8'));}catch(e){if(e.code==='ENOENT')return {stationId:id,occupied:false};throw Error('STATION_BINDING_INVALID');}
    if(b.schema!=='clink.command.station-seat.v1'||b.stationId!==id||!(/^[a-f0-9]{64}$/.test(b.sha256)))throw Error('STATION_BINDING_INVALID');
    if(b.occupied===false)return {stationId:id,occupied:false};
    const p=stationPath.join(this.intake.root,b.sha256,'backpack.zip');let r;try{r=inspectStationCapsule(p);}catch{throw Error('STATION_BACKPACK_INVALID');}
    if(r.archiveSha256!==b.sha256||r.companionId!==b.companionId||r.version!==b.version)throw Error('STATION_BACKPACK_MISMATCH');
    return {stationId:id,occupied:true,companionId:r.companionId,displayName:r.displayName,version:r.version,sha256:r.archiveSha256};}
  list(){return Array.from({length:7},(_,i)=>{const id='0'+(i+1);try{return this.status(id)}catch(e){return {stationId:id,occupied:false,error:e.message}}});}
  write(id,b){const f=this.file(id);stationFs.mkdirSync(this.root,{recursive:true,mode:0o700});const tmp=f+'.'+stationCrypto.randomBytes(8).toString('hex');try{stationFs.writeFileSync(tmp,JSON.stringify(b,null,2)+'\n',{mode:0o600,flag:'wx'});stationFs.renameSync(tmp,f);}finally{try{stationFs.unlinkSync(tmp)}catch{}}}
  assign(id,source,expectedSha,{humanApproved=false}={}){this.file(id);if(!humanApproved)throw Error('STATION_APPROVAL_REQUIRED');const r=this.intake.inspect(source);if(r.archiveSha256!==expectedSha)throw Error('STATION_SOURCE_CHANGED');const s=this.intake.stage(source);if(s.archiveSha256!==expectedSha)throw Error('STATION_SOURCE_CHANGED');this.write(id,{schema:'clink.command.station-seat.v1',stationId:id,occupied:true,sha256:s.archiveSha256,companionId:s.companionId,version:s.version});this.turns.get(id)?.rotated();return this.status(id);}
  eject(id,{humanApproved=false}={}){const f=this.file(id);if(!humanApproved)throw Error('STATION_APPROVAL_REQUIRED');try{stationFs.unlinkSync(f)}catch(e){if(e.code!=='ENOENT')throw e;}this.turns.get(id)?.rotated();return this.status(id);}
}
module.exports.CommandStationSeats=CommandStationSeats;

// Each specialist uses the same canonical primary but an independent, read-only binding.
CommandStationSeats.prototype.turnSeat=function(id,adapters){
 this.file(id);if(this.turns.has(id))return this.turns.get(id);
 const {UniversalCompanionPrimary,FILES}=require('./universal-companion-primary.cjs');
 const {inspectBytes,zipInventory}=require('./companion-zip-intake.cjs');
 const self=this;
 const bags={snapshot(){const s=self.status(id);return {userCompanion:s.occupied?{id:s.companionId,sha256:s.sha256,importFormat:'PERSONAL_IDENTITY_CAPSULE'}:null};},hydrationPacket(){const s=self.status(id);if(!s.occupied)throw Error('NO_COMPANION_LOADED');const raw=stationFs.readFileSync(stationPath.join(self.intake.root,s.sha256,'backpack.zip'));const v=inspectBytes(raw);if(v.archiveSha256!==s.sha256)throw Error('STATION_BACKPACK_MISMATCH');const entries=zipInventory(raw);return {id:v.companionId,version:v.version,sha256:v.archiveSha256,files:FILES.map(path=>({path,text:entries.get(path).toString('utf8')}))};}};
 const seat=new CompanionTurnSeat({primary:new UniversalCompanionPrimary({adapterRegistry:adapters,backpackManager:bags,missionId:'command-station-'+id,stationId:id}),backpackManager:bags});this.turns.set(id,seat);return seat;
};
