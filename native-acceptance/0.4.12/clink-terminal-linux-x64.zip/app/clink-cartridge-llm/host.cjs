'use strict';
// C.Link R385: main-process-only LLM broker. No API key, OS, or network exposed to a CART.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ALLOWED = new Set(['openai', 'xai']);
const MAX_PROMPT = 4096;
const MAX_OUTPUT_TOKENS = 512;
const MAX_RESPONSE_CHARS = 8192;
const REQUESTS_PER_SESSION = 20;
const REQUESTS_PER_MINUTE = 5;
const CONSENT_MS = 60 * 60 * 1000;
function fail(code) { throw new Error(code); }
function check(condition, code) { if (!condition) fail(code); }
function isSafeFile(file) { const s = fs.lstatSync(file); return s.isFile() && !s.isSymbolicLink() && s.size < 8192; }
function safeError(e) { const v = String(e && e.message || e || 'UNKNOWN'); return /^([A-Z][A-Z0-9_]{2,90})$/.test(v) ? v : 'LLM_PROVIDER_REQUEST_FAILED'; }
// PHANTOMTRONIX PROPOSAL V1 — host-owned, no execution or installation.
const proposalSha=b=>crypto.createHash('sha256').update(b).digest('hex');
const proposalVersion='clink.proposal.v1';
const proposalSecret=/(?:-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:sk-(?:proj-)?|xai-|gh[pousr]_|github_pat_)[A-Za-z0-9_-]{16,}\b|(?:password|api[_ -]?key|access[_ -]?token|client[_ -]?secret)\s*[:=]\s*\S{6,})/i;
function proposalText(v,max){return typeof v==='string'&&v.trim()&&v.length<=max&&!/[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(v)&&!proposalSecret.test(v);}
const proposalDescriptions={'companion.chat':'Seated companion conversation through approved xai/openai adapters; no direct tools or arbitrary execution.','command.records':'Immutable canon and work records; local text handoffs.','command.station-mail':'Station inbox/outbox and bounded inter-station delivery.','command.station-seats':'Verified personality capsule seating, import and eject, independent specialist bindings.','cartridge.web-ui':'Manifest-pinned sandboxed static web application interface.','cartridge.web-service':'Verified local Node web-service cartridge interface; separate authorization required.','companion.proposal':'Native structured assessment and development backpack commissioning; no return importer.'};
const proposalRefs={
 'companion.chat':['app/clink-cartridge-llm/host.cjs','app/core/companion-turn-seat.cjs','app/core/universal-companion-primary.cjs'],
 'command.records':['app/clink-cartridge-llm/host.cjs'],
 'command.station-mail':['app/clink-cartridge-llm/host.cjs'],
 'command.station-seats':['app/core/companion-turn-seat.cjs','app/clink-cartridge-llm/host.cjs'],
 'cartridge.web-ui':['app/core/quin-web-plugins.js'],
 'cartridge.web-service':['app/core/quin-service-plugins.js'],
 'companion.proposal':['app/clink-cartridge-llm/host.cjs','app/core/universal-companion-primary.cjs','app/core/companion-turn-seat.cjs']
};
function proposalInventory({builtinsRoot,installedRoot,appRoot=path.resolve(__dirname,'..'),verifyWeb,verifyService,enabled}){
 const refs=new Map(), caps=[], carts=[], issues=[];
 function ref(rel){if(refs.has(rel))return refs.get(rel);try{const f=path.join(appRoot,rel.replace(/^app\//,''));const s=fs.lstatSync(f);check(s.isFile()&&!s.isSymbolicLink()&&s.size<=2*1024*1024,'SOURCE_UNAVAILABLE');const r={path:rel,sha256:proposalSha(fs.readFileSync(f))};refs.set(rel,r);return r;}catch{issues.push('source:'+rel);return null;}}
 for(const [id,files] of Object.entries(proposalRefs)){const sources=files.map(ref);if(sources.every(Boolean))caps.push({id,sources,kind:'host-interface',description:proposalDescriptions[id]});}
 const ids=new Map();
 for(const [origin,root] of [['builtin',builtinsRoot],['installed',installedRoot]]){try{const items=fs.readdirSync(root,{withFileTypes:true});if(items.length>200)throw Error('LIMIT');for(const d of items){if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(d.name))continue;if(!ids.has(d.name))ids.set(d.name,[]);ids.get(d.name).push({origin,root,dir:d});}}catch(e){if(e.code!=='ENOENT')issues.push('inventory:'+origin);}}
 for(const [id,locations] of [...ids].sort((a,b)=>a[0].localeCompare(b[0]))){let item={id,status:'unverified'};try{check(locations.length===1,'DUPLICATE');const loc=locations[0];check(loc.dir.isDirectory()&&!loc.dir.isSymbolicLink(),'NOT_DIR');const mf=path.join(loc.root,id,'manifest.json'),s=fs.lstatSync(mf);check(s.isFile()&&!s.isSymbolicLink()&&s.size<=262144,'MANIFEST');const raw=fs.readFileSync(mf),m=JSON.parse(raw);check(m.id===id&&typeof m.version==='string'&&/^[a-zA-Z0-9.+-]{1,80}$/.test(m.version),'MANIFEST');item={id,version:m.version,origin:loc.origin,manifestSha256:proposalSha(raw),status:'unverified'};
  if(m.runtime==='web'||m.runtime==='web-service'){check(m.files&&typeof m.files==='object'&&!Array.isArray(m.files)&&Object.keys(m.files).length<=200,'ASSET_LIMIT');let size=0;for(const rel of Object.keys(m.files)){check(/^(?:web|service)\/(?:[a-zA-Z0-9_.-]+\/)*[a-zA-Z0-9_.-]+$/.test(rel)&&!rel.split('/').some(x=>x==='.'||x==='..'),'ASSET_PATH');let f=path.join(loc.root,id);for(const seg of rel.split('/')){f=path.join(f,seg);check(!fs.lstatSync(f).isSymbolicLink(),'ASSET_SYMLINK');}const st=fs.lstatSync(f);check(st.isFile()&&st.size<=32*1024*1024,'ASSET_LIMIT');size+=st.size;check(size<=64*1024*1024,'ASSET_LIMIT');}const verified=(m.runtime==='web'?verifyWeb:verifyService)(id);check(verified.manifest.id===id&&verified.manifest.version===m.version,'VERIFY');item.status=enabled(verified.manifest,id)?'verified-enabled':'verified-disabled';if(item.status==='verified-enabled'){const base=m.runtime==='web'?'cartridge.web-ui':'cartridge.web-service';const source=caps.find(x=>x.id===base);if(source)caps.push({id:'cart.'+id,kind:m.runtime,description:'Verified cartridge package; internal feature semantics not certified.',sources:source.sources,manifestSha256:item.manifestSha256,version:m.version,origin:loc.origin});}}
 }catch{item.status='unverified';}carts.push(item);}
 return {schema:proposalVersion,coverage:'host interfaces and installed cartridge integrity; not exhaustive feature semantics or live health',capabilities:caps,cartridges:carts,issues};
}
function proposalDecision(raw,inventory){
 const clarify=q=>({type:'C',question:q});let d;try{d=JSON.parse(raw);}catch{return clarify('The provider did not return a valid determination. Please resubmit the proposal with a clear outcome.');}
 if(!d||typeof d!=='object'||Array.isArray(d))return clarify('Please specify the intended outcome.');
 if(d.type==='C')return clarify(proposalText(d.question,500)?d.question:'What should the requested feature do, and which system should it affect?');
 if(!['A','B'].includes(d.type)||!proposalText(d.outcome,500)||!proposalText(d.reason,500)||!Array.isArray(d.ids)||d.ids.length>5||new Set(d.ids).size!==d.ids.length||!d.ids.every(id=>typeof id==='string'&&inventory.capabilities.some(c=>c.id===id))||!Array.isArray(d.tests)||!d.tests.length||d.tests.length>4||!d.tests.every(t=>proposalText(t,250)))return clarify('The determination could not be validated against the C.Link inventory. Please specify the target capability and measurable result.');
 if(d.type==='A'&&!d.ids.length)return clarify('Which verified interface should this implementation extend?');
 if(d.type==='B'&&(!proposalText(d.missing,250)||!/^([a-z][a-z0-9-]*\.)+[a-z][a-z0-9-]*$/.test(d.missing)||inventory.capabilities.some(c=>c.id===d.missing)||inventory.issues.length||! /^(?:companion|command|cartridge)\./.test(d.missing)))return clarify('The missing capability is not established by the available inventory. Please narrow the proposal.');
 if(d.type==='B'&&inventory.cartridges.some(c=>'cart.'+c.id===d.missing))return clarify('That cartridge is listed but its available capability is not verified. Inspect it before commissioning new work.');
 return {type:d.type,outcome:d.outcome,reason:d.reason,ids:d.ids,tests:d.tests,...(d.type==='B'?{missing:d.missing}: {})};
}
function proposalZip(entries){
 const blocks=[],central=[];let offset=0;function crc(b){let c=0xffffffff;for(const v of b){c^=v;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
 for(const [name,text] of Object.entries(entries)){const n=Buffer.from(name),b=Buffer.from(text),sum=crc(b),h=Buffer.alloc(30),d=Buffer.alloc(46);h.writeUInt32LE(0x04034b50);h.writeUInt16LE(20,4);h.writeUInt16LE(33,12);h.writeUInt32LE(sum,14);h.writeUInt32LE(b.length,18);h.writeUInt32LE(b.length,22);h.writeUInt16LE(n.length,26);d.writeUInt32LE(0x02014b50);d.writeUInt16LE(20,4);d.writeUInt16LE(20,6);d.writeUInt16LE(33,14);d.writeUInt32LE(sum,16);d.writeUInt32LE(b.length,20);d.writeUInt32LE(b.length,24);d.writeUInt16LE(n.length,28);d.writeUInt32LE(offset,42);blocks.push(h,n,b);central.push(d,n);offset+=h.length+n.length+b.length;}
 const c=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(central.length/2,8);end.writeUInt16LE(central.length/2,10);end.writeUInt32LE(c.length,12);end.writeUInt32LE(offset,16);return Buffer.concat([...blocks,c,end]);
}
// Human transfer copies always use Electron's system Downloads location, never a model-supplied path.
function proposalTransfer(zip,id,downloads){
 check(typeof downloads==='string'&&path.isAbsolute(downloads),'PROPOSAL_DOWNLOADS_UNAVAILABLE');
 const dir=fs.realpathSync(downloads),st=fs.statSync(dir);
 check(st.isDirectory()&&st.uid===process.getuid()&&!(st.mode&0o022),'PROPOSAL_DOWNLOADS_UNSAFE');
 const f=path.join(dir,id+'.zip'),tmp=path.join(dir,'.'+id+'.'+crypto.randomUUID()+'.tmp');
 try{const fd=fs.openSync(tmp,'wx',0o600);try{fs.writeFileSync(fd,zip);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
 check(proposalSha(fs.readFileSync(tmp))===proposalSha(zip),'PROPOSAL_TRANSFER_READBACK_FAILED');
 fs.linkSync(tmp,f);check(proposalSha(fs.readFileSync(f))===proposalSha(zip),'PROPOSAL_TRANSFER_READBACK_FAILED');
 }finally{try{fs.unlinkSync(tmp)}catch{}}
 return f;
}
function proposalBackpack({root,proposal,decision,inventory,provider,stationId,getDownloadsPath=()=>require('electron').app.getPath('downloads')}){
 check(proposalText(proposal,4096)&&['A','B'].includes(decision.type),'PROPOSAL_INVALID');
 const id='PD-'+crypto.randomUUID(), selected=inventory.capabilities.filter(c=>decision.ids.includes(c.id));
 const assignment={schema:proposalVersion,id,createdAt:new Date().toISOString(),stationId,provider,type:decision.type==='A'?'IMPLEMENTATION':'CAPABILITY',proposal,decision,selectedInterfaces:selected,inventoryFingerprint:proposalSha(JSON.stringify(inventory)),status:'COMMISSIONED_NOT_APPROVED_FOR_INSTALL'};
 const json=x=>JSON.stringify(x,null,2)+'\n';const entries={'ASSIGNMENT.json':json(assignment),'INVENTORY.json':json({schema:inventory.schema,coverage:inventory.coverage,capabilities:selected,issues:inventory.issues,inventoryFingerprint:assignment.inventoryFingerprint}),'README_FIRST.md':`# Phantomtronix development assignment ${id}\n\nType: ${assignment.type}\n\nRead ASSIGNMENT.json for the exact proposal, rationale, selected interfaces and acceptance tests. INVENTORY.json is a snapshot of verified registration and integrity, not proof of runtime health or all internal features. Obtain matching source using listed paths and SHA-256 pins before editing; request missing source from Command. Do not use obsolete source.\n\nScope: implement only the stated outcome. Use the established native host bridge and manifest-pinned cartridge contracts. No credentials, arbitrary filesystem or shell authority, automatic installation, signing or publication.\n\nReturn a ZIP containing RETURN.json with assignmentId, type, source pins, changed paths, actual tests, limitations, and proposed integration; include source changes and SHA256SUMS covering all entries except itself. Command must validate independently. This return format is a specification, not an implemented importer.\n\nPrivate institutional standards: MissSpock-OddFM/Science-Lab / workspace/phantomtronics-command/PROTOCOL.md.\n`};
 entries.SHA256SUMS=Object.entries(entries).map(([n,b])=>proposalSha(b)+'  '+n+'\n').join('');
 const zip=proposalZip(entries);const dir=path.join(root,'development-outbox');for(const d of [root,dir]){try{fs.mkdirSync(d,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const s=fs.lstatSync(d);check(s.isDirectory()&&!s.isSymbolicLink()&&s.uid===process.getuid()&&(s.mode&0o022)===0,'PROPOSAL_OUTBOX_UNSAFE');}
 const f=path.join(dir,id+'.zip'),tmp=path.join(dir,'.'+id+'.tmp');try{const fd=fs.openSync(tmp,'wx',0o600);try{fs.writeFileSync(fd,zip);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}fs.linkSync(tmp,f);check(proposalSha(fs.readFileSync(f))===proposalSha(zip),'PROPOSAL_READBACK_FAILED');}finally{try{fs.unlinkSync(tmp)}catch{}}
 try{return {id,path:proposalTransfer(zip,id,getDownloadsPath()),sha256:proposalSha(zip)};}catch{return {id,path:f,sha256:proposalSha(zip),transferFailed:true};}
}

function makeHost({ ipcMain, dialog, getActive, verifyInstalled, builtinsRoot, installedRoot, secretStore, adapterRegistry, companionSeat, stationSeats, getDownloadsPath=()=>require('electron').app.getPath('downloads'), clock = Date.now }) {
  check(ipcMain && dialog && getActive && verifyInstalled && secretStore && adapterRegistry, 'HOST_DEPENDENCY_MISSING');
  const grants = new Map();
  const counters = new Map();
  function active(event) {
    const c = getActive(), wc = c && c.webContents;
    check(wc && !wc.isDestroyed() && event.sender === wc && event.senderFrame === wc.mainFrame, 'UNTRUSTED_CARTRIDGE_CALLER');
    check(typeof c.id === 'string' && /^[a-z0-9][a-z0-9-]{1,62}$/.test(c.id), 'CARTRIDGE_ID_INVALID');
    const u = new URL(wc.getURL());
    check(u.protocol === 'quinplugin:' && u.hostname === c.id, 'CARTRIDGE_ORIGIN_DENIED');
    // This checks the installed CART's code-integrity gate, not renderer assertions.
    verifyInstalled(c.id);
    return {id:c.id,wc};
  }
  function declaration(id) {
    const roots = [installedRoot, builtinsRoot];
    let folder = null;
    for (const dir of roots) {
      const p = path.join(dir, id);
      if (fs.existsSync(path.join(p, 'manifest.json'))) {folder=p;break;}
    }
    check(folder !== null && !fs.lstatSync(folder).isSymbolicLink(), 'CARTRIDGE_MANIFEST_MISSING');
    const mf = path.join(folder,'manifest.json'), policyFile = path.join(folder,'web','clink-llm-permissions.json');
    check(isSafeFile(mf) && fs.existsSync(policyFile) && isSafeFile(policyFile), 'LLM_NOT_DECLARED');
    const manifest = JSON.parse(fs.readFileSync(mf,'utf8'));
    check(manifest.id === id && manifest.runtime === 'web', 'CARTRIDGE_NOT_WEB_RUNTIME');
    // R387: native verifier pins only web/ assets. Outside sidecars are NOT trusted.
    const pin = manifest.files && manifest.files['web/clink-llm-permissions.json'];
    check(typeof pin==='string' && /^[a-f0-9]{64}$/i.test(pin), 'LLM_PERMISSION_NOT_PINNED');
    check(crypto.createHash('sha256').update(fs.readFileSync(policyFile)).digest('hex').toLowerCase()===pin.toLowerCase(),'LLM_PERMISSION_PIN_MISMATCH');
    const policy = JSON.parse(fs.readFileSync(policyFile,'utf8'));
    check(policy && policy.schema === 'clink.cartridge.llm-permissions.v1' && policy.cartridgeId === id && Array.isArray(policy.providers), 'LLM_DECLARATION_INVALID');
    check(policy.providers.length>0 && policy.providers.length<=2 && policy.providers.every(x=>ALLOWED.has(x)) && new Set(policy.providers).size === policy.providers.length, 'LLM_PROVIDER_DECLARATION_INVALID');
    check(typeof policy.reason==='string' && policy.reason.length>=8 && policy.reason.length<=200, 'LLM_REASON_INVALID');
    const digest = crypto.createHash('sha256').update(fs.readFileSync(mf)).update(fs.readFileSync(policyFile)).digest('hex');
    return {manifestSha256:crypto.createHash('sha256').update(fs.readFileSync(mf)).digest('hex'),providers:policy.providers, reason:policy.reason, digest, title:String(manifest.name||id).slice(0,80)};
  }
  function sessionKey(c,provider,policy) { return `${c.wc.id}/${c.id}/${provider}/${policy.digest}`; }
  function standing(c,provider,policy) {
    // Host-owned authorization, not a declaration the renderer can grant itself.
    if(c.id!=='phantomtronix-command'||policy.manifestSha256!=='bbe31140f09d11375431dd881b52b61a1e2f4864a54b572b40a8160678ab5d69')return false;
    try {
      const file=path.join(__dirname,'standing-provider-policy.json');
      if(!isSafeFile(file))return false;
      const p=JSON.parse(fs.readFileSync(file,'utf8'));
      return p.schema==='clink.provider-standing.v1'&&p.cartridgeId===c.id&&p.manifestSha256===policy.manifestSha256&&Array.isArray(p.providers)&&p.providers.includes(provider);
    } catch {return false;}
  }
  async function consent(c,provider,policy) {
    if(standing(c,provider,policy))return true;
    const k=sessionKey(c,provider,policy), grant=grants.get(k);
    if (grant && grant.until>clock()) return true;
    // No persistent approval: each new C.Link session must explicitly reapprove.
    const answer=await dialog.showMessageBox({type:'question',title:'C.Link — Cartridge LLM Permission',
      message:`Allow ${policy.title} to use your ${provider.toUpperCase()} API?`,
      detail:`CARTRIDGE: ${c.id}\nPurpose: ${policy.reason}\n\nThis cartridge never receives your API key. Requests may incur provider charges. Limit: ${REQUESTS_PER_SESSION} calls per open cartridge, ${REQUESTS_PER_MINUTE} per minute, up to ${MAX_OUTPUT_TOKENS} output tokens per response.\n\nApproval lasts at most one hour and ends when the cartridge closes.`,
      buttons:['DENY','ALLOW FOR THIS SESSION'],defaultId:0,cancelId:0,noLink:true});
    if (answer.response!==1) return false;
    grants.set(k,{until:clock()+CONSENT_MS});
    return true;
  }
  function record(id,now) {
    const p=counters.get(id)||{times:[],total:0};
    p.times=p.times.filter(t=>now-t<60000);
    check(p.total<REQUESTS_PER_SESSION, 'LLM_SESSION_LIMIT');
    check(p.times.length<REQUESTS_PER_MINUTE, 'LLM_RATE_LIMIT');
    p.total++;p.times.push(now);counters.set(id,p);
  }
  async function generate(event, req) {
    const c=active(event), policy=declaration(c.id);
    check(req && typeof req==='object' && !Array.isArray(req), 'LLM_REQUEST_INVALID');
    const provider=req.provider;
    check(ALLOWED.has(provider) && policy.providers.includes(provider), 'LLM_PROVIDER_DENIED');
    check(typeof req.prompt==='string' && req.prompt.length>=1 && req.prompt.length<=MAX_PROMPT, 'LLM_PROMPT_SIZE');
    const maxOutputTokens=req.maxOutputTokens===undefined?256:req.maxOutputTokens;
    check(Number.isInteger(maxOutputTokens) && maxOutputTokens>=1 && maxOutputTokens<=MAX_OUTPUT_TOKENS, 'LLM_OUTPUT_LIMIT');
    const t=clock();
    const current=counters.get(c.wc.id)||{times:[],total:0};
    check(current.total<REQUESTS_PER_SESSION && current.times.filter(x=>t-x<60000).length<REQUESTS_PER_MINUTE,'LLM_RATE_OR_SESSION_LIMIT');
    if (!await consent(c,provider,policy)) fail('LLM_CONSENT_DENIED');
    // The CART might be closed while its approval dialog is displayed.
    active(event);
    // Recheck after asynchronous consent so a swapped declaration cannot inherit approval.
    check(declaration(c.id).digest===policy.digest,'LLM_DECLARATION_CHANGED');
    record(c.wc.id,clock());
    // Reuse native provider adapter, which retrieves credentials within the Electron main process.
    let envelope;
    try { envelope=await adapterRegistry.createResponse(provider,{
      input:req.prompt,maxOutputTokens,store:false,
      companionId:'cartridge:'+c.id,missionId:'CLINK_CARTRIDGE_LLM',workerId:null,purpose:'cartridge_llm'
    }); } catch { fail('LLM_PROVIDER_REQUEST_FAILED'); }
    if (!envelope || envelope.error) fail('LLM_PROVIDER_REQUEST_FAILED');
    let response='';
    // Use text-only output; never return raw provider envelope, headers, or secret metadata.
    if (typeof envelope.outputText==='string') response=envelope.outputText;
    else if (typeof envelope.text==='string') response=envelope.text;
    else if (typeof envelope.responseText==='string') response=envelope.responseText;
    else if (typeof envelope.output==='string') response=envelope.output;
    else if (Array.isArray(envelope.output)) response=envelope.output.flatMap(o=>Array.isArray(o.content)?o.content:[]).filter(v=>v&&v.type==='output_text'&&typeof v.text==='string').map(v=>v.text).join('');
    check(response.length>0 && response.length<=MAX_RESPONSE_CHARS, 'LLM_RESPONSE_UNSUPPORTED');
    // Defense-in-depth: redact any accidentally reflected credential before returning to CART.
    // No plaintext secret is copied to any object sent to the renderer.
    return {ok:true,provider,text:response,usage:{totalTokens:Number.isSafeInteger(envelope.usage?.totalTokens)?envelope.usage.totalTokens:null}};
  }
  async function status(event) {
    const c=active(event), policy=declaration(c.id);
    return {ok:true,providers:[...policy.providers],limits:{maxPromptChars:MAX_PROMPT,maxOutputTokens:MAX_OUTPUT_TOKENS,maxCallsPerSession:REQUESTS_PER_SESSION,maxCallsPerMinute:REQUESTS_PER_MINUTE},sessionApprovalRequired:policy.providers.some(p=>!standing(c,p,policy))};
  }
  // Companion access is a separate, host-controlled capability. Initial pilot:
  // only the already approved, exact Command build. Future carts need explicit grants.
  function companionAccess(event,provider,stationId="00") {
    const c=active(event), policy=declaration(c.id);
    check(typeof stationId==='string'&&/^0[0-7]$/.test(stationId),'STATION_ID_INVALID');
    check(stationId==='00'||stationSeats,'STATION_SERVICE_UNAVAILABLE');
    const turn=stationId==='00'?companionSeat:stationSeats.turnSeat(stationId,adapterRegistry);
    check(turn && typeof turn.currentKey==='function','COMPANION_ROUTE_UNAVAILABLE');
    check(policy.providers.some(p=>standing(c,p,policy)), 'COMPANION_CARTRIDGE_DENIED');
    if(provider!==undefined)check(policy.providers.includes(provider)&&standing(c,provider,policy),'COMPANION_PROVIDER_DENIED');
    check(!turn.snapshot().disabledReason,'COMPANION_SEAT_LOCKED');
    const key=turn.sync();
    check(key,'NO_COMPANION_LOADED');
    return {c,policy,key,turn,stationId,generation:turn.snapshot().generation};
  }
  async function companionStatus(event,stationId) {
    const {key,policy,c,generation,stationId:resolved}=companionAccess(event,undefined,stationId);
    return {ok:true,stationId:resolved,...(resolved!=="00"?{displayName:stationSeats.status(resolved).displayName}:{}),companionId:key.split(':')[0],generation,providers:policy.providers.filter(p=>standing(c,p,policy))};
  }
  // Fixed local institutional workspace; no model-supplied paths or automatic execution.
  const recordsRoot=path.join(path.dirname(path.dirname(installedRoot)),'phantomtronics-command','records');
  function ensureRecords(){
    for(const d of [path.dirname(recordsRoot),recordsRoot]){
      try{fs.mkdirSync(d,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}
      const st=fs.lstatSync(d);check(st.isDirectory()&&!st.isSymbolicLink(),'COMMAND_RECORD_ROOT_UNSAFE');
    }
  }
  function readRecord(n){
    check(/^(CANON\.001|WORK\.[0-9]{6})\.md$/.test(n),'COMMAND_RECORD_NAME_INVALID');
    const f=path.join(recordsRoot,n);let st;try{st=fs.lstatSync(f);}catch(e){if(e.code==='ENOENT')return null;throw e;}
    check(st.isFile()&&!st.isSymbolicLink()&&st.size<=20000,'COMMAND_RECORD_UNSAFE');
    return fs.readFileSync(f,'utf8');
  }
  function currentRecord(){ensureRecords();const names=fs.readdirSync(recordsRoot).filter(n=>/^WORK\.[0-9]{6}\.md$/.test(n)).sort();const n=names.at(-1);return n?{name:n,text:readRecord(n)}:null;}
  function saveRecord(n,text){
    ensureRecords();check(/^(CANON\.001|WORK\.[0-9]{6})\.md$/.test(n),'COMMAND_RECORD_NAME_INVALID');
    check(typeof text==='string'&&text.trim()&&text.length<=MAX_PROMPT&&!text.includes('\0'),'COMMAND_RECORD_TEXT_INVALID');
    const f=path.join(recordsRoot,n),tmp=path.join(recordsRoot,'.'+crypto.randomBytes(16).toString('hex'));
    check(!fs.existsSync(f),'COMMAND_RECORD_EXISTS');
    try{const fd=fs.openSync(tmp,'wx',0o600);try{fs.writeFileSync(fd,text,'utf8');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}fs.linkSync(tmp,f);}finally{try{fs.unlinkSync(tmp);}catch{}}
    check(readRecord(n)===text,'COMMAND_RECORD_READBACK_FAILED');
    return `C.Link verified save: ${f}\nSHA-256: ${crypto.createHash('sha256').update(text).digest('hex')}`;
  }
  function recordCommand(value){
    const v=value.trim(),work=v.match(/^(?:\/work\s+|save current work:\s*)([\s\S]+)$/i),canon=v.match(/^\/save\s+CANON\.001\.md\s+([\s\S]+)$/i);
    if(work){const old=currentRecord(),i=old?Number(old.name.slice(5,11))+1:1;check(i<=999999,'COMMAND_RECORD_LIMIT');return saveRecord('WORK.'+String(i).padStart(6,'0')+'.md',work[1]);}
    if(canon)return saveRecord('CANON.001.md',canon[1]);
    if(/^\/read\s+CANON\.001\.md$/i.test(v)){ensureRecords();return readRecord('CANON.001.md')??'C.Link: Canon has not been saved.';}
    if(/^\/current$|^what is our current assignment\??$/i.test(v)){const r=currentRecord();return r?`C.Link verified record ${r.name}:\n${r.text}`:'C.Link: No current assignment has been saved.';}
    if(/^\/handoff$|^create a handoff[.!]?$/i.test(v)){const r=currentRecord();return r?`PHANTOMTRONICS COMMAND — DEVELOPMENT HANDOFF\nSource record: ${r.name}\nSHA-256: ${crypto.createHash('sha256').update(r.text).digest('hex')}\n\nCURRENT ASSIGNMENT (human-approved record):\n${r.text}\n\nWork only on this assignment. Do not assume missing facts or authority. Return proposed changes, actual test evidence, limitations and next step to Command for review. No automatic integration.`:'C.Link: No current assignment. Use /work followed by the assignment first.';}
    if(/^\/(work|save|read|current|handoff)(\s|$)/i.test(v))throw Error('COMMAND_RECORD_SYNTAX');
    return null;
  }
  function commandContext(){const work=currentRecord(),canon=readRecord('CANON.001.md');return JSON.stringify({currentWork:work,canon});}
  async function companionChat(event,req) {
    check(req&&typeof req==='object'&&!Array.isArray(req),'COMPANION_REQUEST_INVALID');
    check(typeof req.provider==='string'&&ALLOWED.has(req.provider),'COMPANION_PROVIDER_DENIED');
    check(typeof req.text==='string'&&req.text.trim().length>0&&req.text.length<=MAX_PROMPT,'LLM_PROMPT_SIZE');
    const {c,key,generation,turn,stationId}=companionAccess(event,req.provider,req.stationId);
    check(req.seatGeneration===generation,'STALE_COMPANION_REQUEST');
    check(!turn.snapshot().busy,'COMPANION_TURN_IN_PROGRESS');
    const proposalMatch=req.text.trim().match(/^(?:\/proposal(?:\s+|$)|(?:submit )?proposal:\s*)([\s\S]*)$/i);
    if(proposalMatch){
      check(stationId==='00'&&c.id==='phantomtronix-command','PROPOSAL_COMMAND_ONLY');
      const original=proposalMatch[1].trim(),reply=text=>({ok:true,stationId,companionId:key.split(':')[0],generation,provider:req.provider,text});
      if(!original)return reply('Proposal determination ready. Enter /proposal followed by your intended outcome.');
      check(proposalText(original,MAX_PROMPT),'PROPOSAL_TEXT_INVALID');
      const web=require('../core/quin-web-plugins.js'),service=require('../core/quin-service-plugins.js');
      const inventory=()=>proposalInventory({builtinsRoot,installedRoot,verifyWeb:verifyInstalled,verifyService:id=>service.verify(id,builtinsRoot,installedRoot),enabled:(m,id)=>web.pluginEnabled(m,id,path.dirname(path.dirname(installedRoot)))});
      const before=inventory();record(c.wc.id,clock());
      const result=await turn.reply(original,{provider:req.provider,cartridgeTurn:true,proposalContext:JSON.stringify(before)});
      const after=companionAccess(event,req.provider,stationId);
      check(after.key===key&&after.generation===generation,'STALE_COMPANION_RESPONSE_DISCARDED');
      check(result?.ok&&result.companionId===key.split(':')[0]&&String(result.backpackSha256).toUpperCase()===key.split(':')[1],'COMPANION_REPLY_FAILED');
      if(result.replyIncomplete)return reply('Type C — the provider response was incomplete. No backpack created. Please resubmit.');
      if(proposalSha(JSON.stringify(before))!==proposalSha(JSON.stringify(inventory())))return reply('Type C — capability inventory changed during assessment. Please resubmit.');
      const decision=proposalDecision(result.reply,before);
      if(decision.type==='C')return reply('Type C — clarification required. '+decision.question+' No backpack created.');
      ensureRecords();const pack=proposalBackpack({root:path.dirname(recordsRoot),proposal:original,decision,inventory:before,provider:req.provider,stationId,getDownloadsPath});
      if(pack.transferFailed)return reply('Assignment commissioned, but Downloads export FAILED. No transfer ZIP was delivered. Internal assignment: '+pack.id+'\nSHA-256: '+pack.sha256);
      return reply('Type '+decision.type+' — '+(decision.type==='A'?'Implementation':'New capability')+' Backpack. '+decision.reason+'\nC.Link verified backpack: '+pack.path+'\nAssignment: '+pack.id+'\nSHA-256: '+pack.sha256+'\nCommissioned only; not approved for installation.');
    }
    const mail=mailboxCommand(stationId,req.text,key);
    if(mail!==null)return {ok:true,stationId,companionId:key.split(':')[0],generation,provider:req.provider,text:mail};
    if(stationId==='00'){
      const local=recordCommand(req.text);
      if(local!==null)return {ok:true,stationId,companionId:key.split(':')[0],generation,provider:req.provider,text:local};
    }
    const draft=req.text.trim().match(/^(?:draft and send to|write and send to) (?:station )?(0[0-7]|command|planning|engineering|design|science|logistics|communications|operations)\s*:\s*([\s\S]+)$/i);
    const target=draft?(/^0/.test(draft[1])?draft[1]:'0'+stationNames.indexOf(draft[1].toLowerCase())):null;
    if(draft)check(target!==stationId,'STATION_DESTINATION_INVALID');
    record(c.wc.id,clock());
    const result=await turn.reply(draft?`Compose only the message body for Station ${target}, following this human request. Do not claim delivery or include a preamble: ${draft[2]}`:req.text,{provider:req.provider,cartridgeTurn:true,stationContext:mailboxContext(stationId),...(stationId==='00'?{commandContext:commandContext()}: {})});
    const after=companionAccess(event,req.provider,stationId);
    check(after.key===key&&after.generation===generation,'STALE_COMPANION_RESPONSE_DISCARDED');
    check(result?.ok&&result.companionId===key.split(':')[0]&&String(result.backpackSha256).toUpperCase()===key.split(':')[1],'COMPANION_REPLY_FAILED');
    check(typeof result.reply==='string'&&result.reply.length>0&&result.reply.length<=MAX_RESPONSE_CHARS,'LLM_RESPONSE_UNSUPPORTED');
    if(draft){check(!result.replyIncomplete,'STATION_DRAFT_INCOMPLETE');return {ok:true,stationId,companionId:result.companionId,generation,provider:req.provider,text:deliver(stationId,target,result.reply,key)};}
    return {ok:true,stationId,companionId:result.companionId,generation,provider:req.provider,text:result.reply};
  }
  async function companionDispatch(event,op,req) {
    try{return await (op==='status'?companionStatus(event,req):companionChat(event,req));}
    catch(e){return {ok:false,error:safeError(e)};}
  }
  async function dispatch(event,op,req) {
    try {return await (op==='status'?status(event):generate(event,req));}
    catch(e){return {ok:false,error:safeError(e)};}
  }
  // Exact Command manifest + native confirmation. No renderer-provided file paths.
  let seatDialogBusy=false;
  async function stationDispatch(event,op,id){try{
    function authorized(){const c=active(event),policy=declaration(c.id);check(c.id==='phantomtronix-command'&&policy.manifestSha256==="bbe31140f09d11375431dd881b52b61a1e2f4864a54b572b40a8160678ab5d69"&&policy.providers.some(p=>standing(c,p,policy)),'STATION_ACCESS_DENIED');check(stationSeats,'STATION_SERVICE_UNAVAILABLE');}
    authorized();if(op==='list')return {ok:true,seats:stationSeats.list()};
    check(typeof id==='string'&&/^0[1-7]$/.test(id),'SPECIALIST_STATION_REQUIRED');check(!seatDialogBusy,'STATION_DIALOG_BUSY');seatDialogBusy=true;
    try{if(op==='import'){
      const f=await dialog.showOpenDialog({title:'Select personality ZIP for station '+id,properties:['openFile'],filters:[{name:'Personality ZIP',extensions:['zip']}]});authorized();if(f.canceled||!f.filePaths?.[0])return {ok:true,cancelled:true};
      const r=stationSeats.intake.inspect(f.filePaths[0]);const a=await dialog.showMessageBox({type:'question',title:'Seat specialist companion',message:'Seat '+r.displayName+' at station '+id+'?',detail:'Revision '+r.version+'\nSHA-256 '+r.archiveSha256+'\nThis verifies archive integrity, not Phantomtronics licensing. This will replace the station binding, not the terminal companion. No scripts will execute.',buttons:['Cancel','Seat companion'],defaultId:0,cancelId:0,noLink:true});authorized();if(a.response!==1)return {ok:true,cancelled:true};return {ok:true,seat:stationSeats.assign(id,f.filePaths[0],r.archiveSha256,{humanApproved:true})};
    }else if(op==='eject'){const a=await dialog.showMessageBox({type:'question',title:'Vacate specialist seat',message:'Vacate station '+id+'?',detail:'The staged personality ZIP is retained.',buttons:['Cancel','Vacate seat'],defaultId:0,cancelId:0,noLink:true});authorized();if(a.response!==1)return {ok:true,cancelled:true};return {ok:true,seat:stationSeats.eject(id,{humanApproved:true})};}throw Error('STATION_OPERATION_INVALID');}finally{seatDialogBusy=false;}
  }catch(e){return {ok:false,error:safeError(e)};}}
  // One canonical delivery in the sending outbox; recipient inbox is a view of that same record.
  const stationNames=['command','planning','engineering','design','science','logistics','communications','operations'];
  function boxDir(id,box){
    check(/^0[0-7]$/.test(id)&&['inbox','outbox'].includes(box),'STATION_BOX_INVALID');
    ensureRecords();const root=path.join(path.dirname(recordsRoot),'stations'),station=path.join(root,id),dir=path.join(station,box);
    for(const d of [root,station,dir]){try{fs.mkdirSync(d,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const st=fs.lstatSync(d);check(st.isDirectory()&&!st.isSymbolicLink(),'STATION_BOX_UNSAFE');}return dir;
  }
  function ownItems(id,box){const dir=boxDir(id,box),names=fs.readdirSync(dir).filter(n=>/^[0-9]{6}\.json$/.test(n)).sort();check(names.length<=10000,'STATION_BOX_LIMIT');return names.map(n=>{
    const f=path.join(dir,n),st=fs.lstatSync(f);check(st.isFile()&&!st.isSymbolicLink()&&st.size<=30000,'STATION_BOX_UNSAFE');const item=JSON.parse(fs.readFileSync(f,'utf8'));
    check(item.schema==='phantomtronics.station-box.v1'&&item.stationId===id&&item.box===box&&item.id===n.slice(0,6)&&typeof item.text==='string'&&item.text.length<=MAX_PROMPT&&typeof item.createdAt==='string','STATION_BOX_CORRUPT');
    if(item.to!==undefined)check(box==='outbox'&&/^0[0-7]$/.test(item.to)&&item.to!==id&&typeof item.companionId==='string','STATION_BOX_CORRUPT');return item;
  });}
  function items(id,box){const own=ownItems(id,box);if(box==='inbox')for(let i=0;i<8;i++){const from='0'+i;if(from!==id)for(const item of ownItems(from,'outbox'))if(item.to===id)own.push({...item,sourceId:item.id,stationId:id,box:'inbox',from,id:from+'-'+item.id});}return own.sort((a,b)=>a.createdAt.localeCompare(b.createdAt)||a.id.localeCompare(b.id));}
  function appendBox(id,box,text,route={}){
    check(typeof text==='string'&&text.trim()&&text.length<=MAX_PROMPT&&!text.includes('\0'),'STATION_BOX_TEXT_INVALID');const dir=boxDir(id,box),all=ownItems(id,box),i=all.length?Number(all.at(-1).id)+1:1;check(i<=999999&&all.length<10000,'STATION_BOX_LIMIT');
    const n=String(i).padStart(6,'0'),dest=path.join(dir,n+'.json'),tmp=path.join(dir,'.'+crypto.randomBytes(16).toString('hex'));
    const item={schema:'phantomtronics.station-box.v1',stationId:id,box,id:n,createdAt:new Date().toISOString(),text,...route},body=JSON.stringify(item);
    try{const fd=fs.openSync(tmp,'wx',0o600);try{fs.writeFileSync(fd,body,'utf8');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}fs.linkSync(tmp,dest);const d=fs.openSync(dir,'r');try{fs.fsyncSync(d);}finally{fs.closeSync(d);}}finally{try{fs.unlinkSync(tmp);}catch{}}
    check(fs.readFileSync(dest,'utf8')===body,'STATION_BOX_READBACK_FAILED');return item;
  }
  function deliver(id,to,text,key){check(/^0[0-7]$/.test(to)&&to!==id,'STATION_DESTINATION_INVALID');const item=appendBox(id,'outbox',text,{to,companionId:key.split(':')[0]});return `C.Link verified delivery ${id}-${item.id} → Station ${to} (${stationNames[Number(to)]}):\n${text}`;}
  function mailboxContext(id){const result={stationId:id,stationName:stationNames[Number(id)]};for(const box of ['inbox','outbox']){const all=items(id,box);result[box]={count:all.length,recent:all.slice(-3).map(x=>({...x,text:x.text.slice(0,1500),truncated:x.text.length>1500}))};}return JSON.stringify(result);}
  function mailboxCommand(id,text,key){const v=text.trim();const read=v.match(/^\/(inbox|outbox)(?:\s+(\d+))?$/i)||v.match(/^read (?:your |the )?(inbox|outbox)[.!?]?$/i);if(read){const box=read[1].toLowerCase(),all=items(id,box);if(!all.length)return `C.Link: Station ${id} ${box} is empty.`;const n=read[2]===undefined?all.length:Number(read[2]);check(Number.isSafeInteger(n)&&n>=1&&n<=all.length,'STATION_BOX_PAGE_INVALID');const x=all[n-1];return `C.Link verified ${box} ${n}/${all.length} · ${x.id}${x.from?' · FROM '+x.from:''}${x.to?' · TO '+x.to:''}:\n${x.text}`;}
    const send=v.match(/^(?:\/send\s+|send (?:to )?)(?:station\s+)?(0[0-7]|command|planning|engineering|design|science|logistics|communications|operations)\s*:\s*([\s\S]+)$/i);if(send){const to=/^0/.test(send[1])?send[1]:'0'+stationNames.indexOf(send[1].toLowerCase());return deliver(id,to,send[2],key);}
    if(/^\/(inbox|outbox|send)(\s|$)/i.test(v))throw Error('STATION_MAIL_SYNTAX');return null;
  }
  function stationBox(event,req){try{
    const c=active(event),policy=declaration(c.id);check(c.id==='phantomtronix-command'&&policy.providers.some(p=>standing(c,p,policy)),'STATION_ACCESS_DENIED');
    check(req&&typeof req.stationId==='string'&&/^0[0-7]$/.test(req.stationId)&&['inbox','outbox'].includes(req.box),'STATION_BOX_INVALID');check(['read','append'].includes(req.op),'STATION_BOX_OPERATION_INVALID');
    if(req.op==='append'){companionAccess(event,undefined,req.stationId);appendBox(req.stationId,req.box,req.text);}
    const all=items(req.stationId,req.box),i=req.op==='append'||req.index===undefined?all.length-1:req.index;check(Number.isSafeInteger(i)&&i>=-1&&(all.length===0?i===-1:i>=0&&i<all.length),'STATION_BOX_PAGE_INVALID');return {ok:true,stationId:req.stationId,box:req.box,count:all.length,index:i,item:all[i]||null,saved:req.op==='append'};
  }catch(e){return {ok:false,error:safeError(e)};}}
  function register() {
    ipcMain.handle('clink:cart-stations:box',(e,r)=>stationBox(e,r));
    ipcMain.handle('clink:cart-stations:list',e=>stationDispatch(e,'list'));
    ipcMain.handle('clink:cart-stations:import',(e,id)=>stationDispatch(e,'import',id));
    ipcMain.handle('clink:cart-stations:eject',(e,id)=>stationDispatch(e,'eject',id));
    ipcMain.handle('clink:cart-llm:status',e=>dispatch(e,'status'));
    ipcMain.handle('clink:cart-llm:generate',(e,r)=>dispatch(e,'generate',r));
    ipcMain.handle('clink:cart-companion:status',(e,id)=>companionDispatch(e,'status',id));
    ipcMain.handle('clink:cart-companion:chat',(e,r)=>companionDispatch(e,'chat',r));
  }
  return Object.freeze({register});
}
module.exports={makeHost,proposalInventory,proposalDecision,proposalBackpack,proposalZip,proposalTransfer};
