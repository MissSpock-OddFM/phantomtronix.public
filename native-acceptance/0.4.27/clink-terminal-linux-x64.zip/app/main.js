'use strict';
const { app, BrowserWindow, WebContentsView, ipcMain, clipboard, dialog, safeStorage, protocol, session, nativeTheme } = require('electron');
const fs = require('fs');
const webPlugins=require('./core/quin-web-plugins');
const servicePlugins=require('./core/quin-service-plugins');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const cp = require('child_process');
const { PanelsSupervisor } = require('./core/panels-supervisor');
const { AgentRelay } = require('./core/agent-relay');
const { RelayPackageStore } = require('./core/relay-package');
const { admitRepairProposal } = require('./core/repair-admission');
const { CLinkBrowserRuntime, REQUIRED_ELECTRON } = require('./core/browser-runtime');
const { TEST_SIZES } = require('./core/message-qualification');
const { BackpackManager } = require('./core/backpack-manager');
const { AliceSeatService } = require('./core/alice-seat-service');
const {QuinL1Runner,OBJECTIVE: L1_OBJECTIVE}=require('./core/quin-l1-runner');
const aliceCbVoice = require('./core/alice-cb-voice');
const { CompanionZipIntake } = require('./core/companion-zip-intake.cjs');
const { createAgentShelf } = require('./core/agent-shelf.cjs'); // Miss Spock R315: automatic agent shelf sync
const { CompanionActivationRecovery } = require('./core/companion-activation-recovery.cjs');
const { checkCompanionStartup } = require('./core/companion-startup-preflight.cjs');
const { createRecoveryShell } = require('./core/companion-recovery-shell.cjs');
const { UniversalCompanionPrimary } = require('./core/universal-companion-primary.cjs');
const { CompanionTurnSeat, CommandStationSeats } = require('./core/companion-turn-seat.cjs');
const { createCompanionActivationIpc } = require('./core/companion-activation-ipc.cjs');
const { RestrictedBrowserCartridge } = require('./core/restricted-browser-cartridge.cjs');
const { CompanionChatGPTBridge } = require('./core/companion-chatgpt-bridge.cjs');
const { CompanionOrchestrator } = require('./core/companion-orchestrator');
const { ProviderSecretStore } = require('./core/provider-secret-store');
const { testProviderKey } = require('./core/provider-connectivity');
const { ProviderAdapterRegistry } = require('./core/provider-adapter-registry');
const { AlphaShadowRunner } = require('./core/alpha-shadow-runner');
const { CompanionContextBuilder } = require('./core/companion-context-builder');
const { ApiUsageLedger } = require('./core/api-usage-ledger');
const { AlphaPrimaryRunner } = require('./core/alpha-primary-runner');
const { ApiPrimarySoak } = require('./core/api-primary-soak');
const { ReadOnlyWorkerExperiment } = require('./core/read-only-worker-experiment');
const { Round9Reconciliation } = require('./core/round9-reconciliation');
const { explicitSpecialistRelayRequested: specialistRelayRequested } = require('./core/relay-intent');

const BUILD = 'Quin-0.1.0-alpha-c42-fork';
const MISSION = 'QUIN_FORK_002_Browser_PANELS_RobotRock';
const R8_MISSION = 'AM-032R8A_WORKER_STRUCTURED_REPORT_HOTFIX';
const FIELD_TEST_MODE = process.env.CLINK_FIELD_TEST_MODE === '1';
const PROFILE_ROOT_OVERRIDE = FIELD_TEST_MODE ? String(process.env.CLINK_PROFILE_ROOT||'').trim() : '';
if (FIELD_TEST_MODE && !PROFILE_ROOT_OVERRIDE) throw new Error('CLINK_FIELD_TEST_PROFILE_ROOT_REQUIRED');
const PROFILE_ROOT = PROFILE_ROOT_OVERRIDE ? path.resolve(PROFILE_ROOT_OVERRIDE) : path.join(app.getPath('appData'), 'PhantomTronix', 'Quin');
const QUIN_PROFILE_ROOT = path.join(app.getPath('appData'), 'PhantomTronix', 'Quin');
const PROVIDER_AUTH_DIR = path.join(QUIN_PROFILE_ROOT,'providers','chatgpt-web');
const PROVIDER_AUTH_STATE_FILE = path.join(PROVIDER_AUTH_DIR,'auth-state.json');
const APP_ICON = path.join(__dirname, 'assets', 'clink-icon.png');
const LINUX_DESKTOP_ID = 'com.phantomtronix.clink';
const LINUX_DESKTOP_NAME = `${LINUX_DESKTOP_ID}.desktop`;
const LINUX_DURABLE_APP_DIR = path.join(os.homedir(),'.local','share','phantomtronix','quin','current');
const LINUX_DURABLE_LAUNCHER = path.join(os.homedir(),'.local','bin','phantomtronix-quin');
const LINUX_RUNTIME_CACHE = path.join(QUIN_PROFILE_ROOT,'runtime','electron-path');
let shutdownStarted=false;
let shutdownPromise=null;
let quitScheduled=false;
let inlineAuthView=null;
let inlineAuthPoll=null;
let inlineAuthActive=false;
const PANELS_ROOT = path.join(__dirname, 'panels-os');
const LOG_DIR = path.join(PROFILE_ROOT, 'logs', 'vanilla-core');
const LOG_FILE = path.join(LOG_DIR, 'AM027R28B.jsonl');
const BOOT_LOG = path.join(LOG_DIR, 'AM027R28B-BOOT.txt');
const QUAL_DIR = path.join(PROFILE_ROOT,'qualification');
const QUAL_LATEST = path.join(QUAL_DIR,'browser-message-throughput-latest.json');
const QUAL_HISTORY = path.join(QUAL_DIR,'browser-message-throughput-history.jsonl');
const TERMINAL_SESSION_ID = `TERM-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

protocol.registerSchemesAsPrivileged(['quinplugin','quinservice'].map(scheme=>({scheme,privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true}})));
app.setName('PhantomTronix C.Link Terminal');

// R365: read-only GUI acceptance. Never navigate Browser during installation.
if(process.env.CLINK_R365_SMOKE_MARKER){
 const fs365=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let wrote=false;
  win.webContents.on('did-finish-load',()=>setTimeout(async()=>{
   if(wrote||win.isDestroyed())return;
   let details={ok:false};
   try{details=await win.webContents.executeJavaScript(`(()=>{
    const shell=document.getElementById('clink-r358-shell');
    const d=typeof window.__CLINK_R365_DIAGNOSTICS__==='function'
     ?window.__CLINK_R365_DIAGNOSTICS__():null;
    return {ok:!!shell&&!!d&&d.hasExit&&d.hasReopen,
     nativeBrowserButton:!!d?.nativeBrowserButton,readOnly:true,
     browserInteraction:'NOT_ATTEMPTED'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const proof={loaded:true,visible:win.isVisible(),details,
                timestamp:new Date().toISOString(),pid:process.pid};
   try{fs365.writeFileSync(process.env.CLINK_R365_SMOKE_MARKER,JSON.stringify(proof));wrote=true;}catch(_){}
  },1800));
 });
}


// R363 real Electron smoke: verifies the one-stop manager without mutating packages.
if(process.env.CLINK_R363_SMOKE_MARKER){
 const fs363=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let loaded=false,failed=false,done=false;
  const probe=async()=>{
   if(!loaded||done||win.isDestroyed())return;
   let details={ok:false,error:'NOT_LOADED'};
   try {details=await win.webContents.executeJavaScript(`(async()=>{
     return typeof window.__CLINK_R363_TEST__==='function' ? await window.__CLINK_R363_TEST__() : {ok:false,error:'R363_TEST_MISSING'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const event={loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()};
   try{fs363.writeFileSync(process.env.CLINK_R363_SMOKE_MARKER,JSON.stringify(event));}catch(_e){}
   if(details.ok)done=true;
  };
  win.webContents.on('did-finish-load',()=>{loaded=true;setTimeout(probe,2500);setTimeout(probe,6500);setTimeout(probe,11000);});
  win.webContents.on('did-fail-load',()=>{failed=true;});
 });
}


// R362 GUI verification: tests Alice and Companion Home controls without sending messages.
if (process.env.CLINK_R362_SMOKE_MARKER) {
 const fs362=require('node:fs');
 app.on('browser-window-created',(_ev,w)=>{
  let loaded=false,failed=false,once=false;
  const check=async()=>{
   if(w.isDestroyed()||!loaded||once)return;
   let details={};
   try {details=await w.webContents.executeJavaScript(`(async()=>{
     return typeof window.__CLINK_R362_TEST__==='function'?await window.__CLINK_R362_TEST__():{ok:false,error:'R362_TEST_UNAVAILABLE'};
   })()`,true);}catch(e){details={ok:false,error:String(e)};}
   const event={loaded,failed,visible:w.isVisible(),details,pid:process.pid,time:new Date().toISOString()};
   try{fs362.writeFileSync(process.env.CLINK_R362_SMOKE_MARKER,JSON.stringify(event));}catch(_e){}
   if(details.ok)once=true;
  };
  w.webContents.on('did-finish-load',()=>{loaded=true;setTimeout(check,3000);setTimeout(check,6500);setTimeout(check,10000);});
  w.webContents.on('did-fail-load',()=>{failed=true;});
 });
}


// R361 independent GUI verification (one-shot, triggered only by relay).
if (process.env.CLINK_R361_SMOKE_MARKER) {
 const fs361=require('node:fs');
 app.on('browser-window-created', (_evt, win) => {
  let loaded=false,failed=false;
  const inspect=async()=>{
   if(win.isDestroyed()||!loaded)return;
   let details={};
   try {details=await win.webContents.executeJavaScript(`(()=>{
     const s=window.__CLINK_R361_DIAGNOSTICS__;
     return typeof s==='function'?s():{ready:false,error:'R361_DIAGNOSTICS_NOT_MOUNTED'};
   })()`,true);} catch(err){details={error:String(err)};}
   try {fs361.writeFileSync(process.env.CLINK_R361_SMOKE_MARKER,
    JSON.stringify({loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}
   catch(_err){}
  };
  win.webContents.on('did-finish-load',()=>{loaded=true;[500,1500,3000,5000,7500].forEach(ms=>setTimeout(inspect,ms));});
  win.webContents.on('did-fail-load',()=>{failed=true;void inspect();});
 });
}


// R360: visible, Home-start, Alice blank UI smoke when explicitly requested by relay.
if (process.env.CLINK_R360_SMOKE_MARKER) {
 const fs360=require('node:fs');
 app.on('browser-window-created',(_event,w)=>{
  let loaded=false,failed=false;
  const run=async()=>{
   if(w.isDestroyed()||!loaded)return;
   let details={};
   try {details=await w.webContents.executeJavaScript(`(()=>{
     const alice=document.getElementById('aliceSeatPanel');
     const transcript=document.getElementById('aliceSeatTranscript');
     const home=document.getElementById('quinHome');
     return {ready:window.__CLINK_R360_READY__===true,
       homeVisible:!!home&&!home.hidden,
       aliceHidden:!!alice&&alice.hidden,
       aliceEscape:!!alice?.querySelector('.clink-r360-return'),
       companionEscape:!!document.getElementById('companionSeatPanel')?.querySelector('.clink-r360-return'),
       transcriptChildren:transcript?.childElementCount??-1,
       appTitle:document.title,
       cLinkShell:!!document.getElementById('clink-r358-shell')};
   })()`,true);}
   catch(e){details={error:String(e)};}
   try{fs360.writeFileSync(process.env.CLINK_R360_SMOKE_MARKER,JSON.stringify({loaded,failed,visible:w.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}catch(_e){}
  };
  w.webContents.on('did-finish-load',()=>{loaded=true;[250,750,1500,2900,5200,8000].forEach(ms=>setTimeout(run,ms));});
  w.webContents.on('did-fail-load',()=>{failed=true;void run();});
 });
}


// R358 smoke: actual visible C.Link desktop AND working 8-slot application grid.
if (process.env.CLINK_R358_SMOKE_MARKER) {
 const smokeFs=require('node:fs');
 app.on('browser-window-created', (_evt,win)=>{
  let loaded=false,failed=false,details={};
  const record=event=>{try{smokeFs.writeFileSync(process.env.CLINK_R358_SMOKE_MARKER,JSON.stringify({event,loaded,failed,visible:win.isVisible(),details,pid:process.pid,time:new Date().toISOString()}));}catch(_e){}};
  const check=async()=>{
   if(!loaded||win.isDestroyed())return;
   try{
    details=await win.webContents.executeJavaScript(`(()=>{
      const shell=document.getElementById('clink-r358-shell');const deck=document.getElementById('clink-r358-deck');const grid=document.getElementById('clink-r358-card-grid');const sidebar=document.getElementById('clink-r358-side');
      const rect=shell?.getBoundingClientRect();const style=shell&&getComputedStyle(shell);
      return {present:!!shell,revision:shell?.dataset.revision,width:rect?.width||0,height:rect?.height||0,display:style?.display,brand:document.getElementById('clink-r358-brand')?.textContent||'',navCount:sidebar?.querySelectorAll('[data-view]').length||0,gridVisible:!!grid&&grid.getBoundingClientRect().width>100,cardCount:grid?.querySelectorAll('.cl-card').length||0,ready:window.__CLINK_R358_READY__===true,deckVisible:!!deck&&!deck.hidden};
    })()`,true);
    record('renderer-checked');
   }catch(error){details={error:String(error)};record('probe-error');}
  };
  record('window-created');win.on('show',()=>{record('window-shown');setTimeout(check,700);});
  win.webContents.on('did-finish-load',()=>{loaded=true;let attempts=0;const timer=setInterval(()=>{check();if(++attempts>=17)clearInterval(timer);},600);});
  win.webContents.on('did-fail-load',(_event,code,description,url)=>{failed=true;details={code,description,url};record('renderer-load-failed');});
 });
}

try { require('electron').Menu.setApplicationMenu(null); } catch (_err) {}

// R356 verification probe only when launched by the installer; no background service.
if (process.env.CLINK_R356_SMOKE_MARKER) {
  const smokeFS = require('node:fs');
  app.on('browser-window-created', (_evt, win) => {
    const file = process.env.CLINK_R356_SMOKE_MARKER;
    let loaded = false, failed = false;
    const save = (event, extra={}) => {
      try { smokeFS.writeFileSync(file, JSON.stringify({event, loaded, failed, visible:win.isVisible(), pid:process.pid, time:new Date().toISOString(), ...extra})); }
      catch (_err) { /* optional diagnostic */ }
    };
    save('window-created');
    win.on('show', () => save('window-shown'));
    win.webContents.on('did-finish-load', () => { loaded=true; save('renderer-loaded'); });
    win.webContents.on('did-fail-load', (_e, code, description, url) => { failed=true; save('renderer-load-failed',{code,description,url}); });
    win.on('closed', () => save('window-closed'));
  });
}

if (process.platform === 'linux' && typeof app.setDesktopName === 'function') app.setDesktopName(LINUX_DESKTOP_NAME);
if (process.platform === 'linux') app.commandLine.appendSwitch('class',LINUX_DESKTOP_ID);
app.setPath('userData', PROFILE_ROOT);
if (process.platform === 'win32') app.setAppUserModelId('PhantomTronix.Quin');
fs.mkdirSync(LOG_DIR, { recursive: true });
const COMPANION_CONTEXT_FILE = path.join(__dirname, 'context', 'COMPANION-CONTEXT.json');
const CANONICAL_COMPANION_CONTEXT = Object.freeze(JSON.parse(fs.readFileSync(COMPANION_CONTEXT_FILE, 'utf8')));
const QUAL_PROOF_FILE = path.join(__dirname,'context','R27A2-MESSAGE-QUALIFICATION.json');
const COMPANION_STORE_SEED_FILE = path.join(__dirname,'context','COMPANION-STORE-SEED.json');
const COMPANION_STORE_SEED = Object.freeze(JSON.parse(fs.readFileSync(COMPANION_STORE_SEED_FILE,'utf8')));
const API_R4_FIELD_FILE = path.join(__dirname,'context','API-R4-FIELD-EVIDENCE.json');
const API_R4_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R4_FIELD_FILE,'utf8')));
const API_R5_FIELD_FILE = path.join(__dirname,'context','API-R5-FIELD-EVIDENCE.json');
const API_R5_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R5_FIELD_FILE,'utf8')));
const API_R6_FIELD_FILE = path.join(__dirname,'context','API-R6-FIELD-EVIDENCE.json');
const API_R6_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R6_FIELD_FILE,'utf8')));
const API_R7_FIELD_FILE = path.join(__dirname,'context','API-R7-FIELD-EVIDENCE.json');
const API_R7_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R7_FIELD_FILE,'utf8')));
const API_R8_FIELD_FILE = path.join(__dirname,'context','API-R8-FIELD-EVIDENCE.json');
const API_R8_FIELD = Object.freeze(JSON.parse(fs.readFileSync(API_R8_FIELD_FILE,'utf8')));
const HIVE_R7_RELEASE_FILE = path.join(__dirname,'context','HIVE-R7-RELEASE.json');
const HIVE_R7_RELEASE = Object.freeze(JSON.parse(fs.readFileSync(HIVE_R7_RELEASE_FILE,'utf8')));
const PROTECTED_QUALIFICATION = Object.freeze(JSON.parse(fs.readFileSync(QUAL_PROOF_FILE,'utf8')));
function restoredQualification(){
  const q=PROTECTED_QUALIFICATION;
  if(q.status!=='QUALIFIED'||q.samples!==9||q.passes!==9||q.failures!==0||q.knownSafeMaxChars!==131072||q.recommendedFutureChunkChars!==98304)throw new Error('R27A2_PROTECTED_QUALIFICATION_EVIDENCE_INVALID');
  return {...q,restoredByBuild:BUILD,restoredAt:new Date().toISOString(),detail:'R27A2 FIELD PROOF RESTORED: 9/9 text passes; known safe >= 131072 chars; operational chunk target 98304; attachments unqualified; MESSAGE BATCH rerun disabled.'};
}

function boot(text) { try { fs.appendFileSync(BOOT_LOG, `${new Date().toISOString()} | ${text}\n`); } catch (_) {} }
boot(`PROFILE_ROOT_SOURCE=${PROFILE_ROOT_OVERRIDE?'CLINK_FIELD_TEST_OVERRIDE':'CANONICAL_APPDATA'} fieldTestMode=${FIELD_TEST_MODE} pid=${process.pid}`);
function log(event, data = {}) {
  try {
    fs.appendFileSync(LOG_FILE, JSON.stringify({ts:new Date().toISOString(),build:BUILD,mission:MISSION,sessionId:TERMINAL_SESSION_ID,event,...data}) + '\n');
  } catch (_) {}
}
function tail(file, count = 120) { try { return fs.readFileSync(file,'utf8').split(/\r?\n/).filter(Boolean).slice(-count); } catch (_) { return []; } }

function ensureLinuxDesktopIdentity(){
  if(process.platform!=='linux')return null;
  try{
    const dataHome=String(process.env.XDG_DATA_HOME||path.join(os.homedir(),'.local','share'));
    const appDir=path.join(dataHome,'applications');
    const iconThemeRoot=path.join(dataHome,'icons','hicolor');
    const iconDir=path.join(iconThemeRoot,'512x512','apps');
    const desktopPath=path.join(appDir,LINUX_DESKTOP_NAME);
    const stableIconPath=path.join(iconDir,`${LINUX_DESKTOP_ID}.png`);

    fs.mkdirSync(appDir,{recursive:true});
    fs.mkdirSync(iconDir,{recursive:true});
    fs.mkdirSync(path.dirname(LINUX_DURABLE_LAUNCHER),{recursive:true});

    let changed=false;
    const sourceIcon=fs.readFileSync(APP_ICON);
    let targetIcon=null;
    try{targetIcon=fs.readFileSync(stableIconPath);}catch(_){}
    if(!targetIcon||!targetIcon.equals(sourceIcon)){
      fs.writeFileSync(stableIconPath,sourceIcon);
      changed=true;
    }

    const upsert=(text,key,value)=>{
      const line=`${key}=${value}`;
      const escaped=key.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      const rx=new RegExp(`^${escaped}=.*$`,'m');
      return rx.test(text)?text.replace(rx,line):`${text.replace(/\s*$/,'')}\n${line}\n`;
    };

    let desktop='';
    try{desktop=fs.readFileSync(desktopPath,'utf8');}catch(_){}
    if(!desktop.includes('[Desktop Entry]'))desktop='[Desktop Entry]\n';
    const before=desktop;

    desktop=upsert(desktop,'Type','Application');
    desktop=upsert(desktop,'Version','1.0');
    desktop=upsert(desktop,'Name','Phantom-Tronix Quinquedent Browser (Quin)');
    desktop=upsert(desktop,'GenericName','Quin Browser and Plugins');
    desktop=upsert(desktop,'Comment','Quin — browser built from the IRIS/C.Link foundation');
    desktop=upsert(desktop,'Exec',`"${LINUX_DURABLE_LAUNCHER}"`);
    desktop=upsert(desktop,'TryExec',LINUX_DURABLE_LAUNCHER);
    desktop=upsert(desktop,'Icon',LINUX_DESKTOP_ID);
    desktop=upsert(desktop,'StartupWMClass',LINUX_DESKTOP_ID);
    desktop=upsert(desktop,'Terminal','false');
    desktop=upsert(desktop,'NoDisplay','false');
    desktop=upsert(desktop,'StartupNotify','true');
    desktop=upsert(desktop,'DBusActivatable','false');
    desktop=upsert(desktop,'Categories','Development;Utility;');
    desktop=upsert(desktop,'Keywords','Quin;Quinquedent;Robot Rock;Phantom-Tronix;');

    if(desktop!==before){
      fs.writeFileSync(desktopPath,desktop);
      changed=true;
    }

    if(changed){
      try{cp.spawnSync('update-desktop-database',[appDir],{stdio:'ignore',timeout:3000});}catch(_){}
      try{cp.spawnSync('gtk-update-icon-cache',['-f','-t',iconThemeRoot],{stdio:'ignore',timeout:4000});}catch(_){}
    }

    const result={
      desktopId:LINUX_DESKTOP_ID,
      desktopName:LINUX_DESKTOP_NAME,
      desktopPath,
      durableLauncher:LINUX_DURABLE_LAUNCHER,
      durableAppDir:LINUX_DURABLE_APP_DIR,
      runtimeCache:LINUX_RUNTIME_CACHE,
      stableIconPath,
      sourceIconSha256:crypto.createHash('sha256').update(sourceIcon).digest('hex').toUpperCase(),
      searchable:true,
      changed
    };
    log('desktop.identity.ready',result);
    return result;
  }catch(error){
    log('desktop.identity.error',{error:String(error.message||error)});
    return null;
  }
}

function readProviderAuthState(){
  try{return JSON.parse(fs.readFileSync(PROVIDER_AUTH_STATE_FILE,'utf8'));}catch(_){return{};}
}
function writeProviderAuthState(patch={}){
  try{
    fs.mkdirSync(PROVIDER_AUTH_DIR,{recursive:true});
    const current=readProviderAuthState();
    const next={schema:'CLINK_PROVIDER_AUTH_STATE_V1',...current,...patch,updatedAt:new Date().toISOString()};
    const tmp=`${PROVIDER_AUTH_STATE_FILE}.tmp-${process.pid}`;
    fs.writeFileSync(tmp,JSON.stringify(next,null,2)+'\n');
    fs.renameSync(tmp,PROVIDER_AUTH_STATE_FILE);
    return next;
  }catch(error){
    log('provider.session.state-write.error',{error:String(error.message||error)});
    return null;
  }
}
async function flushProviderSession(reason='UNSPECIFIED'){
  if(!browserRuntime)return{ok:false,reason:'BROWSER_RUNTIME_NOT_READY'};
  const started=Date.now();
  try{
    const ses=browserRuntime.getSession();
    let cookieResult='PASS';
    try{
      await Promise.race([
        ses.cookies.flushStore(),
        new Promise((_,reject)=>setTimeout(()=>reject(new Error('COOKIE_FLUSH_TIMEOUT')),1800))
      ]);
    }catch(error){cookieResult=String(error.message||error);}
    try{ses.flushStorageData();}catch(error){
      log('provider.session.storage-flush.error',{reason,error:String(error.message||error)});
    }
    const state=writeProviderAuthState({
      canonicalSessionPath:browserRuntime.sessionPath,
      lastFlushAt:new Date().toISOString(),
      lastFlushReason:reason,
      lastFlushCookieResult:cookieResult
    });
    log('provider.session.flush',{
      reason,cookieResult,elapsedMs:Date.now()-started,
      sessionPath:browserRuntime.sessionPath,
      stateStatus:state?.status||'UNKNOWN'
    });
    return{ok:cookieResult==='PASS',cookieResult};
  }catch(error){
    log('provider.session.flush.error',{reason,error:String(error.message||error)});
    return{ok:false,error:String(error.message||error)};
  }
}

let windowMain = null;
let cartridgeVoiceHost=null;
let webPluginView=null;let webPluginId=null;let webPluginSession=null;let activeWebService=null;
let restrictedBrowserCartridge = null;
let companionChatGPTBridge = null;
let panels = null;
let browserRuntime = null;
let broadcastTimer = null;
let lifecycleSyncPromise = null;


const companionZipIntake = new CompanionZipIntake({profileRoot:PROFILE_ROOT});
const commandStationSeats = new CommandStationSeats({profileRoot:PROFILE_ROOT,intake:companionZipIntake});
const companionActivationRecovery = new CompanionActivationRecovery({activeFile:companionZipIntake.activeFile,logger:log});
// Reconcile any interrupted activation BEFORE binding initial Companion identity.
let activationColdRecovery={ok:true,action:'NONE'};
try{activationColdRecovery=companionActivationRecovery.recover();}
catch(error){
  activationColdRecovery={ok:false,error:String(error?.message||error)};
  log('companion.activation.startup_recovery_blocked',{error:activationColdRecovery.error});
}
// Recovery-only boot does not call the legacy manager, which could otherwise
// silently reseed an invalid CURRENT.json to a hardcoded historical Companion.
const companionPreflight = checkCompanionStartup({activeFile:companionZipIntake.activeFile});
let backpackManager=null;
let bootstrapBackpackState=null;
let companionStartupError=!activationColdRecovery.ok ? 'ACTIVATION_JOURNAL_RECOVERY_FAILED' :
  (!companionPreflight.ok ? companionPreflight.reason : null);
if(!companionStartupError){
  try{
    backpackManager = new BackpackManager({profileRoot:PROFILE_ROOT,appRoot:__dirname,logger:log});
    const backpackState = backpackManager.initialize();
    bootstrapBackpackState=backpackState;
    if(!backpackState?.systemControl)throw Error('SYSTEM_CONTROL_INITIAL_STATE_INCOMPLETE'); // Empty Companion is allowed.
  }catch(error){companionStartupError='BACKPACK_INITIALIZATION_FAILED';log('companion.recovery.bootstrap_blocked',{error:String(error?.message||error)});}
}
if(companionStartupError){
  log('companion.recovery.safe_shell_start',{reason:companionStartupError});
  createRecoveryShell({app,BrowserWindow,ipcMain,clipboard,profileRoot:PROFILE_ROOT,reason:companionStartupError,logger:log});
}else{
const companionOrchestrator = new CompanionOrchestrator({profileRoot:PROFILE_ROOT,logger:log});
companionOrchestrator.initialize(bootstrapBackpackState);
const providerSecrets = new ProviderSecretStore({profileRoot:PROFILE_ROOT,safeStorage,logger:log});
// R378 opt-in one-time native credential decryptability check. No value, length,
// ciphertext or full exception is logged. No API calls are performed.
if(process.env.CLINK_R378_PROBE_ON_START==='1'){
  const report={};
  for(const p of ['openai','xai']){
    try{
      const current=providerSecrets.status(p);
      if(!current.configured){report[p]='NOT_CONFIGURED';}
      else if(!providerSecrets.secureStorageAvailable()){report[p]='SECURE_STORAGE_UNAVAILABLE';}
      else{
        const ephemeral=providerSecrets.getForMainProcess(p);
        report[p]=ephemeral?'DECRYPT_OK':'EMPTY_AFTER_DECRYPT';
      }
    }catch(error){
      const label=String(error?.message||'');
      report[p]=label==='SECURE_STORAGE_DECRYPT_FAILED'?'SECURE_STORAGE_DECRYPT_FAILED':label==='SECURE_STORAGE_UNAVAILABLE'?'SECURE_STORAGE_UNAVAILABLE':'OTHER_STORE_ERROR';
    }
  }
  process.stdout.write('CLINK_R378_CREDENTIAL_PROBE='+JSON.stringify(report)+'\n');
}

const apiUsage = new ApiUsageLedger({profileRoot:PROFILE_ROOT,logger:log});
function dh017Modules(){
const factories={"./development_live_gate_011.cjs":function(module,exports,require){
'use strict';
// DH011: one provider decision reservation per explicitly approved experiment.
// Not a billing cap. The native transport must independently enforce its
// verified token/request bounds and no retries before this can be enabled.
const fs = require('node:fs');
const path = require('node:path');
function createOneShotGate({stateDir, approval, now=Date.now}) {
  if (!path.isAbsolute(stateDir)) throw Error('DH_STATE_PATH');
  if (!approval || approval.workflow !== 'development.smoke.v1' ||
      approval.maxDecisions !== 1 || !Number.isSafeInteger(approval.expiresAt) ||
      approval.transportBoundsVerified !== true ||
      approval.humanAuthorized !== true) throw Error('DH_NOT_AUTHORIZED');
  const st=fs.lstatSync(stateDir);
  if (!st.isDirectory() || st.isSymbolicLink() || (st.mode & 0o077) ||
      st.uid!==process.getuid()) throw Error('DH_STATE_PERMISSIONS');
  const file=path.join(stateDir,'live-decision-reserved.json');
  async function decideOnce(decide,prompt) {
    if(now() >= approval.expiresAt) throw Error('DH_APPROVAL_EXPIRED');
    let fd;
    try { fd=fs.openSync(file,'wx',0o600); }
    catch(e) { if(e.code==='EEXIST') throw Error('DH_DECISION_ALREADY_RESERVED'); throw e; }
    try {
      fs.writeFileSync(fd,JSON.stringify({workflow:approval.workflow,reservedAt:now(),maxDecisions:1}));
      fs.fsyncSync(fd);
    } finally {fs.closeSync(fd);}
    const dir=fs.openSync(stateDir,'r');
    try {fs.fsyncSync(dir);} finally {fs.closeSync(dir);}
    // A rejected/unknown call consumes the reservation. No retry.
    return await decide(prompt);
  }
  return Object.freeze({decideOnce});
}
module.exports={createOneShotGate};
if(require.main===module){
  const assert=require('node:assert/strict'),os=require('node:os');
  const base=fs.mkdtempSync(path.join(os.tmpdir(),'dh011-'));
  const a={workflow:'development.smoke.v1',maxDecisions:1,expiresAt:100,
    transportBoundsVerified:true,humanAuthorized:true};
  (async()=>{
    let n=0;
    try {
      assert.throws(()=>createOneShotGate({stateDir:base,approval:{...a,humanAuthorized:false}}),/NOT_AUTHORIZED/);
      assert.throws(()=>createOneShotGate({stateDir:base,approval:{...a,transportBoundsVerified:false}}),/NOT_AUTHORIZED/);
      const expired=createOneShotGate({stateDir:base,approval:a,now:()=>100});
      await assert.rejects(expired.decideOnce(()=>{n++;},'x'),/EXPIRED/);
      const gate=createOneShotGate({stateDir:base,approval:a,now:()=>1});
      const call=async()=>{n++;throw Error('unknown transport outcome');};
      await assert.rejects(gate.decideOnce(call,'x'),/unknown transport/);
      const reopened=createOneShotGate({stateDir:base,approval:a,now:()=>2});
      await assert.rejects(reopened.decideOnce(call,'x'),/ALREADY_RESERVED/);
      assert.equal(n,1);
      console.log('DH011 gate: 5 checks passed; zero provider calls');
    }finally{fs.rmSync(base,{recursive:true,force:true});}
  })().catch(e=>{console.error(e);process.exitCode=1;});
}

},
"./development_bounded_transport_012.cjs":function(module,exports,require){
'use strict';
// DH012: use existing native provider transport only within the accepted tool decision.
// No key handling, provider replacement, retry, or billing guarantee.
const {AsyncLocalStorage}=require('node:async_hooks');
const {createOneShotGate}=require('./development_live_gate_011.cjs');
const MAX_BYTES=65536, MAX_OUTPUT=256;
function createAcceptance({stateDir,approval,transport,now=Date.now}){
  const scope=new AsyncLocalStorage();
  const gate=createOneShotGate({stateDir,approval,now});
  let busy=false;
  async function decide(decideNative,prompt){
    if(busy)throw Error('DH_BUSY');
    busy=true;
    const context={active:true,used:false};
    try{return await scope.run(context,()=>decideNative(prompt));}
    finally{context.active=false;busy=false;}
  }
  async function boundedTransport(req){
    const ctx=scope.getStore(),p=req?.payload;
    if(!ctx?.active||ctx.used)throw Error('DH_TRANSPORT_SCOPE');
    if(req.provider!=='openai'||p?.model!=='gpt-5.6-luna'||
       typeof p.input!=='string'||typeof p.instructions!=='string'||
       !Number.isInteger(p.max_output_tokens)||p.max_output_tokens<16||
       p.max_output_tokens>MAX_OUTPUT||p.store!==false||
       Object.keys(p).some(k=>!['model','input','instructions','max_output_tokens','store'].includes(k))||
       Buffer.byteLength(JSON.stringify(p),'utf8')>MAX_BYTES)throw Error('DH_TRANSPORT_BOUNDS');
    ctx.used=true;
    return gate.decideOnce(()=>transport(req),'');
  }
  return Object.freeze({decide,transport:boundedTransport});
}
module.exports={createAcceptance,MAX_BYTES,MAX_OUTPUT};
if(require.main===module){
  const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
  const stateDir=fs.mkdtempSync(path.join(os.tmpdir(),'dh012-'));
  const approval={workflow:'development.smoke.v1',maxDecisions:1,expiresAt:100,transportBoundsVerified:true,humanAuthorized:true};
  let calls=0;
  const options={stateDir,approval,now:()=>1,transport:async()=>{calls++;return {statusCode:200};}};
  const a=createAcceptance(options);
  const req={provider:'openai',payload:{model:'gpt-5.6-luna',input:'x',instructions:'y',max_output_tokens:256,store:false}};
  (async()=>{
    try{
      await assert.rejects(a.transport(req),/SCOPE/);
      for(const bad of [{...req,provider:'xai'}, {...req,payload:{...req.payload,max_output_tokens:257}}, {...req,payload:{...req.payload,input:'x'.repeat(65537)}}, {...req,payload:{...req.payload,previous_response_id:'x'}}, {...req,payload:{...req.payload,model:'other'}}]){
        await assert.rejects(a.decide(()=>a.transport(bad),'test'),/BOUNDS/);
      }
      assert.equal(calls,0);
      await a.decide(async()=>{assert.equal((await a.transport(req)).statusCode,200);await assert.rejects(a.transport(req),/SCOPE/);},'test');
      const b=createAcceptance(options);
      await assert.rejects(b.decide(()=>b.transport(req),'test'),/ALREADY_RESERVED/);
      assert.equal(calls,1);
      console.log('DH012: bounded transport fixture PASS; no real provider calls');
    }finally{fs.rmSync(stateDir,{recursive:true,force:true});}
  })().catch(e=>{console.error(e);process.exitCode=1;});
}

},
"./development_tool.cjs":function(module,exports,require){
'use strict';
// Host-owned, explicitly enabled registered workflow. No renderer paths, commands or budgets.
const {spawn}=require('node:child_process');
const path=require('node:path');
const WORKFLOW='development.smoke.v1';
const REQUEST='{"tool":"development.smoke.v1"}';
function eligible(text){
  return typeof text==='string' && text.length<=300 &&
    /^(?:please,?\s+)?(?:miss flower,?\s+)?(?:please,?\s+)?(?:create|build|write|make)\s+(?:and test\s+)?(?:a\s+)?(?:small\s+|simple\s+)?python calculator(?:\s+and test it)?[.!]?$/i.test(text.trim()) && /\btest\b/i.test(text);
}
function createDevelopmentTool({run}){
  if(typeof run!=='function')throw Error('DEVELOPMENT_RUNNER_REQUIRED');
  let busy=false;
  async function handle({text,decide,authorize}){
    if(!eligible(text))return null;
    if(busy)throw Error('DEVELOPMENT_BUSY');
    busy=true;
    try{
      authorize();
      const decision=await decide('The human requested this exact fixed offline assignment: '+text+'\nIf you choose to invoke the registered tool, reply ONLY with '+REQUEST+'. Otherwise decline. Do not invent execution evidence.');
      authorize();
      if(decision?.complete!==true||decision.text!==REQUEST)return {text:'C.Link: No development tool was invoked. No execution receipt exists.'};
      const result=await run();
      authorize();
      if(result?.status!=='PASS'||!/^[a-f0-9]{64}$/.test(result.artifact_sha256||'')||result.provider_calls!==0)
        return {text:'C.Link: Development execution did not pass. Inspect the machine receipt.'};
      return {text:'C.Link verified development receipt: '+WORKFLOW+'\nTwo checks passed. Artifact SHA-256: '+result.artifact_sha256+'\nExecution provider calls: 0.',receipt:result};
    }finally{busy=false;}
  }
  return Object.freeze({handle});
}
// Reuse accepted guest runner. Only trusted native code supplies an absolute bundle path.
function createVmRunner(bundle,progress=()=>{}){
  const script=path.join(path.resolve(bundle),'development_guest_008.py');
  let child=null;
  function signal(p,sig){try{process.kill(-p.pid,sig);}catch(e){if(e.code!=='ESRCH')throw e;}}
  function cancel(){if(!child)return false;signal(child,'SIGINT');return true;}
  function run(){
    if(child)throw Error('DEVELOPMENT_RUNNER_BUSY');
    return new Promise((resolve,reject)=>{
      const p=spawn('/usr/bin/python3',['-B',script],{cwd:path.dirname(script),env:{PATH:'/usr/bin:/bin',HOME:require('node:os').homedir(),LANG:'C.UTF-8'},stdio:['ignore','pipe','pipe'],shell:false,detached:true});
      child=p;let output='',err='',over=false;
      const timer=setTimeout(()=>{over=true;signal(p,'SIGINT');},620000);
      const force=setTimeout(()=>{if(child===p)signal(p,'SIGKILL');},640000);
      p.stdout.on('data',b=>{if(over)return;output+=b.toString();if(output.length>65536){over=true;signal(p,'SIGINT');}else progress(b.toString());});
      p.stderr.on('data',b=>{err=(err+b.toString()).slice(-4096);});
      p.on('error',e=>{clearTimeout(timer);clearTimeout(force);child=null;const code=/^[A-Z0-9_]{1,20}$/.test(String(e.code||''))?e.code:'UNKNOWN';reject(Error('DEVELOPMENT_START_FAILED_'+code));});
      p.on('close',(code,sig)=>{clearTimeout(timer);clearTimeout(force);child=null;try{
        if(over)throw Error('DEVELOPMENT_PROCESS_LIMIT');if(code!==0)throw Error('DEVELOPMENT_PROCESS_FAILED_'+(Number.isInteger(code)?String(Math.abs(code)):String(sig||'UNKNOWN').replace(/[^A-Z0-9_]/g,'')));
        const lines=output.split(/\r?\n/).filter(l=>l.startsWith('CLINK_HOST_RECEIPT='));
        if(lines.length!==1)throw Error('DEVELOPMENT_RECEIPT_MISSING');
        resolve(JSON.parse(lines[0].slice('CLINK_HOST_RECEIPT='.length)));
      }catch(e){reject(e);}});
    });
  }
  return Object.freeze({run,cancel});
}
module.exports={createDevelopmentTool,createVmRunner,eligible,WORKFLOW};

},
"./development_installed_integration_017.cjs":function(module,exports,require){
'use strict';
// Real installed terminal; no replacement profile, key handling or separate provider.
const fs=require('node:fs'),path=require('node:path');
const {AsyncLocalStorage}=require('node:async_hooks');
const {createResponsesTransport}=require('./provider-transport');
const {createAcceptance}=require('./development_bounded_transport_012.cjs');
const {createDevelopmentTool,createVmRunner,eligible}=require('./development_tool.cjs');
function createInstalledIntegration({stateDir,bundle,approve,transport=createResponsesTransport(),progress=()=>{},publish=()=>{},runnerFactory=createVmRunner}){
  const routing=new AsyncLocalStorage();
  let active=null;
  function providerTransport(req){
    const route=routing.getStore();
    return route?route.gate.transport(req):transport(req);
  }
  function persist(name,value){
    const p=path.join(stateDir,name),fd=fs.openSync(p,'wx',0o600);
    try{fs.writeFileSync(fd,JSON.stringify(value)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
    const dir=fs.openSync(stateDir,'r');try{fs.fsyncSync(dir);}finally{fs.closeSync(dir);}
  }
  const developmentTool=Object.freeze({handle:async request=>{
    if(!eligible(request.text))return null;
    if(request.provider!=='openai')return {text:'C.Link: Select OpenAI for this acceptance assignment. No provider request occurred.'};
    if(active)return {text:'C.Link: A development acceptance is already active.'};
    if(fs.existsSync(stateDir))return {text:'C.Link: This one-use acceptance has already been reserved. No new provider request occurred.'};
    const job={cancelled:false,handle:null,vm:null,owned:false};
    active=job;
    function check(){if(job.cancelled)throw Error('DEVELOPMENT_CANCELLED');request.authorize();}
    try{
      check();
      if(!await approve())return {text:'C.Link: Development acceptance declined. No provider request occurred.'};
      check();
      // Fixed path, exclusive creation; no rearming on crash or unknown dispatch.
      fs.mkdirSync(stateDir,{mode:0o700});job.owned=true;
      progress('Development authorization accepted. Ctrl+Shift+X cancels.');
      const a={workflow:'development.smoke.v1',maxDecisions:1,expiresAt:Date.now()+600000,transportBoundsVerified:true,humanAuthorized:true};
      persist('approval.json',{...a,provider:'openai',estimatedUsd:0.02});
      const gate=createAcceptance({stateDir,approval:a,transport:async req=>{
        check();
        persist('dispatch.json',{provider:req.provider,model:req.payload.model,bytes:Buffer.byteLength(JSON.stringify(req.payload)),maxOutputTokens:req.payload.max_output_tokens});
        try{
          const result=await transport({...req,onHandle:h=>{job.handle=h;req.onHandle?.(h);if(job.cancelled)h?.cancel();}});
          const u=result.body?.usage||{};
          persist('provider-result.json',{statusCode:result.statusCode,inputTokens:Number(u.input_tokens)||0,outputTokens:Number(u.output_tokens)||0});
          return result;
        }finally{job.handle=null;}
      }});
      job.vm=runnerFactory(bundle,progress);
      const tool=createDevelopmentTool({run:async()=>{
        check();
        const result=await job.vm.run();
        persist('machine-result.json',{status:result.status,artifact_sha256:result.artifact_sha256,provider_calls:result.provider_calls,receipt_path:result.receipt_path});
        return result;
      }});
      const result=await tool.handle({...request,authorize:check,decide:prompt=>routing.run({gate},()=>gate.decide(async p=>{
        check();
        const d=await request.decide(p);
        persist('decision.json',{complete:d?.complete===true,invoked:d?.text==='{"tool":"development.smoke.v1"}'});
        return d;
      },prompt))});
      persist('tool-result.json',{receiptReturned:!!result?.receipt,artifact_sha256:result?.receipt?.artifact_sha256||null});
      return result;
    }catch(e){
      if(job.owned){try{persist('failure.json',{code:job.cancelled?'DEVELOPMENT_CANCELLED':'DEVELOPMENT_FAILED'});}catch(_){}}
      return {text:job.cancelled?'C.Link: Development cancelled. No success is claimed.':'C.Link: Development acceptance failed. Inspect the local machine receipt. No automatic retry.'};
    }finally{
      if(job.owned){try{await publish(stateDir);}catch(_){progress('Development receipt export failed; local evidence preserved.');}}
      active=null;progress('Development acceptance finished.');
    }
  }});
  function cancel(){
    if(!active)return false;
    active.cancelled=true;
    try{active.handle?.cancel();}catch(_){}
    try{active.vm?.cancel();}catch(_){}
    return true;
  }
  return Object.freeze({developmentTool,transport:providerTransport,cancel});
}
module.exports={createInstalledIntegration};

}};
const cache={};
function load(id){
 if(id==='./provider-transport')return require('./core/provider-transport');
 if(!Object.prototype.hasOwnProperty.call(factories,id)){
   if(!['node:fs','node:path','node:os','node:child_process','node:async_hooks'].includes(id))throw Error('DH017_MODULE_DENIED');
   return require(id);
 }
 if(cache[id])return cache[id].exports;
 const m={exports:{}};cache[id]=m;
 const r=name=>load(name);r.main=null;
 factories[id](m,m.exports,r);
 return m.exports;
}
return {integration:load('./development_installed_integration_017.cjs'),tool:load('./development_tool.cjs')};
}

const dh017=dh017Modules();
const dh017State=path.join(PROFILE_ROOT,'development-acceptance-0.4.22');
const dh017Runner=path.join(dh017State,'runner');
const dh017OriginalTitle='Phantom-Tronix Quinquedent Browser';
const dh017Embedded={"development_guest_008.py": "IiIiREgwMDg6IGhvc3Qtb3duZWQgb2ZmbGluZSBWTSBleGVjdXRpb24gb2YgdGhlIGV4aXN0aW5nIGRldGVybWluaXN0aWMgdGFzayBlbmdpbmUuIiIiCmltcG9ydCBiYXNlNjQKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAppbXBvcnQgc2h1dGlsCmltcG9ydCBzdWJwcm9jZXNzCmltcG9ydCBzeXMKaW1wb3J0IHRlbXBmaWxlCmltcG9ydCB0aW1lCmltcG9ydCB6aXBmaWxlCmZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGV0aW1lLCB0aW1lem9uZQpmcm9tIHNlZWQgaW1wb3J0IHNlZWRfaXNvCmZyb20gZGV2ZWxvcG1lbnRfc21va2UgaW1wb3J0IFNPVVJDRSwgVEVTVCwgU1BFQywgV09SS0ZMT1cKCkJBU0VfU0hBID0gIjA0ZThmMjQ2MWExNmE0NGU3OGEzNzAyODQ0NzFmMjk2MTZjZGQ5YmFmMTg5M2RmMjU4MDdiNzFmOTg1YjZjOTQiClBSRUZJWCA9ICJDTElOS19ESDAwNj0iCkdVRVNUID0gcicnJwppbXBvcnQgaGFzaGxpYiwganNvbiwgb3MsIHN1YnByb2Nlc3MsIHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKZnJvbSBkZXZlbG9wbWVudF9zbW9rZSBpbXBvcnQgcnVuX2pvdXJuYWxlZApyb290PVBhdGgoIi9ob21lL3VidW50dS9jbGluay1zbW9rZSIpCnJvb3QubWtkaXIobW9kZT0wbzcwMCwgZXhpc3Rfb2s9VHJ1ZSkKaWYgc3lzLmFyZ3ZbMV0gIT0gImNvbGxlY3QiOgogICAgcHJpbnQoanNvbi5kdW1wcyhydW5fam91cm5hbGVkKHJvb3Qsc3lzLmFyZ3ZbMV0pKSkKZWxzZToKICAgIGFzc2VydCBzb3J0ZWQocC5uYW1lIGZvciBwIGluIFBhdGgoIi9zeXMvY2xhc3MvbmV0IikuaXRlcmRpcigpKSA9PSBbImxvIl0KICAgIGFzc2VydCBvcy5nZXRldWlkKCkgIT0gMAogICAgcm93cz1bXQogICAgZm9yIHRhc2sgaW4gKCJzbW9rZS1vcmlnaW5hbCIsInNtb2tlLW9yaWdpbmFsIiwic21va2UtcmVwbGF5Iik6CiAgICAgICAgcD1zdWJwcm9jZXNzLnJ1bihbc3lzLmV4ZWN1dGFibGUsX19maWxlX18sdGFza10sY2FwdHVyZV9vdXRwdXQ9VHJ1ZSx0ZXh0PVRydWUsY2hlY2s9VHJ1ZSx0aW1lb3V0PTI1KQogICAgICAgIHJvd3MuYXBwZW5kKGpzb24ubG9hZHMocC5zdGRvdXQpKQogICAgYSxiLGM9cm93cwogICAgYXNzZXJ0IGE9PWIgYW5kIGFbInN0YXRlIl09PWNbInN0YXRlIl09PSJzdWNjZWVkZWQiCiAgICBhc3NlcnQgYVsicmVjZWlwdCJdWyJhcnRpZmFjdF9yZWYiXT09Y1sicmVjZWlwdCJdWyJhcnRpZmFjdF9yZWYiXQogICAgYXNzZXJ0IGFbInJlY2VpcHQiXVsicHJvdmlkZXJfY2FsbHMiXT09Y1sicmVjZWlwdCJdWyJwcm92aWRlcl9jYWxscyJdPT0wCiAgICBzaGE9YVsicmVjZWlwdCJdWyJhcnRpZmFjdF9yZWYiXS5zcGxpdCgiOiIpWzFdCiAgICBkYXRhPShyb290LyhzaGErIi5qc29uIikpLnJlYWRfYnl0ZXMoKQogICAgYXNzZXJ0IGhhc2hsaWIuc2hhMjU2KGRhdGEpLmhleGRpZ2VzdCgpPT1zaGEKICAgIHByaW50KCJDTElOS19ESDAwNj0iK2pzb24uZHVtcHMoeyJpbnRlcmZhY2VzIjpbImxvIl0sInVpZCI6b3MuZ2V0ZXVpZCgpLCJvcmlnaW5hbCI6YSwicmVvcGVuZWQiOmIsInJlcGxheSI6YywiYXJ0aWZhY3QiOmRhdGEuZGVjb2RlKCl9LHNlcGFyYXRvcnM9KCIsIiwiOiIpKSxmbHVzaD1UcnVlKQonJycKIyBGaXhlZCBwcml2aWxlZ2VkIHByb3Zpc2lvbmluZyBvbmx5LiBXb3JrZmxvdyBydW5zIHVuZGVyIHRoZSBndWVzdCdzIHVidW50dSB1c2VyLgpXUkFQUEVSID0gcicnJwppbXBvcnQgc3VicHJvY2VzcyxzeXMKd2l0aCBvcGVuKCIvZGV2L3R0eVMwIiwidyIpIGFzIGY6CiAgICBwPXN1YnByb2Nlc3MucnVuKFsicnVudXNlciIsIi11IiwidWJ1bnR1IiwiLS0iLCJweXRob24zIiwiL29wdC9jbGluay1zbW9rZS9ndWVzdC5weSIsImNvbGxlY3QiXSxjYXB0dXJlX291dHB1dD1UcnVlLHRleHQ9VHJ1ZSx0aW1lb3V0PTEwMCkKICAgIGYud3JpdGUoIlxuIitwLnN0ZG91dCsiXG4iKQogICAgaWYgcC5yZXR1cm5jb2RlOgogICAgICAgIGYud3JpdGUoIkNMSU5LX0RIMDA2X0VSUk9SPSIrcmVwcihwLnN0ZGVyclstMjAwMDpdKSsiXG4iKQogICAgZi5mbHVzaCgpCiAgICBzeXMuZXhpdChwLnJldHVybmNvZGUpCicnJwoKZGVmIHNoYShwKToKICAgIHdpdGggcC5vcGVuKCJyYiIpIGFzIGY6CiAgICAgICAgcmV0dXJuIGhhc2hsaWIuZmlsZV9kaWdlc3QoZiwic2hhMjU2IikuaGV4ZGlnZXN0KCkKCmRlZiB2ZXJpZnkocHJvb2YpOgogICAgaWYgcHJvb2ZbImludGVyZmFjZXMiXSAhPSBbImxvIl0gb3IgdHlwZShwcm9vZlsidWlkIl0pIGlzIG5vdCBpbnQgb3IgcHJvb2ZbInVpZCJdIDw9IDA6CiAgICAgICAgcmFpc2UgVmFsdWVFcnJvcigiZ3Vlc3QgaXNvbGF0aW9uL3VzZXIgZXZpZGVuY2UgaW52YWxpZCIpCiAgICBhLGIsYz0ocHJvb2Zba10gZm9yIGsgaW4gKCJvcmlnaW5hbCIsInJlb3BlbmVkIiwicmVwbGF5IikpCiAgICBpZiBhIT1iOgogICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoImpvdXJuYWwgcmVvcGVuIG1pc21hdGNoIikKICAgIGFydGlmYWN0PXByb29mWyJhcnRpZmFjdCJdLmVuY29kZSgpCiAgICBleHBlY3RlZD1qc29uLmR1bXBzKHsiY2FsY3VsYXRvci5weSI6U09VUkNFLmRlY29kZSgpLCJjaGVjay5weSI6VEVTVC5kZWNvZGUoKSwKICAgICAgICAgICAgICAgICAgICAgICAgICJzdGRvdXQiOiIyIGNoZWNrcyBwYXNzZWRcbiJ9LHNvcnRfa2V5cz1UcnVlLHNlcGFyYXRvcnM9KCIsIiwiOiIpKS5lbmNvZGUoKQogICAgaWYgYXJ0aWZhY3QhPWV4cGVjdGVkOgogICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoInVuZXhwZWN0ZWQgYXJ0aWZhY3QgY29udGVudCIpCiAgICByZWY9InNoYTI1NjoiK2hhc2hsaWIuc2hhMjU2KGFydGlmYWN0KS5oZXhkaWdlc3QoKQogICAgZm9yIHJvdyx0aWQgaW4gKChhLCJzbW9rZS1vcmlnaW5hbCIpLChjLCJzbW9rZS1yZXBsYXkiKSk6CiAgICAgICAgcj1yb3dbInJlY2VpcHQiXQogICAgICAgIGlmIChyb3dbImlkIl0hPXRpZCBvciByb3dbInN0YXRlIl0hPSJzdWNjZWVkZWQiIG9yIHJvd1siYXR0ZW1wdHMiXSE9MSBvcgogICAgICAgICAgICByb3dbInNwZWMiXSE9U1BFQyBvciByWyJ3b3JrZmxvdyJdIT1XT1JLRkxPVyBvciByWyJleGl0X2NvZGUiXSE9MCBvcgogICAgICAgICAgICByWyJ0ZXN0X3Jlc3VsdCJdIT0iMiBjaGVja3MgcGFzc2VkIiBvciByWyJwcm92aWRlcl9jYWxscyJdIT0wIG9yIHJbImFydGlmYWN0X3JlZiJdIT1yZWYpOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCJ1bmV4cGVjdGVkIHRhc2sgcmVjZWlwdCIpCiAgICByZXR1cm4gYXJ0aWZhY3QKCmRlZiBjbG91ZF9jb25maWcoc291cmNlX2Rpcik6CiAgICBmaWxlcz17bjooc291cmNlX2Rpci9uKS5yZWFkX2J5dGVzKCkgZm9yIG4gaW4gKCJ0YXNrX2VuZ2luZS5weSIsImRldmVsb3BtZW50X3Ntb2tlLnB5Iil9CiAgICBmaWxlcy51cGRhdGUoeyJndWVzdC5weSI6R1VFU1QuZW5jb2RlKCksIndyYXBwZXIucHkiOldSQVBQRVIuZW5jb2RlKCl9KQogICAgbGluZXM9WyIjY2xvdWQtY29uZmlnIiwic3NoX3B3YXV0aDogZmFsc2UiLCJwYWNrYWdlX3VwZGF0ZTogZmFsc2UiLCJwYWNrYWdlX3VwZ3JhZGU6IGZhbHNlIiwid3JpdGVfZmlsZXM6Il0KICAgIGZvciBuYW1lLGRhdGEgaW4gZmlsZXMuaXRlbXMoKToKICAgICAgICBsaW5lcy5leHRlbmQoWyIgIC0gcGF0aDogL29wdC9jbGluay1zbW9rZS8iK25hbWUsIiAgICBwZXJtaXNzaW9uczogJzA2NDQnIiwKICAgICAgICAgICAgICAgICAgICAgICIgICAgZW5jb2Rpbmc6IGI2NCIsIiAgICBjb250ZW50OiAiK2Jhc2U2NC5iNjRlbmNvZGUoZGF0YSkuZGVjb2RlKCldKQogICAgbGluZXMuZXh0ZW5kKFsicnVuY21kOiIsIiAgLSBbcHl0aG9uMywgL29wdC9jbGluay1zbW9rZS93cmFwcGVyLnB5XSIsCiAgICAgICAgICAgICAgICAgICJwb3dlcl9zdGF0ZToiLCIgIG1vZGU6IHBvd2Vyb2ZmIiwiICB0aW1lb3V0OiA2MCIsIiAgY29uZGl0aW9uOiB0cnVlIl0pCiAgICByZXR1cm4gKCJcbiIuam9pbihsaW5lcykrIlxuIikuZW5jb2RlKCkKCmRlZiBtYWluKCk6CiAgICBvcy51bWFzaygwbzA3NykKICAgIHN0YW1wPWRhdGV0aW1lLm5vdyh0aW1lem9uZS51dGMpLnN0cmZ0aW1lKCIlWSVtJWRUJUglTSVTJWZaIikKICAgIHJvb3Q9UGF0aC5ob21lKCkvIi5sb2NhbC9zaGFyZS9waGFudG9tdHJvbml4LWRldmVsb3BtZW50LWhvc3QiCiAgICBkb3dubG9hZHM9cm9vdC8icmVjZWlwdHMiCiAgICBkb3dubG9hZHMubWtkaXIobW9kZT0wbzcwMCxwYXJlbnRzPVRydWUsZXhpc3Rfb2s9VHJ1ZSkKICAgIHJlY2VpcHQ9eyJyb3VuZCI6IjAwOCIsInN0YXR1cyI6IkJMT0NLRUQiLCJ0aW1lc3RhbXAiOnN0YW1wLCJwcm92aWRlcl9jYWxscyI6MCwicHJvZHVjdGlvbl9tb2RpZmllZCI6RmFsc2V9CiAgICBmaWxlcz17fQogICAgc2VyaWFsPU5vbmUKICAgIHRyeToKICAgICAgICBiYXNlPXJvb3QvInVidW50dS0yNC4wNC1zZXJ2ZXItY2xvdWRpbWctYW1kNjQuaW1nIgogICAgICAgIHByaW50KCJWZXJpZnlpbmcgY2FjaGVkIFVidW50dSBpbWFnZSAobm8gZG93bmxvYWQpLi4uIixmbHVzaD1UcnVlKQogICAgICAgIGlmIG5vdCBiYXNlLmlzX2ZpbGUoKSBvciBzaGEoYmFzZSkhPUJBU0VfU0hBOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoImFjY2VwdGVkIGJhc2UgaW1hZ2UgdW5hdmFpbGFibGUgb3IgY2hlY2tzdW0gbWlzbWF0Y2giKQogICAgICAgIHJlY2VpcHRbImltYWdlX3NoYTI1NiJdPUJBU0VfU0hBCiAgICAgICAgaWYgc2h1dGlsLmRpc2tfdXNhZ2Uocm9vdCkuZnJlZSA8IDIqMTAyNCoqMzoKICAgICAgICAgICAgcmFpc2UgUnVudGltZUVycm9yKCJpbnN1ZmZpY2llbnQgZnJlZSBkaXNrIHNwYWNlIikKICAgICAgICB3b3JrPVBhdGgodGVtcGZpbGUubWtkdGVtcChwcmVmaXg9ImpvYi0wMDgtIixkaXI9cm9vdCkpCiAgICAgICAgZGlzaz13b3JrLyJkZXZlbG9wbWVudC5xY293MiIKICAgICAgICBzdWJwcm9jZXNzLnJ1bihbInFlbXUtaW1nIiwiY3JlYXRlIiwiLWYiLCJxY293MiIsIi1GIiwicWNvdzIiLCItYiIsc3RyKGJhc2UpLHN0cihkaXNrKSwiOEciXSxjaGVjaz1UcnVlLHRpbWVvdXQ9NjApCiAgICAgICAgc2VlZD13b3JrLyJzZWVkLmlzbyIKICAgICAgICBzZWVkLndyaXRlX2J5dGVzKHNlZWRfaXNvKGNsb3VkX2NvbmZpZyhQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50KSwKICAgICAgICAgICAgKCJpbnN0YW5jZS1pZDogZGgwMDYtIitzdGFtcCsiXG5sb2NhbC1ob3N0bmFtZTogcGhhbnRvbXRyb25peC1kZXZcbiIpLmVuY29kZSgpKSkKICAgICAgICByZWNlaXB0WyJzZWVkX3NoYTI1NiJdPXNoYShzZWVkKQogICAgICAgIHNlcmlhbD13b3JrLyJzZXJpYWwubG9nIgogICAgICAgIGFyZ3Y9WyJxZW11LXN5c3RlbS14ODZfNjQiLCItbWFjaGluZSIsInEzNSxhY2NlbD1rdm0iLCItY3B1IiwiaG9zdCIsIi1zbXAiLCIyIiwiLW0iLCIyMDQ4IiwKICAgICAgICAgICAgICAiLW5vZGVmYXVsdHMiLCItbm8tdXNlci1jb25maWciLCItbmljIiwibm9uZSIsIi1kaXNwbGF5Iiwibm9uZSIsIi1tb25pdG9yIiwibm9uZSIsCiAgICAgICAgICAgICAgIi1zZXJpYWwiLCJmaWxlOiIrc3RyKHNlcmlhbCksIi1uby1yZWJvb3QiLCItZHJpdmUiLCJmaWxlPSIrc3RyKGRpc2spKyIsaWY9dmlydGlvLGZvcm1hdD1xY293MiIsCiAgICAgICAgICAgICAgIi1kcml2ZSIsImZpbGU9IitzdHIoc2VlZCkrIixpZj12aXJ0aW8sZm9ybWF0PXJhdyxyZWFkb25seT1vbiJdCiAgICAgICAgcHJpbnQoIlN0YXJ0aW5nIGlzb2xhdGVkIGd1ZXN0OyBDdHJsK0MgY2FuY2VscyB0aGlzIGpvYi4iLGZsdXNoPVRydWUpCiAgICAgICAgd2l0aCAod29yay8icWVtdS5zdGRlcnIiKS5vcGVuKCJ3YiIpIGFzIGVycjoKICAgICAgICAgICAgcD1zdWJwcm9jZXNzLlBvcGVuKGFyZ3Ysc3Rkb3V0PXN1YnByb2Nlc3MuREVWTlVMTCxzdGRlcnI9ZXJyKQogICAgICAgICAgICBzdGFydGVkPXRpbWUubW9ub3RvbmljKCkKICAgICAgICAgICAgdHJ5OgogICAgICAgICAgICAgICAgd2hpbGUgcC5wb2xsKCkgaXMgTm9uZToKICAgICAgICAgICAgICAgICAgICBlbGFwc2VkPWludCh0aW1lLm1vbm90b25pYygpLXN0YXJ0ZWQpCiAgICAgICAgICAgICAgICAgICAgaWYgZWxhcHNlZD49NjAwOiByYWlzZSBUaW1lb3V0RXJyb3IoImd1ZXN0IHRpbWVvdXQiKQogICAgICAgICAgICAgICAgICAgIHByaW50KCJHdWVzdCBhY3RpdmU6IixlbGFwc2VkLCJzZWNvbmRzIixmbHVzaD1UcnVlKQogICAgICAgICAgICAgICAgICAgIHRyeTogcC53YWl0KHRpbWVvdXQ9MTUpCiAgICAgICAgICAgICAgICAgICAgZXhjZXB0IHN1YnByb2Nlc3MuVGltZW91dEV4cGlyZWQ6IHBhc3MKICAgICAgICAgICAgZmluYWxseToKICAgICAgICAgICAgICAgIGlmIHAucG9sbCgpIGlzIE5vbmU6CiAgICAgICAgICAgICAgICAgICAgcC50ZXJtaW5hdGUoKQogICAgICAgICAgICAgICAgICAgIHRyeTogcC53YWl0KHRpbWVvdXQ9MTApCiAgICAgICAgICAgICAgICAgICAgZXhjZXB0IHN1YnByb2Nlc3MuVGltZW91dEV4cGlyZWQ6IHAua2lsbCgpOyBwLndhaXQoKQogICAgICAgIHJlY2VpcHRbImV4aXRfY29kZSJdPXAucmV0dXJuY29kZQogICAgICAgIHJlY2VpcHRbInN0ZGVyciJdPSh3b3JrLyJxZW11LnN0ZGVyciIpLnJlYWRfYnl0ZXMoKVstODAwMDpdLmRlY29kZShlcnJvcnM9InJlcGxhY2UiKQogICAgICAgIGlmIHAucmV0dXJuY29kZSE9MDogcmFpc2UgUnVudGltZUVycm9yKCJRRU1VIGZhaWxlZCIpCiAgICAgICAgd2l0aCBzZXJpYWwub3BlbigicmIiKSBhcyBmOgogICAgICAgICAgICBmLnNlZWsobWF4KDAsc2VyaWFsLnN0YXQoKS5zdF9zaXplLTI2MjE0NCkpCiAgICAgICAgICAgIGxpbmVzPWYucmVhZCgpLmRlY29kZShlcnJvcnM9InJlcGxhY2UiKS5zcGxpdGxpbmVzKCkKICAgICAgICBtYXRjaGVzPVtsaW5lW2xlbihQUkVGSVgpOl0gZm9yIGxpbmUgaW4gbGluZXMgaWYgbGluZS5zdGFydHN3aXRoKFBSRUZJWCldCiAgICAgICAgaWYgbGVuKG1hdGNoZXMpIT0xOiByYWlzZSBSdW50aW1lRXJyb3IoImV4cGVjdGVkIGV4YWN0bHkgb25lIGd1ZXN0IHByb29mIikKICAgICAgICBwcm9vZj1qc29uLmxvYWRzKG1hdGNoZXNbMF0pCiAgICAgICAgYXJ0aWZhY3Q9dmVyaWZ5KHByb29mKQogICAgICAgIGZpbGVzWyJBUlRJRkFDVC5qc29uIl09YXJ0aWZhY3QKICAgICAgICBmaWxlc1siR1VFU1QuUFJPT0YuanNvbiJdPWpzb24uZHVtcHMocHJvb2YsaW5kZW50PTIpLmVuY29kZSgpCiAgICAgICAgKHdvcmsvIkFSVElGQUNULmpzb24iKS53cml0ZV9ieXRlcyhhcnRpZmFjdCkKICAgICAgICByZWNlaXB0WyJhcnRpZmFjdF9zaGEyNTYiXT1oYXNobGliLnNoYTI1NihhcnRpZmFjdCkuaGV4ZGlnZXN0KCkKICAgICAgICByZWNlaXB0WyJzdGF0dXMiXT0iUEFTUyIKICAgIGV4Y2VwdCBLZXlib2FyZEludGVycnVwdDoKICAgICAgICByZWNlaXB0WyJzdGF0dXMiXT0iQ0FOQ0VMTEVEIgogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBlOgogICAgICAgIHJlY2VpcHRbImVycm9yIl09c3RyKGUpWzo0MDAwXQogICAgaWYgc2VyaWFsIGFuZCBzZXJpYWwuaXNfZmlsZSgpOgogICAgICAgIHdpdGggc2VyaWFsLm9wZW4oInJiIikgYXMgZjoKICAgICAgICAgICAgZi5zZWVrKG1heCgwLHNlcmlhbC5zdGF0KCkuc3Rfc2l6ZS02NTUzNikpCiAgICAgICAgICAgIGZpbGVzWyJHVUVTVC5TRVJJQUwubG9nIl09Zi5yZWFkKCkKICAgIGZpbGVzWyJSRUNFSVBULmpzb24iXT1qc29uLmR1bXBzKHJlY2VpcHQsaW5kZW50PTIpLmVuY29kZSgpCiAgICBvdXQ9ZG93bmxvYWRzL2YiQ0xJTksuUkVUVVJOLkRFVkVMT1BNRU5ULUhPU1QuMDA4LntzdGFtcH0uemlwIgogICAgd2l0aCB6aXBmaWxlLlppcEZpbGUob3V0LCJ4Iix6aXBmaWxlLlpJUF9ERUZMQVRFRCkgYXMgejoKICAgICAgICBmb3Iga2V5LGRhdGEgaW4gZmlsZXMuaXRlbXMoKTogei53cml0ZXN0cihrZXksZGF0YSkKICAgICAgICB6LndyaXRlc3RyKCJTSEEyNTZTVU1TIiwiIi5qb2luKGhhc2hsaWIuc2hhMjU2KGRhdGEpLmhleGRpZ2VzdCgpKyIgICIra2V5KyJcbiIgZm9yIGtleSxkYXRhIGluIGZpbGVzLml0ZW1zKCkpKQogICAgcHJpbnQoIkRFVkVMT1BNRU5UIEhPU1QgMDA4OiIscmVjZWlwdFsic3RhdHVzIl0sZmx1c2g9VHJ1ZSkKICAgIHByaW50KCJDTElOS19IT1NUX1JFQ0VJUFQ9Iitqc29uLmR1bXBzKHsqKnJlY2VpcHQsInJlY2VpcHRfcGF0aCI6c3RyKG91dCl9LHNlcGFyYXRvcnM9KCIsIiwiOiIpKSxmbHVzaD1UcnVlKQoKaWYgX19uYW1lX189PSJfX21haW5fXyI6CiAgICBtYWluKCkK", "development_smoke.py": "IiIiRml4ZWQgb2ZmbGluZSBEZXZlbG9wbWVudCBIb3N0IHdvcmtmbG93OyBpbnZva2Ugb25seSBpbiBhcHByb3ZlZCBpc29sYXRlZCBydW50aW1lLgpObyBhcmJpdHJhcnkgY29tbWFuZHMsIHBhdGhzIG9yIG1vZGVsLWdlbmVyYXRlZCBjb2RlLiBTdGF0ZSByb290IGlzIGhvc3Qtb3duZWQuCiIiIgppbXBvcnQgZmNudGwKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAppbXBvcnQgc3VicHJvY2VzcwppbXBvcnQgc3lzCmltcG9ydCB0ZW1wZmlsZQoKV09SS0ZMT1cgPSAnZGV2ZWxvcG1lbnQuc21va2UudjEnClNPVVJDRSA9IGInZGVmIGFkZChhLCBiKTpcbiAgICByZXR1cm4gYSArIGJcbicKVEVTVCA9IGInZnJvbSBjYWxjdWxhdG9yIGltcG9ydCBhZGRcbmFzc2VydCBhZGQoMiwgMykgPT0gNVxuYXNzZXJ0IGFkZCgtNCwgNCkgPT0gMFxucHJpbnQoIjIgY2hlY2tzIHBhc3NlZCIpXG4nCgpkZWYgZGlnZXN0KGRhdGEpOgogICAgcmV0dXJuIGhhc2hsaWIuc2hhMjU2KGRhdGEpLmhleGRpZ2VzdCgpCgpTUEVDID0geydvYmplY3RpdmUnOiAnQ3JlYXRlIGNhbGN1bGF0b3IucHkgYW5kIHRlc3QgYWRkaXRpb24nLAogICAgICAgICdhY2NlcHRhbmNlJzogJ1R3byBmaXhlZCBjaGVja3MgcGFzcycsCiAgICAgICAgJ2lucHV0X3JlZic6ICdzaGEyNTY6JyArIGRpZ2VzdChTT1VSQ0UgKyBiJ1wwJyArIFRFU1QpLAogICAgICAgICd3b3JrZmxvdyc6IFdPUktGTE9XfQoKCmRlZiBleGVjdXRlKHJvb3QpOgogICAgIiIiVHJ1c3RlZCBmaXh0dXJlIG9ubHk7IHRoaXMgZnVuY3Rpb24gaXMgTk9UIGFuIE9TIGlzb2xhdGlvbiBib3VuZGFyeS4iIiIKICAgIHJvb3QgPSBQYXRoKHJvb3QpLnJlc29sdmUoc3RyaWN0PVRydWUpCiAgICB3aXRoIHRlbXBmaWxlLlRlbXBvcmFyeURpcmVjdG9yeShwcmVmaXg9J3Ntb2tlLScsIGRpcj1yb290KSBhcyB0bXA6CiAgICAgICAgd29yayA9IFBhdGgodG1wKQogICAgICAgICh3b3JrIC8gJ2NhbGN1bGF0b3IucHknKS53cml0ZV9ieXRlcyhTT1VSQ0UpCiAgICAgICAgKHdvcmsgLyAnY2hlY2sucHknKS53cml0ZV9ieXRlcyhURVNUKQogICAgICAgICMgSXNvbGF0ZWQgUHl0aG9uIGltcG9ydCBtb2RlOyBleHBsaWNpdCB0cnVzdGVkIGZpeHR1cmUgZGlyZWN0b3J5IG9ubHkuCiAgICAgICAgYXJndiA9IFtzeXMuZXhlY3V0YWJsZSwgJy1JJywgJy1CJywgJy1jJywKICAgICAgICAgICAgICAgICdpbXBvcnQgc3lzLHJ1bnB5O3N5cy5wYXRoLmluc2VydCgwLCIuIik7cnVucHkucnVuX3BhdGgoImNoZWNrLnB5IixydW5fbmFtZT0iX19tYWluX18iKSddCiAgICAgICAgcmVzdWx0ID0gc3VicHJvY2Vzcy5ydW4oYXJndiwgY3dkPXdvcmssIGVudj17J1BBVEgnOiAnL3Vzci9iaW46L2JpbicsICdIT01FJzogdG1wLCAnTENfQUxMJzogJ0MnfSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGRpbj1zdWJwcm9jZXNzLkRFVk5VTEwsIGNhcHR1cmVfb3V0cHV0PVRydWUsIHRpbWVvdXQ9MTAsIGNoZWNrPUZhbHNlKQogICAgICAgIGlmIHJlc3VsdC5yZXR1cm5jb2RlICE9IDAgb3IgcmVzdWx0LnN0ZG91dCAhPSBiJzIgY2hlY2tzIHBhc3NlZFxuJyBvciByZXN1bHQuc3RkZXJyOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoJ2ZpeGVkIHZhbGlkYXRvciBmYWlsZWQnKQogICAgICAgIGFydGlmYWN0ID0ganNvbi5kdW1wcyh7J2NhbGN1bGF0b3IucHknOiBTT1VSQ0UuZGVjb2RlKCksICdjaGVjay5weSc6IFRFU1QuZGVjb2RlKCksCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc3Rkb3V0JzogcmVzdWx0LnN0ZG91dC5kZWNvZGUoKX0sIHNvcnRfa2V5cz1UcnVlLCBzZXBhcmF0b3JzPSgnLCcsICc6JykpLmVuY29kZSgpCiAgICAgICAgc2hhID0gZGlnZXN0KGFydGlmYWN0KQogICAgICAgIGRlc3QgPSByb290IC8gKHNoYSArICcuanNvbicpCiAgICAgICAgIyBBdG9taWMgaW1tdXRhYmxlIHB1YmxpY2F0aW9uOyBleGlzdGluZyBvYmplY3QgbXVzdCBtYXRjaC4KICAgICAgICBmZCwgc3RhZ2luZyA9IHRlbXBmaWxlLm1rc3RlbXAocHJlZml4PScuYXJ0aWZhY3QtJywgZGlyPXJvb3QpCiAgICAgICAgdHJ5OgogICAgICAgICAgICB3aXRoIG9zLmZkb3BlbihmZCwgJ3diJykgYXMgZjoKICAgICAgICAgICAgICAgIGYud3JpdGUoYXJ0aWZhY3QpOyBmLmZsdXNoKCk7IG9zLmZzeW5jKGYuZmlsZW5vKCkpCiAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAgIG9zLmxpbmsoc3RhZ2luZywgZGVzdCkKICAgICAgICAgICAgZXhjZXB0IEZpbGVFeGlzdHNFcnJvcjoKICAgICAgICAgICAgICAgIGlmIGRlc3QuaXNfc3ltbGluaygpIG9yIGRlc3QucmVhZF9ieXRlcygpICE9IGFydGlmYWN0OgogICAgICAgICAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcignYXJ0aWZhY3QgbWlzbWF0Y2gnKQogICAgICAgIGZpbmFsbHk6CiAgICAgICAgICAgIG9zLnVubGluayhzdGFnaW5nKQogICAgICAgIHJldHVybiB7J3dvcmtmbG93JzogV09SS0ZMT1csICd0ZXN0X2NvbW1hbmQnOiAncHl0aG9uIC1JIC1CIDxmaXhlZCBjaGVjayBydW5uZXI+JywKICAgICAgICAgICAgICAgICd0ZXN0X3Jlc3VsdCc6IHJlc3VsdC5zdGRvdXQuZGVjb2RlKCkuc3RyaXAoKSwgJ2V4aXRfY29kZSc6IHJlc3VsdC5yZXR1cm5jb2RlLAogICAgICAgICAgICAgICAgJ2FydGlmYWN0X3JlZic6ICdzaGEyNTY6JyArIHNoYSwgJ3Byb3ZpZGVyX2NhbGxzJzogMH0KCgpkZWYgcnVuX2pvdXJuYWxlZChyb290LCB0YXNrX2lkKToKICAgICIiIlVzZSBleGlzdGluZyBFbmdpbmUgaW4gYSBkZWRpY2F0ZWQgaG9zdC1vd25lZCBqb3VybmFsOyBuZXZlciBkaXNwYXRjaCBhIHByb3ZpZGVyLiIiIgogICAgZnJvbSB0YXNrX2VuZ2luZSBpbXBvcnQgRW5naW5lCiAgICBpZiB0YXNrX2lkIG5vdCBpbiAoJ3Ntb2tlLW9yaWdpbmFsJywgJ3Ntb2tlLXJlcGxheScpOgogICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoJ3VucmVnaXN0ZXJlZCB0YXNrJykKICAgIHJvb3QgPSBQYXRoKHJvb3QpLnJlc29sdmUoc3RyaWN0PVRydWUpCiAgICB3aXRoIChyb290IC8gJ2RldmVsb3BtZW50LXNtb2tlLmxvY2snKS5vcGVuKCdhJykgYXMgbG9jazoKICAgICAgICBmY250bC5mbG9jayhsb2NrLCBmY250bC5MT0NLX0VYIHwgZmNudGwuTE9DS19OQikKICAgICAgICByZXR1cm4gX3J1bl9sb2NrZWQocm9vdCwgdGFza19pZCwgRW5naW5lKQoKCmRlZiBfcnVuX2xvY2tlZChyb290LCB0YXNrX2lkLCBFbmdpbmUpOgogICAgZW5naW5lID0gRW5naW5lKHJvb3QgLyAnZGV2ZWxvcG1lbnQtc21va2Uuc3FsaXRlJykKICAgIHRyeToKICAgICAgICBlbmdpbmUuZW5xdWV1ZSh0YXNrX2lkLCBTUEVDLCBtYXhfYXR0ZW1wdHM9MSkKICAgICAgICByb3cgPSBlbmdpbmUuZ2V0KHRhc2tfaWQpCiAgICAgICAgaWYgcm93WydzdGF0ZSddID09ICdzdWNjZWVkZWQnOgogICAgICAgICAgICByZWNlaXB0ID0gcm93WydyZWNlaXB0J10KICAgICAgICAgICAgYXJ0aWZhY3QgPSByb290IC8gKHJlY2VpcHRbJ2FydGlmYWN0X3JlZiddLnNwbGl0KCc6JywgMSlbMV0gKyAnLmpzb24nKQogICAgICAgICAgICBpZiBhcnRpZmFjdC5pc19zeW1saW5rKCkgb3IgZGlnZXN0KGFydGlmYWN0LnJlYWRfYnl0ZXMoKSkgIT0gcmVjZWlwdFsnYXJ0aWZhY3RfcmVmJ10uc3BsaXQoJzonLCAxKVsxXToKICAgICAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcignc3RvcmVkIGFydGlmYWN0IG1pc21hdGNoJykKICAgICAgICAgICAgcmV0dXJuIHJvdwogICAgICAgICMgRGVkaWNhdGVkIGpvdXJuYWw7IGRvIG5vdCBjbGFpbSBhbm90aGVyIHF1ZXVlZCB0YXNrLgogICAgICAgIHBlbmRpbmcgPSBlbmdpbmUuZGIuZXhlY3V0ZSgiU0VMRUNUIGlkIEZST00gdGFza3MgV0hFUkUgc3RhdGU9J3F1ZXVlZCcgT1JERVIgQlkgY3JlYXRlZCxpZCBMSU1JVCAxIikuZmV0Y2hvbmUoKQogICAgICAgIGlmIHBlbmRpbmcgaXMgTm9uZSBvciBwZW5kaW5nWydpZCddICE9IHRhc2tfaWQ6CiAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcigncmVxdWVzdGVkIHRhc2sgbm90IHF1ZXVlZCBmaXJzdCcpCiAgICAgICAgcm93ID0gZW5naW5lLmNsYWltKFdPUktGTE9XLCBzZWNvbmRzPTMwKQogICAgICAgIGlmIHJvdyBpcyBOb25lIG9yIHJvd1snaWQnXSAhPSB0YXNrX2lkOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoJ2NsYWltIHVuYXZhaWxhYmxlJykKICAgICAgICB0cnk6CiAgICAgICAgICAgIHJlY2VpcHQgPSBleGVjdXRlKHJvb3QpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgZW5naW5lLmZhaWwodGFza19pZCwgcm93Wyd0b2tlbiddLCAnZml4ZWQgZXhlY3V0aW9uIGZhaWxlZCcpCiAgICAgICAgICAgIHJhaXNlCiAgICAgICAgZW5naW5lLmZpbmlzaCh0YXNrX2lkLCByb3dbJ3Rva2VuJ10sIHJlY2VpcHQpCiAgICAgICAgcmV0dXJuIGVuZ2luZS5nZXQodGFza19pZCkKICAgIGZpbmFsbHk6CiAgICAgICAgZW5naW5lLmNsb3NlKCkK", "task_engine.py": "IiIiT2ZmbGluZSBkdXJhYmxlIHRhc2sgZW5naW5lLiBObyBzaGVsbCwgbmV0d29yaywgb3IgbW9kZWwgZXhlY3V0aW9uLiIiIgppbXBvcnQganNvbgppbXBvcnQgbWF0aAppbXBvcnQgcmUKaW1wb3J0IHNlY3JldHMKaW1wb3J0IHNxbGl0ZTMKaW1wb3J0IHRpbWUKZnJvbSBjb250ZXh0bGliIGltcG9ydCBjb250ZXh0bWFuYWdlcgoKCmNsYXNzIENvbmZsaWN0KFJ1bnRpbWVFcnJvcik6CiAgICBwYXNzCgoKY2xhc3MgRW5naW5lOgogICAgZGVmIF9faW5pdF9fKHNlbGYsIHBhdGgsIGNsb2NrPXRpbWUudGltZSk6CiAgICAgICAgc2VsZi5jbG9jayA9IGNsb2NrCiAgICAgICAgc2VsZi5kYiA9IHNxbGl0ZTMuY29ubmVjdChwYXRoLCB0aW1lb3V0PTEwLCBpc29sYXRpb25fbGV2ZWw9Tm9uZSkKICAgICAgICBzZWxmLmRiLnJvd19mYWN0b3J5ID0gc3FsaXRlMy5Sb3cKICAgICAgICBzZWxmLmRiLmV4ZWN1dGUoJ1BSQUdNQSBqb3VybmFsX21vZGU9V0FMJykKICAgICAgICBzZWxmLmRiLmV4ZWN1dGUoJ1BSQUdNQSBzeW5jaHJvbm91cz1GVUxMJykKICAgICAgICBzZWxmLmRiLmV4ZWN1dGVzY3JpcHQoJycnCiAgICAgICAgQ1JFQVRFIFRBQkxFIElGIE5PVCBFWElTVFMgdGFza3MoCiAgICAgICAgICAgIGlkIFRFWFQgUFJJTUFSWSBLRVksIHNwZWMgVEVYVCBOT1QgTlVMTCwgbWF4X2F0dGVtcHRzIElOVEVHRVIgTk9UIE5VTEwsCiAgICAgICAgICAgIGF0dGVtcHRzIElOVEVHRVIgTk9UIE5VTEwgREVGQVVMVCAwLCBzdGF0ZSBURVhUIE5PVCBOVUxMIERFRkFVTFQgJ3F1ZXVlZCcsCiAgICAgICAgICAgIHRva2VuIFRFWFQsIHdvcmtlciBURVhULCBleHBpcmVzIFJFQUwsIHJlY2VpcHQgVEVYVCwgY3JlYXRlZCBSRUFMIE5PVCBOVUxMKTsKICAgICAgICBDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyBldmVudHMoCiAgICAgICAgICAgIHNlcSBJTlRFR0VSIFBSSU1BUlkgS0VZLCB0YXNrX2lkIFRFWFQsIGtpbmQgVEVYVCBOT1QgTlVMTCwKICAgICAgICAgICAgYXQgUkVBTCBOT1QgTlVMTCwgZGV0YWlsIFRFWFQgTk9UIE5VTEwpOwogICAgICAgIENSRUFURSBUQUJMRSBJRiBOT1QgRVhJU1RTIGNvbnRyb2woaWQgSU5URUdFUiBQUklNQVJZIEtFWSwgcGF1c2VkIElOVEVHRVIgTk9UIE5VTEwpOwogICAgICAgIElOU0VSVCBPUiBJR05PUkUgSU5UTyBjb250cm9sIFZBTFVFUygxLDApOwogICAgICAgICcnJykKCiAgICBkZWYgY2xvc2Uoc2VsZik6CiAgICAgICAgc2VsZi5kYi5jbG9zZSgpCgogICAgQGNvbnRleHRtYW5hZ2VyCiAgICBkZWYgdHgoc2VsZik6CiAgICAgICAgc2VsZi5kYi5leGVjdXRlKCdCRUdJTiBJTU1FRElBVEUnKQogICAgICAgIHRyeToKICAgICAgICAgICAgeWllbGQKICAgICAgICAgICAgc2VsZi5kYi5jb21taXQoKQogICAgICAgIGV4Y2VwdCBCYXNlRXhjZXB0aW9uOgogICAgICAgICAgICBzZWxmLmRiLnJvbGxiYWNrKCkKICAgICAgICAgICAgcmFpc2UKCiAgICBkZWYgZXZlbnQoc2VsZiwgdGFza19pZCwga2luZCwgZGV0YWlsPU5vbmUpOgogICAgICAgIHNlbGYuZGIuZXhlY3V0ZSgnSU5TRVJUIElOVE8gZXZlbnRzKHRhc2tfaWQsa2luZCxhdCxkZXRhaWwpIFZBTFVFUyg/LD8sPyw/KScsCiAgICAgICAgICAgICAgICAgICAgICAgICh0YXNrX2lkLCBraW5kLCBzZWxmLmNsb2NrKCksIGpzb24uZHVtcHMoZGV0YWlsKSkpCgogICAgZGVmIGdldChzZWxmLCB0YXNrX2lkKToKICAgICAgICByb3cgPSBzZWxmLmRiLmV4ZWN1dGUoJ1NFTEVDVCAqIEZST00gdGFza3MgV0hFUkUgaWQ9PycsICh0YXNrX2lkLCkpLmZldGNob25lKCkKICAgICAgICBpZiByb3cgaXMgTm9uZToKICAgICAgICAgICAgcmFpc2UgS2V5RXJyb3IodGFza19pZCkKICAgICAgICByZXN1bHQgPSBkaWN0KHJvdykKICAgICAgICBmb3Iga2V5IGluICgnc3BlYycsICdyZWNlaXB0Jyk6CiAgICAgICAgICAgIHJlc3VsdFtrZXldID0ganNvbi5sb2FkcyhyZXN1bHRba2V5XSkgaWYgcmVzdWx0W2tleV0gaXMgbm90IE5vbmUgZWxzZSBOb25lCiAgICAgICAgcmV0dXJuIHJlc3VsdAoKICAgIGRlZiBlbnF1ZXVlKHNlbGYsIHRhc2tfaWQsIHNwZWMsIG1heF9hdHRlbXB0cz0zKToKICAgICAgICBmb3Iga2V5IGluICgnb2JqZWN0aXZlJywgJ2FjY2VwdGFuY2UnLCAnaW5wdXRfcmVmJyk6CiAgICAgICAgICAgIGlmIG5vdCBpc2luc3RhbmNlKHNwZWMuZ2V0KGtleSksIHN0cikgb3Igbm90IHNwZWNba2V5XS5zdHJpcCgpOgogICAgICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcihrZXkpCiAgICAgICAgaWYgbm90IHJlLmZ1bGxtYXRjaChyJ3NoYTI1NjpbMC05YS1mXXs2NH18Z2l0OlswLTlhLWZdezQwfScsIHNwZWNbJ2lucHV0X3JlZiddKToKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignaW1tdXRhYmxlIGlucHV0X3JlZiByZXF1aXJlZCcpCiAgICAgICAgaWYgbm90IGlzaW5zdGFuY2UodGFza19pZCwgc3RyKSBvciBub3QgdGFza19pZC5zdHJpcCgpIG9yIHR5cGUobWF4X2F0dGVtcHRzKSBpcyBub3QgaW50IG9yIG5vdCAxIDw9IG1heF9hdHRlbXB0cyA8PSAxMDoKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignaW52YWxpZCB0YXNrIGlkIG9yIGF0dGVtcHQgY2VpbGluZycpCiAgICAgICAgcGF5bG9hZCA9IGpzb24uZHVtcHMoc3BlYywgc29ydF9rZXlzPVRydWUsIGFsbG93X25hbj1GYWxzZSkKICAgICAgICB3aXRoIHNlbGYudHgoKToKICAgICAgICAgICAgb2xkID0gc2VsZi5kYi5leGVjdXRlKCdTRUxFQ1Qgc3BlYyxtYXhfYXR0ZW1wdHMgRlJPTSB0YXNrcyBXSEVSRSBpZD0/JywgKHRhc2tfaWQsKSkuZmV0Y2hvbmUoKQogICAgICAgICAgICBpZiBvbGQ6CiAgICAgICAgICAgICAgICBpZiB0dXBsZShvbGQpICE9IChwYXlsb2FkLCBtYXhfYXR0ZW1wdHMpOgogICAgICAgICAgICAgICAgICAgIHJhaXNlIENvbmZsaWN0KCd0YXNrIGlkIGFscmVhZHkgaGFzIGRpZmZlcmVudCBpbnB1dHMnKQogICAgICAgICAgICAgICAgcmV0dXJuCiAgICAgICAgICAgIHNlbGYuZGIuZXhlY3V0ZSgnSU5TRVJUIElOVE8gdGFza3MoaWQsc3BlYyxtYXhfYXR0ZW1wdHMsY3JlYXRlZCkgVkFMVUVTKD8sPyw/LD8pJywKICAgICAgICAgICAgICAgICAgICAgICAgICAgICh0YXNrX2lkLCBwYXlsb2FkLCBtYXhfYXR0ZW1wdHMsIHNlbGYuY2xvY2soKSkpCiAgICAgICAgICAgIHNlbGYuZXZlbnQodGFza19pZCwgJ3F1ZXVlZCcpCgogICAgZGVmIF9yZWNvdmVyKHNlbGYsIG5vdyk6CiAgICAgICAgZm9yIHJvdyBpbiBzZWxmLmRiLmV4ZWN1dGUoIlNFTEVDVCAqIEZST00gdGFza3MgV0hFUkUgc3RhdGU9J3J1bm5pbmcnIEFORCBleHBpcmVzPD0/IiwgKG5vdywpKS5mZXRjaGFsbCgpOgogICAgICAgICAgICBzdGF0ZSA9ICdmYWlsZWQnIGlmIHJvd1snYXR0ZW1wdHMnXSA+PSByb3dbJ21heF9hdHRlbXB0cyddIGVsc2UgJ3F1ZXVlZCcKICAgICAgICAgICAgc2VsZi5fcmVsZWFzZShyb3dbJ2lkJ10sIHN0YXRlKQogICAgICAgICAgICBzZWxmLmV2ZW50KHJvd1snaWQnXSwgJ2xlYXNlX2V4cGlyZWQnLCB7J25leHQnOiBzdGF0ZSwgJ2F0dGVtcHQnOiByb3dbJ2F0dGVtcHRzJ119KQoKICAgIGRlZiByZWNvdmVyKHNlbGYpOgogICAgICAgIHdpdGggc2VsZi50eCgpOgogICAgICAgICAgICBzZWxmLl9yZWNvdmVyKHNlbGYuY2xvY2soKSkKCiAgICBkZWYgX3JlbGVhc2Uoc2VsZiwgdGFza19pZCwgc3RhdGUsIHJlY2VpcHQ9Tm9uZSk6CiAgICAgICAgc2VsZi5kYi5leGVjdXRlKCdVUERBVEUgdGFza3MgU0VUIHN0YXRlPT8sdG9rZW49TlVMTCx3b3JrZXI9TlVMTCxleHBpcmVzPU5VTEwscmVjZWlwdD0/IFdIRVJFIGlkPT8nLAogICAgICAgICAgICAgICAgICAgICAgICAoc3RhdGUsIGpzb24uZHVtcHMocmVjZWlwdCkgaWYgcmVjZWlwdCBpcyBub3QgTm9uZSBlbHNlIE5vbmUsIHRhc2tfaWQpKQoKICAgIEBzdGF0aWNtZXRob2QKICAgIGRlZiBfZHVyYXRpb24oc2Vjb25kcyk6CiAgICAgICAgaWYgdHlwZShzZWNvbmRzKSBub3QgaW4gKGludCwgZmxvYXQpIG9yIG5vdCBtYXRoLmlzZmluaXRlKHNlY29uZHMpIG9yIG5vdCAwIDwgc2Vjb25kcyA8PSAzNjAwOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCdpbnZhbGlkIGxlYXNlIGR1cmF0aW9uJykKCiAgICBkZWYgY2xhaW0oc2VsZiwgd29ya2VyLCBzZWNvbmRzPTYwKToKICAgICAgICBzZWxmLl9kdXJhdGlvbihzZWNvbmRzKQogICAgICAgIGlmIG5vdCBpc2luc3RhbmNlKHdvcmtlciwgc3RyKSBvciBub3Qgd29ya2VyLnN0cmlwKCk6CiAgICAgICAgICAgIHJhaXNlIFZhbHVlRXJyb3IoJ3dvcmtlciByZXF1aXJlZCcpCiAgICAgICAgd2l0aCBzZWxmLnR4KCk6CiAgICAgICAgICAgIG5vdyA9IHNlbGYuY2xvY2soKQogICAgICAgICAgICBzZWxmLl9yZWNvdmVyKG5vdykKICAgICAgICAgICAgaWYgc2VsZi5kYi5leGVjdXRlKCdTRUxFQ1QgcGF1c2VkIEZST00gY29udHJvbCBXSEVSRSBpZD0xJykuZmV0Y2hvbmUoKVswXToKICAgICAgICAgICAgICAgIHJldHVybiBOb25lCiAgICAgICAgICAgIHJvdyA9IHNlbGYuZGIuZXhlY3V0ZSgiU0VMRUNUIGlkIEZST00gdGFza3MgV0hFUkUgc3RhdGU9J3F1ZXVlZCcgT1JERVIgQlkgY3JlYXRlZCxpZCBMSU1JVCAxIikuZmV0Y2hvbmUoKQogICAgICAgICAgICBpZiByb3cgaXMgTm9uZToKICAgICAgICAgICAgICAgIHJldHVybiBOb25lCiAgICAgICAgICAgIHRhc2tfaWQgPSByb3dbJ2lkJ10KICAgICAgICAgICAgdG9rZW4gPSBzZWNyZXRzLnRva2VuX2hleCgzMikKICAgICAgICAgICAgc2VsZi5kYi5leGVjdXRlKCJVUERBVEUgdGFza3MgU0VUIHN0YXRlPSdydW5uaW5nJyxhdHRlbXB0cz1hdHRlbXB0cysxLHRva2VuPT8sd29ya2VyPT8sZXhwaXJlcz0/IFdIRVJFIGlkPT8iLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgKHRva2VuLCB3b3JrZXIsIG5vdytzZWNvbmRzLCB0YXNrX2lkKSkKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAnY2xhaW1lZCcsIHsnd29ya2VyJzogd29ya2VyfSkKICAgICAgICAgICAgcmV0dXJuIHNlbGYuZ2V0KHRhc2tfaWQpCgogICAgZGVmIF9vd25lZChzZWxmLCB0YXNrX2lkLCB0b2tlbik6CiAgICAgICAgcm93ID0gc2VsZi5nZXQodGFza19pZCkKICAgICAgICBpZiBub3QgdG9rZW4gb3Igcm93WydzdGF0ZSddICE9ICdydW5uaW5nJyBvciByb3dbJ3Rva2VuJ10gIT0gdG9rZW4gb3Igcm93WydleHBpcmVzJ10gPD0gc2VsZi5jbG9jaygpOgogICAgICAgICAgICByYWlzZSBDb25mbGljdCgnaW52YWxpZCBvciBleHBpcmVkIGxlYXNlJykKICAgICAgICByZXR1cm4gcm93CgogICAgZGVmIHJlbmV3KHNlbGYsIHRhc2tfaWQsIHRva2VuLCBzZWNvbmRzPTYwKToKICAgICAgICBzZWxmLl9kdXJhdGlvbihzZWNvbmRzKQogICAgICAgIHdpdGggc2VsZi50eCgpOgogICAgICAgICAgICBzZWxmLl9vd25lZCh0YXNrX2lkLCB0b2tlbikKICAgICAgICAgICAgc2VsZi5kYi5leGVjdXRlKCdVUERBVEUgdGFza3MgU0VUIGV4cGlyZXM9PyBXSEVSRSBpZD0/JywgKHNlbGYuY2xvY2soKStzZWNvbmRzLCB0YXNrX2lkKSkKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAncmVuZXdlZCcpCgogICAgZGVmIGZpbmlzaChzZWxmLCB0YXNrX2lkLCB0b2tlbiwgcmVjZWlwdCk6CiAgICAgICAgZm9yIGtleSBpbiAoJ3Rlc3RfY29tbWFuZCcsICd0ZXN0X3Jlc3VsdCcsICdhcnRpZmFjdF9yZWYnKToKICAgICAgICAgICAgaWYgbm90IGlzaW5zdGFuY2UocmVjZWlwdC5nZXQoa2V5KSwgc3RyKSBvciBub3QgcmVjZWlwdFtrZXldLnN0cmlwKCk6CiAgICAgICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKGtleSkKICAgICAgICBpZiBub3QgcmUuZnVsbG1hdGNoKHInc2hhMjU2OlswLTlhLWZdezY0fXxnaXQ6WzAtOWEtZl17NDB9JywgcmVjZWlwdFsnYXJ0aWZhY3RfcmVmJ10pOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCdpbW11dGFibGUgYXJ0aWZhY3RfcmVmIHJlcXVpcmVkJykKICAgICAgICBpZiB0eXBlKHJlY2VpcHQuZ2V0KCdleGl0X2NvZGUnKSkgaXMgbm90IGludCBvciByZWNlaXB0WydleGl0X2NvZGUnXSAhPSAwOgogICAgICAgICAgICByYWlzZSBWYWx1ZUVycm9yKCdzdWNjZXNzZnVsIHRlc3QgZXhpdCBjb2RlIHJlcXVpcmVkJykKICAgICAgICB3aXRoIHNlbGYudHgoKToKICAgICAgICAgICAgcm93ID0gc2VsZi5fb3duZWQodGFza19pZCwgdG9rZW4pCiAgICAgICAgICAgIHJlY29yZGVkID0geyoqcmVjZWlwdCwgJ2lucHV0X3JlZic6IHJvd1snc3BlYyddWydpbnB1dF9yZWYnXSwgJ2F0dGVtcHQnOiByb3dbJ2F0dGVtcHRzJ10sICd3b3JrZXInOiByb3dbJ3dvcmtlciddfQogICAgICAgICAgICBzZWxmLl9yZWxlYXNlKHRhc2tfaWQsICdzdWNjZWVkZWQnLCByZWNvcmRlZCkKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAnc3VjY2VlZGVkJywgcmVjb3JkZWQpCgogICAgZGVmIGZhaWwoc2VsZiwgdGFza19pZCwgdG9rZW4sIHJlYXNvbik6CiAgICAgICAgaWYgbm90IGlzaW5zdGFuY2UocmVhc29uLCBzdHIpIG9yIG5vdCByZWFzb24uc3RyaXAoKToKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignZmFpbHVyZSByZWFzb24gcmVxdWlyZWQnKQogICAgICAgIHdpdGggc2VsZi50eCgpOgogICAgICAgICAgICByb3cgPSBzZWxmLl9vd25lZCh0YXNrX2lkLCB0b2tlbikKICAgICAgICAgICAgc3RhdGUgPSAnZmFpbGVkJyBpZiByb3dbJ2F0dGVtcHRzJ10gPj0gcm93WydtYXhfYXR0ZW1wdHMnXSBlbHNlICdxdWV1ZWQnCiAgICAgICAgICAgIHNlbGYuX3JlbGVhc2UodGFza19pZCwgc3RhdGUpCiAgICAgICAgICAgIHNlbGYuZXZlbnQodGFza19pZCwgJ2F0dGVtcHRfZmFpbGVkJywgeydyZWFzb24nOiByZWFzb24sICduZXh0Jzogc3RhdGV9KQoKICAgIGRlZiBjYW5jZWwoc2VsZiwgdGFza19pZCk6CiAgICAgICAgd2l0aCBzZWxmLnR4KCk6CiAgICAgICAgICAgIGlmIHNlbGYuZ2V0KHRhc2tfaWQpWydzdGF0ZSddIG5vdCBpbiAoJ3F1ZXVlZCcsICdydW5uaW5nJyk6CiAgICAgICAgICAgICAgICByZXR1cm4gRmFsc2UKICAgICAgICAgICAgc2VsZi5fcmVsZWFzZSh0YXNrX2lkLCAnY2FuY2VsbGVkJykKICAgICAgICAgICAgc2VsZi5ldmVudCh0YXNrX2lkLCAnY2FuY2VsbGVkJykKICAgICAgICAgICAgcmV0dXJuIFRydWUKCiAgICBkZWYgcGF1c2Uoc2VsZiwgcGF1c2VkPVRydWUpOgogICAgICAgIGlmIHR5cGUocGF1c2VkKSBpcyBub3QgYm9vbDoKICAgICAgICAgICAgcmFpc2UgVmFsdWVFcnJvcignYm9vbCByZXF1aXJlZCcpCiAgICAgICAgd2l0aCBzZWxmLnR4KCk6CiAgICAgICAgICAgIHNlbGYuZGIuZXhlY3V0ZSgnVVBEQVRFIGNvbnRyb2wgU0VUIHBhdXNlZD0/IFdIRVJFIGlkPTEnLCAoaW50KHBhdXNlZCksKSkKICAgICAgICAgICAgc2VsZi5ldmVudChOb25lLCAncGF1c2VkJyBpZiBwYXVzZWQgZWxzZSAncmVzdW1lZCcpCgogICAgZGVmIGhpc3Rvcnkoc2VsZiwgdGFza19pZCk6CiAgICAgICAgcmV0dXJuIFtkaWN0KHJvdykgZm9yIHJvdyBpbiBzZWxmLmRiLmV4ZWN1dGUoJ1NFTEVDVCAqIEZST00gZXZlbnRzIFdIRVJFIHRhc2tfaWQ9PyBPUkRFUiBCWSBzZXEnLCAodGFza19pZCwpKV0K", "seed.py": "aW1wb3J0IHN0cnVjdAoKZGVmIHNlZWRfaXNvKHVzZXIsIG1ldGEpOgogICAgIiIiQnVpbGQgYSBzbWFsbCBmaXhlZCBJU085NjYwL1JvY2sgUmlkZ2UgTm9DbG91ZCBpbWFnZSwgbm8gZXh0ZXJuYWwgdG9vbHMuIiIiCiAgICBibG9jayA9IDIwNDgKICAgIGRlZiBib3RoKG4sIHNpemUpOgogICAgICAgIHJldHVybiBuLnRvX2J5dGVzKHNpemUsICdsaXR0bGUnKSArIG4udG9fYnl0ZXMoc2l6ZSwgJ2JpZycpCiAgICBkZWYgcmVjb3JkKG5hbWUsIGV4dGVudCwgbGVuZ3RoLCBkaXJlY3Rvcnk9RmFsc2UsIHN1PWInJyk6CiAgICAgICAgZGF0YSA9IChiJ1wwXDAnICsgYm90aChleHRlbnQsIDQpICsgYm90aChsZW5ndGgsIDQpICsKICAgICAgICAgICAgICAgIGJ5dGVzKFsxMjYsIDEsIDEsIDAsIDAsIDAsIDAsIDIgaWYgZGlyZWN0b3J5IGVsc2UgMCwgMCwgMF0pICsKICAgICAgICAgICAgICAgIGJvdGgoMSwgMikgKyBieXRlcyhbbGVuKG5hbWUpXSkgKyBuYW1lKQogICAgICAgIGlmIGxlbihuYW1lKSAlIDIgPT0gMDoKICAgICAgICAgICAgZGF0YSArPSBiJ1wwJwogICAgICAgIGRhdGEgKz0gc3UKICAgICAgICByZXR1cm4gYnl0ZXMoW2xlbihkYXRhKV0pICsgZGF0YVsxOl0KICAgIGRlZiBubShuYW1lKToKICAgICAgICByZXR1cm4gYidOTScgKyBieXRlcyhbNSArIGxlbihuYW1lKSwgMSwgMF0pICsgbmFtZQogICAgZmlsZXMgPSBbKGInTUVUQV9EQVQuOzEnLCBiJ21ldGEtZGF0YScsIG1ldGEpLCAoYidVU0VSX0RBVC47MScsIGIndXNlci1kYXRhJywgdXNlcildCiAgICBlbnRyaWVzID0gW10KICAgIGVuZCA9IDIxCiAgICBmb3IgaXNvLCByciwgZGF0YSBpbiBmaWxlczoKICAgICAgICBlbnRyaWVzLmFwcGVuZCgoaXNvLCByciwgZGF0YSwgZW5kKSkKICAgICAgICBlbmQgKz0gbWF4KDEsIChsZW4oZGF0YSkgKyBibG9jayAtIDEpIC8vIGJsb2NrKQogICAgZW5kID0gbWF4KGVuZCwgMTUwKQogICAgaW1hZ2UgPSBieXRlYXJyYXkoZW5kICogYmxvY2spCiAgICBkZWYgcHV0KGxiYSwgZGF0YSk6CiAgICAgICAgaW1hZ2VbbGJhKmJsb2NrOmxiYSpibG9jaytsZW4oZGF0YSldID0gZGF0YQogICAgcm9vdCA9IHJlY29yZChiJ1wwJywgMjAsIGJsb2NrLCBUcnVlKQogICAgcHZkID0gYnl0ZWFycmF5KGJsb2NrKQogICAgcHZkWzo3XSA9IGInXHgwMUNEMDAxXHgwMScKICAgIHB2ZFs4OjQwXSA9IGInUEhBTlRPTVRST05JWCcubGp1c3QoMzIsIGInICcpCiAgICBwdmRbNDA6NzJdID0gYidDSURBVEEnLmxqdXN0KDMyLCBiJyAnKQogICAgcHZkWzgwOjg4XSA9IGJvdGgoZW5kLCA0KQogICAgcHZkWzEyMDoxMjRdID0gYm90aCgxLCAyKQogICAgcHZkWzEyNDoxMjhdID0gYm90aCgxLCAyKQogICAgcHZkWzEyODoxMzJdID0gYm90aChibG9jaywgMikKICAgIHB2ZFsxMzI6MTQwXSA9IGJvdGgoMTAsIDQpCiAgICBwdmRbMTQwOjE0NF0gPSBzdHJ1Y3QucGFjaygnPEknLCAxOCkKICAgIHB2ZFsxNDg6MTUyXSA9IHN0cnVjdC5wYWNrKCc+SScsIDE5KQogICAgcHZkWzE1NjoxOTBdID0gcm9vdAogICAgcHZkWzE5MDo4MTNdID0gYicgJyAqIDYyMwogICAgZm9yIG9mZnNldCBpbiAoODEzLCA4MzAsIDg0NywgODY0KToKICAgICAgICBwdmRbb2Zmc2V0Om9mZnNldCsxN10gPSBiJzAnKjE2ICsgYidcMCcKICAgIHB2ZFs4ODFdID0gMQogICAgcHV0KDE2LCBwdmQpCiAgICBwdXQoMTcsIGInXHhmZkNEMDAxXHgwMScpCiAgICBwdXQoMTgsIHN0cnVjdC5wYWNrKCc8QkJJSEJCJywgMSwgMCwgMjAsIDEsIDAsIDApKQogICAgcHV0KDE5LCBzdHJ1Y3QucGFjaygnPkJCSUhCQicsIDEsIDAsIDIwLCAxLCAwLCAwKSkKICAgIHNwID0gYidTUFx4MDdceDAxXHhiZVx4ZWZceDAwJwogICAgZXIgPSBiJ0VSXHgxMlx4MDFceDBhXHgwMFx4MDBceDAxUlJJUF8xOTkxQScKICAgIGRpcmVjdG9yeSA9IHJlY29yZChiJ1wwJywgMjAsIGJsb2NrLCBUcnVlLCBzcCtlcikgKyByZWNvcmQoYidcMScsIDIwLCBibG9jaywgVHJ1ZSkKICAgIGZvciBpc28sIHJyLCBkYXRhLCBsYmEgaW4gZW50cmllczoKICAgICAgICBkaXJlY3RvcnkgKz0gcmVjb3JkKGlzbywgbGJhLCBsZW4oZGF0YSksIHN1PW5tKHJyKSkKICAgICAgICBwdXQobGJhLCBkYXRhKQogICAgYXNzZXJ0IGxlbihkaXJlY3RvcnkpIDw9IGJsb2NrCiAgICBwdXQoMjAsIGRpcmVjdG9yeSkKICAgIHJldHVybiBieXRlcyhpbWFnZSkK"};
const dh017ReceiptSource="\nimport hashlib,json,sys,zipfile\nfrom pathlib import Path\nfrom datetime import datetime,timezone\nstate=Path(sys.argv[1]);out=Path(sys.argv[2]);files={}\nfor n in ('approval.json','live-decision-reserved.json','dispatch.json','provider-result.json','decision.json','machine-result.json','tool-result.json','failure.json'):\n p=state/n\n if p.is_file() and not p.is_symlink() and p.stat().st_size<=65536:files[n]=p.read_bytes()\nif 'machine-result.json' in files:\n j=json.loads(files['machine-result.json'])\n p=Path(j.get('receipt_path') or '/nonexistent').resolve()\n root=(Path.home()/'.local/share/phantomtronix-development-host/receipts').resolve()\n if p.parent==root and p.is_file() and p.stat().st_size<1048576:\n  with zipfile.ZipFile(p) as z:\n   assert z.testzip() is None\n   rows=z.read('SHA256SUMS').decode().splitlines()\n   for row in rows:\n    h,n=row.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h\n  files['MACHINE.zip']=p.read_bytes()\nfiles['RECEIPT.json']=json.dumps({'round':'017-LIVE','status':'REVIEW_REQUIRED','provider_dispatch_recorded':'dispatch.json' in files,'machine_receipt_present':'MACHINE.zip' in files}).encode()\nfiles['SHA256SUMS']=''.join(hashlib.sha256(b).hexdigest()+'  '+n+'\\n' for n,b in sorted(files.items())).encode()\nout.mkdir(exist_ok=True)\np=out/('CLINK.RETURN.DEVELOPMENT-HOST.LIVE.'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.zip')\nwith zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED) as z:\n for n,b in files.items():z.writestr(n,b)\nprint(p)\n";
const developmentAcceptance=dh017.integration.createInstalledIntegration({
 stateDir:dh017State,bundle:dh017Runner,
 approve:async()=>{
   if(!windowMain||windowMain.isDestroyed())return false;
   const r=await dialog.showMessageBox(windowMain,{type:'question',title:'Development Host — one-use acceptance',
     message:'Allow Miss Flower to create and test the Python calculator?',
     detail:'One OpenAI request, estimated maximum $0.02 (not a provider billing cap). No automatic retry. The isolated Development Host VM executes the fixed calculator workflow. Ctrl+Shift+X cancels.',
     buttons:['Cancel','Authorize once'],defaultId:0,cancelId:0,noLink:true});
   return r.response===1;
 },
 runnerFactory:(dir,progress)=>{
   fs.mkdirSync(dir,{mode:0o700});
   for(const [name,data] of Object.entries(dh017Embedded))fs.writeFileSync(path.join(dir,name),Buffer.from(data,'base64'),{mode:0o600,flag:'wx'});
   return dh017.tool.createVmRunner(dir,progress);
 },
 progress:message=>{
   try{
     log('development.acceptance.progress',{message:String(message).slice(0,160)});
     if(windowMain&&!windowMain.isDestroyed()){
       const done=message==='Development acceptance finished.';
       windowMain.setProgressBar(done?-1:2);
       windowMain.setTitle(done?dh017OriginalTitle:'C.Link — Development Host active (Ctrl+Shift+X cancels)');
     }
   }catch(_){}
 },
 publish:dir=>new Promise((resolve,reject)=>{
   cp.execFile('/usr/bin/python3',['-B','-c',dh017ReceiptSource,dir,app.getPath('downloads')],{timeout:20000,env:{PATH:'/usr/bin:/bin',HOME:os.homedir(),LANG:'C.UTF-8'}},(err,stdout)=>{
     if(err)return reject(Error('DEVELOPMENT_RECEIPT_EXPORT_FAILED'));
     log('development.acceptance.receipt',{path:String(stdout).trim()});resolve();
   });
 })
});


const dh025Module=(()=>{const module={exports:{}};const exports=module.exports;
'use strict';
// DH025: exact prior live decision recovery, no provider call or synthetic model reply.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os');
const PRIOR=Object.freeze({
 'approval.json':'3eeec7ec07093986cf2f53e7cf661ce3d3dcfc98103e557c46712c417786e2a9',
 'decision.json':'0fbd4943b58d0d2885f10e8d74ddd2b4fd72df9bfee9f795385dd73a36110df3',
 'dispatch.json':'36ea9fd312d07532093d52daee72f4e4cbbc97eade601d38594ffa9650edc250',
 'failure.json':'a0ac6ab353cd085ae16f77ab9f66a8eadbd68dc93e6de861e3a1abd56c562679',
 'live-decision-reserved.json':'b5b09b4d2fe7d8c80a71db769b9081cfbdcc936dd726aa4cf351afb1d03fab73',
 'provider-result.json':'3f7c91b5ae6cc05376791b6c2148582313786e9a21405a280eb8657cf6231b80'
});
const RUNNER=Object.freeze({
 'development_guest_008.py':'24db50fb9d7c493740067f9dd72dd9d07fe39b285d26d5da74b131c1a8b2d633',
 'development_smoke.py':'7e7ed93df0ae9c63f8e888b9cf63a3978c0cf7c36172a41461bfeccba1d90842',
 'task_engine.py':'f5b80ae5c1fa284bf5fc95f8b33b2f0fb77a6a6be1d2ec878522ce6c5add53bd',
 'seed.py':'32b8ccb44e16b8b4c816187572d9ce40a3accc52219c90972370b5dfbc166cf0'
});
function need(ok,code){if(!ok)throw Error(code);}
function privateDir(p){const s=fs.lstatSync(p);need(s.isDirectory()&&!s.isSymbolicLink()&&s.uid===process.getuid()&&!(s.mode&0o077),'DH025_UNSAFE_DIRECTORY');}
function verify(p,h){const s=fs.lstatSync(p);need(s.isFile()&&!s.isSymbolicLink()&&s.nlink===1&&s.uid===process.getuid()&&!(s.mode&0o077)&&s.size<65536,'DH025_UNSAFE_FILE');need(crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')===h,'DH025_EVIDENCE_DRIFT');}
function syncdir(p){const fd=fs.openSync(p,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
function write(p,v){const fd=fs.openSync(p,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(v)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}syncdir(path.dirname(p));}
function safeCode(e){const m=String(e?.message||'');return /^[A-Z][A-Z0-9_]{1,80}$/.test(m)?m:'DH025_UNCLASSIFIED';}
const CANCELLED=Object.freeze({"approval.json": "1b5fcf3166dd1470e4e86e15e2974e02573fa232c8321683e97fc7ca3766b1a3", "decision.json": "ac7f6340381ae502ec97f187f410040507e35cd74936a89ab149b4ad2fdfb2bd", "machine-result.json": "7beae09b14f42c75e6e7f49f3a8dcfd9ff791b15ba819d3aa87f2d04457eceab", "failure.json": "9e561720c9d6d4794b1cf4527ed78f183fdc41abc67426fe782c90f0b914f85b"});
const MACHINE_PIN='b786320f5d169e6987659e20ab2f6972dd64d40c3b5369ea7ab925b91ab4c51d';
const CANCELLED_MACHINE='CLINK.RETURN.DEVELOPMENT-HOST.008.20261126T052417055256Z.zip';
function assertNoGuest(runner,root){
 // Conservative process inventory: no second known Development Host runner or guest.
 for(const name of fs.readdirSync('/proc')){
  if(!/^\d+$/.test(name)||Number(name)===process.pid)continue;
  const p=path.join('/proc',name);
  try{
   if(fs.statSync(p).uid!==process.getuid())continue;
   const argv=fs.readFileSync(path.join(p,'cmdline')).toString().split('\0');
   const exe=path.basename(argv[0]||'');
   const isRunner=argv.some(a=>a===path.join(runner,'development_guest_008.py')||path.basename(a)==='development_guest_008.py');
   const isGuest=/^qemu-system-/.test(exe)&&argv.some(a=>a.includes(root+'/job-008-'));
   need(!isRunner&&!isGuest,'DH039_GUEST_STILL_ACTIVE');
  }catch(e){if(e.code==='ENOENT'||e.code==='ESRCH')continue;throw e;}
 }
}

// DH046: fixed delivery-only collection of the proven completed job. No execution authority.
const COMPLETED=Object.freeze({"approval.json": "6ef40490a592f56459521e217c43bbd4704879f33349492d1d029b983a80eb54", "decision.json": "ac7f6340381ae502ec97f187f410040507e35cd74936a89ab149b4ad2fdfb2bd", "machine-result.json": "a7448928a34b35fe827f3f8bd101846ab3b6fd28bf1c51892458067f3cefbd2e", "failure.json": "7f7094acc1dcfb7bce889c925dbb4d926ebf6b149335b3011788fa7939209b62"});
const COMPLETE_MACHINE="CLINK.RETURN.DEVELOPMENT-HOST.008.20261126T144725237962Z.zip", COMPLETE_MACHINE_PIN="24a1349780dab2cd248b0052b0b13c4a7cc256df39667cc361ce79c8e1d2eb62", COMPLETE_ARTIFACT="fd7f269a139d5f3501e633e4b31ed5ecdd174dc71d94498c8b1adee50597d22a";
function collectCompleted(prior,guestRoot,req){
 req.authorize();
 need(String(req.companionKey||'').toLowerCase()==='miss-flower:33a2bdcb8066e5549f90b314182605365d9a1431f2ece5d119443d7b925b847a','DH046_COMPANION_DENIED');
 privateDir(prior);const retry=path.join(prior,'retry-039');privateDir(retry);
 for(const [n,h] of Object.entries(PRIOR))verify(path.join(prior,n),h);
 for(const [n,h] of Object.entries(COMPLETED))verify(path.join(retry,n),h);
 const result=JSON.parse(fs.readFileSync(path.join(retry,'machine-result.json'),'utf8'));
 const root=path.join(guestRoot,'receipts');privateDir(guestRoot);privateDir(root);
 const machine=path.join(root,COMPLETE_MACHINE);
 need(result.status==='PASS'&&result.provider_calls===0&&result.artifact_sha256===COMPLETE_ARTIFACT&&result.receipt_path===machine,'DH046_RESULT_MISMATCH');
 verify(machine,COMPLETE_MACHINE_PIN);
 const dir=path.join(prior,'collection-046');
 const record={workflow:'development.smoke.v1',mode:'delivery-only',deliveryAuthorized:true,machineReceiptSha256:COMPLETE_MACHINE_PIN,artifact_sha256:COMPLETE_ARTIFACT,executionStarted:false,provider_calls:0};
 const records={'machine-result.json':result,'collection.json':record};
 req.authorize();
 // Atomic directory publication. Existing collection is read-only and idempotent.
 if(!fs.existsSync(dir)){
  const tmp=fs.mkdtempSync(path.join(prior,'.collection-046-'));
  try{for(const [n,v] of Object.entries(records))write(path.join(tmp,n),v);syncdir(tmp);fs.renameSync(tmp,dir);syncdir(prior);}finally{if(fs.existsSync(tmp))fs.rmSync(tmp,{recursive:true,force:true});}
 }
 privateDir(dir);
 for(const [n,v] of Object.entries(records))verify(path.join(dir,n),crypto.createHash('sha256').update(JSON.stringify(v)+'\n').digest('hex'));
 return {dir,result};
}

function createRecovery({prior,normal,eligible,approve,runnerFactory,progress=()=>{},publish,guestRoot=path.join(os.homedir(),'.local/share/phantomtronix-development-host'),checkGuest=assertNoGuest}){
 const previous=path.join(prior,'resume-025'),runner=path.join(prior,'runner');let active=null;
 async function handle(req){
  const text=typeof req.text==='string'?req.text.trim():'';
  if(/^\/development collect$/i.test(text)){
   if(active)return {text:'C.Link: Development work is active; collection is unavailable.'};
   try{
    const collected=collectCompleted(prior,guestRoot,req);
    await publish(collected.dir);
    req.authorize();
    return {text:'C.Link: Completed calculator collected. Two checks passed. Artifact SHA-256: '+COMPLETE_ARTIFACT+'. No new execution or provider request.',receipt:collected.result};
   }catch(e){return {text:'C.Link: Collection stopped ('+safeCode(e)+'). Completed work preserved; no new execution or provider request.'};}
  }
  const explicit=/^\/development retry$/i.test(text)||/^Miss Flower,? please retry the cancelled calculator assignment[.!]?$/i.test(text);
    if(!explicit&&!/^\/development resume$/i.test(text)&&(!eligible(req.text)||!fs.existsSync(prior)))return normal.handle(req);
  const dir=explicit?path.join(prior,'retry-039'):previous;
  if(active)return {text:'C.Link: Offline recovery already active.'};
  if(fs.existsSync(dir))return {text:'C.Link: Offline recovery already reserved. Inspect its receipt; no provider request occurred.'};
  if(!fs.existsSync(prior))return {text:'C.Link: No prior accepted development decision exists. No provider request occurred.'};
  const job={cancelled:false,owned:false,vm:null,cancelReason:null,dir};active=job;let stage='VERIFY_PRIOR';
  function check(){need(!job.cancelled,'DEVELOPMENT_CANCELLED');req.authorize();}
  try{
   privateDir(prior);privateDir(runner);
   for(const [n,h] of Object.entries(PRIOR))verify(path.join(prior,n),h);
   for(const [n,h] of Object.entries(RUNNER))verify(path.join(runner,n),h);
   need(!fs.existsSync(path.join(prior,'machine-result.json'))&&!fs.existsSync(path.join(prior,'tool-result.json')),'DH025_PRIOR_OUTCOME_EXISTS');
   if(explicit){stage='VERIFY_CANCELLED_ATTEMPT';privateDir(previous);
   for(const [n,h] of Object.entries(CANCELLED))verify(path.join(previous,n),h);
   need(!fs.existsSync(path.join(previous,'tool-result.json')),'DH039_PRIOR_SUCCESS_EXISTS');
   const priorMachine=JSON.parse(fs.readFileSync(path.join(previous,'machine-result.json'),'utf8'));
   const receipt=path.join(guestRoot,'receipts',CANCELLED_MACHINE);
   need(priorMachine.status==='CANCELLED'&&priorMachine.provider_calls===0&&priorMachine.artifact_sha256===null&&priorMachine.receipt_path===receipt,'DH039_CANCELLED_RECEIPT_MISMATCH');
   privateDir(guestRoot);privateDir(path.join(guestRoot,'receipts'));verify(receipt,MACHINE_PIN);}
   stage='CHECK_NO_SURVIVING_GUEST';checkGuest(runner,guestRoot);
   stage='INITIAL_SCOPE';check();
   stage='LOCAL_APPROVAL';if(!await approve(explicit))return {text:'C.Link: Offline recovery declined. No provider request occurred.'};
   stage='POST_APPROVAL_SCOPE';check();
   stage='CHECK_NO_SURVIVING_GUEST';checkGuest(runner,guestRoot);
   stage='RESERVE_RETRY';fs.mkdirSync(dir,{mode:0o700});job.owned=true;syncdir(prior);
   write(path.join(dir,'approval.json'),{workflow:'development.smoke.v1',mode:explicit?'offline-cancelled-retry':'offline-recovery',...(explicit?{cancelledReceiptSha256:MACHINE_PIN}:{}),priorDecisionSha256:PRIOR['decision.json'],priorReservationSha256:PRIOR['live-decision-reserved.json'],humanAuthorized:true,provider_calls:0});
   stage='CREATE_RUNNER';job.vm=runnerFactory(runner,progress);
   stage='PRE_EXECUTION_SCOPE';check();
   stage='CHECK_NO_SURVIVING_GUEST';checkGuest(runner,guestRoot);
   stage='RUN_VM';write(path.join(dir,'decision.json'),{priorDecisionVerified:true,providerCallsThisAttempt:0,executionStarted:true});
   progress('Offline recovery executing the previously approved calculator workflow.');
   const result=await job.vm.run();
   write(path.join(dir,'machine-result.json'),{status:result.status,artifact_sha256:result.artifact_sha256||null,provider_calls:result.provider_calls,receipt_path:result.receipt_path||null});
   if(result.status==='CANCELLED'){stage='RUN_VM';throw Error('DEVELOPMENT_CANCELLED');}
   stage='VERIFY_RESULT';need(result.status==='PASS'&&/^[a-f0-9]{64}$/.test(result.artifact_sha256||'')&&result.provider_calls===0,'DH025_MACHINE_NOT_ACCEPTED');
   stage='FINAL_SCOPE';check();
   write(path.join(dir,'tool-result.json'),{receiptReturned:true,artifact_sha256:result.artifact_sha256});
   return {text:'C.Link verified offline recovery: Two checks passed. Artifact SHA-256: '+result.artifact_sha256+'. New provider calls: 0.',receipt:result};
  }catch(e){
   const code=safeCode(e);
   if(job.owned){try{write(path.join(dir,'failure.json'),{stage,code,cancellationReason:job.cancelReason||(code==='DEVELOPMENT_CANCELLED'?'EXTERNAL_OR_UNOBSERVED':null)});}catch(_){}}
   return {text:stage==='FINAL_SCOPE'?'C.Link: Machine result saved; delivery authorization lost. Inspect its receipt. No new provider request occurred.':'C.Link: Offline recovery stopped at '+stage+' ('+code+'). No new provider request occurred.'};
  }finally{
   if(job.owned){try{await publish(dir);}catch(_){progress('Offline recovery receipt export failed; local evidence preserved.');}}
   active=null;progress('Development acceptance finished.');
  }
 }
 function cancel(reason='UNSPECIFIED_NATIVE_CANCEL'){
  if(!active)return false;
  if(!active.cancelled){
   active.cancelled=true;active.cancelReason=['KEYBOARD_CANCEL','CARTRIDGE_CLOSED','APPLICATION_QUIT','OS_SIGTERM','OS_SIGINT','UNSPECIFIED_NATIVE_CANCEL'].includes(reason)?reason:'UNSPECIFIED_NATIVE_CANCEL';
   if(active.owned){try{write(path.join(active.dir,'cancellation-request.json'),{reason:active.cancelReason,at:new Date().toISOString()});}catch(_){}}
   progress('Cancellation requested: '+active.cancelReason+'. Waiting for the guest to stop.');
   try{active.vm?.cancel();}catch(_){}
  }
  return true;
 }
 return Object.freeze({handle,cancel});
}
module.exports={createRecovery,assertNoGuest};

return module.exports;})();
const dh039RenderProgress=(text,done)=>{
 const id='clink-native-development-progress-039';let el=document.getElementById(id);
 if(done){if(el)el.remove();return;}
 if(!el){el=document.createElement('div');el.id=id;el.setAttribute('role','status');el.setAttribute('aria-live','polite');
 Object.assign(el.style,{position:'fixed',top:'3px',left:'180px',right:'8px',height:'52px',boxSizing:'border-box',zIndex:'2147483647',background:'#102922',border:'1px solid #86f7b2',color:'#d6ffe3',padding:'5px 10px',font:'bold 12px monospace',lineHeight:'18px',whiteSpace:'normal',overflow:'hidden',pointerEvents:'none'});
 document.body.appendChild(el);}
 el.textContent=text;
};
let dh039ProgressTimer=null,dh039Started=0,dh039Status='';
const dh025Progress=message=>{
 try{
 const raw=String(message);const done=raw==='Development acceptance finished.';
 log('development.acceptance.progress',{message:raw.slice(0,160)});
 if(done){if(dh039ProgressTimer)clearInterval(dh039ProgressTimer);dh039ProgressTimer=null;dh039Started=0;}
 else{
 if(!dh039Started)dh039Started=Date.now();
 if(/Cancellation requested:/.test(raw))dh039Status='Cancelling — waiting for guest shutdown';
 else if(/Guest active:/.test(raw))dh039Status='Isolated Ubuntu guest running — allow up to 10 minutes';
 else if(/Starting isolated guest/.test(raw))dh039Status='Starting isolated Ubuntu guest';
 else if(/Verifying cached Ubuntu image/.test(raw))dh039Status='Verifying cached Ubuntu image';
 else if(/DEVELOPMENT HOST 008:/.test(raw))dh039Status='Guest returned — verifying result and exporting receipt';
 else if(!dh039Status)dh039Status='Preparing offline calculator assignment';
 }
 const render=()=>{
  if(!windowMain||windowMain.isDestroyed())return;
  const wc=windowMain.webContents,local=require('node:url').pathToFileURL(path.join(__dirname,'renderer','index.html')).href;
  if(wc.isDestroyed()||wc.getURL().split(/[?#]/)[0]!==local)return;
  const elapsed=Math.floor((Date.now()-dh039Started)/1000);
  const text='DEVELOPMENT HOST · '+dh039Status+' · '+elapsed+'s · No API request · Ctrl+Shift+X cancels';
  void wc.executeJavaScript('('+dh039RenderProgress.toString()+')('+JSON.stringify(text)+','+JSON.stringify(done)+')',false).catch(()=>{});
 };
 if(windowMain&&!windowMain.isDestroyed()){windowMain.setProgressBar(done?-1:2);windowMain.setTitle(done?dh017OriginalTitle:'C.Link — Offline Development Host active');}
 render();if(done)dh039Status='';else if(!dh039ProgressTimer)dh039ProgressTimer=setInterval(render,1000);
 }catch(_){}
};
const dh025Recovery=dh025Module.createRecovery({
 prior:dh017State,normal:developmentAcceptance.developmentTool,eligible:dh017.tool.eligible,
 approve:async(retry)=>{
   if(!windowMain||windowMain.isDestroyed())return false;
   const r=await dialog.showMessageBox(windowMain,{type:'question',title:'Development Host — offline recovery',
    message:retry?'Retry the confirmed cancelled calculator assignment?':'Resume the previously accepted calculator assignment?',
    detail:'This is one offline execution of the recorded decision. Keep Command open; progress appears in the top bar. Allow up to 10 minutes. No new API request. Ctrl+Shift+X cancels.',
    buttons:['Cancel',retry?'Retry offline':'Resume offline'],defaultId:0,cancelId:0,noLink:true});
   return r.response===1;
 },
 runnerFactory:(dir,progress)=>dh017.tool.createVmRunner(dir,progress),
 progress:dh025Progress,
 publish:dir=>new Promise((resolve,reject)=>{
   const source=dh017ReceiptSource.replace("'017-LIVE'","'039-RETRY'").replace("'tool-result.json','failure.json'","'tool-result.json','failure.json','cancellation-request.json','collection.json'");
   cp.execFile('/usr/bin/python3',['-B','-c',source,dir,app.getPath('downloads')],{timeout:20000,env:{PATH:'/usr/bin:/bin',HOME:os.homedir(),LANG:'C.UTF-8'}},(err,stdout)=>{
      if(err)return reject(Error('DEVELOPMENT_RECEIPT_EXPORT_FAILED'));
      log('development.acceptance.receipt',{path:String(stdout).trim()});resolve();
   });
 })
});


// COMMAND ENGINEERING: narrow trusted dispatch; separate modular service bundle.
const ce007Scope=(()=>{const module={exports:{}};const exports=module.exports;
'use strict';
// Scope only the engineering turn; the normal native provider pipeline remains unchanged.
const {AsyncLocalStorage}=require('node:async_hooks');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const MODEL='gpt-5.6-luna', MAX_BYTES=65536, MAX_OUTPUT=4096;
function need(v,e){if(!v)throw Error(e);}
function createScope(transport){
 const storage=new AsyncLocalStorage();let active=null;
 async function run({authorize,jobDir,budget,decide},prompt){
  need(budget.maxRequests===1&&budget.maxInputBytes===MAX_BYTES&&budget.maxOutputTokens===MAX_OUTPUT,'ENGINEERING_BUDGET');
  need(typeof authorize==='function'&&typeof decide==='function','ENGINEERING_CALLBACK');
  need(!active,'ENGINEERING_SCOPE_BUSY');
  const s={authorize,jobDir,used:false,settled:false,cancelled:false,handle:null};active=s;
  try{const result=await storage.run(s,()=>decide(prompt));need(!s.cancelled,'ENGINEERING_CANCELLED');return result;}finally{s.settled=true;active=null;}
 }
 async function send(req){
  const s=storage.getStore();if(!s)return transport(req);
  need(!s.used&&!s.settled&&!s.cancelled,'ENGINEERING_REQUEST_LIMIT');s.authorize();
  const p=req.payload;need(req.provider==='openai'&&p?.model===MODEL&&typeof p.input==='string'&&typeof p.instructions==='string'&&p.store===false&&p.max_output_tokens===MAX_OUTPUT&&Object.keys(p).every(k=>['model','input','instructions','max_output_tokens','store'].includes(k))&&Buffer.byteLength(JSON.stringify(p))<=MAX_BYTES,'ENGINEERING_WIRE_BOUNDS');
  s.used=true;
  const f=fs.openSync(path.join(s.jobDir,'wire-reservation.json'),'wx',0o600);
  try{fs.writeFileSync(f,JSON.stringify({provider:'openai',model:MODEL,maxOutputTokens:MAX_OUTPUT,inputBytes:Buffer.byteLength(JSON.stringify(p)),payloadSha256:crypto.createHash('sha256').update(JSON.stringify(p)).digest('hex')})+'\n');fs.fsyncSync(f);}finally{fs.closeSync(f);}
  const d=fs.openSync(s.jobDir,'r');try{fs.fsyncSync(d);}finally{fs.closeSync(d);}
  let timer;
  try{
   const result=await Promise.race([transport({...req,onHandle:h=>{s.handle=h;req.onHandle?.(h);if(s.settled||s.cancelled)h?.cancel?.();}}),new Promise((_,reject)=>{timer=setTimeout(()=>{s.settled=true;s.handle?.cancel?.();reject(Error('ENGINEERING_WIRE_TIMEOUT'));},90000);})]);
   need(!s.cancelled,'ENGINEERING_CANCELLED');
   const u=result?.body?.usage;
   if(result?.statusCode>=200&&result.statusCode<300){
    need(Number.isInteger(u?.input_tokens)&&u.input_tokens>=0&&u.input_tokens<=MAX_BYTES&&Number.isInteger(u?.output_tokens)&&u.output_tokens>=0&&u.output_tokens<=MAX_OUTPUT,'ENGINEERING_USAGE_UNVERIFIED');
    const m=result.body.model;need(typeof m==='string'&&(m===MODEL||m.startsWith(MODEL+'-')),'ENGINEERING_MODEL_MISMATCH');
    const f=fs.openSync(path.join(s.jobDir,'wire-result.json'),'wx',0o600);try{fs.writeFileSync(f,JSON.stringify({model:m,inputTokens:u.input_tokens,outputTokens:u.output_tokens,statusCode:result.statusCode})+'\n');fs.fsyncSync(f);}finally{fs.closeSync(f);}
   }
   return result;
  }finally{clearTimeout(timer);s.settled=true;}
 }
 function cancel(){if(!active)return false;active.cancelled=true;try{active.handle?.cancel?.();}catch(_){}return true;}
 return Object.freeze({run,transport:send,cancel});
}
module.exports={createScope,MODEL,MAX_BYTES,MAX_OUTPUT};

return module.exports.createScope(developmentAcceptance.transport);})();
const ce007IsDevelopment=text => typeof text==='string' && text.length<=4096 &&
  /^(?:(?:hey|hello|hi)[,!]?\s+)?(?:miss flower[,!]?\s*)?(?:please[, ]+)?(?:we need\b|i need\b|(?:could|can|would) you\s+(?:please\s+)?(?:make|build|create|develop|add|modify|update|change|improve|fix)\b|(?:make|build|create|develop|add|modify|update|change|improve|fix)\b)/i.test(text.trim());
const ce007Bundle={"dispatch.cjs":{"sha256":"29b6e8a47c3252802211345b62db11ae1e1c0db86e89e1fc2d2f55463cdbce73","base64":"J3VzZSBzdHJpY3QnOwovLyBIb3N0LXNpZGUgcm91dGluZyBvbmx5OyBubyByZW5kZXJlciBJUEMgb3IgcHJvdmlkZXIgY3JlZGVudGlhbHMuCmNvbnN0IGlzRGV2ZWxvcG1lbnQgPSB0ZXh0ID0+IHR5cGVvZiB0ZXh0PT09J3N0cmluZycgJiYgdGV4dC5sZW5ndGg8PTQwOTYgJiYKICAvXig/Oig/OmhleXxoZWxsb3xoaSlbLCFdP1xzKyk/KD86bWlzcyBmbG93ZXJbLCFdP1xzKik/KD86cGxlYXNlWywgXSspPyg/OndlIG5lZWRcYnxpIG5lZWRcYnwoPzpjb3VsZHxjYW58d291bGQpIHlvdVxzKyg/OnBsZWFzZVxzKyk/KD86bWFrZXxidWlsZHxjcmVhdGV8ZGV2ZWxvcHxhZGR8bW9kaWZ5fHVwZGF0ZXxjaGFuZ2V8aW1wcm92ZXxmaXgpXGJ8KD86bWFrZXxidWlsZHxjcmVhdGV8ZGV2ZWxvcHxhZGR8bW9kaWZ5fHVwZGF0ZXxjaGFuZ2V8aW1wcm92ZXxmaXgpXGIpL2kudGVzdCh0ZXh0LnRyaW0oKSk7CmZ1bmN0aW9uIGNyZWF0ZURpc3BhdGNoKHtsZWdhY3ksIHNlcnZpY2V9KSB7CiAgaWYodHlwZW9mIGxlZ2FjeT8uaGFuZGxlIT09J2Z1bmN0aW9uJ3x8dHlwZW9mIHNlcnZpY2U/LmhhbmRsZSE9PSdmdW5jdGlvbicpIHRocm93IEVycm9yKCdESVNQQVRDSF9DT05GSUdVUkFUSU9OJyk7CiAgcmV0dXJuIE9iamVjdC5mcmVlemUoe2FzeW5jIGhhbmRsZShyZXEpewogICAgLy8gUHJlc2VydmUgb2xkIGNvbGxlY3Rpb24vcmVjb3ZlcnkgYW5kIHNtb2tlIHJvdXRpbmcsIGluY2x1ZGluZyBpdHMgZGVuaWFsIHNlbWFudGljcy4KICAgIGNvbnN0IG9sZD1hd2FpdCBsZWdhY3kuaGFuZGxlKHJlcSk7CiAgICBpZihvbGQhPT1udWxsKXJldHVybiBvbGQ7CiAgICBpZighaXNEZXZlbG9wbWVudChyZXEudGV4dCkpcmV0dXJuIG51bGw7CiAgICByZXEuYXV0aG9yaXplKCk7CiAgICAvLyBTZXJ2aWNlIHJlY2VpdmVzIG9ubHkgYSBib3VuZGVkIHRhc2ssIGlkZW50aXR5IGFuZCB0cnVzdGVkIGNhbGxiYWNrcywgbmV2ZXIgcmF3IElQQy9ldmVudC4KICAgIGNvbnN0IHJlc3VsdD1hd2FpdCBzZXJ2aWNlLmhhbmRsZShPYmplY3QuZnJlZXplKHt0ZXh0OnJlcS50ZXh0LnRyaW0oKSxwcm92aWRlcjpyZXEucHJvdmlkZXIsY29tcGFuaW9uS2V5OnJlcS5jb21wYW5pb25LZXksYXV0aG9yaXplOnJlcS5hdXRob3JpemUsLi4uKHR5cGVvZiByZXEuZGVjaWRlRW5naW5lZXJpbmc9PT0nZnVuY3Rpb24nP3tkZWNpZGVFbmdpbmVlcmluZzpyZXEuZGVjaWRlRW5naW5lZXJpbmd9Ont9KX0pKTsKICAgIHJlcS5hdXRob3JpemUoKTsgLy8gZGVsaXZlcnkgc2NvcGU7IGR1cmFibGUgc2VydmljZSByZXN1bHQgaXMgbm90IHJvbGxlZCBiYWNrIG9uIGRlbmllZCBkZWxpdmVyeQogICAgaWYoIXJlc3VsdHx8dHlwZW9mIHJlc3VsdC50ZXh0IT09J3N0cmluZyd8fHJlc3VsdC50ZXh0Lmxlbmd0aD40MDk2KXRocm93IEVycm9yKCdESVNQQVRDSF9CQURfUkVTVUxUJyk7CiAgICByZXR1cm4ge3RleHQ6cmVzdWx0LnRleHR9OwogIH19KTsKfQptb2R1bGUuZXhwb3J0cz17Y3JlYXRlRGlzcGF0Y2gsaXNEZXZlbG9wbWVudH07Cg=="},"service.cjs":{"sha256":"c696a4bf4e5c7e6ca4d2c91c155768ca37cc2657adc0463c22874b4edc08281e","base64":"J3VzZSBzdHJpY3QnOwovLyBUcnVzdGVkIGxvY2FsIHNlcnZpY2UgcHJvdG90eXBlLiBNb2RlbCBnZW5lcmF0aW9uIGlzIGRlcGVuZGVuY3ktaW5qZWN0ZWQ7Ci8vIG5vIGRlZmF1bHQgbGl2ZSBwcm92aWRlciwgbm8gY3JlZGVudGlhbCBhY2Nlc3MsIG5vIGluc3RhbGxhdGlvbiBvciBwdWJsaWNhdGlvbi4KY29uc3QgZnM9cmVxdWlyZSgnbm9kZTpmcycpLHBhdGg9cmVxdWlyZSgnbm9kZTpwYXRoJyksY3J5cHRvPXJlcXVpcmUoJ25vZGU6Y3J5cHRvJyk7CmNvbnN0IHtzcGF3bn09cmVxdWlyZSgnbm9kZTpjaGlsZF9wcm9jZXNzJyk7CmNvbnN0IHNoYT14PT5jcnlwdG8uY3JlYXRlSGFzaCgnc2hhMjU2JykudXBkYXRlKHgpLmRpZ2VzdCgnaGV4Jyk7CmNvbnN0IGpzb249eD0+SlNPTi5zdHJpbmdpZnkoeCkrJ1xuJzsKZnVuY3Rpb24gYXNzZXJ0KG9rLGNvZGUpe2lmKCFvayl0aHJvdyBFcnJvcihjb2RlKTt9CmZ1bmN0aW9uIHBlcnNpc3QoZGlyLG5hbWUsb2JqKXsKICBjb25zdCBmZD1mcy5vcGVuU3luYyhwYXRoLmpvaW4oZGlyLG5hbWUpLCd3eCcsMG82MDApOwogIHRyeXtmcy53cml0ZUZpbGVTeW5jKGZkLGpzb24ob2JqKSk7ZnMuZnN5bmNTeW5jKGZkKTt9ZmluYWxseXtmcy5jbG9zZVN5bmMoZmQpO30KICBjb25zdCBkPWZzLm9wZW5TeW5jKGRpciwncicpO3RyeXtmcy5mc3luY1N5bmMoZCk7fWZpbmFsbHl7ZnMuY2xvc2VTeW5jKGQpO30KfQpmdW5jdGlvbiByZWFkKGRpcixuYW1lKXtyZXR1cm4gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMocGF0aC5qb2luKGRpcixuYW1lKSwndXRmOCcpKTt9CmZ1bmN0aW9uIHByaXZhdGVEaXIocCl7Y29uc3Qgcz1mcy5sc3RhdFN5bmMocCk7YXNzZXJ0KHMuaXNEaXJlY3RvcnkoKSYmIXMuaXNTeW1ib2xpY0xpbmsoKSYmKHMubW9kZSYwbzA3Nyk9PT0wJiYodHlwZW9mIHByb2Nlc3MuZ2V0dWlkIT09J2Z1bmN0aW9uJ3x8cy51aWQ9PT1wcm9jZXNzLmdldHVpZCgpKSwnUFJJVkFURV9TVEFURV9SRVFVSVJFRCcpO30KZnVuY3Rpb24gY3JlYXRlQnVpbGRlcih7cHl0aG9uPScvdXNyL2Jpbi9weXRob24zJyxzY3JpcHQsc2RrLGJhc2VsaW5lRm9yPSgpPT5udWxsfSl7CiAgcmV0dXJuIGFzeW5jICh7Z3JhbnQscHJvcG9zYWwsb3V0cHV0fSk9PnsKICAgIGNvbnN0IGFyZ3M9WyctQicsc2NyaXB0LHNkayxvdXRwdXRdLGJhc2U9YmFzZWxpbmVGb3IoZ3JhbnQpOwogICAgaWYoYmFzZSlhcmdzLnB1c2goYmFzZSk7CiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUscmVqZWN0KT0+ewogICAgICBjb25zdCBwPXNwYXduKHB5dGhvbixhcmdzLHtzaGVsbDpmYWxzZSxlbnY6e1BBVEg6Jy91c3IvYmluOi9iaW4nLExBTkc6J0MuVVRGLTgnLEhPTUU6cGF0aC5kaXJuYW1lKG91dHB1dCksUFlUSE9ORE9OVFdSSVRFQllURUNPREU6JzEnfSxzdGRpbzpbJ3BpcGUnLCdwaXBlJywncGlwZSddfSk7CiAgICAgIGxldCBvdXQ9JycsZXJyPWZhbHNlLGZpbmlzaGVkPWZhbHNlOwogICAgICBjb25zdCB0aW1lcj1zZXRUaW1lb3V0KCgpPT57ZXJyPXRydWU7cC5raWxsKCdTSUdLSUxMJyk7fSw5MDAwMCk7CiAgICAgIGNvbnN0IGRvbmU9KGUscik9PntpZihmaW5pc2hlZClyZXR1cm47ZmluaXNoZWQ9dHJ1ZTtjbGVhclRpbWVvdXQodGltZXIpO2U/cmVqZWN0KGUpOnJlc29sdmUocik7fTsKICAgICAgcC5vbignZXJyb3InLCgpPT5kb25lKEVycm9yKCdCVUlMRF9TVEFSVCcpKSk7cC5zdGRpbi5vbignZXJyb3InLCgpPT57ZXJyPXRydWU7fSk7CiAgICAgIHAuc3Rkb3V0Lm9uKCdkYXRhJyxiPT57b3V0Kz1iO2lmKG91dC5sZW5ndGg+MTYzODQpe2Vycj10cnVlO3Aua2lsbCgnU0lHS0lMTCcpO319KTsKICAgICAgcC5zdGRlcnIucmVzdW1lKCk7CiAgICAgIHAub24oJ2Nsb3NlJyxjPT57aWYoYyE9PTB8fGVycilyZXR1cm4gZG9uZShFcnJvcignQlVJTERfRkFJTEVEJykpO3RyeXtkb25lKG51bGwsSlNPTi5wYXJzZShvdXQpKTt9Y2F0Y2goXyl7ZG9uZShFcnJvcignQlVJTERfUkVDRUlQVCcpKTt9fSk7CiAgICAgIHAuc3RkaW4uZW5kKGpzb24oe2dyYW50LHByb3Bvc2FsfSkpOwogICAgfSk7CiAgfTsKfQpmdW5jdGlvbiBjcmVhdGVTZXJ2aWNlKHtzdGF0ZURpcixhcHByb3ZlSm9iLGdlbmVyYXRlLGJ1aWxkLG5vdz1EYXRlLm5vd30pewogIHByaXZhdGVEaXIoc3RhdGVEaXIpOwogIGFzc2VydChbYXBwcm92ZUpvYixnZW5lcmF0ZSxidWlsZF0uZXZlcnkoZj0+dHlwZW9mIGY9PT0nZnVuY3Rpb24nKSwnU0VSVklDRV9DT05GSUdVUkFUSU9OJyk7CiAgbGV0IGJ1c3k9ZmFsc2U7CiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlKHJlcSl7CiAgICBpZihidXN5KXJldHVybiB7dGV4dDonRGV2ZWxvcG1lbnQgc2VydmljZSBidXN5Lid9OwogICAgYnVzeT10cnVlOwogICAgdHJ5ewogICAgICByZXEuYXV0aG9yaXplKCk7CiAgICAgIGNvbnN0IGE9YXdhaXQgYXBwcm92ZUpvYih7dGV4dDpyZXEudGV4dCxwcm92aWRlcjpyZXEucHJvdmlkZXIsY29tcGFuaW9uS2V5OnJlcS5jb21wYW5pb25LZXksYXV0aG9yaXplOnJlcS5hdXRob3JpemV9KTsKICAgICAgcmVxLmF1dGhvcml6ZSgpOwogICAgICBpZighYSlyZXR1cm4ge3RleHQ6J0RldmVsb3BtZW50IGFzc2lnbm1lbnQgbm90IGF1dGhvcml6ZWQuIE5vIG1vZGVsIGdlbmVyYXRpb24gb3IgYnVpbGQgb2NjdXJyZWQuJ307CiAgICAgIGFzc2VydChhLmh1bWFuQXV0aG9yaXplZD09PXRydWUmJmEucmVxdWVzdFNoYTI1Nj09PXNoYShyZXEudGV4dCkmJmEuY29tcGFuaW9uS2V5PT09cmVxLmNvbXBhbmlvbktleSYmYS5wcm92aWRlcj09PXJlcS5wcm92aWRlciwnR1JBTlRfU0NPUEUnKTsKICAgICAgYXNzZXJ0KC9eW2EtZjAtOV17MzJ9JC8udGVzdChhLmpvYklkKSYmTnVtYmVyLmlzU2FmZUludGVnZXIoYS5leHBpcmVzQXQpLCdHUkFOVF9FWFBJUllfT1JfSUQnKTsKICAgICAgYXNzZXJ0KGEuYnVkZ2V0JiZhLmJ1ZGdldC5tYXhSZXF1ZXN0cz09PTEmJk51bWJlci5pc0ludGVnZXIoYS5idWRnZXQubWF4T3V0cHV0VG9rZW5zKSYmYS5idWRnZXQubWF4T3V0cHV0VG9rZW5zPjAmJmEuYnVkZ2V0Lm1heE91dHB1dFRva2Vuczw9ODE5MiYmTnVtYmVyLmlzSW50ZWdlcihhLmJ1ZGdldC5tYXhJbnB1dEJ5dGVzKSYmYS5idWRnZXQubWF4SW5wdXRCeXRlcz4wJiZhLmJ1ZGdldC5tYXhJbnB1dEJ5dGVzPD0xMzEwNzIsJ0JVREdFVF9TQ09QRScpOwogICAgICBhc3NlcnQoYS5ncmFudCYmdHlwZW9mIGEuZ3JhbnQuaWQ9PT0nc3RyaW5nJywnQ0FSVFJJREdFX0dSQU5UJyk7CiAgICAgIGNvbnN0IGRpcj1wYXRoLmpvaW4oc3RhdGVEaXIsYS5qb2JJZCk7CiAgICAgIGFzc2VydChmcy5leGlzdHNTeW5jKGRpcil8fG5vdygpPGEuZXhwaXJlc0F0LCdHUkFOVF9FWFBJUllfT1JfSUQnKTsKICAgICAgdHJ5e2ZzLm1rZGlyU3luYyhkaXIse21vZGU6MG83MDB9KTt9Y2F0Y2goZSl7CiAgICAgICAgaWYoZS5jb2RlIT09J0VFWElTVCcpdGhyb3cgZTsKICAgICAgICBwcml2YXRlRGlyKGRpcik7CiAgICAgICAgY29uc3Qgb3JpZ2luYWw9cmVhZChkaXIsJ2dyYW50Lmpzb24nKTsKICAgICAgICBhc3NlcnQoc2hhKGpzb24ob3JpZ2luYWwpKT09PXNoYShqc29uKGEpKSwnSk9CX0dSQU5UX0NIQU5HRUQnKTsKICAgICAgICBpZihmcy5leGlzdHNTeW5jKHBhdGguam9pbihkaXIsJ3Jlc3VsdC5qc29uJykpKXtjb25zdCByPXJlYWQoZGlyLCdyZXN1bHQuanNvbicpO3JldHVybiB7dGV4dDonRXhpc3Rpbmcgam9iICcrYS5qb2JJZCsnOiAnK3Iuc3RhdHVzKycuIE5vIHJlcGVhdCBleGVjdXRpb24uJ307fQogICAgICAgIHJldHVybiB7dGV4dDonRXhpc3Rpbmcgam9iICcrYS5qb2JJZCsnIHJlc2VydmVkIG9yIGludGVycnVwdGVkLiBObyByZXBlYXQgZ2VuZXJhdGlvbi4nfTsKICAgICAgfQogICAgICBwZXJzaXN0KGRpciwnZ3JhbnQuanNvbicsYSk7CiAgICAgIC8vIFJlc2VydmUgYmVmb3JlIHRoZSBzaW5nbGUgbW9kZWwgYWRhcHRlciBpbnZvY2F0aW9uLiBBZGFwdGVyIE1VU1QgZW5mb3JjZSBpdHMgYWN0dWFsIHdpcmUgYnVkZ2V0OwogICAgICAvLyB0aGlzIHNlcnZpY2UgZG9lcyBub3QgcHJvdmlkZSBhIHByb3ZpZGVyIGJpbGxpbmcgZ3VhcmFudGVlIG9yIGVuYWJsZSBhIGxpdmUgYWRhcHRlci4KICAgICAgcmVxLmF1dGhvcml6ZSgpOyBhc3NlcnQobm93KCk8YS5leHBpcmVzQXQsJ0dSQU5UX0VYUElSRUQnKTsKICAgICAgcGVyc2lzdChkaXIsJ3Jlc2VydmF0aW9uLmpzb24nLHtyZXF1ZXN0U2hhMjU2OmEucmVxdWVzdFNoYTI1NixtYXhSZXF1ZXN0czoxLGJ1ZGdldDphLmJ1ZGdldH0pOwogICAgICB0cnl7CiAgICAgICAgY29uc3QgcHJvcG9zYWw9YXdhaXQgZ2VuZXJhdGUoe29iamVjdGl2ZTpyZXEudGV4dCxncmFudDphLmdyYW50LGJ1ZGdldDphLmJ1ZGdldCxqb2JEaXI6ZGlyLGF1dGhvcml6ZTpyZXEuYXV0aG9yaXplLGRlY2lkZUVuZ2luZWVyaW5nOnJlcS5kZWNpZGVFbmdpbmVlcmluZ30pOwogICAgICAgIGFzc2VydChwcm9wb3NhbCYmdHlwZW9mIHByb3Bvc2FsPT09J29iamVjdCcmJiFBcnJheS5pc0FycmF5KHByb3Bvc2FsKSYmT2JqZWN0LmtleXMocHJvcG9zYWwpLmxlbmd0aD09PTEmJk9iamVjdC5oYXNPd24ocHJvcG9zYWwsJ2ZpbGVzJykmJkJ1ZmZlci5ieXRlTGVuZ3RoKGpzb24ocHJvcG9zYWwpKTw9MTA0ODU3NiwnUFJPUE9TQUxfTElNSVQnKTsKICAgICAgICBwZXJzaXN0KGRpciwncHJvcG9zYWwuanNvbicscHJvcG9zYWwpOwogICAgICAgIC8vIFRoZSBhbHJlYWR5IGF1dGhvcml6ZWQgbG9jYWwsIHVuc2lnbmVkIGRhdGEtb25seSBidWlsZCBkb2VzIG5vdCByZXF1aXJlIGEgZm9jdXNlZCBVSS4KICAgICAgICAvLyBQcm92aWRlciBhZG1pc3Npb24gYW5kIGRlbGl2ZXJ5IHJlbWFpbiBnYXRlZDsgbm8gaW5zdGFsbCBvciBwdWJsaXNoIGlzIHBlcm1pdHRlZCBoZXJlLgogICAgICAgIGFzc2VydChub3coKTxhLmV4cGlyZXNBdCwnR1JBTlRfRVhQSVJFRCcpOwogICAgICAgIGNvbnN0IHI9YXdhaXQgYnVpbGQoe2dyYW50OmEuZ3JhbnQscHJvcG9zYWwsb3V0cHV0OnBhdGguam9pbihkaXIsJ2NhbmRpZGF0ZScpfSk7CiAgICAgICAgYXNzZXJ0KHI/LnN0YXR1cz09PSdVTlNJR05FRF9DQU5ESURBVEUnJiYvXlthLWYwLTldezY0fSQvLnRlc3Qoci5zaGEyNTYpJiZyLnB1Ymxpc2hlZD09PWZhbHNlJiZyLmluc3RhbGxlZD09PWZhbHNlJiZyLmZ1bmN0aW9uYWxfdGVzdGVkPT09ZmFsc2UsJ0JVSUxEX1JFQ0VJUFQnKTsKICAgICAgICBwZXJzaXN0KGRpciwncmVzdWx0Lmpzb24nLHsuLi5yLGpvYklkOmEuam9iSWQsc3RhdHVzOidVTlNJR05FRF9DQU5ESURBVEUnfSk7CiAgICAgICAgcmV0dXJuIHt0ZXh0OidDYW5kaWRhdGUgYnVpbHQ6ICcrYS5ncmFudC5pZCsnICcrYS5ncmFudC52ZXJzaW9uKycuIEZ1bmN0aW9uYWwgdGVzdGluZyBhbmQgcmVsZWFzZSBhcHByb3ZhbCBwZW5kaW5nLiBKb2IgJythLmpvYklkKycuJ307CiAgICAgIH1jYXRjaChlKXsKICAgICAgICBwZXJzaXN0KGRpciwncmVzdWx0Lmpzb24nLHtqb2JJZDphLmpvYklkLHN0YXR1czonRkFJTEVEX09SX0lOVEVSUlVQVEVEJyxyZWFzb246L15bQS1aMC05X117MSw4MH0kLy50ZXN0KGU/Lm1lc3NhZ2V8fCcnKT9lLm1lc3NhZ2U6J1NFUlZJQ0VfRkFJTEVEJ30pOwogICAgICAgIHJldHVybiB7dGV4dDonRGV2ZWxvcG1lbnQgYXNzaWdubWVudCBmYWlsZWQgb3Igd2FzIGludGVycnVwdGVkLiBKb2IgJythLmpvYklkKycuIE5vIGF1dG9tYXRpYyByZXRyeS4nfTsKICAgICAgfQogICAgfWZpbmFsbHl7YnVzeT1mYWxzZTt9CiAgfQogIHJldHVybiBPYmplY3QuZnJlZXplKHtoYW5kbGV9KTsKfQptb2R1bGUuZXhwb3J0cz17Y3JlYXRlU2VydmljZSxjcmVhdGVCdWlsZGVyLHNoYX07Cg=="},"provider_scope.cjs":{"sha256":"c95d3d59d6dc7ea400e4fd1f2f9a4f824d833d4d6e50448c29359095049edc55","base64":"J3VzZSBzdHJpY3QnOwovLyBTY29wZSBvbmx5IHRoZSBlbmdpbmVlcmluZyB0dXJuOyB0aGUgbm9ybWFsIG5hdGl2ZSBwcm92aWRlciBwaXBlbGluZSByZW1haW5zIHVuY2hhbmdlZC4KY29uc3Qge0FzeW5jTG9jYWxTdG9yYWdlfT1yZXF1aXJlKCdub2RlOmFzeW5jX2hvb2tzJyk7CmNvbnN0IGZzPXJlcXVpcmUoJ25vZGU6ZnMnKSxwYXRoPXJlcXVpcmUoJ25vZGU6cGF0aCcpLGNyeXB0bz1yZXF1aXJlKCdub2RlOmNyeXB0bycpOwpjb25zdCBNT0RFTD0nZ3B0LTUuNi1sdW5hJywgTUFYX0JZVEVTPTY1NTM2LCBNQVhfT1VUUFVUPTQwOTY7CmZ1bmN0aW9uIG5lZWQodixlKXtpZighdil0aHJvdyBFcnJvcihlKTt9CmZ1bmN0aW9uIGNyZWF0ZVNjb3BlKHRyYW5zcG9ydCl7CiBjb25zdCBzdG9yYWdlPW5ldyBBc3luY0xvY2FsU3RvcmFnZSgpO2xldCBhY3RpdmU9bnVsbDsKIGFzeW5jIGZ1bmN0aW9uIHJ1bih7YXV0aG9yaXplLGpvYkRpcixidWRnZXQsZGVjaWRlfSxwcm9tcHQpewogIG5lZWQoYnVkZ2V0Lm1heFJlcXVlc3RzPT09MSYmYnVkZ2V0Lm1heElucHV0Qnl0ZXM9PT1NQVhfQllURVMmJmJ1ZGdldC5tYXhPdXRwdXRUb2tlbnM9PT1NQVhfT1VUUFVULCdFTkdJTkVFUklOR19CVURHRVQnKTsKICBuZWVkKHR5cGVvZiBhdXRob3JpemU9PT0nZnVuY3Rpb24nJiZ0eXBlb2YgZGVjaWRlPT09J2Z1bmN0aW9uJywnRU5HSU5FRVJJTkdfQ0FMTEJBQ0snKTsKICBuZWVkKCFhY3RpdmUsJ0VOR0lORUVSSU5HX1NDT1BFX0JVU1knKTsKICBjb25zdCBzPXthdXRob3JpemUsam9iRGlyLHVzZWQ6ZmFsc2Usc2V0dGxlZDpmYWxzZSxjYW5jZWxsZWQ6ZmFsc2UsaGFuZGxlOm51bGx9O2FjdGl2ZT1zOwogIHRyeXtjb25zdCByZXN1bHQ9YXdhaXQgc3RvcmFnZS5ydW4ocywoKT0+ZGVjaWRlKHByb21wdCkpO25lZWQoIXMuY2FuY2VsbGVkLCdFTkdJTkVFUklOR19DQU5DRUxMRUQnKTtyZXR1cm4gcmVzdWx0O31maW5hbGx5e3Muc2V0dGxlZD10cnVlO2FjdGl2ZT1udWxsO30KIH0KIGFzeW5jIGZ1bmN0aW9uIHNlbmQocmVxKXsKICBjb25zdCBzPXN0b3JhZ2UuZ2V0U3RvcmUoKTtpZighcylyZXR1cm4gdHJhbnNwb3J0KHJlcSk7CiAgbmVlZCghcy51c2VkJiYhcy5zZXR0bGVkJiYhcy5jYW5jZWxsZWQsJ0VOR0lORUVSSU5HX1JFUVVFU1RfTElNSVQnKTtzLmF1dGhvcml6ZSgpOwogIGNvbnN0IHA9cmVxLnBheWxvYWQ7bmVlZChyZXEucHJvdmlkZXI9PT0nb3BlbmFpJyYmcD8ubW9kZWw9PT1NT0RFTCYmdHlwZW9mIHAuaW5wdXQ9PT0nc3RyaW5nJyYmdHlwZW9mIHAuaW5zdHJ1Y3Rpb25zPT09J3N0cmluZycmJnAuc3RvcmU9PT1mYWxzZSYmcC5tYXhfb3V0cHV0X3Rva2Vucz09PU1BWF9PVVRQVVQmJk9iamVjdC5rZXlzKHApLmV2ZXJ5KGs9PlsnbW9kZWwnLCdpbnB1dCcsJ2luc3RydWN0aW9ucycsJ21heF9vdXRwdXRfdG9rZW5zJywnc3RvcmUnXS5pbmNsdWRlcyhrKSkmJkJ1ZmZlci5ieXRlTGVuZ3RoKEpTT04uc3RyaW5naWZ5KHApKTw9TUFYX0JZVEVTLCdFTkdJTkVFUklOR19XSVJFX0JPVU5EUycpOwogIHMudXNlZD10cnVlOwogIGNvbnN0IGY9ZnMub3BlblN5bmMocGF0aC5qb2luKHMuam9iRGlyLCd3aXJlLXJlc2VydmF0aW9uLmpzb24nKSwnd3gnLDBvNjAwKTsKICB0cnl7ZnMud3JpdGVGaWxlU3luYyhmLEpTT04uc3RyaW5naWZ5KHtwcm92aWRlcjonb3BlbmFpJyxtb2RlbDpNT0RFTCxtYXhPdXRwdXRUb2tlbnM6TUFYX09VVFBVVCxpbnB1dEJ5dGVzOkJ1ZmZlci5ieXRlTGVuZ3RoKEpTT04uc3RyaW5naWZ5KHApKSxwYXlsb2FkU2hhMjU2OmNyeXB0by5jcmVhdGVIYXNoKCdzaGEyNTYnKS51cGRhdGUoSlNPTi5zdHJpbmdpZnkocCkpLmRpZ2VzdCgnaGV4Jyl9KSsnXG4nKTtmcy5mc3luY1N5bmMoZik7fWZpbmFsbHl7ZnMuY2xvc2VTeW5jKGYpO30KICBjb25zdCBkPWZzLm9wZW5TeW5jKHMuam9iRGlyLCdyJyk7dHJ5e2ZzLmZzeW5jU3luYyhkKTt9ZmluYWxseXtmcy5jbG9zZVN5bmMoZCk7fQogIGxldCB0aW1lcjsKICB0cnl7CiAgIGNvbnN0IHJlc3VsdD1hd2FpdCBQcm9taXNlLnJhY2UoW3RyYW5zcG9ydCh7Li4ucmVxLG9uSGFuZGxlOmg9PntzLmhhbmRsZT1oO3JlcS5vbkhhbmRsZT8uKGgpO2lmKHMuc2V0dGxlZHx8cy5jYW5jZWxsZWQpaD8uY2FuY2VsPy4oKTt9fSksbmV3IFByb21pc2UoKF8scmVqZWN0KT0+e3RpbWVyPXNldFRpbWVvdXQoKCk9PntzLnNldHRsZWQ9dHJ1ZTtzLmhhbmRsZT8uY2FuY2VsPy4oKTtyZWplY3QoRXJyb3IoJ0VOR0lORUVSSU5HX1dJUkVfVElNRU9VVCcpKTt9LDkwMDAwKTt9KV0pOwogICBuZWVkKCFzLmNhbmNlbGxlZCwnRU5HSU5FRVJJTkdfQ0FOQ0VMTEVEJyk7CiAgIGNvbnN0IHU9cmVzdWx0Py5ib2R5Py51c2FnZTsKICAgaWYocmVzdWx0Py5zdGF0dXNDb2RlPj0yMDAmJnJlc3VsdC5zdGF0dXNDb2RlPDMwMCl7CiAgICBuZWVkKE51bWJlci5pc0ludGVnZXIodT8uaW5wdXRfdG9rZW5zKSYmdS5pbnB1dF90b2tlbnM+PTAmJnUuaW5wdXRfdG9rZW5zPD1NQVhfQllURVMmJk51bWJlci5pc0ludGVnZXIodT8ub3V0cHV0X3Rva2VucykmJnUub3V0cHV0X3Rva2Vucz49MCYmdS5vdXRwdXRfdG9rZW5zPD1NQVhfT1VUUFVULCdFTkdJTkVFUklOR19VU0FHRV9VTlZFUklGSUVEJyk7CiAgICBjb25zdCBtPXJlc3VsdC5ib2R5Lm1vZGVsO25lZWQodHlwZW9mIG09PT0nc3RyaW5nJyYmKG09PT1NT0RFTHx8bS5zdGFydHNXaXRoKE1PREVMKyctJykpLCdFTkdJTkVFUklOR19NT0RFTF9NSVNNQVRDSCcpOwogICAgY29uc3QgZj1mcy5vcGVuU3luYyhwYXRoLmpvaW4ocy5qb2JEaXIsJ3dpcmUtcmVzdWx0Lmpzb24nKSwnd3gnLDBvNjAwKTt0cnl7ZnMud3JpdGVGaWxlU3luYyhmLEpTT04uc3RyaW5naWZ5KHttb2RlbDptLGlucHV0VG9rZW5zOnUuaW5wdXRfdG9rZW5zLG91dHB1dFRva2Vuczp1Lm91dHB1dF90b2tlbnMsc3RhdHVzQ29kZTpyZXN1bHQuc3RhdHVzQ29kZX0pKydcbicpO2ZzLmZzeW5jU3luYyhmKTt9ZmluYWxseXtmcy5jbG9zZVN5bmMoZik7fQogICB9CiAgIHJldHVybiByZXN1bHQ7CiAgfWZpbmFsbHl7Y2xlYXJUaW1lb3V0KHRpbWVyKTtzLnNldHRsZWQ9dHJ1ZTt9CiB9CiBmdW5jdGlvbiBjYW5jZWwoKXtpZighYWN0aXZlKXJldHVybiBmYWxzZTthY3RpdmUuY2FuY2VsbGVkPXRydWU7dHJ5e2FjdGl2ZS5oYW5kbGU/LmNhbmNlbD8uKCk7fWNhdGNoKF8pe31yZXR1cm4gdHJ1ZTt9CiByZXR1cm4gT2JqZWN0LmZyZWV6ZSh7cnVuLHRyYW5zcG9ydDpzZW5kLGNhbmNlbH0pOwp9Cm1vZHVsZS5leHBvcnRzPXtjcmVhdGVTY29wZSxNT0RFTCxNQVhfQllURVMsTUFYX09VVFBVVH07Cg=="},"native_bridge.cjs":{"sha256":"aebe7e1c42d159e00990930239c5bf48b5d47361211217bedd2fa0b9afe795ed","base64":"J3VzZSBzdHJpY3QnOwovLyBUcnVzdGVkIG1vZHVsYXIgc2VydmljZS4gSW5pdGlhbCBzaWduZWQgaG9zdCBpbnRlZ3JhdGlvbiBzdXBwbGllcyBvbmx5IG5hdGl2ZSBjYWxsYmFja3MuCmNvbnN0IGZzPXJlcXVpcmUoJ25vZGU6ZnMnKSxwYXRoPXJlcXVpcmUoJ25vZGU6cGF0aCcpLGNyeXB0bz1yZXF1aXJlKCdub2RlOmNyeXB0bycpOwpjb25zdCB7c3Bhd25TeW5jfT1yZXF1aXJlKCdub2RlOmNoaWxkX3Byb2Nlc3MnKTsKY29uc3Qge2NyZWF0ZVNlcnZpY2UsY3JlYXRlQnVpbGRlcixzaGF9PXJlcXVpcmUoJy4vc2VydmljZS5janMnKTsKY29uc3Qge2NyZWF0ZURpc3BhdGNofT1yZXF1aXJlKCcuL2Rpc3BhdGNoLmNqcycpOwpjb25zdCB7TU9ERUwsTUFYX0JZVEVTLE1BWF9PVVRQVVR9PXJlcXVpcmUoJy4vcHJvdmlkZXJfc2NvcGUuY2pzJyk7CmNvbnN0IEZMT1dFUj0nbWlzcy1mbG93ZXI6MzNhMmJkY2I4MDY2ZTU1NDlmOTBiMzE0MTgyNjA1MzY1ZDlhMTQzMWYyZWNlNWQxMTk0NDNkN2I5MjViODQ3YSc7CmZ1bmN0aW9uIHRpdGxlRnJvbSh0ZXh0KXsKIGNvbnN0IG09dGV4dC50cmltKCkubWF0Y2goL14oPzooPzpoZXl8aGVsbG98aGkpWywhXT9ccyspPyg/Om1pc3MgZmxvd2VyWywhXT9bIF0qKT8oPzpwbGVhc2VbLCBdKyk/KD86KD86d2V8aSkgbmVlZHwoPzpjcmVhdGV8bWFrZXxidWlsZHxkZXZlbG9wKSlccysoPzphIHxhbiB8dGhlICk/KFthLXpdW2EtejAtOSAtXXsxLDQ4fT8pWy4hXT8kL2kpOwogaWYoIW0pcmV0dXJuIG51bGw7Y29uc3QgbmFtZT1tWzFdLnRyaW0oKTtpZighL15bYS16XVthLXowLTldKig/OlsgLV1bYS16MC05XSspezAsNH0kL2kudGVzdChuYW1lKSlyZXR1cm4gbnVsbDsKIGNvbnN0IGlkPW5hbWUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC8gKy9nLCctJyk7aWYoWydjbGluay10ZXJtaW5hbCcsJ2NvbnZleW9yLWNsdWInLCdtb2RlbC1mYWN0b3J5JywncGhhbnRvbXRyb25peC1jb21tYW5kJ10uaW5jbHVkZXMoaWQpKXJldHVybiBudWxsOwogcmV0dXJuIHtpZCxuYW1lOm5hbWUucmVwbGFjZSgvXGJcdy9nLGM9PmMudG9VcHBlckNhc2UoKSksdmVyc2lvbjonMS4wLjAnLGJhc2Vfc2hhMjU2Om51bGwsaW5zdGFsbGVkX3ZlcnNpb246bnVsbH07Cn0KZnVuY3Rpb24gcmV2aXNpb25Gcm9tKHRleHQpewogY29uc3QgbT10ZXh0LnRyaW0oKS5tYXRjaCgvXig/Oig/OmhleXxoZWxsb3xoaSlbLCFdP1xzKyk/KD86bWlzcyBmbG93ZXJbLCFdP1sgXSopPyg/OnBsZWFzZVssIF0rKT8oPzp1cGRhdGV8bW9kaWZ5fGltcHJvdmV8Zml4fGNoYW5nZSlccysoPzp0aGUgKT8oW2Etel1bYS16MC05LV17MSw2Mn0pXHMqOlxzKihcU1tcc1xTXSopJC9pKTsKIHJldHVybiBtP3tpZDptWzFdLnRvTG93ZXJDYXNlKCksb2JqZWN0aXZlOm1bMl19Om51bGw7Cn0KZnVuY3Rpb24gY3JlYXRlTmF0aXZlQnJpZGdlKHtsZWdhY3ksc2NvcGUsc3RhdGVEaXIsYnVuZGxlRGlyLGFwcHJvdmUsZXhpc3RzLHNoZWxmUm9vdCxpbnN0YWxsZWRSb290LHJlc29sdmVCYXNlfSl7CiBjb25zdCBiYXNlbGluZXM9bmV3IE1hcCgpOwogY29uc3QgcmVzb2x2ZT1yZXNvbHZlQmFzZXx8KChpZCk9PnsKICAgaWYoIXNoZWxmUm9vdHx8IWluc3RhbGxlZFJvb3QpcmV0dXJuIG51bGw7CiAgIGNvbnN0IHI9c3Bhd25TeW5jKCcvdXNyL2Jpbi9weXRob24zJyxbJy1CJyxwYXRoLmpvaW4oYnVuZGxlRGlyLCdyZXZpc2lvbl9iYXNlLnB5Jyksc2hlbGZSb290LGluc3RhbGxlZFJvb3QsaWRdLHtlbnY6e1BBVEg6Jy91c3IvYmluOi9iaW4nLExBTkc6J0MuVVRGLTgnfSxlbmNvZGluZzondXRmOCcsdGltZW91dDoxNTAwMCxtYXhCdWZmZXI6MTMxMDcyfSk7CiAgIGlmKHIuc3RhdHVzIT09MClyZXR1cm4gbnVsbDtyZXR1cm4gSlNPTi5wYXJzZShyLnN0ZG91dCk7CiB9KTsKIGNvbnN0IHNlcnZpY2U9Y3JlYXRlU2VydmljZSh7c3RhdGVEaXIsCiAgYXBwcm92ZUpvYjphc3luYyByZXE9PnsKICAgaWYocmVxLnByb3ZpZGVyIT09J29wZW5haSd8fFN0cmluZyhyZXEuY29tcGFuaW9uS2V5KS50b0xvd2VyQ2FzZSgpIT09RkxPV0VSKXJldHVybiBudWxsOwogICBjb25zdCByZXZpc2lvbj1yZXZpc2lvbkZyb20ocmVxLnRleHQpO2xldCBiYXNlPW51bGwsZ3JhbnQ7CiAgIGlmKHJldmlzaW9uKXtiYXNlPXJlc29sdmUocmV2aXNpb24uaWQpO2lmKCFiYXNlfHxiYXNlLmdyYW50LmlkIT09cmV2aXNpb24uaWR8fCFleGlzdHMocmV2aXNpb24uaWQpKXJldHVybiBudWxsO2dyYW50PWJhc2UuZ3JhbnQ7YmFzZWxpbmVzLnNldChncmFudC5iYXNlX3NoYTI1NixiYXNlKTt9CiAgIGVsc2Uge2dyYW50PXRpdGxlRnJvbShyZXEudGV4dCk7aWYoIWdyYW50fHxleGlzdHMoZ3JhbnQuaWQpKXJldHVybiBudWxsO30KICAgY29uc3Qgam9iSWQ9c2hhKEpTT04uc3RyaW5naWZ5KHJldmlzaW9uP1tyZXEuY29tcGFuaW9uS2V5LHJlcS5wcm92aWRlcixyZXEudGV4dCxncmFudC5iYXNlX3NoYTI1Nl06W3JlcS5jb21wYW5pb25LZXkscmVxLnByb3ZpZGVyLHJlcS50ZXh0XSkpLnNsaWNlKDAsMzIpOwogICBjb25zdCBleGlzdGluZz1wYXRoLmpvaW4oc3RhdGVEaXIsam9iSWQsJ2dyYW50Lmpzb24nKTtpZihmcy5leGlzdHNTeW5jKGV4aXN0aW5nKSlyZXR1cm4gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmMoZXhpc3RpbmcsJ3V0ZjgnKSk7CiAgIGNvbnN0IG1hcmtlcj1wYXRoLmpvaW4oc3RhdGVEaXIscmV2aXNpb24/J3JldmlzaW9uLScrZ3JhbnQuYmFzZV9zaGEyNTYrJy5qc29uJzonZmlyc3QtdHJpYWwuanNvbicpOwogICBpZihmcy5leGlzdHNTeW5jKG1hcmtlcikpcmV0dXJuIG51bGw7CiAgIGlmKCFhd2FpdCBhcHByb3ZlKHtyZXF1ZXN0OnJlcS50ZXh0LGdyYW50LG1vZGVsOk1PREVMLGVzdGltYXRlZFVzZDowLjAzLG1heE91dHB1dFRva2VuczpNQVhfT1VUUFVULG1heElucHV0Qnl0ZXM6TUFYX0JZVEVTfSkpcmV0dXJuIG51bGw7CiAgIHJlcS5hdXRob3JpemUoKTsKICAgLy8gRmlyc3QgbGl2ZSBlbmdpbmVlcmluZyB0cmlhbDogb25lIHBlcnNpc3RlZCByZXNlcnZhdGlvbiwgbm8gYXV0b21hdGljIHJldHJpZXMgb3IgcmVhcm1pbmcuCiAgIHRyeXtmcy53cml0ZUZpbGVTeW5jKG1hcmtlcixKU09OLnN0cmluZ2lmeSh7am9iSWQsYXV0aG9yaXplZDp0cnVlfSkrJ1xuJyx7ZmxhZzond3gnLG1vZGU6MG82MDB9KTt9Y2F0Y2goZSl7aWYoZS5jb2RlPT09J0VFWElTVCcpcmV0dXJuIG51bGw7dGhyb3cgZTt9CiAgIGNvbnN0IGZkPWZzLm9wZW5TeW5jKG1hcmtlciwncicpO3RyeXtmcy5mc3luY1N5bmMoZmQpO31maW5hbGx5e2ZzLmNsb3NlU3luYyhmZCk7fWNvbnN0IGQ9ZnMub3BlblN5bmMoc3RhdGVEaXIsJ3InKTt0cnl7ZnMuZnN5bmNTeW5jKGQpO31maW5hbGx5e2ZzLmNsb3NlU3luYyhkKTt9CiAgIHJldHVybiB7aHVtYW5BdXRob3JpemVkOnRydWUsam9iSWQsZXhwaXJlc0F0OkRhdGUubm93KCkrNjAwMDAwLHJlcXVlc3RTaGEyNTY6c2hhKHJlcS50ZXh0KSxjb21wYW5pb25LZXk6cmVxLmNvbXBhbmlvbktleSxwcm92aWRlcjpyZXEucHJvdmlkZXIsYnVkZ2V0OnttYXhSZXF1ZXN0czoxLG1heE91dHB1dFRva2VuczpNQVhfT1VUUFVULG1heElucHV0Qnl0ZXM6TUFYX0JZVEVTfSxncmFudH07CiAgfSwKICBnZW5lcmF0ZTphc3luYyAoe29iamVjdGl2ZSxncmFudCxidWRnZXQsam9iRGlyLGF1dGhvcml6ZSxkZWNpZGVFbmdpbmVlcmluZ30pPT57CiAgIGNvbnN0IGJhc2U9Z3JhbnQuYmFzZV9zaGEyNTY/YmFzZWxpbmVzLmdldChncmFudC5iYXNlX3NoYTI1Nik6bnVsbDtpZihncmFudC5iYXNlX3NoYTI1NiYmIWJhc2UpdGhyb3cgRXJyb3IoJ1JFVklTSU9OX0JBU0VfTUlTU0lORycpOwogICBjb25zdCBwcm9tcHQ9J0RldmVsb3BtZW50IGFzc2lnbm1lbnQgZm9yIHRoZSBzZWF0ZWQgTWlzcyBGbG93ZXIuIEh1bWFuIG9iamVjdGl2ZTogJytKU09OLnN0cmluZ2lmeShvYmplY3RpdmUpKydcblRydXN0ZWQgY2FydHJpZGdlIGdyYW50OiAnK0pTT04uc3RyaW5naWZ5KGdyYW50KSsoYmFzZT8nXG5SZXZpc2UgdGhpcyBleGFjdCBleGlzdGluZyBzdGF0aWMgdXRpbGl0eTsgcHJlc2VydmUgdW5yZWxhdGVkIGZ1bmN0aW9uYWxpdHkgYW5kIGFwcGVhcmFuY2UuIEV4aXN0aW5nIGFzc2V0czogJytKU09OLnN0cmluZ2lmeShiYXNlLmZpbGVzKTonJykrJ1xuR2VuZXJhdGUgYSBjb21wbGV0ZSBmdW5jdGlvbmFsLCBkZXBlbmRlbmN5LWZyZWUgQy5MaW5rIHN0YXRpYyB3ZWIgdXRpbGl0eS4gUmV0dXJuIE9OTFkgSlNPTiB7ImZpbGVzIjp7IndlYi9pbmRleC5odG1sIjoiLi4uIiwid2ViL3N0eWxlLmNzcyI6Ii4uLiIsIndlYi9hcHAuanMiOiIuLi4ifX0uIEFsbCBmaWxlcyBhcmUgcmVsYXRpdmUgd2ViIGFzc2V0cywgbm8gZXh0ZXJuYWwgbmV0d29yaywgbm8gcmF3IGNyZWRlbnRpYWxzLCBubyB0b29scyBvciBzaGVsbCwgbm8gaW5saW5lIHNjcmlwdDsgdXNlIGxpbmtlZCBsb2NhbCBKUyBhbmQgQ1NTLiBUaGVtZTogZGFyayBuYXZ5ICMwNTA3MTAsIHBhbmVsICMxMDE4MjcsIGJvcmRlciAjN2E5Y2I1LCBncmVlbiAjN2ZmOWE1LCB3YXJtIHdoaXRlICNlZGVlZTcsIGdvbGQgI2ZmZDg3ZCwgY3Jpc3AgYWNjZXNzaWJsZSBjb250cm9scywgbm8gc2Nyb2xsYmFycy4gSHVtYW4gbmVlZHMgYSB3b3JraW5nIHByb2R1Y3QsIG5vdCBhIGRlbW8uIEtlZXAgc291cmNlIGNvbXBhY3QuIERvIG5vdCBjbGFpbSBpbnN0YWxsYXRpb24sIHRlc3Rpbmcgb3IgcHVibGljYXRpb247IGhvc3Qgd2lsbCBwYWNrYWdlIGFuZCBpbmRlcGVuZGVudGx5IHRlc3QuIERvIG5vdCBjaGFuZ2UgZ3JhbnRlZCBpZGVudGl0eS92ZXJzaW9uLic7CiAgIGNvbnN0IHI9YXdhaXQgc2NvcGUucnVuKHthdXRob3JpemUsam9iRGlyLGJ1ZGdldCxkZWNpZGU6ZGVjaWRlRW5naW5lZXJpbmd9LHByb21wdCk7CiAgIGlmKHI/LmNvbXBsZXRlIT09dHJ1ZXx8dHlwZW9mIHIudGV4dCE9PSdzdHJpbmcnfHxCdWZmZXIuYnl0ZUxlbmd0aChyLnRleHQpPjI2MjE0NCl0aHJvdyBFcnJvcignRU5HSU5FRVJJTkdfSU5DT01QTEVURScpOwogICBpZighZnMuZXhpc3RzU3luYyhwYXRoLmpvaW4oam9iRGlyLCd3aXJlLXJlc3VsdC5qc29uJykpKXRocm93IEVycm9yKCdFTkdJTkVFUklOR19XSVJFX1JFQ0VJUFRfTUlTU0lORycpOwogICByZXR1cm4gSlNPTi5wYXJzZShyLnRleHQpOwogIH0sYnVpbGQ6Y3JlYXRlQnVpbGRlcih7c2NyaXB0OnBhdGguam9pbihidW5kbGVEaXIsJ2J1aWxkX2NsaS5weScpLHNkazpwYXRoLmpvaW4oYnVuZGxlRGlyLCdzZGswMDUuemlwJyksYmFzZWxpbmVGb3I6Zz0+Zy5iYXNlX3NoYTI1Nj9iYXNlbGluZXMuZ2V0KGcuYmFzZV9zaGEyNTYpPy5iYXNlbGluZTpudWxsfSl9KTsKIHJldHVybiBjcmVhdGVEaXNwYXRjaCh7bGVnYWN5LHNlcnZpY2U6e2FzeW5jIGhhbmRsZShyZXEpewogICBpZihyZXEucHJvdmlkZXIhPT0nb3BlbmFpJylyZXR1cm4ge3RleHQ6J1NlbGVjdCBPcGVuQUkgZm9yIHRoZSBmaXJzdCBhdXRob3JpemVkIGRldmVsb3BtZW50IHRyaWFsLid9OwogICBpZihTdHJpbmcocmVxLmNvbXBhbmlvbktleSkudG9Mb3dlckNhc2UoKSE9PUZMT1dFUilyZXR1cm4ge3RleHQ6J1RoZSBmaXJzdCBkZXZlbG9wbWVudCB0cmlhbCBpcyBzY29wZWQgdG8gTWlzcyBGbG93ZXIuJ307CiAgIGlmKCF0aXRsZUZyb20ocmVxLnRleHQpJiYhcmV2aXNpb25Gcm9tKHJlcS50ZXh0KSlyZXR1cm4ge3RleHQ6J0ZvciBhIG5ldyB1dGlsaXR5LCBuYW1lIGl0LiBGb3IgYW4gZXhpc3RpbmcgdXRpbGl0eSwgc2F5IHVwZGF0ZSB0aGUgbmFtZTogZm9sbG93ZWQgYnkgeW91ciBjaGFuZ2VzLid9OwogICByZXR1cm4gc2VydmljZS5oYW5kbGUocmVxKTsKIH19fSk7Cn0KbW9kdWxlLmV4cG9ydHM9e2NyZWF0ZU5hdGl2ZUJyaWRnZSx0aXRsZUZyb20scmV2aXNpb25Gcm9tfTsK"},"candidate.py":{"sha256":"5eac502e52329838add71640915a94a8e07ff4942de14f5a33d4962e5b400360","base64":"IiIiVHJ1c3RlZCwgZGF0YS1vbmx5IFNESzAwNSBjYW5kaWRhdGUgYnVpbGRlcjsgbm90IGEgbW9kZWwgcnVubmVyIG9yIHB1Ymxpc2hlci4iIiIKaW1wb3J0IGhhc2hsaWIsIGlvLCBqc29uLCByZSwgc3VicHJvY2Vzcywgc3lzLCB0ZW1wZmlsZSwgemlwZmlsZQpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClNES19QSU49J2ExOTkzOTNlNjJkNTI0MDQxZmY4MWRhNTgzMzYwOWUxMjcwMTA4NmM3ZWNhN2I4NzQ3YTg3MjQ5ZjIwMTk1ODAnCklEPXJlLmNvbXBpbGUocidbYS16MC05XVthLXowLTktXXsxLDYyfVxaJykKVkVSPXJlLmNvbXBpbGUocicoPzowfFsxLTldWzAtOV17MCw1fSlcLig/OjB8WzEtOV1bMC05XXswLDV9KVwuKD86MHxbMS05XVswLTldezAsNX0pXFonKQpBU1NFVD1yZS5jb21waWxlKHInd2ViLyg/OlthLXpBLVowLTlfLV0rLykqW2EtekEtWjAtOV8tXStcLig/Omh0bWx8Y3NzfGpzfGpzb24pXFonKQoKZGVmIGRpZ2VzdChiKTogcmV0dXJuIGhhc2hsaWIuc2hhMjU2KGIpLmhleGRpZ2VzdCgpCmRlZiByZXF1aXJlKG9rLCByZWFzb24pOgogICAgaWYgbm90IG9rOiByYWlzZSBWYWx1ZUVycm9yKHJlYXNvbikKZGVmIHJ1bih0b29sLCphcmdzKToKICAgIHI9c3VicHJvY2Vzcy5ydW4oW3N5cy5leGVjdXRhYmxlLHN0cih0b29sKSwqbWFwKHN0cixhcmdzKV0sY2FwdHVyZV9vdXRwdXQ9VHJ1ZSx0ZXh0PVRydWUsdGltZW91dD0zMCkKICAgIGlmIHIucmV0dXJuY29kZTogcmFpc2UgVmFsdWVFcnJvcignU0RLIHJlamVjdGVkIGNhbmRpZGF0ZTogJytyLnN0ZGVyclstMTAwMDpdKQogICAgcmV0dXJuIHIuc3Rkb3V0CgpkZWYgYnVpbGQoc2RrX2J5dGVzLCBncmFudCwgcHJvcG9zYWwsIG91dHB1dCwgYmFzZWxpbmU9Tm9uZSk6CiAgICAiIiJHcmFudCBhbmQgYmFzZWxpbmUgYXJlIHRydXN0ZWQgc3VwZXJ2aXNvciBpbnB1dHMsIG5vdCBtb2RlbCBvdXRwdXQuCiAgICBQcm9wb3NhbCBpcyBkYXRhIG9ubHk7IGdlbmVyYXRlZCBhc3NldHMgYXJlIG5ldmVyIGV4ZWN1dGVkIGhlcmUuCiAgICBPdXRwdXQgbXVzdCBiZSBhIG5ldyBkaXJlY3Rvcnk7IG9ubHkgc3RhdGljLCBuby1jYXBhYmlsaXR5IHdlYiBjYXJ0cyBzdXBwb3J0ZWQuCiAgICAiIiIKICAgIHJlcXVpcmUoZGlnZXN0KHNka19ieXRlcyk9PVNES19QSU4sJ1NES19QSU4nKQogICAgcmVxdWlyZShzZXQoZ3JhbnQpPT17J2lkJywndmVyc2lvbicsJ25hbWUnLCdiYXNlX3NoYTI1NicsJ2luc3RhbGxlZF92ZXJzaW9uJ30sJ0dSQU5UX0ZJRUxEUycpCiAgICBjaWQsdmVyc2lvbixuYW1lPWdyYW50WydpZCddLGdyYW50Wyd2ZXJzaW9uJ10sZ3JhbnRbJ25hbWUnXQogICAgcmVxdWlyZShpc2luc3RhbmNlKGNpZCxzdHIpIGFuZCBJRC5mdWxsbWF0Y2goY2lkKSBhbmQgY2lkIG5vdCBpbiB7J2NsaW5rLXRlcm1pbmFsJywnY29udmV5b3ItY2x1YicsJ3BoYW50b210cm9uaXgtY29tbWFuZCcsJ21vZGVsLWZhY3RvcnknfSwnSURfU0NPUEUnKQogICAgcmVxdWlyZShpc2luc3RhbmNlKHZlcnNpb24sc3RyKSBhbmQgVkVSLmZ1bGxtYXRjaCh2ZXJzaW9uKSwnVkVSU0lPTicpCiAgICByZXF1aXJlKGlzaW5zdGFuY2UobmFtZSxzdHIpIGFuZCAxPD1sZW4obmFtZSk8PTgwIGFuZCBuYW1lLnN0cmlwKCk9PW5hbWUsJ05BTUUnKQogICAgcmVxdWlyZShpc2luc3RhbmNlKHByb3Bvc2FsLGRpY3QpIGFuZCBzZXQocHJvcG9zYWwpPT17J2ZpbGVzJ30gYW5kIGlzaW5zdGFuY2UocHJvcG9zYWxbJ2ZpbGVzJ10sZGljdCksJ1BST1BPU0FMX0ZJRUxEUycpCiAgICBjaGFuZ2VzPXByb3Bvc2FsWydmaWxlcyddOyByZXF1aXJlKDE8PWxlbihjaGFuZ2VzKTw9MzIsJ0ZJTEVfQ09VTlQnKQogICAgZm9yIHAsdiBpbiBjaGFuZ2VzLml0ZW1zKCk6CiAgICAgICAgcmVxdWlyZShpc2luc3RhbmNlKHAsc3RyKSBhbmQgbGVuKHApPD0xNjAgYW5kIEFTU0VULmZ1bGxtYXRjaChwKSBhbmQgbm90IHAubG93ZXIoKS5lbmRzd2l0aCgncGVybWlzc2lvbnMuanNvbicpLCdBU1NFVF9QQVRIJykKICAgICAgICByZXF1aXJlKGlzaW5zdGFuY2UodixzdHIpIGFuZCAnXDAnIG5vdCBpbiB2IGFuZCAwPGxlbih2LmVuY29kZSgndXRmOCcpKTw9NjU1MzYsJ0FTU0VUX1NJWkUnKQogICAgcmVxdWlyZShzdW0obGVuKHYuZW5jb2RlKCd1dGY4JykpIGZvciB2IGluIGNoYW5nZXMudmFsdWVzKCkpPD0yNjIxNDQsJ1RPVEFMX1NJWkUnKQogICAgb3V0PVBhdGgob3V0cHV0KS5yZXNvbHZlKCk7IHJlcXVpcmUobm90IG91dC5leGlzdHMoKSwnT1VUUFVUX0VYSVNUUycpCiAgICB3aXRoIHRlbXBmaWxlLlRlbXBvcmFyeURpcmVjdG9yeSgpIGFzIHRkOgogICAgICAgIHJvb3Q9UGF0aCh0ZCkKICAgICAgICB3aXRoIHppcGZpbGUuWmlwRmlsZShpby5CeXRlc0lPKHNka19ieXRlcykpIGFzIHo6IHouZXh0cmFjdGFsbChyb290LydzZGsnKSAjIGV4YWN0IHRydXN0ZWQgZGlnZXN0IGNoZWNrZWQgYWJvdmUKICAgICAgICBzZGs9bmV4dCgocm9vdC8nc2RrJykuaXRlcmRpcigpKTsgdG9vbD1zZGsvJ1RPT0xTL2NhcnRyaWRnZS5weScKICAgICAgICBydW4oc2RrLydUT09MUy92ZXJpZnlfYmFja3BhY2sucHknKQogICAgICAgIHJ1bih0b29sLCduZXcnLCd3ZWInLGNpZCwnLS1uYW1lJyxuYW1lLCctLWRlc3QnLHJvb3QvJ3Byb2plY3QnKQogICAgICAgIHNyYz1yb290Lydwcm9qZWN0Jy9jaWQKICAgICAgICBpbXBvcnQgc2h1dGlsCiAgICAgICAgc2h1dGlsLnJtdHJlZShzcmMvJ3dlYicpOyAoc3JjLyd3ZWInKS5ta2RpcigpCiAgICAgICAgYXNzZXRzPXt9OyBvbGQ9Z3JhbnRbJ2luc3RhbGxlZF92ZXJzaW9uJ10KICAgICAgICBpZiBiYXNlbGluZSBpcyBOb25lOgogICAgICAgICAgICByZXF1aXJlKGdyYW50WydiYXNlX3NoYTI1NiddIGlzIE5vbmUgYW5kIG9sZCBpcyBOb25lLCdCQVNFX1JFUVVJUkVEJykKICAgICAgICBlbHNlOgogICAgICAgICAgICByZXF1aXJlKGlzaW5zdGFuY2Uob2xkLHN0cikgYW5kIFZFUi5mdWxsbWF0Y2gob2xkKSBhbmQgZGlnZXN0KGJhc2VsaW5lKT09Z3JhbnRbJ2Jhc2Vfc2hhMjU2J10sJ0JBU0VfUElOJykKICAgICAgICAgICAgcmVxdWlyZSh0dXBsZShtYXAoaW50LHZlcnNpb24uc3BsaXQoJy4nKSkpPnR1cGxlKG1hcChpbnQsb2xkLnNwbGl0KCcuJykpKSwnVkVSU0lPTl9OT1RfTkVXRVInKQogICAgICAgICAgICAocm9vdC8nYmFzZS56aXAnKS53cml0ZV9ieXRlcyhiYXNlbGluZSk7IHJ1bih0b29sLCdjaGVjaycscm9vdC8nYmFzZS56aXAnKQogICAgICAgICAgICB3aXRoIHppcGZpbGUuWmlwRmlsZShpby5CeXRlc0lPKGJhc2VsaW5lKSkgYXMgejoKICAgICAgICAgICAgICAgIG09anNvbi5sb2Fkcyh6LnJlYWQoJ21hbmlmZXN0Lmpzb24nKSkKICAgICAgICAgICAgICAgIHJlcXVpcmUobVsnaWQnXT09Y2lkIGFuZCBtWyd2ZXJzaW9uJ109PW9sZCBhbmQgbVsncnVudGltZSddPT0nd2ViJyBhbmQgbm90IG0uZ2V0KCdjYXBhYmlsaXRpZXMnKSBhbmQgbVsnZW50cnknXT09J3dlYi9pbmRleC5odG1sJywnQkFTRV9TQ09QRScpCiAgICAgICAgICAgICAgICBmb3IgcCBpbiBtWydmaWxlcyddOgogICAgICAgICAgICAgICAgICAgIHJlcXVpcmUoQVNTRVQuZnVsbG1hdGNoKHApIGFuZCBub3QgcC5sb3dlcigpLmVuZHN3aXRoKCdwZXJtaXNzaW9ucy5qc29uJyksJ0JBU0VfQVNTRVQnKQogICAgICAgICAgICAgICAgICAgIGFzc2V0c1twXT16LnJlYWQocCkKICAgICAgICBhc3NldHMudXBkYXRlKHtwOnYuZW5jb2RlKCd1dGY4JykgZm9yIHAsdiBpbiBjaGFuZ2VzLml0ZW1zKCl9KQogICAgICAgIHJlcXVpcmUoJ3dlYi9pbmRleC5odG1sJyBpbiBhc3NldHMgYW5kIGxlbihhc3NldHMpPD0zMiBhbmQgc3VtKG1hcChsZW4sYXNzZXRzLnZhbHVlcygpKSk8PTI2MjE0NCwnQVNTRVRfTElNSVQnKQogICAgICAgIHJlcXVpcmUobGVuKGFzc2V0cyk9PWxlbih7cC5jYXNlZm9sZCgpIGZvciBwIGluIGFzc2V0c30pLCdDQVNFX0NPTExJU0lPTicpCiAgICAgICAgZm9yIHAsYiBpbiBhc3NldHMuaXRlbXMoKToKICAgICAgICAgICAgZGVzdD1zcmMvcDsgZGVzdC5wYXJlbnQubWtkaXIocGFyZW50cz1UcnVlLGV4aXN0X29rPVRydWUpOyBkZXN0LndyaXRlX2J5dGVzKGIpCiAgICAgICAgbWV0YT1qc29uLmxvYWRzKChzcmMvJ2NhcnRyaWRnZS5qc29uJykucmVhZF90ZXh0KCkpOyBtZXRhLnVwZGF0ZSh2ZXJzaW9uPXZlcnNpb24sZGVzY3JpcHRpb249J1Njb3BlZCBlbmdpbmVlcmluZyBjYW5kaWRhdGUnLGNhcGFiaWxpdGllcz1bXSkKICAgICAgICAoc3JjLydjYXJ0cmlkZ2UuanNvbicpLndyaXRlX3RleHQoanNvbi5kdW1wcyhtZXRhKSkKICAgICAgICBzdGFnZT1yb290LydhcnRpZmFjdHMnOyBzdGFnZS5ta2RpcigpOyBhcmNoaXZlPXN0YWdlLyhjaWQrJy0nK3ZlcnNpb24rJy56aXAnKQogICAgICAgIGFyZ3M9WydwYWNrJyxzcmMsJy0tb3V0JyxhcmNoaXZlXQogICAgICAgIGlmIG9sZDogYXJncys9WyctLWluc3RhbGxlZC12ZXJzaW9uJyxvbGRdCiAgICAgICAgcnVuKHRvb2wsKmFyZ3MpOyBydW4odG9vbCwnY2hlY2snLGFyY2hpdmUpCiAgICAgICAgcGxhbj1qc29uLmxvYWRzKFBhdGgoc3RyKGFyY2hpdmUpKycucmVsZWFzZS1wbGFuLmpzb24nKS5yZWFkX3RleHQoKSk7IGJsb2I9YXJjaGl2ZS5yZWFkX2J5dGVzKCkKICAgICAgICByZXF1aXJlKHBsYW5bJ3JlbGVhc2UnXVsnc2hhMjU2J109PWRpZ2VzdChibG9iKSBhbmQgcGxhblsncmVsZWFzZSddWydjYXJ0cmlkZ2VJZCddPT1jaWQgYW5kIHBsYW5bJ3JlbGVhc2UnXVsndmVyc2lvbiddPT12ZXJzaW9uIGFuZCBwbGFuWydwcm9kdWN0aW9uUmVhZHknXSBpcyBGYWxzZSwnUExBTl9CSU5ESU5HJykKICAgICAgICBvdXQubWtkaXIobW9kZT0wbzcwMCk7IHNodXRpbC5jb3B5dHJlZShzcmMsb3V0Lydzb3VyY2UnKQogICAgICAgIGZvciBmIGluIHN0YWdlLml0ZXJkaXIoKTogc2h1dGlsLmNvcHlmaWxlKGYsb3V0L2YubmFtZSkKICAgICAgICByZXR1cm4geydzdGF0dXMnOidVTlNJR05FRF9DQU5ESURBVEUnLCdzaGEyNTYnOmRpZ2VzdChibG9iKSwnYXJjaGl2ZSc6YXJjaGl2ZS5uYW1lLCdmdW5jdGlvbmFsX3Rlc3RlZCc6RmFsc2UsJ3B1Ymxpc2hlZCc6RmFsc2UsJ2luc3RhbGxlZCc6RmFsc2V9Cg=="},"build_cli.py":{"sha256":"f6511630e2a3be3b9e345027eb3534172720668af5b838b3186902eb7abbabe4","base64":"IiIiUHJpdmF0ZSBzdXBlcnZpc29yLW9ubHkgZGF0YSBicmlkZ2U7IG5ldmVyIHJ1bnMgZ2VuZXJhdGVkIGFwcGxpY2F0aW9uIGNvZGUuIiIiCmltcG9ydCBqc29uLCBzeXMKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmZyb20gY2FuZGlkYXRlIGltcG9ydCBidWlsZAoKZGVmIHVuaXF1ZShwYWlycyk6CiAgICByZXN1bHQ9e30KICAgIGZvciBrLHYgaW4gcGFpcnM6CiAgICAgICAgaWYgayBpbiByZXN1bHQ6IHJhaXNlIFZhbHVlRXJyb3IoJ0RVUExJQ0FURV9LRVknKQogICAgICAgIHJlc3VsdFtrXT12CiAgICByZXR1cm4gcmVzdWx0CgpkZWYgbWFpbigpOgogICAgc2RrLCBvdXRwdXQsICpiYXNlID0gbWFwKFBhdGgsc3lzLmFyZ3ZbMTpdKQogICAgaWYgbGVuKGJhc2UpPjE6IHJhaXNlIFZhbHVlRXJyb3IoJ0FSR1MnKQogICAgcmF3PXN5cy5zdGRpbi5idWZmZXIucmVhZCgxMDQ4NTc3KQogICAgaWYgbGVuKHJhdyk+MTA0ODU3NjogcmFpc2UgVmFsdWVFcnJvcignSU5QVVRfTElNSVQnKQogICAgb2JqPWpzb24ubG9hZHMocmF3LG9iamVjdF9wYWlyc19ob29rPXVuaXF1ZSkKICAgIGlmIHNldChvYmopIT17J2dyYW50JywncHJvcG9zYWwnfTogcmFpc2UgVmFsdWVFcnJvcignSU5QVVRfRklFTERTJykKICAgIHJlc3VsdD1idWlsZChzZGsucmVhZF9ieXRlcygpLG9ialsnZ3JhbnQnXSxvYmpbJ3Byb3Bvc2FsJ10sb3V0cHV0LGJhc2VbMF0ucmVhZF9ieXRlcygpIGlmIGJhc2UgZWxzZSBOb25lKQogICAgcHJpbnQoanNvbi5kdW1wcyhyZXN1bHQsc29ydF9rZXlzPVRydWUpKQppZiBfX25hbWVfXz09J19fbWFpbl9fJzogbWFpbigpCg=="},"sdk005.zip":{"sha256":"a199393e62d524041ff81da5833609e12701086c7eca7b8747a87249f2019580","base64":"UEsDBBQAAAAIAKSzeV2GZxMWRgQAAPgHAABEAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1LzAwX1NUQVJUX0hFUkUubWR9VctuGzcU3esrLuJdMTOSlbpA65VtOYlQRzIkoQW68VDklcRoRE5JjpTJqqt+QNEvzJf0kKNHihaGIXge5OW553Hnih6KJ2229CBccFqtmUa858rW7OheyG2NHw0GN/T1j7+pdlY1MmhrSDTB7kTQkppaicCefBBGCad6vefLspXmSpGQkmu8lvzT6bxB8X0xHBC20EeruKJ3QgbrWrouhsU1ff3zr3Q1zGhi97xbAs7wJqPhYPhDQRMcvGfyem1Y0YGXJM/wT3CEYwobJsUr0VShoAVu+LP2QZs1bawPJDcst55W1p13AbKxbicqAgMGK29xf6me+5qlXp27dhlVojEohCuUUdqxDPRehw/NkpQ9mMoKBezak2FWrIpe7+qK5gEVSeDZ4VK81yvLcin8ple3YWPNW1pMp0/z/nlBUbdpR2x41+a4zC9957kRO6Y3H1uaYM1Zzzd4oxjd/jqd/fxa5aR0XNT/n9q2Cf85Mr8uBvj7ouvXyiaSX9uLpnu9xUUpKiOSkg5OJx1pVQloBafoSDn9Nn5OtnH8ewO6FZWF44qF57yuhCk+eWtKeEMxToNXWMMGSYGjX6ATG2erCtctH53hbeMkU3kq5TlEo/hjuaifjYq5xgQNnoX3cevUwAlrB409bZnrZDkfhRiPMtJGOt6xCbRn55GHjBqPQ/JcG8QlIsiPb8rUU+cIkF2D75WuOGpa0D3Do4wHDjp+E8Ij2Ax7YyA31ukvaKpulpX2seldgw1ds6jtJUyt6FENb26ufwTeNh2qjWKYXQFnhSc1DkC44ptIWOqIPyOdiJTcIHfZ6YC0Bvj1qj1GTWkJiVScBcsKgGH5gt7hdHug0fRh3r9++zK5W4x/eXx5uJstZuPR+8eX+eJuMrqbjYodFo9sIhoIXDJAKuy4tl7H8ZAfoCsyF6Kja6sNMljQDIxpwyQrHck+hfnokJhgx0fGkb8S+YG+bq8lJ2UrXgvZ9isrRZVbAxKiyBWZbsx05cg3dW2RWmz4dqqxugU9daWljvQlfVOU8vxSsExDJoL2BX3ADIJSeBd5cuggetp3WqwcFO9HCXScG6gMfqOFuonmOAgdTSxieyt2jKGaJcouvsgdC9VCjgrwXVTCn4k90pBoBWs4Ynmc8lEol/x3Pj3SC3Mnr8XG7jvBHp7Gj5NFH2ybbd6RhJgk/LFsmq2AvdM+OtuTtCY4GOg2PvXoPoq0ZoPOJN09jwlnxAaRFTQH8pOndBqWs8aAz3+Nl85xL2fcdVtmlzX5DgV0SAZRGpbHcso9LR7ni3mZJZSlwScHAqVF6UX/uyLeFPKTL+En8Hfya5e6LHbWZcGmcXLqCUNeNp0+UeIISKwxODJMgRWHFv87px354fT9KRBCnWiNn1Y4C7xwnCEou4KV0jeqs+Up5Ek51wnscXOxwhkBhp2FeHof7Yp0e0qIvD9Yp9KeiH+rQ9H7B1BLAwQUAAAACACzs3ldaJtoDC0OAAB8HAAAUQAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9CQUNLUEFDSy5NQU5JRkVTVC5TSEEyNTYuanNvbrWZSVObSbaG9/UrKry+QM7D3VEg20TJiBayb9RKkWOXupkCZFe5K/q/95MgYcvG2L24DpswkvjezDznvEPy108///wip/LPG/69+N+fXxydLH7bn56c/rq/mMzfnJweTvePDueL+cnxq8n+8eTdZDo7m8z3fzk8+vWMf/tC2Bf/Mx7S6mq9ur4az3h8ra7+3u7W46W735Oy7uHVy3aZ2+0dL//Ftz+Pzy/PF4AsX0/mk/3LOn6gWxWact1aX6srvXdhjEla2KS96cn4YJuxpkRTRes5JaOyt9nmLJo06h6KZ/9yv/Ll0fRkcro4KBerq3/u5dtV/Xvb/8dYwovaaiuh5i5L7k75ZmvpSXgfpei6KSOs7b2wDutE6llLF2OLUspua/D2OaCrtF592AKZKL10uWurdK05BZ+cibEa12Wz3vlqms9FiSgK+5QhNRPYaNBGF+cegY5nR+cHQi4fy7I8mp0u5odHi+3RFdbsioo5WF2s9DUW2SWn071qOsSQk4lB1maqFUUn4YprhXO0umUbdoHU8v8Op78uXs9nb1+93iKEkETIPWrntK3G8wjXVShJlWJ6q7ztswyWL754ViKMzU61WnSpRe0i6OV0dnQ4XZ5P5u9OjibLs/lsMTuaTTdgtptUgyw6tKyqkyG6khsPr7VR7BKzy7kFY7zsXZWeW5X0jqVcUvcad8EMMEdv53T58vD0GKyTd4dHv22gZFbdmW5dFb7pbL3xyniXjO3Ke1WU71THd99ZQzetqCZSqiWWao2UaRfKLg9f0QvL1wDNXr7cYPjAY1RI9K80zhXpgrSiW20T7dYLjZEtPem7yykqHawDPdIyMhYfyy6GWy4ozC/Tyfnr2WxxcvpqgyIE1TRCR5Gjr6mHbmKJvmiaIQrhQqCvdI2t5R5sLlWI4m0pUvFWK3kXxS/nk+nk8JxWez05+nV6cr7tNS2DSsyly0o6XZOsvSqrg8ilqNFkmrKx+JB4vAvCiRhNYI5NF7TjF8UJtPKbs8PFyS8n022FBg2db+sjjbHSmZJzbFVV+lCpAnZ0gval6qlHxrXqAHVkFaRojZY30UifjdhFi0saYT4qtKW6XfgNKC0hfdc6abpJhBR0ltaEpJKt2pla61hT4r++OJ9K1Da4BKwQOcmgd0AlVHfy6nRyvHx7dny4mJzf73E6OzyGVB/wKs0XlFZNeXZgLdPTc1Y61tZTTSblwuBKyljTqCVUpH3SUlqvdIu7wyXl8vXsfLHcsNN88re3J/PJGzZ9/tiPIXSfbYrQkQiSJ3llazYm2GBKdbBr4PVgGLmghYOGDUegvPDCxC+2p8b0vjthN1vId3pbPEG9NJWiG7TNHFbWdGJVwlcvWzZNd5+kVTAwE19dTDZmLxk1p5T0u0B6eUqh3k0+o0E05PT4cH685Y1gHGg2hGggPghbxyBUkyW6wFw3BdeZGgokqbqClBNTWJ2PnRr2xxG4P7/55CXadHo0OTg8OpqcLSigMEoczCeHx2+2miWj6mNcjY1SG+iQFciiKuSYFSIjVO/SRqtFoVJSOuaQWhq0xxr/SUqeRSzXt22/bLQLMUHsCrrEs6MRTmuRYZeBlGzIKuVWXCy8YkysEZY2/BCKiRon/0OA7c/1bSrrvbvU2/7Nx3spQ14YgKJStE1EOEOx3RyUQB9DjsEb+rOwqBZ7ZGi0rBEiKC50IUz4IdwH8dz7IPfS3V1b3203DS/TFrZQvGBFrKhqk4opYPZEEbCxNa4xg0pVWSzjIrw2Ltt7nkjivwT/Y/XpvJvJTqBrYhTPFq+jjZFWpZktWipzsc0WWdFAU4sUfBDxNj1HvIUO7oeg79pF33t/U9O67d1cX6zKxy2857Srs7kzKZ0TQHFEKpy06y34GG2SSiCPIaVW+JOEKXRg1A1GyeXH4Cn21d3N9e16ixoS41Jc10YqlYOhx9Pgm+x7FslKSg8d9ZAbXGxzo8fxNQ0tzQ65+VaTzTVceHK6mLyaM8iz080MtS59qFgwD7siVzIjVVZAQ0yoc7gJIRSiplvVSqpaoylauxZiV4jzt6b25vb6w6q22633255opm4MglWlQTdeBNwWzgvWkS0aFYXlL7MpcuWAk+gIiZIMFi3IG99AW9++v1u3utdv02Xbu71+v263W0gkyQVsi6qh44W8KKinldUmj4ltjecLp2rDM/kUChpQcL8xepeh3vboMR6YZ/lyNn+wGfvrP++ddjHj87g5iAEToKKXiAb94bJHvGROtqnIWGIMDF7Z0kwS/bYV9sX5fHr+veIz/uny5qLtXVyXdLF3db1ud/v/Wt3cT2KxYjg9fEWhPN6aRPkgc02nNO9Uwew0Dg4jUowEDIebMCFwu821fAtqvbrkvDYgAptVUmzQGs6scXq+ZipU6EXH+UVZiq+9tGGX2LA3NUttYXnGxYmv9nPze7paX1+ub6+vVn/ulevLy3RFpS6u/6A7yu9pvfdB7709PZ6cTWe/TY63y7CtdaGH0qrgcMkmYwiNTDhbbChKg+sogZ5A/jFAnS12WtJDvIoziZ+WcTabL84PjnCFrwhTr0hQatP7hdKU4LCd3SYBZajWmtFKyNYEwpFCpBFbS/QeTrqVxjjg3ypz2Agmz2E8qnAabRwDMlutxV/SVDWViqHCzYvCG0PXpdEYA10zqhUoFQNJTOnNPIdhNhgZy4zm6RJFCqHykxUWdkDB063jOQlPjvCkJOHAC2wVZI3RsQh08ek5DLs1njp4b1IZLiFTGYIGfOQoAL7PId/dFsRRWCiK3snoHcOEUoaUK2b1S4yX9/7v8O3xyeKzighUg9yWMEdaR6UIBuypMIYxdacZ04r9H0YPPsCmORVrMCJVrG7y4quq76Jsa6INKYaVjmbWOAMymoz4yzE6ZBhaz5NRvSZERVhAiWFqUib4OMKCsl+iYCsXe/PJ+dspLm8c2YYa1CCZjh0iLJP3oL7MaDY8QYH/sJVkK23YWmlJDINp8HjRKkMsoLW/OrN3h9OT4wfyHpv5x91D/C/NIguJh7LWzAgQ0/qQ4V4JVA42Ryc1vr1GBcMXTC19iCWkJ5h09yyMfYTpIxcHQn+yhuDJakVtaeg+i66cDa3eGUcv8QUxo5UgmdysaS5hX56B2ULITNxEFEXSCD9Hj3vp2NMgR8ZlLhOuVbAN3HlyPbSgUwzkYQg1pvy4k8Xkzdl0uP2Dz3jmoKTb9fYm4gEPamzUhrhRCTmOoASXkcay0D470nkdeNbK2LsYakHqTBWBwHfgtvrzeH+0fJBubjbXEVJXYiXBsDqcGWFGg40sOUF2Rm4SOt6JVZGMpRM5DmL3Dq9VyKelh+9j/b9cs3wbbnVV25/7v68vL+5niiFEzq1R0hJLtSJyYz9VNJVk43PDlQbpepHsVvoSJImGLG5SVzRO+T7e3frjBUbi7sEZitjdaGrdPCqX9GAJM2gQnoB7ikvoq6FNYmrDFkIWSMhIcx6/9ETl7trth1Vpe3dr2qTdPtEtIUYe463mMFsc9zhIPRGeOpHIBYkXOuzFOeFbSYPgUx+fwux0zzx/H3Pz/cFlWl3tX27s9wgtweVcUHkZSm0WOS5sU+IrsOQWK0rWxnRT1ZSYf+zBuPCiZXtOP466268G4uijODHj2GDjIiS0aR1q2aTA8mN7pe00EFSCAw9V6G7iyBu09BMFfQ53t5nc4HbaQw43JQnohrOH06RlBAX+xNlq0YmIy1E5M8B1XEB455xB9v6Lk/6qsRhB0pOjYTI0Bju42qkk2MEZnBc5vcYWqAM2TkNzwy+TYEuiFTmCr6GBeKapWDT+ossAGWfTad/uK7KsLSMCBbJLZX0jw+PJFf4PfUeYYHuYm2T5PN5uSdO4OknsrTGTTsPgKWDrB8UYmCFAuYKtg6Nat1jZiKnE7ym8asQmfx9rt4xEi+FAtU7ASUYPKQSni9I6gQIpFMxOKswpnlLgybM3YXj0JB3a9X28+9LdbWtH12iF2Iyxoz9pSj34VAdNZoqBbDbuPXrtGFb6C0JPoadSjCJEe/vZqJyjTw90ulcuVu1qvY8Nf0xomgxBFsN5QNUSL+wMfBCMRgILrcB+LAxHW6ReYZ8ixyUaixrmvPq8i7OJvk/g2F44fSTJCuy7Zfo5vYzzJ+mWYSsy7ihgU0lLaHEdGysyydSbotJuF+fLSPY5Etwl4CikmhMiYWeUHhYfzOkZB60zI073Y1Gjx98pzJHShh3a0EmFu0jjyctPrf5wh1FoNdzukEHZky6JsGrHLykwDgpXqsejcPcGparZMmJ0fMPa245OfD7TjxDjgu79xXp52y5autsCjcEcdwWwBQwhx4W4waRUrStmQuUy5kY4Xc39bTIoQXRsCh0vht18Amh7dGzqJuXVxWr9cflBb/ACljfgHKVjb7iF4jzLHnehw4SHRGmywpPJNMxG74TdJKuBIlEjpf0TeJsNLW8u0tUGpXEK2PXCQLEZbfA/kYRHgytKQdVGRCG9M2YN1x0hSLgQQ06DjqviJ1A2HLi8fX81EuD2+Oq4vpPGMz6MDgvnC3a0Yoc65szqAHeISpzuXWOi8UoCWKExoMKUL4CeSuafd14ZN/FMJmkEY+WLJJ4rrJwRqo+rQzK06LQIk+XuoxRxz2f8eVVMl/4k5LPZ9Pzgy6bDyNDPfSQjxMy6TAYat8k5eQ+5w4SlkB1txCMTonDiRDEoGUoUI17uPv2JsnQjx9V7LtmS6rGFuAHKEwZNk44tycjytAA11KQILGX8OgOjBBX0KusuwId2u+ofl9vfD24wIkdhq1LoUDbKcziYVQ6rIk5d0eY+EF2ZS0QEFwA1MP6JNfEKsyxeAPHvn/79038AUEsDBBQAAAAIAI2zeV2HuTPHDAMAADEGAABRAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0JSSURHRV9DTElFTlQvY2xpbmstYnJpZGdlLmpzfVTvT9swEP3OX3FIk+JAFsrQvoA6qUA1qrWUlbKvxU2uxSONM9tpx0r/951/pHQw0Q9VbN+99+7d2UcHcPvAFeaQFQJLAzOpIOPKKJHPEVY4BYVljgpVCte4RAU8y7AyGijwgZd5gRoqJZeCgkBjptDodA8ArqQ2sKjpj7LE7Almii8QKK40wjwB07JWGUK73QZRasOLwsrYcrvwGIiCNis+FQVlOeTOTQ9WQqEVu+AG8LchjRrMA4KcalRLAhqdHLfgIu2L8hEqkjJArTnBKvxVozZHCnUlS40wVfKRqts7ONpjs7rMjJAlMCWliWFNdFFNQZpEZSY6o3WBhupUghfQhpbdyQjHQEUaRDmnzRJXMOAVi3cOyWNytw0WN/Ure+qWPM+7S9roC02FoGLRwouNEnhRhF4OgJjRIg3u7ZN7Afz5GfYxzbnh9tN/pdRWMsBGHe/smqfKp0ZkQxSTKaZW5ZmD94J1Ia3cUFQ6R8NCrsjjs62OfRv3Kr9ArsZigbI2zB6nxi9CWgOZIzmJ/0UNe/LRDYdRNdXukEitLJbbJFrWRYOLhe2Tj/qJmWG2DV2lpGK31L1y3mSh3bNmRFfD2/HkfNS7/NqddEej4SiKU12IDFkrgU+tVhw77I3733Yio0llskqAq7lOIFQ30GTX5xb9dvvU9L3tO984BTdKLoTGt1Kji37v+tvEKRt1v9/1Rt3LKI53WyNyYrrPph8/rC+5wbSUKxZvaHV46Odyc+/DA5cFD3yMBQcT8MwxtL8EuQ18qIc4NJqmj8wHvm6e7Rq8rWHX13Fv0B3ejSfD0eTuuvOj0+t3zvtdWxJsdswLFb6MB5ETfEKcIcZK/kd76ItLcjanO/ecrcGN/ikcEwuN+6md9V90oyxo0z0rITqIAo7H2zTX8sK+Hef+MWrDcGo505lC/EPofpTDu6dPwRvkRiOaupx0e0qkayI6oemIE9/IB24op4lIIFx4nTTvUy9/C2izLBa8m0dlBBJeZlgQzXuQLsaB7gAkbpAdjPVkE7OVKHO5ou+/UEsDBBQAAAAIAI2zeV0ZvLp3BAIAAOYDAABRAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0JSSURHRV9DTElFTlQvY2xpbmstbmF0aXZlLmpzjVJNc5swEL3nV8gnUIYhSafNoZR2KObAlNou/rh0Oh4h1rZqLDGSiOMa/nuFE+zY02R60ay0q7dv39ubaxSSUlcScsSJZg+AQjdhfI22kKFgFHuIC7SGnUJCIiIzpiWROxSPQhcNS80EJwUqpXhgOZgCSkEpF13fXNmLitM2b0shNN5blQKktGRUW94V6rIok2IN0sZ7KrjSKPPbcpcWhkNIpKnPl5Ak3z22sHtZXetdCWKBMldpoivV832rg7JeZJfAQRINZ3msV1JsUSSlkLYVJvHg23wQTOJZNB+lw1ncj9L5dBDMgjgJviaRhT0JRhrD0WteMKYroGvIbYn3hpT84oq1aaNlBWcNxoY7X7Z5aO91bSIqcqjr89ZRmg5TC7uqYBTsW+fu/S0+dpZt54MiYevK4GCRP8x+A9XuQgL8AXvfya8+ErXj1Mb+544j2RKmjxo/i2Zj7HQCPX/pIBwTbErtbMjjsNJlpSfmJ1f+uw/3BrWdt/fTEiVwwizHejTnL5dxWlQ5qCMIPhrxhNaaoA5qGIt6T29uAXypV+Y+qDYZSJepmGtYGpoXvQ3axcunu3Mn48EsSOL+PI1+TKPx5OTbKyp0s5+Ue2XsxhjROFWZm+LxQbqTwm/t6xiKxfTw63/W9o21nI76wST691JeDHfy1msa7F012N4ynoutif8CUEsDBBQAAAAIAI2zeV3dBY5wpwkAAGwTAABRAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0RPQ1MvMDFfQ0FSVFJJREdFX0NPTlRSQUNULm1klVjbbhvJEX3nVzTkB0kMZyjRuwYiBQG0krxmohtM2QliGJrmTFNsq2d6truHEtcysE/5gCRf6C/JqeoZXpTkIYANkX2prq4651Q1X4nDVJxKF5wu7pX42/hGzKwrZRDff/uXyGUdGqcK8XE0EI86zEXtbG09RhavRWZMmeZzGTKxlzfOqSqIufVBNNVCOT3Tqtjv9V69Epey0jPlQ693ApPdWdoLyQeyYfUk82CWot+3ler3RVa2m9Iv3lbZQCisUk7MDHzDP3zhzc7aIKzDmQVmsVc8OlnX+Fxop/Jg3VLgOvlcV/dCBy86uyLTRZaK8ydZ1ibaym0VcAl/1OtlWRbUU+iVy2SmnQ/Jyu9hT4gt3/D9UU1pWAgNL57SeSgNf4UjWMIffVga5dPce7KNSFRC/dLohTQUtqnMH1RVbESn8cqLzCu30LkallJXafnFZ0JiVd3gHv2+NAaBojvV2C6xSXqv8DXGYrU5S3u97pp7Psigc/J4P16Tr/AVPu74fK5KuXMkdm5Ors4vJnc3Fx9+Hl/dXZ5cjd+eT27vPo52BrRQF7ToP0MTZytZKpq/XIq3NL+GV5wHNry2FS05TA/SgzhaKJ87XYd25kR4ZWYJZQRXB96MzaURwVoT17umCjoehLvEMUTSLduR4ToV3aScGkWeB9coHpJNsJMA7zA4k8bH0SkQdeo0oiTN1gTYIKfaYEZ5THz6zKMzbfjrV07zy6PhzB/e/JCAJQ74RlaMfVQul16JybuTZPTjG2FnADPIQIb+yL62ZiJ6/n8TsPCt9y3C7BY0qY3M1dwagAKUm9oFgOIU8Rysw2QlKergDuhH8Or3KxsIWRXAYgyFTdT4kooPOJOINwXCEEv81WQV2jDX+Rz8KQFN4JbWMKHFXPo5BvgsJH4Jo7lpCuwlX1MxBpmNt0JVHkJDO8FtHM90xV9htA9YrSuRcaQzIpWSuAmG6JxNL0Hi9KVyEEEAJZIbvhfI4gJFrLUHciTgCmM/Y9XrpCj7nzTApoT1g9c3lf6lUWL0/bd/vnm9kafx2Vp5sk8y+fUg+f3n9m/y+evh4M3oW3ZMxxE1wfapaVQCH1VSywKSl+VA/UNycAidOrPVbhBOQRc47CHB/RHV9voI0fgMGXqLISmuzv+ylpIBaQkSCz8bz+u6Zb6ZeogQCZBTRgFRAyT/QamaI+tBZAElRTxpyfgMmCB8NC0K1BNyQ5cj0U+wChJUCK/via9NXcigBKJRVcoc84d7Wkw7EZncKUlQkdDp2Uxx8Vi5TNfl7AM3OfveXRMSDxg9gp5YROB2pKJUoupmCqxQsIfkAh11cjOmtJOhtZAwbDD6oANnkeQq5vHDGL54EGIpaJBnW7GKCwpA2FhEZNcL+1h1QYO2Ozpuj+1Ozv7cijerW0YH+pjhfTbZKlc0mYHoGeWRPiStYmdkCjF+tKKweVMiNhRYUioEICzrzhQLXjRUNlDaKRO12uLLMZse9lmPMmZirAGDdYXox9pCc20lYvMt4VaciPUF4ES9/v73f6zkpwQlEYBjQTOewgL7UJlg15WS7G0KaHv9T58zrKfURNX4OIIH4CtSFfOLPoMiyiJBWKRyl33a6VqPHeyXnhBCUqZzHRgRVN/pNmRy1bJwbzJtOdGJHHZSGSi5KvIBnhIeD1+Ti/dyjLnmCU0JpcQwI+6drEKE1eqOy1RMlBJn16eT4eGI77+qN5kYgu0bdSZGg5mXccHJWve1KxISrOWaHD7lpmoSC3mLpqOIJBR6Utkon/DGWMla62wJpvX7XEUHnLgIlAFWWaQLi6zTIGi/D7+5Enu+2ulkIvzcNqZgdMVGo6CYx4rMGInRir2fZ1JDy+FtzjA4jW0VwoEuEYERNxaZWh6JWPH9MPZGQ13CtB/OsNwPS1VoCfVHwnEckFSo3Ei36gTaVmePfOSNAnojxYf3F36flNPidnlIvMvFLun/LvS0soiELCk2CC71ua3nbVO00OqRKhaDQ1zZAjjh+y1Rg8oBkKQX+Er3rwFyxHZAhqSb6uAkilulwFn3sIEjCidavXe3lxfIYLWQHhFHOKhEUGxIl5w1GOWLVEmpSmpZySO0smTsURnoZ01C5DmOxFrlEq+L9tLwwZAxNKzKVQgOhM9DOlj5Yrlcgxx4XkYE/dQ2nVsQWmkQlcVz0pfawuGj/9KLDjbEZpPn/T6DcLsrBdU6iXrZnoq92BRQXihQAwLdQPxpwjGx3BPiUkZPEWTdat87AhtLomdko6njRoGyJkaj3+E8ED9X3sf3BSlB90gBRknCrycbiWIkgDE6Zj9Qeezw6uHH1D4hl6uDCXsz/YQDVbXQzlasBQv4R41IpA4UCRCMbJDFMqmto4aoKvxcPqhjGFEiO3h9d3F9enJxNzl//3F8en538/769vr0+iItC24z3jqmTxGZVdHjzHBpTiJhIRgKTcbeLvpFPUzTdHc/6zTQH/O9mZiIxhOCt5oiTtFkpFObjBaFX1q/EQGIs5A5xzFYwIVcurIbmrmabCs/9SVTZx9hkeYswOWJOnahKe0EzcEGZQJlgNKL5rGk2DClNpjGztMu6FKDJpPYA70lUCAcirQIfkIjQZgBoR0nYZCJBZJFqN+0UGQ98b3eM4lSobnvfRYXNCqee89JkvB/zPNLGC4IqrEUt2dxggpAzvT7o4MD4GsDth3898mKuLWoGpR+3Ie65GV4sf/1SFzqn2CCVk9gwBArqH2Gbvq2Od7acbi5g3zj0s/rqFfZ9u6HA7HqQn27p3uDY+V529/SY5mmTqKUricCYq66zpsQkVtHb2lMdSW/ZT5tv+Gi/yzed2X/5noy/mvbC9Cj4oiEN0tTCIacotrgicCzA242vMETYSD8skTRf0D6y8YETW9Vetp7PoJ1CEdckoJw27n1IICH3Gh3SpZ4EE/PAM71bwC0yDczcBYW+VkU6UPI637lWDeZTrUUqNZdLjVHXeM9PjuOTxU8G/IHiJqx1T2TID6JW0ss4DO81zxXATzZO3iu+bPVLyNZeJlsnvri95IO6ds9N/WkzIhBlHxRNNQMYV2CVrt1hh5bvm3k2g55uG6aY1Wa4aXYtcwbrWfXM69ChjaN+mdxRY86gVIdNnqltcucoDYJqDqIwZI7A3qBTdVcLjSCWqga8kZQ2RJp5j2nti0bM61MkYBK8Aiszm6vry8mw/WboUYnXKBznFIsFLDqm5okN4KQbcdum4xut9vxJy94yj9CTEl18CI5FnQt34b0XlUwbJK6cdROQuuNRspiI0E1TXs811Z9Zm0aEudVVNG1/RtQSwMEFAAAAAgAjbN5Xe0l+PovCAAAaBEAAEoAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wMl9XQUxLVEhST1VHSC5tZI1YwXLjNhK98yu6MgdXqUQqmWyyVfHJsTS7rp3YLtuT1OZiQiQkYUwCDADK5nz9vgZAUnZmUzlM2SYJoPv16/ca847eF/Rzr5qaBtNb2inrPD0b+6T0niphvVX1XmbZYnFrTd1XXhlNjdrJaqgaSdp4+dNiQQ8H6SRVpm2Frh1VVgovSWAHXauaf5/2ot+vbs/JH+RAteENqOu3jXIH8oYfk1N7LWsSvTd538XFB6G1bAq62lHvpHUkGhxRD3QQRxlWTfsv6UnKLu4kWkmlqsslKc0xIcbyiOVIosQjcsi5ktRKL3COWJKXSF/shdL4yVuIyveiIf5bNA3COhjnl/xK42xdh4+wpdopvJzTTbkgiYOx6ktaSFY2IYpOdbJRWhZ0LbGahHtKiWFhr9NxKyvTb2TsGANQdbIyOLoRva4OWL3DW0HW9B5bUsSsoHuJbL/79vH+6l/Xm/Xjp9v1xcPm/vHiev348eZivbkr2rossuzdO7oo6PJgjItQ2l571aLon/BgscCpXlVUPsttiVLzYZVoqr4R3li3pFq4w9YIW+N3WSt+SM8Kefee5IuXVgNABKxlYA++4t155R71QSmRylE5wKy+iPAFHSQIifq0sjV2mIJbLDiIHDgdVSU5mGeuA5hLWgJib3vn8bMxCJCuTc2UrMGIzqojV2WnGolzBdW9FVvwl6u+RUGWFCCsTdW3UvMefAigvbi9Kmjz0jWgxFhUiYC5WPhDoFnmiHCOqaRzSAoYBhB4gbJ0c0+dtK1yTD0XQf8ZecU+4U2x9DMACmgwiqR8ln2wpg1va7CkMdgi34rqqcM/1KGppf0py8qyRAqHrBuAuf6eHm5uPt6vpn4ougHoPHOc1A753Id5rrk/vvlloMvx4Td4WnMPFKvfbu7+w3tn2YbD4Sj8wcoEIlen5E9Wp3uucMiqjIkLPSQ6FLQ2qB1aHRXjpslDgpAK6AjOOiB66Qr6YGxs24TmUVglNLrNSuCPB4GCcfdXREj9GHb9SlDps1WLGhbtZ1cGkMvxcYgZJYGGUTnD9tmxSLxRCFKOS1/Tdgihblk6JTK88vxKgTqaKYw+HaaUK9OxOOBl5M9O6VlSAg0hiQX9lwV4FAjoVdOjElSOMKWAOHSjsbvyDjKig1SCcj6x6rKgW9BDoMChsViahr9FksCqP6EHQnAjnz4qvqjurzaCJmGn/7sib1nhfJDaWrnKcJ/ljiBOD/eUd3TGrx4X2OqM8mPk4MMMdnIXCAeAkHnsg7dwLhOrogoHfJYzIIoJDPyQWdf7YCssImwzAbchLoHCQr6WoZlLhqeM3lCw340lApPuNh83F/eblXwRbdfIPOgb55yY9vZ90KecvdOlr5Kb1dA75GFZFI7Qw/ptWqnI62TaKwCsdvCo0FZmt8uyNXyFAQ12vlhwT4TFkciLxTLCmE8rA1j3/77I3//wYzRAIHW1XlIyyuXoB8tTCVsG6QxKy3yHUyXmLyE2ngeIFRTtqFAat6pgfVHnrWkaVjCKydMFuvZFOc/TRpBUKyuJ+F1yMRfGgJYNKLTUUYnTGWHsljQfLGPLgRhoGrZt5DYiuFgEGeLXexVnhiit4ADOnWRVMGVMvz+AINBMG6eYkcfjFvJFVr1/M3mAjuEBJ3LmyA0wo3ayQtExIKKJFdyAdGgCdSIEYbRikDR+5QhlxAVKe1l8VPqJHhh/aEeWfQcCcLR9HHR8eoFTq95aVIL9hIU6bDhNLydtza7OofIJJ0HHKAFtsDLYpCyy91GaBdCN8+GriFmMmFZ9mh7GAHjeOXOnE9BiMfmMgyyiRlApGyMEP6Ypahx0do155jGmYV+MSH91mmTKHYMdQ4Inp5xKGrsVKkFnV2nn26bfK32G/t7KhvDP6L0b7R3R7oNCV6LzAGDGz57zHAMM2tPZcEz40xV2wnQkw/eWZ2VgKwKyRfZ9QXfyqGDEyVI47VcN1XFL8lhlQfQw0kGHXvlckGhgdg7+dY2qlMeXqWIhohRokf0Ds0WK1PUVzyS7vqGvVI+jgIIC6dOURqLNmfBUpnZoOKy1weus/KNXQCeRg91+7OR5WmYdqWfzjxzB4tSfXOHzaf4XeqZfanCe4POr9awC43Sb/cBTIftMGMKC2s2kwAnYEWPckjlDoEPMtGoMz3rIojN8T0HFUVAPVXLxKZjGmeGig8NbEwWNV9YGWsSdD8eyfefnZKdToc0/jp3SsXY6lsRxmlkil9TUFO8aIRgIZ4jO2Anb0xEoBJ0KCWk0GLJRULw7MvCX05s/etbtWWuSe4Q7hzdPOGAnFHjxz+B1KBaqgNj5oZtbd+pApuxK1OBAiIo5PevBqIGxhmAgG/izVT46tM+xqgsN5sJU3XgZ57qJVcgDFcSd8toQu9UbQdnx1y5c3+CWJwBzXStM4i1fpyDNRbx5DlGnQ8qCZ/fTC9yv7+f2DXA2RrApsayCGsqZJqyR+qis0Tz9n59cIKbRPtSGPe1lQJvj2qmQ2zPcwkk0LrZouAGkrZTj0kAMwGWJN7qS4ayY6YRBah/Ht4k8WF+8A6EFK9l5Xhad4gMLR7S5w7BXUuNi9mu05mTyydr5lPDAPONmi6KJ6TIseAYdErIoJYTI9O7tcBHg4VDy4O2sn33nRv5H32u3fM1Fh7Dbi4YtPE5J47gAyeetpn557d+TG4wzPePNcXEpTlQjTAYn1vEVORj/b2C8Sr/WpAvWztRRd+lpOReuxUURf429JevRu0/dK43klWk7dMwKnQ8ebnG0hctUiqfzIF0VSltJHaw0qHp4GMnMzgxh+B9QSwMEFAAAAAgAjbN5XZ4SWTkMCAAA1w8AAFUAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wM19MT0NBTF9TRVJWSUNFX1BST1RPQ09MLm1kdVdhb9s4Ev2uX0G0CyQxbNlN7naB5vYAN81ufZsmWcctcPeloiXaZkORWpKy40M/3I+4X3i/5N4MJcfd7aIIUMnD4cybN29GL8VFLm5cKY24dZUSQfmtLpX433/+K9STLKMonY0e/8myweCq9V7ZONq4EMVOeqvt+vVgIOJGCStrFcRSGbcT0qvutK5gr1da+SBW3tVsWsomtl5V4uO5UHarvbM1zC7pxz0fvr1bCG0r1ShLDsyewlhpX+OQtslJigWPIUpj8EPjXdWWUTsrrvIbbR9z8VF5vdqzvW8thSs49j4pxLtyuM8rs6cfHfnWoYchz7IPQaVXsBMFnERdq9fixU4tR53ViwLnzD5nBPPPQQwG5+cC5lbtlAc8OO3Vb61GyrmYGiNW2gAro7dKtEgQjjtX4yIXCwSLlHw8fl9LbfP6cyhEG3CU7hPLVps4Ahxcuen9LAxFcJQsMsKd1gnb1D1AkoEJUTXI6uVL8Q44jADZFiWqjssgttJruaQIT1f6CT9O38xSec+yjKIbDJzXa21BmqNSItGePQd4OVhCf+UMiEEQG43EcJIdXsJXhTBdBEL0howDJ3NMncFgKNRWUXFcu96wx67aJ0E07dLokh1S2lc67gWVX5xe5fyfM7FQvqZ4X2fZFzE7OBZfxHslmRZfsi+j0Yj/YFL8+mF2++nhev5xdnX9aXH3y/VtAeO5tBU43Hi9lRGxukfEtFYWCUVgsExMI4ahEgTl0RsK+AnsDqJ4GoEMtqfPiN2g8LdI0QMHAGqFjnCfoENdIvqAGGXcOuTijxHe380XFOBVXw6+MagoiklBjoh/Cq+kFXcPuNmokiI23PmN8/FbXt9OF1Pyeq/8qAQhva7Wqj+DsmiwCUmCXgCjAr3L6Dz64CFST6H2XlQySkGEHKLSKDN1gxV71/rjxpXlo1wrCoH5tcQzJVy3iHgJHSDGEeOLV+c/5BP8e1UQJcqNcyCLBERKIS9OZEigWbHz4FkSIbNPHWy0pZoh3sq1ET0EpgJm/oUyITHLsqIoonqK2VdIzK+nb//JKP/46vziL38lqyw7LfihIBcAFpfVjVEsYwL3toBJhqDXlnJEaGKn0fyVXq2Uz8+40blOHHC5UeUjyPHz9UKMC5jGDaIjKSpBCWAoSShAQNTyM5DGlYd+ixsZxUpqE1KtQ+MspGae1IozlK3FDVXySwFSedA8hBroDEFaK1DrbWpGhN2mZjwUg1QRty8dKQKoWMs94w50PWIbJ8AdqY9AMW0MJ1z9PNX05w8z0QkrzseNPzQyQUBd/BXJUrMkmUmS2Ot9ekcG0ZUu6QjDkgZO6skeLdAwSZimypC6JRk80pZLsfRuR1wteQBCYUxF6IB0GAuwh0p/mN+wCIW23HALr1QsN6cnY9noMQBT4eSsGHIYoDn1MYjetFzaLiTE/A+5lQ+l1w1I+m7x/maYpto6zYMh3YJe8EgIEonnvuFZrx+6WoMPrSeJW0q0MSidZSMxZ0r0XR64yq67/giXS1xYN4QKPyY7CgKdiLHOZFnuo+rMdHA2h/eP0uiKehyBbVzFgQ6RECe4b9Dbs7cIt9eYoP+tEhbc/Q1pL9oAt1yibKTjOOYlQArUIcQtS+HrdNu9kaXqRqR6Kk0bUAGwLE3KJP1Jf7+lVhg0MLvkAk5+mEwOuqQJ4cn3eJNc070yuhqTg6k7TgOIIvgJnSRKA21BaCsBjymTUlpqjiWKIFc98Q89E+CWVxWHzFI3aLsl6JJCkuc7UrGkNrRrHOnZUDBtoNf8YlKQ+XTrcLrfXMJGQT5QmhqxB65/RV48LUmesIFu0bE3gMqgKWDdLSzU0CqmpJu0QGkvNhIuURSZrlE1iIz4qCHhOTBTAzl89zy/ujaEmbJYiUpCkhae4WQyob8R86enwtJVlG+tSfhZu6jtcfhigiEE4lW0V2GTpB2kP0QBg7y5oN0r1DQj/IHa43LT2seUSSTrZ1qkuUul+EyDg+cUvaMM+u45yAYjkSYy2oFHk7ibtnEzxNgxUfP0ki1Jc9Qlq8aQONECmL0tuTmlqCEZpt+iSEGsfSby9RPamJYkq+LO+Ufwx0ChSTijKjdW0/Oe6NQ49Ac2rrQi0zp3KSpVGgqNqthfkNIuXehKucZgUE8Nth8d07yVDdlK028TnZBL2wlz00BqISprVdHmiPUssB7C3xasp7Uvyc28Ix2jiChp/a3g0riGZDTLZhb5R98yVyqNkRPo9PMeMKQxTz1DJOQCaYtupkr36+2xTPUrGu1MKV+6njcFTP+dPbqDvjiYKCysiQl1k3oU1+fiJwTbTeM00dErmwxI0RD+42r344vvTps9QrEXYlSKEwwLMkyTN1xCbmw87Z5yvvTTRj2dXpyfnZ2cvfimXxIjcls/cmij6k/seKWYZJZGz+L6/f3NdHH9MO43ww6n8e+/AtL6MaOeRGhpw05L3LTDPwHUdxQvUoGm+Dd3z9fib4zzURWf8f17cVC4NqSVALJnDvU66VeUwF9m1KM5KsZfMVyBNFcxBUChmr9K1O8bA+VqpK7EcyNRp+SDQaKiYhw6/TCGNpIsuyPh4x+Gzzs24oDSBnLo1eHjI9CK8PV+wVxJsyIXb9JHYK3X2OOJddissCzVctg5TNtd12d0fds8CxDgJsXH3juHgm7pPC+ADdmndeNfs/tUg6/mBL4aOkC7XSzQ3lyxQ18BxV+UakRiTeg2v3QVAVWqCps+gU8rQ0w7kGvogzDP/g9QSwMEFAAAAAgAjbN5XWCsOrFVBQAA9QkAAFMAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wNF9TRUNVUklUWV9BTkRfUFJJVkFDWS5tZE1W244bRRB991eUEqRIxh5gSQIkT6sElFVEErGBBxDS1vTUeBr3dE/6Ysc88RF8IV/CqZ6xd6Vd7Xi2u/rUuVT7MT1t6FZMiTafNjRFe2CDh3D0EtNgpw2x78iElFerx4/pYywpUxuK7zieVqtrujtKe0eGY4622wnZhJ/gOEtHfQwjvQudbCgPQgOq4Ahxgbv5jQuGHfXWSTqlLGM9jGNrc0R5ks9ZoseKJPFgjaSGbrKekIrN3DqhPkQUOW4VOKrsziUNDm3O8LbL9ocwY/GJ1uus/QCpgmz+SnR19SUdbR4quoJ9TxK9v6VJ4mhTssGn9foMYr32IVMC5DZ8lm7+R6KRve0lZey8fXO9vXr2nMwgZp/KmNB9OAhNbPasXPksO2We2pJRrwukJedFFrW0jdov96L1fwUinKAa8DQvS6FEI5W42gzZcXLWcFaw1AoY0oNSZues3xEIQ+9eH21u6Bp4sdyGks4sgyWPX3RPHY+KUw7iyfYVEnqiCfUgE1aGGMXkZvbGYGO3nUDxqQLGHxPG0eZRfE6r1TcNvZ4btN64gs5y2ItPG7r+cEN7OeGJjYG3Mt28TosbM04ZOLKBFZSZapYNmSgdylp2+CBjK10HGW9v3yyFklS5gCDsrW6YOKVjiB0eQYFKi+4yA0vVepGkWV1dUCYTeVJmAxZEJfxJOtfdUHvSinXvR3UHbIp/c8lDiPbvSv+GxtDZXmkAVwtwHI59ZRTtVbRCgPrW5a319/5MzerbC5AJ5mAyLhR0+PptLStuq/rbDshgeIc8iZNRcjxpZNmdsjVKqNoCvUHv+eySwwh0hsqE/qsNPCAwJINxpLo/4EDjhKM7UWcTTk6zX6rNQpvZVgM9CMl9QprVU0VuispOx4FrWKJo5o8wexYQE0VrCF7J5ylEjaCWRluC55fUs3V0sMm2gADnVakUPl26RtHi+YCFOgkuZPXcRrU/Ii5pQgaUy2cN/cz7GSx4V3Eq+J2u0xmyBGSRbWLbYfunghiDQ1VOTeh3KuAMOC14E0JX6zWr58AgPReX6U5pvs1Q8wUAuSR3G7prQ8ivQADQuQevDU/cWof3kl7QH3/eNavvGnrDaahHANmEiFW4v998OCd6Kq2zGNB+93IhE9zE4FwLsZFNM9gDSPlF1Fsgt9f4IMeYqnMnzer7BuNcIE8UD0IlbuHcHQpVslnpXcbj5sEEgNvg3TrZFdLFsfAALg1Qp6V/aOgnVWunFjhrB3SynRyf1DrzvAedy8y7+BIqnIBInSLqymW8aaX7fGWsPOj4wQTwRQeoalgHQj419GOVSAmRg5VjvSkwp5D+Sqkqa8HhPELZzePrFW4nTKmPaCofNZO+c7BlUhVryM7RpIFxtg/315MX7Ih7TJ3SYmrY6ZJ+cTWdSfFVV51n7IKhjsaFrIeXaL0Y5nheTjk7v5K2xAtmhDkAE5cHknCir+gosq8PI9gZ6hN7X9it13WSagc4buS4VwVHelT83kO7//75d0GV7lP2qYQsjy7pMo7tSF98rV64ACuJ54sfevR2V6I6BpZ2+leHrTcS1aINva+zg8JUx93iZfVRb6N+scCmqhYvmVJhbk3AGHZ2rLIj0bNIanSd2nowz3kw256NcrZeozDsVOWeE7Ar6AcUaNr1wNCqFGDut6vqI71hzjd7NSR24NqBEFjb46fHLanfLNCK7ZcLdrOcq1MS0uEWry+T3XnORVvTAGGClPoJ1+GEfTXts2URvEnTBymRvSHX6+B8n+jk7kSFgkXeBRUFVyLCjhCrQ+avRnNA1F/LdSkeIRaJSsQyCOq3svnS7ZrV/1BLAwQUAAAACACks3ld7xtMFwYHAACDDQAATAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9ET0NTLzA1X0FHRU5UX0hBTkRPRkYubWSFV2Fv28gR/a5fMUA/XCxItONc7q4OUECQ3Fg4nxXISoq0KKQVOTS3Jrm83aV06q/vmyGp2EHRAkEQkdzZmTfvvZn8hW4zG62r6erq/Q0tVvPHy7fvtg+zzfLL7XY+W2/Wy8XH2+3jZvawmK0XSZVRaBv2gTMOlLo6L20abf1EhQ3ReZuakmwdom9TiRsSWnBu2jJSY9Jn4srGQIby0kT6+/ITmTqjCn8ZHD6R55JNYGpKU3+gkp9MeqLA/mBTpn1rywyHPVPpcM/U1eUpGY3+RO8TmrvmNPVsstOr6yl3HnfgWcYN46860myJxDPJ2Tzh92j01bUaVS/Q5zQez2080b2tn+nNPNF/XNCGfWVrVJgaH73Nnng8TugzEpZUKAIDyvjApQNEtEfBWrQJdHKt7+Kjxpw91yl/oMxR7SLeP2ue+GPrg6Ro0pRDoOjwILKXKz03LliBmMPkWyYBgVOeUOpZirOmxNvG24OJLGFcW0c8QejGOzznaIAz10+2ZvZSbHSuDIBxPF7z761FHDo6/5yX7jgej0ZvE1oDVtpdXQkN1pvt3e36FkTYTWinhLl6+4Ip89XDZj2bb159cL392+z+183devX545280bb3L3/cPt7OP6+Xm69bkGz7ab38Mpt/1a/2DFi471ZCyxydGdgAqFFBxtmEULMjr0l2Id9t71fz2T0Cr78s57eIudqs5qt7CZqMrhOaAfFYMBUtuKfYy69zV38IFHBjyYJkJYA1rQf8wBm0V4i0L7kR6I8F4zQAhiwgAumf8pNEEKDYq1RRt6nRgD8aCMdG6crBZuwva44C+2UjnQ1BNOm7flSIGLrqy47hkCCOS7yeQSAHQ1BSxO8th055o3eQReHcQE9Xs550PqIAD2LYim9od+T9TjGwwUGWeNeln3uHIpEwXslH0x767mNILMi3Dy7j6+v+iFAeJyD6Lq/Gs0aQxEI00abDvUPhAVD0DJ99WoKpqLCkCkFFZaWyecAVXcfFuS05nPC76mWSjH5M6DE1ee4gL2Rd6X37ts5KJIgPGykrUCtNpV1zioWr39Fmtbp/vDw3PWlOaNORkiTZyT0C/sGU0s5OZJKVzeFwvbH9ytzoTeNx0+7RTqkpg/FQbSo4AziCjpW4lv30YIPdg1AR5SoLxBnMk/B6BPtaIkdttHpPh4GtbdVWdLBGDuZtrZYmjrM4d70EA5UnrM3odA3dFOZgUcPRxgIRM07BxGgPUgMMCW/6M8i/541kKU7cIuUT5WYvXg4PkXfqkxCFa2PTxmT0E/COokwTAsPPgTR3Euq7Ow0Np4IVZSBwKt4uWdc/xL4tIG7aSr0K5mRwTUUgpN42iIosA8PX8E8gKdHF2ZGe4oHh8QEPhd17HEVj8VHfKJAHtcqd2qOdaaN7hPHFGxRWBhZn2jsX5x7DDyx78Tg1jdnbEs853NA//rlDcaV4sThPY4AiA54he0CODCLlUF8reLTIyNt/g2wV8ElGPyf0kWuWYyC6ATce72bT6/c/UYNilAj/pbCub/+LqDpXhKnizmnB+PX/2d19159q61cqaWuYEUQiTvNX5wclD3YbOpOVDzqFqt619iDAts2kb9a0gEWBDVzDJVLlNKaT80IDNenTVByICtQeCvPMCoJnDfNS68noF9CscEchQt9RTTnXwTcevwTtXKfANx5PSNaMHurux0Eiu/pyubgcLEjNWJaY1AYhTUc8cV6Xw9WNzOHY6UGsOUy6h0fM86h66x9YUQDig/DyTKcv9hZbicd3btEV6cpScE1Gf07ogaWevgYpUd3lpBXeyViC3nC9aPY87Hsq4hPMgF5hmp5pxE6/8UjuHK6ARsFV0eh3pN0rYKjq7MCAouZ+ceo2Bp1NL5cLXRTgVmihkUEHYvuXg+oGvnf7B1poVZGaDi489wdQNZnuJtBkZWJXwER2JB0ScE7M3qf65RlaLj7A8Hp3GqJO5FFpYIsYvvojmIOYISwpoQ2CuRzbKezwyzVkAdx3KLCSZRP6RSI6oMS4QzFc2eUGSMB1t48GljL0tcNsWFBf7ZhQd6Hc1EVTFjjdqwqu0IPOdtEtyBRxCyPbw/39b683NkmqdDBv3AAnHhA97wmT7/Loe6fdmGEKNuhGiplzQ19l0/yX2+vWgQqhFhQoS13BmEdqLxUWULAG081qvZg/kSrMc9EfZNsN0G9jZZgn2CdQvhcD7DrcKnZqulM5BzH0QUVFOooHsQ0xJiRK/sYtWaSefHdAUHD1FMNANjxzrkvLXHQWIHIPUugbczFQoV/8dSS82V8Q4z81agvDPBiGEF6nF/C2gMmkZtebj9AZ77KLVwq6HAQrQHLAB3whe08s8rak59odaxSD/9EMG8EMm53OUQBgxBhPOjPFTr53eePTAuUko/8AUEsDBBQAAAAIAI2zeV1eawdokAcAANgOAABOAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0RPQ1MvMDZfVFJPVUJMRVNIT09USU5HLm1kdVdNc9s2EL37V2Amh8549JG6HxefFElp2Mqya8rJpBcLIlciKpJgAVAyO/nxfQuAtNxpD06GIrAfb9++Xb4TP0/Exuh2V5IttHaqPghZ5+JY63MtSlUpZ6+uvom0qxqnK/FNzGVrCf9/VC/i29W38Xg8/OFcUlsny5KMsLKzYvuwevolWT9/vnl+XP7+lDwuF1vc/WI0/NisoEri8QkG6UVmDudn6+UqfY7X7mbr5OMy3eD+dsLeBoNpsv5ltXw9cGn9TlnLeWgjqrZ0qilJVLJWe7JO7BUyxaH7mnyiui47/HNxQjrhChKNzI7yQMIAFTYlBRuFqbORTUPmbTxP64dkvV4unj8mq2X6vFiukxDMH8mDyHTtpKqtaOucslIayoW0lhwH8ki7VpU5fKIMh0JsN/f3q3SaSeOMyg80abrtrajpBExlnotcZ1ao2mkfpRrwhqN/QfRpdvPTz893SXo328w/bX3NOHnKleMI9g7XCmkLBosDMW0ttpz3dsTG8YAK4emt3dnqcTlbfH1O1ulmtlqFNFNZkUgWQpaGZN4NceV4l+xFhl8Dt0Su9nsyVDsxpDgSTCmJJM+wMeELCKppAhlF2+TS4dCRqPFJp7O7pXeG+vFN/g01MfoEf9fXVh1qzq8FYeE1iwaur0VWyLqmsofzrM1RAnWY2XX+5YFdsjlYR8332mT8C7jRylIYimlFQD48JasNEEkW4F+6fPwcsMDdTJelyoH1WblCcIHdWNXcPWgyn+srDIdS72CzAzvUXy2JUp/JZNKSx8I7+rL80LfEcr15/PpfzeR8qjBouthS2zPtpgqUe5kUripRVB+NRDou80UHRQRQvvDCWSTz5f+62YEdBLze+LFkTiqjaQWST6o/LTytdU7i5kYs07sRu0BBLrzM0nS5SZ/v16uvWzF96/nNO7CyrZ0Ct/a6zFGySlkfPd48tE5cA7jrvpe4u0zIesvVG+LaonK2ocypE5VdiOOzAtmUFbtS1scL0Sh1hkrbzKjGTedpCh1wxUj8mgoyRpuRmKcP4qR0Cbh1HREwxI8nCpH4K/ZW+OYRO6PPCIRFwOqSbtHA9XeOr7DuiPliHb1ZjrnQUKAGL7WMgKWhsA1rUQb6Qo2shKsgZLiCeEsUlemvGIDhionQocVFrX1Jpn39GqNOMHDwWhhJyciNI2bbwBV6aUqVKRfbC8hwz0kWobYCB9Bm0WIMNtzGPcwNQdKU3QW2HMHNzUjYDnr40gNaxbdUnyA7GsamaFfZVxylIqP2XZ/OiKluXNv4UMLY8JozbrRxSLbObSGPNBELDzQyRZNZggQ5+zZK3RBEeQcezR4SGHGtwfOP73+4iDlcFAU8IBgULFcGTAo88dXy+PPkAy4bMpWqAdMJ9AqyZqGMY20UpEVs9wTuQs4B5ksnbNsAXpTAZz1hE8itzmXJA8lhGFlkSwFxZRttJea0f9FfuUwnGB3S+P4HL+qQFBzH0Dkgfgd4xM3o/fv3/AfVc54AC8XUCVNlx3qIumZFWx+tQLv58eJv+rnovfjNILhfcLEQHk9FaWzkH3mW5rD5Zk7lfiDyZKZKQ0EMWqW3zpzki3kwyDBrLzL3Hj2g+vlGRH6K2YeE4cWKAYlaD+qxmG1mwJdVD8XNQVEwEK23V6YSWWu84vqywcAoQNk2B4PqTiESzCzPqzAg8AuFdovMmbOs8djgEdxTwWudt8RU4gYdaACVYri8aoyGhkT6kRAebIkkwzhg8Da+unEZYOg42u+sJwsIDgTtZb17Pdl1DcSHI8ZMzVibYshxIwtyxWcoUH6PidwaoK3JsgHOiuP1aw8zH92u8nBNWZ9WH7/MMmpA1Iz6eEsWvx0VEspoPIC9Qoi9VCX82D7QKFeVhjZKlKbCesZZxXg4aEQ9w/Aeh7ntI/T+pTHsJyxVZ2nDYB1QD3N/2mCZVbag15UK3MIyUADzv/ErxJV4usZlwDcJtyvScjzlAWveegSHo2wZkIwESGHxYjRc9nLYLxrjnBgIlJO4n4DPLWIAeEflehWOpvoo/b6hddwoFi3LLee8rHk5m2LZ5Kn7IOHLivtU8FxgHTJBGj8xkzmGYZcCpaDbilH18PtBPY3XnhJudtoryAv2eySDNUvoPZQaIxVjiFhTVuEwvgda7KWhrVFcLENh1Yp7MNSCvFKEWPnRSI/bbZQoPsv6w0TB0TFKOkyKdRiYGMsE19PX8YUguG2VLHmiyxPo41UPV3TfwejpEw8FBe8eyAxj1mfPqzZHEXQH0KeL3zhnHRiSYXenYSSjFbiafopStYMxngNH6kBWE4WTudOvlvPJSmFZyGQjd6pUrhvceda+eye+FPHrgacib9LDyGap766ukMPF7DwQaiDLcdOahiewF6bkYe47zEL8m7JlmWhYT2KsO+p0nXsnkMP+q2X0umT+F5IjFmgQBK3CvK6kOZJrSpnxOA3rcmy2ipja2LL8N48PAwTllWSMoW7DEp9l0C0MeMUymJVtztsdtnYOKgL32tHQUsotf2ONhPIBYZjzyX7wDzVjIvN1yCp/blEjDYc04M8Ug1SH1rwYHKo+sdnwtYASTq7+AVBLAwQUAAAACACks3ldfXevgcIFAACZCgAAUAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9ET0NTLzA3X1JFTEVBU0VfQ0hFQ0tMSVNULm1khVbvj9NGEP2ev2J0fIFrfhxHAYmTKoVLgIgjiS4+PoCQvbE3lyXrXXd3nTRU/d/7Zh07tKpUIR1xvDPz5s2bt/mNpoUKyhq6unr5hiaL29Xo+Yt0Pk5mn6fp7fg+uZ9N3k/TVTKeT8b3k2FZkK8r6bwspKfcmo1WeVDmkbbKB+tULjQp44Orc87rhzSRG1HrQJXIdyRLFTwJ2mgR6MtsScIUVOKPQPCRnNRSeEmVFuaGtHwU+ZG8dHuVS1rXShcIdpK0RZ2BNfo47PWe0GuuspfaAlmXI9/KfKeBqtd7KzcWUY9qz0gF5cIFp4pHScHisUaFPsk/KvSigmYYuXXFm15vQF/pG912x73Ve/QdtpIuL0UeanTr5O+19EEWFITfXV72ydiArKVFvxttD8NTmqV06FSaAPgH6XIGiS/UBtGUqSKjp0YeaDYhoEUCfuiQ3gAfCtJq/Gl6PuLVo0FhZQZgDBTVFYiUzyKr3NVgI3Ju+XZ4p8yOEiBQBpjXDifwooW2qqvKOu4hW47n07tVurx7eD+bp5/G89m76SpJP19ndFBhS9lBrjNCdf4wOM0mI7SF+QmMp6qcrZwCjjb7dC95trUJqpQ44yUoUJGymBJkg3H09mE8uH756ubMCjOpDGUbpaXPunzMBMZkzZnAG5wFRcEJKmzu++Rzp6qAD0WjjJKJj3kYvJe5k1AikrNahdZirSUrsi3C4qxNAUHF1kZe/ZCjSgCuViziWNAfSw1iUQWF0aUXGgVrFhL6P5dj6YYBimFy7dL4tlJWHcPWmheULBZ3q1E38mF1bERMi4dk+ZAMf6gqg9xC7Yyn7MLuLt6gbi07YlZBBJV3TEMBqI4lafalYd5HccQp7TGA8XLWtDK3BfrD8lhR8Mm6rJoFPuV+i/WViGy30UiJZeSo6+tf+rRWBo/Pr18Pr/Dveb9BjlWxiOo3UKCKPdMCjcIBrC547VjCQnv0JYojsQojQIeZgghPXmwkr3mDYmzAibZ1MTIyHKzbjbgPxWNChxqDyC10g2BVohSPn4uhfP+UNmCcbHiVxRCOVCiPfLCz88603LQ1J0cjStC6kQLU8/o3684r2LnAWm7FXll3ecmbmsuGPNoIpQFYCse2AvUAaNgKg7Y1gODLjViza0YPRXI4ZUf5zFR1oL3QCk0w5gjRiBpycZBjMQqihOXhg2Xx4Suk+C6j855Qtrk+yuPaCleQAczHmI65grSFD32Y1RqASIujrcMIGescHZa2K+u3dSjsweAdXPbf2ZdOovnaU4TBqdtZY4r4G6m3Wq/5Digl8Bc4YQOgIglUhDHvGTwE2om58TYvSjnA2qBrO2j8jSpVSexdk1erfWt82HV+gtngj9ooDpeVAO+SmXa2jNa9mnyMt5F0UfmwkMbHT05w8gfLuUVtIGTX9Qn/hlYXK2ISeGSe3d9gH7qK0dKQlknEvQbXKWwNcxlMTcD0UeKxc8Y5BgH0SbIarZIEy7DF7RapOWkaT6xXXhDulW9eNk4kxUL5KLG44BBuh6B/3u51NBIsuGXlHVS8cdwOb97eLW4/Tiejh/nn6f3s3Ww6OasusoDqImcdC+4Oa8IKrZXfsvKZych7d6Ocz95AoqcNUUGWvpEANyVzADjv8ocazNMWd8ZPV28HvbXlqMCn0leIxvMxThCuFwuw/bSO9Ix/Cjzhy6GsIGWGgBlEQ8Gmwg16vSzLvntren/2iC46n01VASO9gPLdAB/7/PJkofz9T9dc846lgxmmGBZuKz7y6lfa4nouALEEFzmmCFvArP4Z0MBIozNy2HK8WjUnFH5YMEnpFu6VsgVLdz43XyR0/zCnEXEE/ns3nt01gRvokxkSOuWG/+c0PJbPNSNLTwy3MeOH5MPifvZlOvmvUFyt0nFUJVSRRq9F4FV8xxabHhymnfocixF7O+0/FDs4/9xqTL/JuDOwkzRepnHInO/rt95fPKXe31BLAwQUAAAACACNs3ldI4XRXRcDAADdBQAAVgAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9ET0NTLzA4X0NPTVBBVElCSUxJVFlfQU5EX1RFUk1TLm1kXVRBctw2ELzvK6Yql5glrV0+pSqnWL6kkptVuWOBITkRCCAYcNfM69MDainFB61AEpjp7unGT/TLmZ7yUlyTi0RpG7kUKIi2Kpe1SU6UcmM9nZ5nUZpWCUyVm5Ok1GamYchVJkkuknelrZUD/fV5GOjJiv0p6YV+fjr3xQd65rq8bq1oECYmn1OrzrczPaPap0+fUf0qao1dCEp+rZVToygj+81H3vEQwKF3yFjiBXmuTcYN5d5zuUmbO8p7lcAl5g0Q56xtGPami0soro3Uz7y4rkBdU5OFSQvHKGlScpWJvwNp/764be+br1wpx2C/lcbVFCAOYtLpXh9SNRcjdkgCGshYah4FVG5OCedlFEDqYEVzdA1P4Nj0V/QgH50s+ICe0L7NrhHj0GalangskHK793B9YrPbZ6MODDhdpea0GH0gvKwS2yOA/P4VSk826O1s08X2hlJACXR/s2/aidp+I2f0E98iRK3SGicaUa2zCYATc8Gmi/MvBX87b9QpVeAVYD28YcK/KfJAMYMV/ktCa7NGEDclbBKvD4Simu2tmwx/ZZ9rwHuPUnghLtqmKldohq8lq7SMdpVHxsA947OxyHXCkP/t8jxiph6SewwPghqxYbBZHq7nAP++egf8fmCFFdBUm4hLOCoJruJkeH6w39VFCQ6AhuGhu8UZxug892mYgPdEPPYcZGgS/jfL19GU9RJF571rZS0wl1zgIKsRxTMe0/TwLrhp6sR1LSXX/nhkTklMyshOuVv0HUc6EjVVB4zF8GmPY8s49KYRPZ17uo9MS1OOo3lMlgKf5BEaY0JwYMhV+e5AZaTR5NkzK34nSr+tLS9Ye1KZEnRYC8TjPXmOXlK+JfNUWJHBW64vY8y313vAAFvX3gRHL1sPACAgvEzfvv5hYd8Rv83f+pgywe6zaML+s0pvpoxYoTloHPnszj2uq9PpC0N8pGaWUrrcNv2Fa+d8iA3/rbgN6O4RL+bJXnSjVbna5LXbAXT2zOWL3a/9luCuPQpGnlz8eGhnlyTfyJU9ZGZ/zMc4oya6K59P/wFQSwMEFAAAAAgApLN5XWhcSMzwBwAAog8AAF0AAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wOV9DVVJSRU5UX1RFUk1JTkFMX0NPTVBBVElCSUxJVFkubWSdV9tu48gRfddXFLAvs4JJXTyzydpAAI2kmRHGlhVJ4wUSBOatJfW6yeZ2N+0R4Id8RL4wX5JT3aR8GSABAtiSTbK7q06dc6r4F5oX0kld0XD44YJmN9PNYHR+t5xsF7fzu+lkvV0vZp/nd5vtZDmbrGdxWZBtamGsKISlXFc7JXMnqz0dpHXayDxVJCvrTJPzvjammdiljXJUp/k9iVI6SyntVOrob4sVpVVBJT5SLD6SEUqkVlCt0uqSlNin+ZGsMA8yF5Q1UhVYbAQpjXMiXalj3Ov9RL/GNG2MEZWLnDClrBBErss6dTKTSrqjP0Y8yEJU2EiJYi8MvRsOxz/3ev3+pAEIhBDERb9P4+H4l2g0isajmPr9jwhHycrfKcSDUBrZU4ZcfD7D4eiMmlrptBAFZUdyB0FfGmTkj6yN4Ohxq6lKXcidxJ9W1KnBYQietoANm4xJMioGIYpHPPImeFmcIZRKOzxTiUfKVSpL0jvKhXFh09roIkBOk9Xi9Qb9PqP0E/12AOiPqaVCGpE7daQHYcJyWSFyxBAi6PUiujFy74FEir5S0/X0glaTzSZ+vpd8nEy/rvAbX0+Wi0/zzTbefJmMP/wS/251lVzQ+MNg/CGsernn6ugOiLSpgLsT1tkLGr0fjN77Jy8p0+6AclcFKsVnW5DHWo+t7rbQux3XxdMq3QvKDyK/F4aP+Szdlyaj5Fpau6l1fh/dFMWn68Eml1z/6CrNkjPKTFrlB0rKVFaJrxbvn5RYFFleNcjkPsqBXzSOHrVRRbTTDTMVICft8gtKgPzvQNMO8ggB3Z8YOGgjC1CQdVIxKyuH8ywlOT8ce05f0Pp8NERISZ4aZyTYOanlBQ3jUVSYdOf4FkplcTBffR+fJ/TOiLQggPjM159bPuFnebMFV5gFSjiAE9ThlZkqoBodtHU+GpPmLv4vWaznk9n1HMJPwH+bG5lB+FoVUMF6/OufCMjce/SYwcpq4hNE/JZByXq+ullvN4PbydViBn+5WbbAGFFr4zhqDVNg8qe1a0wXo6dH0O/3GmYjmbfQsRTMVuy+7RTfJufrw0hoGMkLV+KNgnKCh/SN4FLgQCgiXO+fEYtMVoWoBT4qPssI00DNey6b8xzp0OT4grK+VvqxIg7fdErEuj8a6KzEk5be7YwuW2OA4FTxyiR9egd8gNQWluSd5wbkPtWLTsw4o7RxukSWOVm5r7x4IxgmjK2p2cTsGdm0hDIATFpxoItZDPvanqypZpnrxiK7NM9Fzain3W5TXT2IozY0VRBR2JJ8+Mn4z/F5fD5MyOnun1FyGZzDG5hPLQqgH9vKBkxx6htYAepm9hVXndgbXzRfopg2rT/6gNBaBnWTKWkP3GWc1oq/ywa1yGAHWVtDHyAX5xkyLs+g6yioD5vDmJFdARVl6WZD3rcNsLEH3aAomTjF43FFniptoPOYVi1mnbtbK6zl4nIv2+/x+KPRiMyi7OwycIY5tjIJR1W1J4W/2xvgKAjsAA8VDVObc/a3mJHpqRm+IFLcO+cEloDrAfjUQsDB3m0hq812+zPyYCL1+9P4ijV8YJ5dXV1TDjVhtYQ++Rlz2hO4aT6tLf2JZKBQ1rhQWC7SAQEhzFO78BXJ8Tzklim0Zr8qpiU6JCsAnoNAYGd16lsQxHpBf/9HQkCW5QAYyrj33heDfc06BnKK/vR5tQVW8A2E2FiBcPnsTIjKxwyCiCKmj0Y/WsapYUAdQ8f88axgtmVMHhWIluuaQ0aecK+05uXrkD0wLtDcMxG6MRsMPKMInZtdxbLjtkxCjtr3lw++Ato34kAOYS4ZHdCigc9wr2yF6C/b9IEHFmtZg37k4Z4N17WtqrhPsA1yIyLkvGsUE8C3hoF3LVnVjbMsNHH05QujQDCSVqHswzulH4Mhnbz3dnzyU641fIP+/c9/hQ06H0EVj2xbpWbWg/OdwWGS6PWeaOFESU+v/fw0TD11oxcbv4M+nnpPURSdfrE+WU2W86vN3erq2+fF8q4bFe5uxwmWrzsqysrvzHCgtE++h93O14tPi/mMG10X1YtRxxfGH/EosoQG/jtqB8aEPcbJEo3iRfDie8pNMXjuQ6qkHz3DgPGci98Yky4bmA/ktXmdhODP/us3ZLWZr28X0/ldP6HJxwW2upJQMg8qqjiNsAjd6VwrnzY7F0kvTOxlrNfiab55NcEFOeb/R3Dj4RA8Uazo8zFdy4/McqQuMFKO2gspTASpdzThInQuakhJP7I/Q/PDrf8RwXWQRbII62ilmn03cZ18L1rMoACeQF7WaieNdVF7IDG7+W7jCm/PPMi27xatBtKCUb78sUO29wHo4bX1ie/wHm4obH2eu7QJS7iFclStlJmP0Eyh84aN+JmuT+gMoeEHOYam15XHhhNYKZcv3h/azuZH9W/Lr8ub35b+7LedyT8QTj4dt56Db2tIIhOHFC0J5uOb2+Cg9f2r3b74Ge/Z+89ODsu9C/pBaw6dpO0gPxzVOe5l6/BvAsa707xCqQTqjWxMo8J7kvb+kmOiwRJuyrBGuWMns3DLMj0DdYI4ftBOBdgR6LP9noZUXEXB2jjYsyxhYmTf9jZaihIzR0yfmDNBPezw7djGHRu9AupyIeNXWpLsCFxW30b86eyV2L8xeF9QXLcwiJ6FmfPNHG1LtIbugdeUay8y2V9Of2HswhuE4G7kGeNluPdzz/MLYu8/UEsDBBQAAAAIAKSzeV3IbDoOsAUAAA0LAABYAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0RPQ1MvMTBfU0lHTkVEX1VQREFURVNfQU5EX0xPQURFUi5tZG1W227bOBB991cM0IfuCraS9LZAChTIxkFrNEiMJO1eXmJKoiwiEqklKbvar98zI8lxu30xZIlzO3PmDD/QVWGicZZOT9+e0/L28v7k7PXjzcXD6uvV4+XF3cPdavnx6vH+4eJmeXG3TJuCQtdqH3ShA+XOlrXJo7FbqkyIzptc1WRsiL7L2W9IaalL1dWRWpU/kW5MDKSorFWkv1drUragBj8Kxj15XWsVNLW1su+p1luV9xS035lcU9aZuoCx11Q7xFk4W/fpbPaCzk5TWmsPP9pGypWP3hRbTabAfxP7OQWztbqgrkUgHeYSdo3jdaDbe7hThfbw9IJu9P7IwQ75DzYUHYykNFXXcHU4NJs9VJpcCSTsmKT2jFLrPGrdWL3fzGnD5W+GwJu80vhDpfMU2dabrbEA7usrQUkhcqhUq1NaRapUoCSxbgJnwbUw4k+6J5XnOoQkmRMO5JWyKAkHt2iGV9yAISI+NjpWruAy2i6rTajQhda7YujT9wAxqD9iMafS+BCp0G3t+gbAzmZnKV1WzqFh8HXAf1u7DBj11FnzT6dpY4qNZAH8VIuYrTeMaOVCXMiLHSL7Dq1qEPpVSr8ziGICvFudR/jP8ddIcnSn4Rap6G8t2Gfi4HUHANlkp70pewGWI0wtEzSYsQAmj+nsdUqftW7l3E+6OmSN11mtn2tDURyi9ZpJCUM0GB8Xz2bIUB3Bh2QCx3WlVF97rYr+5yw6O0ooSYJqdJJIFu8nCgbXeczBZnS6OUaTJwHIrafMgsIPCNaoeIJgsObE997g6YBb7poWuGSmxpCcNGY7cIYwIjEIROuBjnMSytL9p4vFq7fvqEUFA7PQNio7KyRCA0bLNyndZlEZK9UA746b04GB3vyLsi/Ta2OfaGTyycTsicCHLtEDZIUMK0aSZJj6Jya+/ha152jgoraY8bwHVNZFTJ8tGNZKezDpLdt7122rIY3n+OMIYE73zj+VtdsPEjF0d5wPtuE2LFbLaS6gkHRz+0CNK5hj49Cgh6ZEukizjDz7Q1np7F1KX5/Z+DOWISe3GFWJ9gYJdpE6tFDEEXAUUJUtQz2RIOtilLGGLgKnQkE2a4UOoJo5pARiBtJz+9GH33hYWIdwuFVeeHJ+0BhMDE+UqMTlakBAxQ76KjMELR++ed04RBZcpnc4aHZj/oWu8ewhs5+6hmkOUWqjsjkLSZIsHfcGHWKsAZbrWAPX118+rm4eL67vri6Wfz2ubrBjrq+vlhvKelGyLbd6tZwzi3O9gEh4pq/sGi6xMB7KgIaynkNqBnQFLaDAcxDlsLCfmXAktKenZ4OcLUazCQtYFg6tYDKZpq01C93AhEkgMSSFPvBGZv1olTgwUqKyRgEBBkBQWXi8QcoFZbpSO+P8OSBxWBm5Y7oizI8LCZXXCMEmvZw0NvJCk0nDiuxZnBZ443v5xCMjzWGKbq74DS0+TM7wJK82RyrxPS0Z1pcB44XtwTWMhm5vITiVad8DG/vyGBglEqLldOaAWci91rImsXtFtcG9ztZYUgfZgYgOvRsK4xyQViONkVjAdA1dw14p6MufR3Q6oEq/8NXD+IbUVnEBlHdeMOQafj2fzRZ0LUMh7p/nrfSuGdUnxZmlCYzjsIVLMN7I4uJtgvz/f0VAF3KIYabBSbHAnKB0Ni8lf0GYBdfz4mm7yFH+qACJKP9cVomJI/CR1Qs3KvjAljm2HTrJR5ycnbrNICKmltlaYLgxrsI3nBtFVVRZTzx8ZrNFy+EYz6x7Uz2eMty1IMW5tuLyRmPQSLRWIrMYDaSIchp1PE2hPjle2LPrwdfOBMh8OFEBoxcOEoELwhP+QdBBimEJA+QMGjSuEKx9zjRJ+GbHqfLdqTYTO6D+98vPSQLxFSEB5dpeBNEOMoWDuIyyeiO/vFamGawKl3fCUjwfN3iq/UBjkbR09h9QSwMEFAAAAAgAjbN5XQr4AgdnBQAAigoAAFcAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8xMV9IT1NUX0JSSURHRV9SRVFVSVJFTUVOVFMubWSNVsGSGjcUvPMVr8qH2FvA2s7NPmEWeyljIAvrpHJaMfNgVAhpImlgySkfkS/Ml6SfZgZmq5yqXLaWGempX3e/1ryid++GdO9CpI3X+Y5J2ZwyVaqNNjqeyfMflfZ8YBsDvf7+njYqsNGWP9LxZyq9iy6eSyZt6W4xXt2+e/+m11sXTM7rnbbKEPas7r6Ss+ZMucuqulSIKuqMjMuw5MQbUiEwnsvxypIro3ayu14wdzlTYH/UGQ9pGlGIA80X60tFGi2ngbbOk0XhI1aXzFnRp9ns2wAwjzpnT5nnHIu1MqFPKstcZeMgcAg4DK1WgfsU9M5yTmW1MToU2u76dK1qVGWzgozecnbODA97vVev5Axqz6hbuB5Ul+31BnTHAUzmtOFCHbXzH0hVsQBPf7JQ7mMSIBCW03g403b/UyB+1iECBF17cHard5VXwtBHso7yqjQ6U5Fpz2fCsf6cQOBVqbK92vGADxvOc5yDFWEoYBxeR4BTORUif12WttowuGF71N7ZxOxRea026fHGuxNkgHrOo6wQkzm310AdHW3OJVQkRQcNRoG5tpQcNxL8JXY2LrPMuTQnwHUkvBlcGLjQkjqETrSBTgJezMgh3noOpbOgCaL3r8zAmJzVe9h7YJMz1a4pUwUgvs2k11yHzLhQechd+91mbExaKGi/Q0ZxxNu3P1OoSoBkaSt5ES6OwCAOQXUX8M+TMYdhVqj4JATtgUSKet6yZxSmDPvB43VEYGGLATBGhK88VsVBEkHbyLtaWew/KG0D3dx8mi3GXyd39M9ff9P9YrWWtulx/n3yMP08ndzd3NQunHeNT6/X61XCsVqv3/zYflejtROStz7H5ltspFOBHkgdlTZigT4BHB5RLDCktblEaAXuYaCcKusZPKJQA4MtFiQLSCikJg8V/uB1prdnOjC0lmMP4i/4IHkntZ+0ljmtcu1ktA9Kfh4dQqCrNdIqQsrrULbyA2Nu0gALDyKk80k4IJRy3UHQFmo1IeLdgSZS3kt59Eu/IqBWdUPJcije6VQdSgOVkVFDWrP4iyWoMAYZLFI4y53G+o3bbjFDJdKmAhNibpgaA2JfRoHgdtut5O1FNyRpwqSyWCFehFLp4xFpY1q35mknP7PPNBwK2Vh6//9eWsoEwOWwbZ2HA7h3DIt/Wa47KYD+/9NaMn7tCIQGT5NlUlIKhsJVJhdy5DAZkNqOtV10uMa8BsXnLjMgUQKcJW+gX5GipYZVYpWurSEXSxNQl7xHUu0ZcwUmZdy83DKlhFmuopKTp9vL1aBOyneYB6LmPsxrX1z93EYZUOJfxILMhNpy19PCUMqHIS0E8QnatD5P5YQ1ZL4qZRyx+uT8fmvc6cXUhcyrUlgEoIC0tnJm5spznbgdaV7EwuNvTdS1KZuw81Fu4x9rKAsG7iSwl8qyCbRYIQMVohbdS1dC3b07IM6xpc3ZnMXQkhY0edZRLlS7k/m4nKwl/OCKfps2VQnuG5OUHeepI6cZfahJv1z2QHQZ9qaFfvPBUd8Vyp+7xONt8/HQXuAIq+gxQTIZhvFJMxBPCoMyDw2OzpUk3oBLYhGGKcjaoZQPokobuX2SVyVKmiyFWmKDy7eUll5EkBFsWyYCCInm9XOv9xlasgKuLauUZQfl9yTB4bYf6Olh8svjZLWe3D316Wm1eHwYTwbjxfzz9OFb/Wyd3g6m88F0tZiN1tPFvPN4gcfz1Xo0m+GHDH0qM/0yx8+HyWwyWk0Gy8dPs+nqvi53//htNB+MxuPJUg4dtiGZOVySZZDWOLWG2wq0ozG54FV96f8+XeKTwWhQVo+MzC84cVs08+KGw+sdch9xfB72/gVQSwMEFAAAAAgApLN5XQPl+O5MCwAA8BYAAFEAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8xMl9QUk9WSURFUl9CUklER0VfVjMubWR1WNtu4zgSfc9XEJgH93hluy+YFwcYwLGdtDCJnfWlgd7FIGIk2iYiixqScuLpaWA/Yr9wv2RPFSXZycy8JLJEFotVp04d8mcxzbTXphDv3/80FJP5eDn48OlhNlrFX6YP49FitYgnN9OH5Wo0m4wWk/4+E64qlXUqU06kptjkOvW62Iqddt5Yncpc6MJ5W6Vk1/XFRG1klXtRyvRJqL32TkixyaUX/4rvhSwysccficlHYVWupFOizGVxKXK1lelROGUPOlXisdJ5hslWidxgnZ4p8mP/4uIH8eGj+N9//iu+fBL31hx0pqy4sjrbqqHYGed7svI7+Pa7ysTt7Z2Qaaqcu7jodpde+soNu11x+CRKa0rj4D/55ExlUzXwynmh92Wu9qrAYGwpEt3ubL7CHEzIwjZ7tGWZ51jAWJEq6/VGq6wvVjslqjI3MsOn9+8/iuXkF6Gd8Hhfe0VWD9iyRUjJL2MvaSf4TRtHlCli3S8fRb0Gh21j7F76bnBVbwuV9aoSQVQihdkQeFqbQiRkRqtT/BGYVJbyUefaH8VB5pUib5I83/fTnfQJhfMHcWUqZMQeLy7G0nqOpHhWj0hPgdjCSO9nsbFyD6vj/q0unkSCyPk7eC+3KsG43yoK3KM1T2F0twtEOI8JlBCKt8w1+QsQtUsgcYUnx2hXJ59oPqcRcPPWcJQBwV47cVA2WccIBxts4LHCJ99MFqVOn5zYm0yFBFslAaZul6Jrngvh5IHsNpae1BFeNpOBttydPuK1Vb6yBRKpXnx0ZtZjx4WoKA59Aoo6KAtD8Cojmy6iv6ihzUa/KPxyiBnVX2rMk6YXwZQ1FVdVSqhAUCSWB7KsfD55oaw1Fh4Y1FMbCySQ8s7RBmIYaJyqjqsxTQnHosHqkAfwHs2jl4CYSFpbcZZgrtnzmBPCGxRQ2F+O7KqioigMJZYnSLEPWADqjoT+gEYUut5wRTn2uUViDZhIwEZTF79ztfXFkuEtAryxiZ2p8qwtDxFPOO74KCN+gpPmGRYPWj0LsxGFes7bFWCoXRbhDnBHtY3uY/HOqg32VVCIOGSIoixcaaz/8eJiEQwMRfItzQH54YfIH0s17MByJ9LZsFMVGkM6kSmHnceQjCZXrvNH84ogffZLYrm8E0m7dcNv/X7/+/dEMIQfjxz2U3UElw5aiuRZF5l57pegwsL3X5Ue0NBm1O1UnvfFQpX58a/8dm/8fhoCNirCB/B16w1gl9Azfd8Ahypi4A074/lk2vme9MUof5ZH6gYW/E0cVAONshFPLpEBFAGRgcxSCb8sHArB74nkbaSStrSSb5hGxQGXW9S74b87L1J3oo4pVYGHX6MzIA07DWt0IlDEXnNxDTtMH0AfQpTBZfEuM4ASgQ395olLEnSqLCrix/6ZV4F/KDnwpnFhyA780TgQ1dCK21D2mAQ6UV0DcPkbaAshrwBZTJTwCsVUwEmiNORw2EGAO99/RTSx+rLiBnUWCGKZMCZ67UXEdFFv0KF7poB4J2L+GX7TRVn54fsIFcoP34P95BX42v2d7cMBaj3NoQqDqGNJf0Ij2ESm3LeIGsno/RlzNjSG/+QY/q0Xt/jr1R5ZQcu1qiZLk4eG3rAHteaSqpRp5AT+JpTAzJRpD3gej+5HV/FtvPr6MJnO4ukkiURyP13cxctlPJ+dvbxaQ8Sszkct5l/iyXTxgEb+MJ7PruOb9SJ8ugOqb//ifTtlPVuu7+/ni1VtOyikq/Xy69nP0RUPeJgvHlbxHT2sV6+sjNarzw/Xo/j2jfXFaDV9uI3v4tfDF9N/rqfL1dmMq9Hk4W66XI5upkv2Ozyf5n6eY3ztDvkAD8id9Wz0BUZGV7fTutu3mZOZROwtlNEV+j9Rfd20e0wnmdVUkCc5xEyTmbSiHxjd7S4U6BIt2BGhIp3JPZwQg8OHgW2+AG5eJDvvSzccDGSp+y99qZPQ889fh/Lqp2afcPeALPTPhtFi1RYFBK7OiCazIDAvW1w3n5uNvWtqJs6iZpM/JqFROLGpGI+oMFUQW5AoYNnEEAztH2DudkF0Z4hEXRB/QA2DXRnfxJTU69o49sXMiExbFCU4EM7bpwE1mqA/m+583ro/02oy0Cmc3pfeIXIgVtK9JQlUUBSJvDOds6dOrwoowpR2gahB0tOOck1iO3TeU2tDYVY5QimfkCUMh37XSEgrkQk6HJkrnefyMecXwYc1txj8hK76RR3rpzuq9IR54BESs16wXqbb3UiNGk9zgyMDEKE3tGnkkvJo4KAnmTwxTMYnZEnR0PdBvRYE7UIUv5MCpy6U1zqNTZceopwDVBofxA7yhDYBXF+SfEi1I/Rik8B0pihukMtt9yS9VPPpmbxrxRcSkUKghQqKAf8teI0U27P2uyDvU1/hMHFykc0GeWZyrrcDYkMhFotPH96/0dB1D91J7Kdo0EljWZ+NsRu05pKQiVzifQTB6/ms0KqscEggsdXQqz8/juBIEUb0xZXCkyKI5UfahMdp7oSZqNaGod7RvM2xFvLNMQk8TLZ4+Ubov5LnjU60fRG/og/1gjjR6ctwZ+D645XgOOZRodQ120ibtLIke9oksW6/wUljMEcORzF3cy4Mzlop/Y5NnA4Nbfn8A+0fDlqxjqk5OV4So+ojFQHP1OeqGtaQXUUdvidNpWqKlgqwnt4c34jlFcG4kJBhS6VqUl5Mr6eL6Ww8HVDeH+LZanoD3kfPwvm6JuVrbYM7ZnNxkaymd/e36AzLwQaVSdtgYaIpVgxuUzC8ibngDwXP4eiAkwgxWbc7FLPpsuf8kVy6Q1mJa7YTwasiq3VzQUXDll6Fk+PizXabKyY0F47BbhBiN6Ba5LM9qhdSGQn2teKTDicuggWRHskC/gb1h2FOBLJuTjHI/Q5TkPdCbOQjXSRwOUGAPzOV3tMSlaN3SXkEIRSfxGo+v10OTgRaHsMtw1+GS/R6QKCAiAr9hIeSIPwzqQMf1OlQKwgtFX59+miPu4z9lq3Ccb7eD+sa/PxcoQ4FWIG+n7RoyO4Y1I791acfcAC0Eqnhw0eQV7oj0quLdxCuPSB3lvP1YjztsSpZ3LEIoLXMZgNZD2hhu1AcvXjWi5fzW4YTqz3UVn0OHyCyT6rXcpgP55m/mxi3IK533VQeqj2i83P+p7LLcYqtShzjwp0GsAUt3CNmrde6up2Pf5lO+LqGaoGhsZ59mS7ia9JmLH9JfOJYVxdhfSf0ZvIyvpnFsxueD7EmaqU0aW4wLFo7bbE5wSGnZyEPLMy9WxMA8Bf7SnfGkHZ5I2uoSEPtvKHo1jgrgzo4YFVGR7fLjfmVWHLqjOaoGRbMmNTfqIhThlh7yVJnDfWDHFM5oQ38VumDzDEYxd4QrdvpfV9MX6B5qDrQW04tgLZIu2/PO3sggDcIP+kiqWYq7kJwh/Z6SSs1DGYHrS0i+XSnqNLp+O4Uzp8kRrb4028jTmcc1xSSelGW+2xOcKC7NyJlEm2OAnOkcBSh4ajaHTHeQfioqC6k0L9Y5REeasWKJcBTPOS5HhLabX7k0/PFxTXCJsXmxKLR+bmYrxAamVhvtwy9nqmQpBa1lcQdMWIPY+86JajJm723ptAvPcCJri070JEYu9E5wSndgfMA1K+mYhHyimlp+ftzG8QCZIPufmyGJuEN2mMzF/7IJwpNEJCU79D/RtleW2ooI6ZGqrXK0s7Bzky70DaeSu4IS0AbEQntC4a22tP1ZlAjVZGTCm2jQpe52u7pvrGfMEHqQpNs4qu/E0eyNqb7rLpQMMJsK8U3YZc1M6K92poWm+jwRusC+5s7N27YtK9jI8rPbpIHdFg8I1LHVzqaItUA8fxmh9dr5W2g4f7F/wFQSwMEFAAAAAgApLN5XfU4I/vBBwAAxA8AAFgAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8xM19OQVRJVkVfQ0FSVFJJREdFX1NUQU5EQVJELm1knVfNchu5Eb7zKbrKh0hV5IiiRFE2t7bKkWibsWOr9LOV7MUEZzAkoiEwATCUuad9h+QJ90nyNYCZoZ3KJQeVTXLQ3ejvp3te0Wfh1V5SLqy3qthIqq0pmtwro8l5oQthC/rj93/TolDhy/F4OhjcZJ+UfiYdD4+zy2wyJuWowseM3oncG3ug82ySTWgrHK2l1CTyXNZeFrRXrhFVdSBRemlJG7sT1XFiU0ut9GaOIx5PIrKpBJ9s6o0VhSQrc6lqT0937+/f3i5uv/6yuF++Wy5uCRXT+dX0DH+ceSsd1cI5nJXCVkrajL74LbJ2N3bhjJN2r3JEbrRXO/7SSlTmSTTe7HDPPFScS+tVqWSR0eMWF35WnnbimbNYWQsrQv077hu3YBhCSG1NVe2kPoqWDQavXtGtLEVTeVo3qipQ1Iuxz2VlXgaDJydp1dWY1QfS8oVe5Ho1JAkoCJdAG9CcstGha0P+StOqFvnzil6U35rG02o0qgxqHxldHVZctaQSzaRfl3eMWFcqMMpFg6wc+JgEopQkv3kbQEXKfzbK4r7WGL66VqV0PvuHMzoGb6+ykVqiHdxJHKqkQOi6EprWByritefE+VCh0qBaVclitJfWcda/ZX/Pfl1RiYw4kmDP6KOUNdUSfNHczeXtEPl2NaVjwxBQhFbh8jXuX6pKarGTQELiKVI6rxowqNG10hq0YHJ4R0jkZG7x34xWqd6vXC9avyJROZP4y3RBP5TzYGhspbD5NhA/iWmntNo1uyNdCAQP7JBdLzb48CY0+wX9/JPjUzcVVPVLagGOcYDZETD4amucR4zaWFSi8FfJjcgPxKgLyDd1IqNbE7iXG122qPoXk9GiLT0dBJagPhoBKaIEUZ3dVM26LRM4Sy+U5vMKotkKNK1ykb33kQvFMV3SE3RSKhsqDWFOB4PzjJa6kFB2AehY/DWOoVsuh9wRo1lXyrEyFT+g/IFOFsVkOj1/fRp4EK7PiIMr60q2mYahG04FDrOSS8nqvOtLsrKUVuoc7e5QSBYVVEGPd38doRYvc/aYZwnZdgCrvuZUMSQHFW+NRYmAPLAKRMmZeDhLsVnBGcyRzWSDSUZR1Yxy5mRVjpoa4pOjdJVsf76i2lQKsLB++8PLYtjft+vU8dWHnRafbPtM/lEe7uQuow9Mmq76Ne7kEFsbza72f2cJ3X64+7ik28U9PXx4O5lecQfeoW/S1lZpn9EDjkkKbfZba5rNlvWTGvgb2h0IfeSQKDKXRWPlPCm2kj5YCDCw7CtW4ClvG7jO4OJ/kUp+A8CtMGE58CEQBwlD0TwYhq1UwjctAsybxAOnNnCw8M9xt/7y8OVzJ+ITBx1GziD+0+O70TVbPjnIUbrTiGJi8Ry33MsKZA8j0eVbuRMdGzhZkfjAPBi2OYahAuHRETrpy1jjp6vL04xgF6rs+FLzc0U7mPf8G2ZeL4E0JBK4pHa7JqopNWPkxQZtw4zj/q1+UsXPo/1P6cefz/hz9puqUV6BKZSHoRyfiqo8S4z+bjCsuioxsIo1nAqeVjIvkETtRRBaUjWrd87DNLjSEfVGL/AF4jXA+SGZqnNuho/ZE+LKPbtHLqPUOhUnWnznMrq0woFHObcMQjb4ag8WJehDxwFqoxUnteh5IF2gCm8NEHejI25t8bGibHCJHSjYXxpsUA3P174MgxLnx6zfceSa15pCpkEjwjVu5c4gSDAtTJFm7WC6fCJuTSNelfqtAtN6J0fLW4owRFZELXQjMpUcuZGLuDqEyoMuOoyGtMV64SGUrrvc6robGLial/2gqYTaHU2CEcc5EK9TFZOOxz+yYHI89Jf4ccq004MTBR8+tt+k6c6EdXuJFtd4mX7/LGTUmx05FUa+8J5jdTQIBu9C+QfJaHm5sYHT+K+JMzNNRQTj5RZReT20c9xXtQtdu79wrADwf4/fHqF0LgLkIkLY4IyO+zUyMUCoLFCSN5n4qOW9J3h18nPzAl8CMbTjZeDIJobtuhaQBadMqDsYX0AUK3CdciWjYCgb1zl08KSbdiw8YFI9RWOKz52cztnkWkseYZRFy/TCbiRKebr/xPIAgkhVlogmw2Zm4XjoFYm9gKigmH6jc1Aq9wVpBO9uAbGwisbFBryBNbO67Ru8H6TyV5BPBtL4FXufWKuK9wa+aWtAo7TmrbA6n4V7jXBmxDukciwIFy0qApFMOXpyP7p/PLE/50Ho80Cg78ZnnWp0dMLKFOrsm1CnjIJAFrr+4/d/TcZj5rl10aP+fL+8fb/4evNpufj8mCqMqKCweRyPAepuPX3PmzVrnV/PuIK+NGZgo1tVBJQKbGi57wqjUkQxZ6Elo/Tes2qZ0PKyj/KG+hcIWNYGYOIXpE3mUkN42HWwCW/i687RNpgWfRa9lPThy8Pj1/vFu8X94vPN4uztzc3i7hEvb+NLbMllWJbS/DoK0c0wRrV/D3GmsXlgVRG3C7iHSVTjEeHC2wgrr32PQzF1ZQ79ZDe29Wd+K+z24s41fhgR0aPbBSNYYXSRjO5Ng4/jyQzAyvy5NrAPmpQX55OL/PJyer4WV/nlxay4moxnV7Px9et8fD0tx7PZeiwu573H9MZP02k5u7wuZtPyai2Ka3y8fj2eYcMq1rI4l/nFTJQ4fZEN/gNQSwMEFAAAAAgApLN5XV4AqC6UAAAAygAAAFoAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvSE9TVF9SRUZFUkVOQ0UvQUNDRVBURURfMDQyMC9SRUFETUUubWQdzksKwzAMBNB9TzEXqFu66DFKCfQAwpaJwZGCLKef09fJdgbezMSUzir1i0ird+MEIS8bY2MrubBd+ONG0dVgnNlYIiObLpi0S8L1dg94NUYRaM61CMO5ecPOBjzUQTLa5lQrGwZEg1orRV5YHLM2D3iaph69qBwB9C0N1H1WKz86chpzfU00+N1FHHcHUKi2cPoDUEsDBBQAAAAIAKSzeV0fiWsB/w4AAOUoAABZAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0hPU1RfUkVGRVJFTkNFL0FDQ0VQVEVEXzA0MjAvY29yZS5janO1Wutz2kgS/56/Qq5KWdIiyzjJ5jYQJYVtOSGLwQc4e1nHS8nSYBQLSaeRbLOY//265yGNADvZ3bovxsyjp6cfv34MekGJRvMs9HO9/cxPYpprU+pk5L9FmBFDj5OAtKZUN+Wkny3SPFlbwAerRamXz9aW4FC1YElT7y4eLWJ/tU5qFkbBJM0Sn1Dl2OWU5P6sF87DnARWkNzFUeIF4rtCw97PMy+maZLltv9NIXDa+c/k9+6Z86rZ/Omg+eIV+yMnR+7pZ3fo7P9hNB8uDvbeXH4NfjK/2o9/M9639i6ae286e797e3/ae5cN8/3zfUmuewykLmACVlyKz73L5YH1+sUKV02L2M/DJNb8GfFvjOTG8uHq5jKcGjvJjZnPsuROc7MsyQw20V5VW+jMM66KqbnMSF5ksdCH7WfEy8lHj84MHZa8+Pm1btpFGsAgW24H4TWhuaHPyL1eI+h7cRKHvhcZt4yDTpZ5Czuk7BPGTHGQfqE3bu25lxrlDtP+loSxoVu62dAv9bYG2293d/NFSpKpdus4jp5cfSNgWuaSS+aGLKgzYGM2/g/0bQq6Msy2PGapN3CGnXTjvPs0GvRtNND4OpwujBs4qaU3FKYvbi7NGiMrvb0SxNY239YlSeb+PDU86wq4Y4rgZmDnKCjP3N1Vv1+Zln7YOZ7AwKg76IMM+Y3uHc+maRSCaPd086J5Kb/ZoAC8Q7+YX5HMtBbO1Q8tbE9B7RHJtdBptsO3L9tho2GCYO8vwssdx1nAh1QJDr3Fgfd7B60DKcGmekkvipK7D2E+K66MIousjKSJdRPGgbnEM4p2ni2WhROTO+182MMlICPfA19bqmbIrg4L0HS4rAobfDRP/CRCNc/yPKUtfXe3sAFQstibExxmA6lH6V2SBeUAJV7mz8qvMzBa9sXSz/ujzokrDnqmCTBx9H29gYw39P2MRMSjhO4DWqG54VVw85zkHhi7p0tdAt2E5pKRayYB20/mgqV8hlNgG16W099g1khNPL9zdjYcfHaPJ6fuuHPcGXfkrZ9pJKLkbxNv6BKz9nWwrP2v9p9h+nw/5MZVbaozMXR7bmfkVjwIFcP5GZm2nymKBv8PPtEkHnlTYkzDiFhz7/5wAeSdg9cvf3llLlHTXKI0d6bUjoC/HCGYLQd7ZlejOfj+CQwYwOYO+zZazK+SKPR7YXyDozBIwz/JW3kAd4yjQf+k+2Fy0u25eunNzAFTL6PAE7WRRyRdHmrpRT79RTelzRkcBImNsIeidfsDtz/WpcHHRRS1uV2S9ko18zyZhz7en9O99aKCSNAJwsxB+QIGMssU9wWG5jcwxLiBTwsg1S8yGt6SVp4VIECMR83kX83mSnp7Pk85KYY3uAnct8FGrsAsK+oNcPKGwGYISEEyPz/vHhtwU3S7acD8bhqgHpKUsEhoAHFLv7vXrWbyutlkDN5lEN8qkQXWOqLhPS0Ui/UCzvwa62zblMJysYUN+FFCSTUQOEySTCXIc3k8l8xqGsYAHAvUxTQA0CnigMAYCXZ32XfcbW6QZVeidhFHYCiSZAknK1VfwHeIsekM7WphpOzDijyYn5GsG0gv5hO7u/zTpjA699AwfDxDBLg9f+bFMYns2wNd2OLHTr/v9iZng1736Isubbt7zN1NOackXY0B+eqLpfc65/2jj+5QEJucdkennfHRxw2qghA4/TXJVdJyZKdOGBkdd4Yf3PGke1xSg8SBJxWQM0wwsfi6vzbwfL92HgIjDfMkW4gINXTPBiU5sUhICCUHXn8VERBUf9AfjTuHPbcU17Hb77oVKyKOCxJpcRWFFHjnRNAC9fKK5aQdkfg6n71rPjr19qDZ5IyenR/2uiMQ7VMn+r+SxRmZP3qomFeIr1Of/Op+KcM1pBZOLWU6k0SMLVQlX7DL9uhiDlEmY3NjYBRZIsGLn38+eAPSrB03OT0fjSfuMZ8022oUFsfMvTicghrPIShvaNJS4pmE0qVt28JPgJ0TkATJUhBI3sKUEDkk95j2GkuUYkun6U2oW5BMzL28pQck01emuVJzg1uSAYacCkYMeaRgxwpBXsA4CT4TAMUktnKSzREYxHfpo3Lf7q78b8NPaXgN4LHH3RXdVFkrInqZNlZEYJMHVyeK7rlqR90PfSVEl8rFbc464b+p+GciORd7uKwMhrSHxXQK5jzNknmVCxt4pikDGqqotm7zVpaOEeP1K4h+6waL9+uMz4euXvHBNm+6McRoNpNmpBSkuL00Jli9xcB+Gw76H8oEQyBA6YicpuLx684sTvEhw8nC4Jow2FzDO9UpBkMAORU75b3UHJuRvBXWVU+/2RRY3xHakzRAS+/2P3d63SpRUrJzns3wHH/b7g1zfus0keDR4PSsM+4iLo7d4Wm33+kp7Aoj5apkdVYNmVjZN8Wyb/n61UoitbJa4Xn0scPKNMEqT/8h3erGOQHfFrsg0TKFsPF/BNbyy1tHVLWWLgUwHgwmPQwqa6jD9oCywqnnP4Y5clq57joGODz2PzyoghUa2wAM810To8x40nd/YyAvkAw31QoxSFmPoXr3kQ1MqiSy7EA2Qe5DmlOZo5kPD2y0yl1xcEuOum1NdYZplrXGcXfoHo0Hwy/1qljCs7hKJYhhkuRWGMjcEhMmJSNcXwZALgjZ3yA5LZFq7mzm62VXwmxjI2BeS3oF1Noh+lkY1J1jXjqNSH/Oh0NImyennX73xB2NK9GXKzfjwCj3rokBVYlF8T9LwIlF7vMMjGLkZ2Gam8u6sthSeanMKbs6hp4u8lkSv9StC32vq9epWBunqEBSjglWL60liaEgAA9rcXi18nBOkiJvvWliuMc6hEFt61XzzWvrDkrC5I5+DAOex6+kh2VYkeUFBQmCYYLbAGx8AuW7xy29MWIuzNZArMweHnQoyylYFDGa1sGrplnKEGnWSmwKFW+OekSl0zUbuPL8myJl/5aZ4bKeOJbjW3JC3nPD5SRwLh4jfcmaBqIhoQE+iR1lGo0GGtLOFU2iIifGvckQA2DuszsZDgZoIXXF3peFPtubEdh5S+p3MyGhrc1WDCF9IDuCqrAHWOcy59rf14Yvf3nZ0lJULM1JnFva1AujPVZHBBrPDzTWwfOYcG3tONHiBGs4CiYSaJ52E0MhvXedJIHGz0O6RZyHkZbPiBaTu2ihlXxqR53hWJt5VMM2BHzHNTwL50KytY4muo2wC2JCVqR4MlIFM7wlFM6kcyCmfUtA/V5kwRlgmjAM6dcteO41kAW5JTDIT84KbhkY+dmByIS9bjGfODlDkMUqTzGRtYCjLKqnwmuaVdaBDj4NzocQvyYIwp3D0aB3PlZzinrdqm6FMyQrDZ1Dl0Ktc+quhfLtdbZKsb2J8rX+hQ/CzqRIWBnKqk/4h4G5EgbYpFkvNEXdqrRDkihC8xjExFh+1yMtSJ9uw6SglsCcFSrgrzt2KQq/yKCyzh+NDJs7ODlHMvK+2qkcJGfNFgsKUo87cvzhARt5Q3Lt3qeG/ofeqJTI2tWXjb0qP1k9B4TjlaQkW+n4bOh+7g7ORxORrShq5qo4Ejes60bc27T42CG/1M4Ov8O6JvmoyTt5NbJmlQBUYVwS/164V9YpIb+M+CI66rVzOadbjxVcfu/Uatm2Qw87R7+en8kzpcAhe68dD0aH0zt1WdQasZCtDCDwfxEUJ53+8eSDcMhRt/+BHSE7pwDMqKOnkxnVFgVzbJfjyKziSQbEuZjkyfQbrWckRawBkI4rRNfuPAVoATmvCMQuwmAyiQLtGoCDrZkDngY27JcPA4Ne2X2fdHpDt3P8pTwIzlltsaJlKQoMMxBBt3qV4iR82WOtO6BWb5kJS7P4NnONC6HU+hZ+riVttF32dEvPBwmPICGFAlc6od6CsVPWET7vsz7r8BT+h48R5AnYxen19LVuMAtHitx/BAUVvP77APgDwY07wVp2rwYLkfouxTVI0Jp6ESWrEoNwIgvqSXQt2kho5At3d/nnYw1ENeNg3QmxXHKshMN65i3W3W4pSIWXCEDV11mypb7LkkpE+s3pqvmxQX3onrgAZkeugs/8Hk4tAtq2zela39XhilFSo/GaYDd0w5rl/NRVPaYn83mYs8IiMJY84f++Fcpykpcloims2iaTl5XEzLpDdlkc+bsmu9mHqFdTVU9ha+2zlqhxrlFrUgys1YpUuifdI0i5GSnRT+IyWb86Eq29TtRv8eQ7RW2fct8nN/31tGVrgS5BbaNI/2eRe3voLkMcd5PtnLxXsF1vHGP3EcoHY8vzDHvJMl5CRpSIUpA/lctMC6LYSZKxEFXEYb6HhqL5KJqMWlALCPvUQqolrIDwIlsbY0Hi5SB0DR8MNS+68xZUo0WaRiFUFklMbIaFqostfwRBt8q/nvwrIPHv8y7Gk0P3BOJKGTFYQFNeztSTlhwpW0/i5KbPSnWs2GslPnWBnYXTEEIvQ/BSb3nlu0YK5RmUHO8w4RdeVHNu1ZdMdUbsbCtxQYCeYyA9ns9IDh4ealL+xxUC3vBJoES28E2sTKt4kr3cnkM8nfCb7VKQrP9Qyc9giREmY5genPF34rU8hcNMmXM8TgqTOGEeLs/5BaCVbG7DKiF88bgViFeu9/yjam8w4GlXGd0ZlMchJWX7QO4HH5yR2EhuuAq18mcyGIaBxMNDcvPeLr/KJ7rJSafLuX5KKZo8fpnccCTcsF1ctTJt8SINTKASpbkY5Vt1BkZE7DmhFITbcPS2Nhz0eqiICe8i99yx28JfLshF7VX5ds3so3zz/j8c8Iz1W3rk2vMXGIjBvMKrMArzhTYjUUoyFIOHb7oa5N9Q1OWE4VcJaVdFzjovBeVLZPtGpxLSZM/D0u5moT/TxI+wKMvlyT3gRImKALEaWqPs2dgbqWq3Kgl+qIPGUYR9/4Fwha2EGlTyqfLHTRycNpNSpaNVXyriJdyLvWOz+IPZ6GbkNe1pGMHdjNh5F6u/CVFDE/7WIrbD2I+KAMJQVYiY8vdRQB0NlRi8O1ydLF4+6+zV3X8rtFQULpqXppDVepMTkKKIiHhZpM6SzjyrfPKy+COAVX/Mt+rPipaao1tVtLHWilJL6UJbauJobRqItVneWMpjhyVfRRhugDv/D1BLAwQUAAAACACks3ldWEtO99QEAAB3CQAAYAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9BQ0NFUFRFRF8wNDIwL2V4dHJhY3Qtc2FmZS5weZVWW5ObNhR+969QkpkADcE46W5nnOIZYuOEqW9jSJrNpRrZyLZiQIwk79p+6G/vkYDtbnbTmfrBoHP5zkXnwrMn3YMU3RUru7S8RtVJ7Xj5uvP06dNECbZWaOhNWLlHpKoEv6YZ+hwvED0qQdaKizeo5Kik6oaLPeICyR3Ncw/Ny/yElDhIhchGUaCzbUnUQVBEygwl70N0TQXbMMBbnRCw2DVFOy6VB4Y7G8ELVBG1y9kKsaLiQqEFHGvGmVUbltOW8ZlVYzi64BdO0vkyGpnXUTSehGk06jRiXLpSEeV+l7x0BXXlSXY6Gd2gDWG5Xcit0xeESYqSk1S0iI5M2VY8+xhO4hEGwL71QgsZlYKw0nb6HcQ2KKelDVgeEdtr50lw0Td4Vrh892EazdLEcjpIirWbUalceqzoWtEMs8yFBEjGy6BV/tLrf+ugLNCB2lraMfiZR49MKgn2auQkDd9FOJwso3B0haNPcVIbybxinzFhV0TQUskgFQfqFjyjgc9/832QuGFq16bLBp8cRCQ6QxgIFASjMjh7rNzwHOzZIN+G13CdwaXv+40XENryCg/nH2apNo4kpRAKBb03iiuSBz4QN1ARDJKJWNma0NbgvgsaaIanL1KfNBWslVwZpi4lbVm/O4NXF74mWF+/WhqpFbC+Hn3/HkU/PbhloaSO1ba6lvMo/e+aLqhXELXe2cL660v48jN5ef7Wt1xjtYlzEabvTYBQj6AeGCghIZbKwHuyynWldGshiIGUJ7vSXtmWZ7mWp//AnM6FIRucFj5dhh+jZRJOanXIfUazh0bWRFLNs1sjtaCG04lvwEYfFpN4CEVfg2mOR7LMroUNzdSDbVIPPUxFSXJMlBKDQe/See4fN/BrTOhu8RIcJ5PZH7bWMymzW/J4mjZUfWk6XN+95S2jd/8eRvHSuS3eRTSMwwkex5PoNmN1JeRki1dMSfQc9W6LbLi8WkAT3xdd86ISVEqsThW9Nf+T/m8tD+fTxTJKkng++8EwlCCW7EwHPd//pee/+tX8NWraUZzO53gCHd24bAr8RXBfu4E0vMFF79UDpOjTIpyNotGPaA+i0mi/gy9mVD5w8T6ojvTtfPr2P6AGjwF1C3K0e+5DaUdnoW3yZZjGc6uZBFZBSraBueTpEWq1eb9Tf7M5noazeBwl9UxQ4tQvAi3t5Zxk0j57gpLM/gHJ0bL0uKaVQpF5wFhsIN+Go/uY4EjhbWHOWCyzYN7emai6PBteM1u1QPN6hykOpWIF1Uzrhq6sxlQ8gpkWp1d4GifTMB3Wbf+s3mW6mNkagThaQ/8Klm2pRDBpkTxUer9AM+oOJwfFCyN6qDKiQAZSdN3zOrejYa8phRHe11Oi3n4RzMcTjIr6NITO0gd4xKWiW0GUiaet5hnczMcI5u8owrN5CutgMv+z6ZOfTV29U3QBBFn3sdlraExivUOcfiv82FIxCwnz/YMV82bNIbXlgd4159W6/wtI65ttdfZ4BXtA+2a2FSsr11BadNc6rizD4gdlwkQ3O/11oCHrM1odNgEo1sV3eXHx+tKpGc3GAX5/Bcx9TQUg70aASRsYzr1Q1jtw0vb5pfGxEqxUdQ8m4TiC0oFZHo9jcw+AjbFOL8ZBYGGsvxkwtvr1t0PnH1BLAwQUAAAACACks3ldxJFXfBQGAACODQAAZQAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9BQ0NFUFRFRF8wNDIwL25hdGl2ZS12MS1hc3NldHMuY2pzlVdtU+M2EP7OrxAzN9g+EifHHLQl+DpuYsBtSNI40OEOmnFsOdHh2KkkQ3IZ+tu7kmxjB/jQL7G9Kz379mhX0TKGEeOUBFzr7LVaaPy53UaJz8kjRpxmjOMQ9P4co0dMSUQwNdE17LHPJ84Y4bUfcMTIPIFlX90R8i7tFiM/MPKTUMApaNQ1+yR5gOWcwoYm8yNsrjYmGuPvGNRZsiKJgIhIjJnYq6xtkHPjjG8RzRJOllgAgoHm0fEJimi6RHyB0cgeOH1vOupfX7iD6ZU9cM8dbzK9OUJLPyERZhzNcJRSjAhjGUnmyFcBCTSKA0xW3ESDFM39JW6uaPpIQvBk5fNFA7m9BkrpC1LgJ8jP+CKlMkbYH2OfYXMvSBNQR8yi+J+MUKxrSRri04hpRkNA7ciFCDQB3ax4uqNTQs3o5KBuz9Lg7RFvUtoM4mymFZobu+/2pgP7yrFaf3+7Wx+1m3frn/D94YdWZy/KkoCTNEEhTjZ6+tCg4GmaGFsS6fvpg8EXNH1CDqUp1TVR9antec5kqh3mCzvPLxiqGjZjmHsid7rMYAPEDNQNElpuz9juIWWMb1Y4jRBILUsTDEjm2sEBuOg3f7Sbv9znz+b99lPj5Oj5Q8vkkFydhEZD69rjydjtXThTtydyUIeUZmuoIpMmYfaMpXHGc8cAx/7NG/avJ87Um9gANnb+vHbHThUyYiZeE8aZt0mCfN/BAUhjeOcVIcD3oDwBT+lGhyX7b6/xNstZGpNAMF0HD5ThHljtTobjW2VZFa7g00gwQ0bwPSVJnlSt0JrfoQzvOlzF2PW7pgPXzuFYvfZ8d9VuAOVZGtmTy5r7MwuAgCahAH6NVXq8nJkxTuZ88aV9cFB+nFmf2kefP4qfihHP/eooIzEGEx1ON9ul9bs3HJgrnzIswHjqybrrWsajnzUDOBr4PFhs3yNziS5wNEHpwjPwx2TBAi99Qad3m4gm1kkik1C85oyH7/xNCPP2JICe8EyrBOX2nMHEndy+ZvLSxAmEWONyLjOhQpSzvwhf6AKwpYnSFUqSQA8IMdO1u7t3FKYJvUUDy+PbSu1U3KZssQcHpRvyW7iRzkQvBjf2bUr9jThU4llsAcRzt+94kJ1RlQwPeMOsodxrivdyfWlTSCs8qHyeWSftdrsA7g6vB5MqNF6vABWHVoKfkIe5LnXQy3WlT6BjIwhCIMruU0+xUNfyKwQVRyqfZ9bRMUheGqrqSGKFSLFcWa2KKskr8b8v4ldl2pGeviVstbQ8zZW6FdlYCTuWsrmKCZdedGTAUmVioORGX1tf1vsQNcQrn2b5Ypbgk7ENc9Wz+4UFiSKgxcJ6/6mweTCcTMdQI/fKqW2sc+mbwLnfbf3Q7/1mdL89+Vz2+9r6wjWY79Pz4fjKntRM7BdcMBc+k55CM+inT5h2Yf7qhpwcngMc6vddz5WHXe4u9/lh+NY+sarsCjmN4RLAUxGUMDZ8SkY0XWHKN2bgx3HhdiM/d+VJE9kZuYNBMWREGwtSaA1WuzHbQMRWW9K3mKlPfvygh8Vgaawojsg6p/ELxyXB824Li2Wzfdm0fQLeiSY8AW/ZKVzY8LORYxS8gTuKpcB/VY9DIM4hNkUyTtWjU9sQZXFcmUov1tRio1idF+at0Xd71XcHf2jlUrhz4PoYNbYyfmELbiax0QHbnCQZlj26hMfl9ALUkdN17f5U8KQGLSJ8xVujBKzi/a8KC78a2vVAVbWg/o59lTMxVK3adBWR1VMlVKa4HIsB2P5YGYLqUA6H0749vqhgS9ocWuVGddql9Mw6/nRUxVDXjTdAlIMhmUNqLHW5NAOgE8eXPoOmxRY+XKg1w8xWIQj13dEuAzFMBaBrC7zW6nHl0JZVHGjI2z20DdeDU9y9lDfK2GTAD6y3G8dto+IaHI/DQ/X5nJ9EyYv8KlSZXOooWVZlfEgbnju4KEsjp76ndlHMM5qgvOIRxfgH1rfpgzwljQBaJiXhHLvhKQnLm2zBoRv1ZydUi6V/vrj9ipRhVtdKRVe4dyqdVILfRJVOZa2ewZ/nvWUaZjGGK9wqFY18u3unfu7s/QdQSwMEFAAAAAgApLN5XSmuR1DsBwAA9xQAAGMAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvSE9TVF9SRUZFUkVOQ0UvQUNDRVBURURfMDQyMC9uYXRpdmUtdjEtd2lyZS5janOVWG1zm0YQ/p5fcZ3p5NAYITu1PbFc2lEkGpMqkirJnmkTV3OGQ7oYAT0O24rj/949DsSBZDf9JHHsPftyu/vsgbOUolRw5gl8/qrTQdOfzk67aDJ12u5oNu8Nh725Ox6hdEU49dE94xQRnySCchTEHIkVRfSBpYJFS7n3CPWtIYtukRdzaknA+YqlKGAhRfA7Gs8RiVCW+ERQtIpTYSIWpYKEIQACnrciUURDRJKEx3ckRGsql1i6zsFcgUgGOiPBPEBIc/1evrstNzAfjHQHiCyJhEUECZ6lAhbTFQ1D0MCWLDpHEb2jXAISz6OJgC2dW7rpcJrEncvpEAU8XqMlWVP0gdyRmccZCIF5a3JLYbO4j/ltrjcF88EIcG0d+1kILnuxVOzxTSJiZCNO/8kgaAaOYp921TJunZdiECVdyOrkcfO+pJXMrH/hfOyBFPZCiKyVsmVE/baKoXV3hEtB8FsKxdEd3cS87YXZDT5H4GRIl8TbIJ8GJAsh4rn3EBtOI59yCF1KQ+rJKAnCl1QUeP3edL7IQTt/fyLtr4fts+vit339eGSevnn6sVMqnzpDpzdzFr87f85gx6dXCGHCBQuIJy55iE3swSNn/pK6vnxSBw3/1izqS8euKE9ZHMFKAjaBRSSl2JQ4SXYTMjhADu/kEaVMxHwDD5CVb05O5R/2FWTxXQHx6ro0yxldOcPxpLILb5Fx6q3omuS7lxERGad4u+/Kmc5k3kvfjV+7h98+HYH3n/3HQ/PkqfXZ+r41GZ4gizwBRkFqU+/WeDAR5TzmrUcWGD88tMSKx/fIkUsGlsW3wAdK4Pyp2ksfIIwG1ENGYf9Dkp+WiW5Z5LceIUQKO3+PXr9GYpPQOEDq2bYhK+KbL7AHy5c/9DgnG4ul+a/a1DIl1AFeQIEuxu8+OP25TEAAzqMRxFnk2+Mcw4JCSYtdVhpzYWiCRSL7dmmjlYbMo0ZNMrc1h7RCGi3FCiwsNxYr0k4lIVN1Y0DYWMv+5UGT/MSut1bLw5X21iKmDPiNUt9IYrBio0VKLWihUgtWlV2gCcu+GC0hQSbjodv/czF1JmM9LMy3i31ablcuFtAgVWFJlUVdWdC/hMH81hbfHejoPM4EtfPd7uBXHMp+Jzp+fB+FMfFx18Dl/w4+YBCGNvTRm5AqDE4hoSOEV0IkabfTWTKxym4sL16D9I63B7hT1EUKr3PNsKRaTHsN/TcA3daXFGprb5R73FuxO2pIRBMVZWhK192BFvbvj0hv2r9wr5xGSARZVgG5wweFom7uffX8n/5LM3WXtUCCCnijAmp9ZUndX0h7JmPSy+mJ+nPJLkbOMWbBWZBy4BblCXgnFzW68l1/NxgNAS0yr1/X4tJEMnEf6NmZVjFSsNKYPLPlH0s1OYlasAcNg4I72kUPlhxi4vn0cjZfKLLZwdMTHLAaplTaCkTlRJ6MJbA7WPQveqORM6yBqxiozds238iOxtuiRfxy+Py7n+2zs1Lx5PLd0J1dONNn9e4tegkOtNdr/6UYb2G1rw8+dxoLP3bU2TSBWqV2rWU847D3O91M6Pp5nwuB0rWjw8PDEh36nl4e0JltNWFYHqdwNpNyv7GLpxkF+yySbtZrKgdBeD0HK6VB1H9zcnJ0tj1EZ6Ced9KjbBHA9LCv1ntzgW08PszGo8VvjrMta5h2YIyK79/n9bkLZ+4cEkwMVMAMKkiNoqqis3NUmA1yx8AYST2PMvJdnCa3DJswua6J6GKYfvBTS0PxSBRHkNah/ahlfLeR72aR5t1tkm8TsNtISDm/yGZUGt/d8UbztbvrPXigtZOu5uVTZfU90Z1+lwUBVIIcYQ01TZZOGdt/cB6ZCN7i1m5q7ulijdzcLyGNgL49mUzHV70hJP4fl+60POeiGxcTRMAp/UrhSPJp83vi+1IA8wg/fwBIT/rubh2Y6OUTyOHL64h+FtLhp/rQAfzDgs2ICODCqyODwiQexgktcvj7GKK6EPlXJY/CbQumZBIWC4pE8qNP7JcoaZ++Jo3I41Hj5dbc2tBs4vJRL/tStuIXxRwmnrnvR86gRiR1eKugXVO/Mpi4eKpNQHZzT2UA/29K4nvoSK1XFwx4FZAQjCn1v0xU3CpGjEZJFNcFRQZboVaFWgjshWxcgF6GbgjLxupMP7ojKLk9Onid3BLtsYiExrmJVjVbw/O2rUOOsvUNtBeWzkhA3UhQyCzQI29gLYUp/yp2Vv9/tt+cvj3+6eT45LTCnbl/OXujoe50u0xM2oG8gD6eHj+VrFsKa3GeXfTq/mt3UI2ZynlVD4i5PbedGqnwy7l00ptfPENhNZ1mTcP2RrzH86qiytvoC9PIQef68e3pk22Xodjd3VKl2JtfTp2FM+qPB+7ovV5dIGnrXLELYeIbKJHTY91aeFnd2k6PpWFyScSz3FJju0VGew9iZVO/NxqPXJhhF+8gsnUtzRYIYFEWhujbt3o9NOXA6eKzFbSg52uu0U9fqrhm6zXxxRjmmBp2p4N6nshIWH5pKb6B5d/D8k88OTEwmiJHTVQoll9gGuxctKSWqSDVd57yMoVI5COwhK2zdf7h7ByB44j4PpPUA7rVVzzlaIrIDahABHQHhIVtL4xTuF1vD78wyFdjg+KtjwXrVUSQmDtc1IzH8+xuWVapxfw/w5Ti1OJzmpreUvuxoBd3YOrTpdkoaHMvG5p1XobJ6V9QSwMEFAAAAAgApLN5XehYorOBBAAAGgwAAGcAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvSE9TVF9SRUZFUkVOQ0UvQUNDRVBURURfMDQyMC9zZWxmLXVwZGF0ZS1wb2xpY3kuY2pzpVZrc5tGFP3uX4FnMgZNELLTSWeMSztEwgmNLFEke8ZtXc0aLhYRr+4utmWN/nsvLwkIctL2i0DsfZ17z55dMWUgME59h4sXR4OBYP9wfiZYttE3J3Pjo63PzelEFZj/EIErMBJC3xwJQ92eCxQCIOj9SALfJdyPI2E6Gd8qWZRJLPgR4yQIgMpCBPwppiuBUxKxJKZciKng+QGwNeMQCmHKc38l8/t11mdpkgQ+5uOEPgAXzBFTjpwYAwoOXSc81ij8nfoUJDGKXVCLj2LvojKKKexNlEH2X3G+sL2FOdIGf/1B+i+n/fO78tm/25zJP77bvhlcHHlp5OSInCU4K+lZdjBPb+N70vFzjy9p/CQYlMZUEmfG+HJxbY30ubEQ3+ZmF9u9fxTTEPvzAhNE+AhWHPjOWqLkSRZIypcQcd8hHNwhodx0e5sjoUzJ1wnEXpeRpmliNrHoQTw5MUcKB8alrmCyONTHY8NemKMMeRUZk5+clOHxPQsX338BJMDJybFOKVkrPsufmSlGmSAJboyFNR2bw9tWJIXha0iyIE7gRyuFQeD10wQJAX1nSaIIAuXxTJTF2fCTcaW33R0slfruA+S4OlCgo35lIISFbfx2bdpGG4tSZinaQu4DwGST6WQ21z+MjcXImJhNnz10JUnvA58tgTZ62lhRAoge+PLn0+7vP2lnp6eyaF1/GJuzT4Z9IBGFJGY+j+m6kQk5qPd/L+i3UPp3b/8ctD68GRTzbQbBodiGNZ2Z86l9+xo25zOsLQi74ZWLFRIEUiEZLj4bVdx8v6xgrRW7THEo4HSsKoDUDlerBr0UwtZhCJnA4PIcy8tqAffd+/dn5zgozLOY31rGARAhiXwP8V/ToIZBFq/0iXlpzOaLa3tc1Yl7HPUmfvro82V6L7Xc5WYHZRGLIshS0oJ5iQmAJpiHa3lMtiQ5EHjOlEvaZNWpIktWvih72e7mqugCFbe9WiCHRHGENA60TY3hahe/S/qqO/LuKKY2CCdjcEHYI1BbgGpY1Tb2Jq5tVicFnlJU7HznKx4FeAFpoyjKrnS5PlW1PeaiHJIkNMYDoBZd3XXtQ+p5uFE8GodSIcFVaGn31uv1tti3mmJiG3jKugRN3p0p7g1QhsYyHikpHiFuoatyWQ+4tXpqmvrvxDIf5GORSGtnRjZGaRD8kv2o7cXMHY+K0ve4MO0VfYHQCZNqSS6fvdLjuAGn1z2jeKWiGcjfIlY+oHZpapW56pTqkYDBjoVZpXLseajlYAVknVFSbQLZ1tqTaN0HXHMsXf0+zMHvxXcQWo2ZiK+DEji8ROmg7td78dudqDEXF31vPcuvSkMSudmtCL6byEBDPyLB68xulltey65KJSuYXswl9/pfwym2TEfarHu5a2cLRd2y7OmNPm6f13ld8OwzjtbaprjaHRhtTeXKVDWhy8f7imqWHnvhbOhYfbX8tt3XV95pC+Uv5nlV6qjUbLZcQfmKh3JrlPXrShH+v996Dqp2GblgZBi7aQDlicW0TScN5EJo5U7WYkv+AVBLAwQUAAAACACks3ldzaistYwDAAAABwAAXgAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9BQ0NFUFRFRF8wNDIwL3RyYW5zcG9ydC5janOVlG1v2kgQx9/nU7iv1r6YLSFtWsVyJAooQZeQCIiqXhShxR5jX82uuw8HHPDdb9Y2T+md7u7FIrM7O/Of38wsMQocpWUWaRKcRYIr7SQqlPDDZBJcwkUM14kiXlCdpVoXb4/Lvb1FJFeFFm9Mqk20qUN0uoOQw8IZgXZfyCzTqZnSSMyJT8T0d4i0otUmypN4RQPX9bmEHJiCBlMK/tHsFSMlhkc6E9yRUCUI8bPMXSNzb12pMKWG5+F9uRlkiWtoIYUWkcjfhSEpE7smm8071EtTpvA8FUpzNgdvszHUhrV/7HeBghZCxvYbTVNPp1IsnJ6UQrpk0Bt/fRz+Onkc9m/7g0m3N+j3ushDgjaSOybYHuv9YVCyFeVLiJEi8gib3ro2tqKfpJhnClwXkxP5H4CGFpsX3qy1XK0xlf3Nm4+nUsaPj5OH9uDbZNjr9oe9zni0r50Jf2YVlBToDCtl/HUKLAaprtfkGXNvtGdInFyTzn3Gvzc6TOLleAaN5yJmGuT7CyxYO4qgsEasKPIsYjbH9wJD6AbGAjYn2y3KVyj9zEHhL5fNC/+y2cJ1iesTrs+vNONRbmJQNmGqNNNGdbCzvF0tOSz1vpzWplZKc1GF3GwI8Y1HUwlJYA1wmTm4tgYlQnfH3bo6gD+/8HZlwiI5JdljBdgorWZZnBOXthpuTfxuPH6akPO3yo+8HiQo7Fxn61HBXQL2OtmVNthiIlHq4q6NVgaw38F2i+uMqRWPnH0TJYC299k8w1KWnTRnyy8rjZgvW5+uPu+wVRUI2YJl+rjxvCAHhBo2/Sg1/LsKX16DREinNHSru1NHJLUDb83PwynNgc90ageJ3+zieevKhMa2tcQK6Zy040Nv3O62x+2J7cv79vC2R2yqZVRaGJW6U/xft/4XkyQgccQ5snAro79JPhYLngsWH+evmcQe9lX2J/gqZa2PV77gOEYzZK7+M456UOJsFlZvGo3whoY7nHiXVH7345TEYaKoKICPUJ5bKyCLJfGb4gqbJrCz+v+wWv2bDb/50Gz+ctFsfSh//o3xb/2nU7woayERTakriX1EjClRU46tBY6xjugcPl1eEqxcJJZ67cLuZJzlOSakaJQLBYeTcmw4Tkql3obCZdmSFJbEsyclOu8n2d3+bW80njz0Rw/tcefu8GRWNNH3XMQmBwrLQkh8J9cnT5h/PAf+m77YBmd/AVBLAwQUAAAACACNs3ldvJ0e+GUHAABeDgAAVgAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9SMzEwX0lOVEVHUkFUSU9OLm1kfVddb9vIFX3Xr7hAHiSxJBUr7baQkQfHsTfqxh+InPShKMIRZyRNTHG4M0PJWsPA/oj+wv6SnjskJRrYFnkIRc/cz3POvXxDn4zzpEuv1lZ4bUqyaqWsKnNF//n932SWTtmdklSotcgP9OXd2VsyZXGg0e3dA4kSd50XRYEjlTWyzoORSvh8Mx4MomiRm0rNoogWpra5SnJTrrTd4nh2o51bVCZ/TO6kvL6ZLHLNfpPPYjmBrR8q926SJ4UuHxOv7FaXosjgnJZWlPmGsi0MJI4tTPLC1DKxqhCHZPp2+lNydpZMpxmpp8o45UKgKyu2ijK88DfKObFWGUyZR2VjynJh/SXyyPB8d//98uJ+gccNziZmX3K4TuVWeZeulR8Nn4Qejvkskvcqzc22EiUyT7dGKjYiSklPF3P6ohBgySFc3M9TetgoiuqqMEIqGdFuSouPv4QaKiGp5nPZ/cXt1efF9/vPX3+e336/ubidX18tHr5/QzpsNdurZcJd0bnKzkkaKo0n1MKLR0V+o5yilbH8RI4zLvROhUzo4sM8HQzOUrovBBqcfbqD3S9X11dfrm4vr7joOy2VTZZWyzWy+uEyxBYsRZG3NaKUaOVD2wzaCl0muJWjnORCg+MQjSCuZ2NlME3p6skrhM6GustDh+ulXinEtROFlsJz0AYAzM261L+FXCgrim2ab4TPYLISS11of6C99hs42SpYKNeruuhg2GB4Lyy/P6dS7ZQlpwtVemAWGC+Bdp8O3qV0aRVaR1mTLL2nPLy4b4vwIbwePadp+jLOGo84UDSVXCjv4QHAkqICON1sQEQJZUDHL+ow6ko5zmZ8q0ldFPx4SJxgRsGdRFhahOBxmC7Tz8D6yfbIFDDR4xxbZYT8ARTPkRawgL9GaEBELc9ovwGbg/fKAhlIP8TvUGyc5fd3lSoB1Ed1GKenJG4Yx6/SADjD+cAJUYVYJAW8U4Uwu7NxW/WAl3CjOePqqio0riwPJ3TQ3xcp3Z3SPGb4h7QKuP4ZlA3l6KIVtd8YC8CMno925zLu4nnh4N3G7AGYI4p7zAagARyzn6AbB65bqNLXeSAbEnNgFq7iKTmaj8PPzkOLKw+UNhWqgWzkyGK6g76kUAFWM85cqpWoC3+MnT1/0ADusvh/8aOgenXgHthT7SuhJctKaA1HG1pbs7JNljWs+HNE8D88M82s/MqHR8A4O4HhwFJz7DNIKmvLsTVmMQZg1h5VpzBrbtm28o7QGmDIdfbdAXXeXhvbWX+NmxMCuMSmFDRS6TolHgp0jaIAdOchXxcqCYpUnAhHZtUaPQGuJTVeyKunY2Irhdkz31bFDED0afiZ0SjA66qADWvKMUcLq+rXWkN8OlokgWUlRASKGS6mgz+ndCFfFeU0INrxMetEJO165ng0dCrK4tX7idnFUEbnkQj8277IpYO/pHSNijaiq56QKLSAOtg2M0wH4fCHKCZras+8xJQjTNpmiDsO9+SwKHrImtGzlrM81RJEhTE88n8xqZL7zH9qn+KT4mrl8L7/8yWGu1jYtQM+U/rY4KHhvGjGaQvkrJM3PhzTx7sbLv6nh4d72kAOUax08BNGEssTVo2Q+DHvYOiak87aAUP5RuWPPJYyt1FFkfKQGmWQnNKn7ZH379/T8WIaagYtwZJT+n/oUpp9Nj5yctusAg6lRdUFJMAgAttUupnjFmtLcJrX1jaT5Lj1/KktFgXF4u2ExY8VDqEN/tqARxz7F0JmcWElq3gUOtdsXTut9hPWi7yZYUF9OoFx7Uhoad3sEadNDepYFzxfTKmYLdwKJXXDFqmwbhzg+yuG/9+ArnY3iCL009fMom9TiGBvrWDHT4eYNFiktsyOHlH6Chrgx33qNhizoiUWNokSIUPMYRm62EIxykJdXMemI0qgM7dQeGp3iYCnKAyyqF3hgrbgEhyuN9TFqcqdBp1DiDthNbciKNEKIz8MXoBr8OYNFhCBXvdWP6QhICnGehr1d1vFm0poCWLBeVFgjc2y7IcbTCawWKIdaMioxfSrLNoVczyoBMMk7bkbPVPOi+yMzmLyB6zENAT7h6ixxGO+TOpS/1qrIdMKL3ragVfMHPAWAtchAkd47sdBQrBCzWVjsDWTnE3fDWOc79A9o38+o1kF+2VRxc2WEHjxCZg0feUd0su/Bi+g+DAajs858df4tYonORYUsYIMN4zkPvdJOOZrXdZd0gjRNTm/TvlxBgcq5isE6w5zCvkGWZ8NMT9w5ph5m3jYCGbDINtOsa4riddhTM2edVnVfvY2BjzDwwvhH/dxMGio02zlpDFdjOXvBs6uhaULXcb2aPpawLA6tZpnUl4IveV1MnDq27T3BRQ3684h0NirIIpQCB6kgTdH9J03EEI5S9/s/36DoE7c7mMW+3swGEV7rAxBcffGPoblFJk2G0hTEQYn0FOuVRSl/CF2a3qfaiGGvXBcRb3CUpaCf/0PON4qQoUn4F2zLZLIw57P1zij9pLTa/48qivJ+lfVoD9AItMoGvwXUEsDBBQAAAAIAI2zeV32UmymRQsAAMseAABWAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0hPU1RfUkVGRVJFTkNFL3Byb3ZpZGVyLWJyaWRnZS5janOVWftzIsUW/j1/Radqy4F1MiRxta5QcYtsiHLlkcvDqzcbsQMNjDvM4EyTBCP/+/1OP2aaR+JqqUD36fPuc77T8VaZYJlMw7H0akeVt2+P2Fv2IWiF8Sf28BVbpolM5Hop2DzJ5EkWTgSrN9l9mnwSqc86CX6fn38Z0KnBPMzYNIwEaw/7AyaexHglBQtjJueCyXSVSTFRfIjtWGSZz2LxIFKQKMacjXkKVSYzYRgKrEQRKBTHVGRJ9CAKKoZTsQzlmk3TZKHEEHsPaqR8ISoQ87RmabKSYTwrdByT1pNEZCxOJLjyCZbiaTjz2SexhlZJyrI1tF2wJZfzLGBNmUHJ38WYLJiu4rEMkzhjC5hEXMmH4inMSIw2sC8k/chYaSbkj2JdwUcbYqOyT9QpCcygOxs2WYmv5DxJwz8FNnk8YZGAbSnpWzkiOsna9Z9Hg8bPA3bB3p2envp6oTuot7By9k2xNOx1+mqpZk42r0a9BlYqv97ykz9PT769M5/Byd3zmX92erp5U7HEV43r+rA1GA2a7UZ3OBi1ide7r8G+5ijSa/Rvup1+Y3T5y6BBFF+fncMJZ6fn72pHR9Y7yBEKUSNNk7REHi+zZ6aZCFrDuVg8Mme/pjcCFZ4LFaUaoiNXaax3amxTsE/FH6swFddxaYo0QrSJfzhlJcrWZMqm7PjignmW3isjPdLkUQkdgEQL9tphluVRC2MpZikn+irz2Jeab67EdEsBKZ7kNdKuJ7IlBbN0n0zWUOKIIYCUVtkqkrDDw71ibAqLS9r8kBILGhJ9gNxcriT76y92e6cPM2WFIvriC0UcqAt4QeYscGv4THi0VU9Tvg7CTH2qA3AdLIhl2XLakjsmoVtkStKYeI0dGVqlEdmn5BiHggQrmoQKRjyDT42VX16Y7ZoSuznS/xH7Y0NSMHLsHr3M8mKPjnibSGiaIIvCsSgh99UVKNeOnPA88CiccCna2mNZKeWP2i1Kq23nqT3EAJ9BJOKZnCulTnfWvisumU0nN8u9y/rVqN3o9+vfN/peuWYyYZysYrLnlBZ0KEwYM6wS+wVflkqLMrv4zsmA4wVJNz5b6GxO7qkGebRxfOtRIfF85nGkcCZ5LL27IIzH0WoCcxdBmkSi7PKwcde8jMMVr3wrwOKipE4Va9vWowx9pvHMmI7s2GVWy83UJN8VFe0gc8N41Gq2mwPL3STDMyNLq0xb7DMjqeoYvKEDG3WMZFr339ov1sQTdnanuGgXKQcf1Oe62am3rLkj6k6jy8Zo2G/0tHJGNct/KzNTUzCy+oQvpUhLqFsTtIU0gopFhlZ+nUu5zKofKx8rJb4MPwZPHwMe/qW+JksRc3yOk0X5Y+Xh7GMl5/qmgpuYyRL4ld2iZzQfdgY9qNu4Gt30uj81rxq90bDX2tLa5ODEV588W8djOHWxRDILKDsVcjxv4qdqlz5bUF/zc1t9loWzmGPF9NBNUY1MAYyp5F3Y/ffs1obQ00ueE0TLxGdBEFgZd6zq+NblnapLxR95KAtFyRd+rgTDUTTcCcTddPsDz8/X54ACIs2qSCmvbpqy6gZelf12KXiKxv3mGUZvfsO1+6BVPKFuAgKPL5eoR4q+8nuGQ1A6Z03FrMr+3e92An3xwukavjS+Ux6Bw2SSwgtTHgFQbMq5Jw2XTdnaWqmwjkJOJmIAOg/AQqlprRAWCpgBQLRmi3A2l8qfPCTK8IErVIbOsFDKBoaprdZB8ulQztMOqoxcZao2vjs9U9Vxd/UrxNPLU6s+HPwwuq43W40rDzHbpT7/dou6Vx/YK86q7nrjP8MGrphhVN4JOX/MQ04CqFeUchqyaq+Eb0OYgzfcEX7T+gWlqTtq1XvfNwrpVNsprPa3TNdIHFqBOirSS54CF1BzAXIAbEU6guI1YVRElUCPjmyZqVvlC7DDtfaYSF63qdG+GfySC9oSs6JLZbuv/oEwP28sVV50SYqfZ15V1TCVzlXWVxmuNAvUkuonCv46PRsdu7gfShJdPHUVqqwN4I2++ESUndXiHmVSkQRqfyQxfwCAv3+vDwZQY7F0l09VD3Ml5P9oSPGKCIs5dmSYEogbc0AO4mtcpC79ZqvijzFjSHFjXHWpQlJKlmqI0MVR+17PCgQKcnBrqAK9haqjv+io5afUaPHSubauMZ796p7NR4+Dh/NdAhn2+9bxKEoeL8Mo4vfRCyxcCmLj/nZZpWKcpJOhyb59Rs4+2Di/XCZ5xT/IothFyGZRcs8jmgf1Opjm+y7LKJlhGKOLp1GUZYZ1DVzzCQOlzN2sspJGdJuCmW5m18kBfs7WS1wLEstbzxamPoQLgcxtU/+zJ4o1WLw/3TmBhLAHYWayNuCoG2QNUzJn91Zl+q33xEP06oOABvVb76L34rvGMpUK0EvwBBgDzFJAFnTK8p1veGpo8wrbnGCfs96im3qY/50yC91TvQPgX3oyQB3DZQ7vw4heEpYJpsCA/ZConJwBWOuBkCVxtK6xOGGTNcbCcFw0XeCnTL9AbL9gMAfyESOR2hJQomJp/OpOfSYnwsk+RM8H+BEG93P/q/ONBXrhRNUgG6ZgzjO7dmwWnSnArNhqJl4Yk/egfdHSr+o3A4tzWSE2E3LLrJoZAjV+LGohKgAimfvJR7LiUDqj/HreFGhRtbLiqYesUY8Z2ujCz8bUYgEpgNqiXSjTlT66Pe8VxGO+5CryAEzaZYf3isHKiyIMFnMuvfJBZ32o39Qvm60mGuxVo9Ms8AoZlCz19dYnAptCmVdg5LzBAt9l6iXirGizAHW3wMG50+m9qoTcZrmuQJmFhjgo0gU9cagXDfWGt+AxqubEy/vVS8qNeTymbrGL3icIlOnwFLaACi1C0pyQ+7xdPMEJm6nqQr1oO24uauH0QsAD4g4dKKjP+EmwFaNBhITl90lKuK5wkFYQoa7qOG8KyHSIxsDqA1Yfu1aryB4K7LDzY6f7387oste8wtDXvWkArza7nWLYjfXTpq4K207Kl10fbdVX8pMNK3nKnnCy5zgvGa+Bu2GnP7y56fYGRerZFmsD9TkBNEMoVZ36yf9M4fmX/827vPDk5w5fBI1lNXJv7qjiPIDsPdQonSyBo4zJIipvW1l0WLgO0uWwnyNclP2b/DZQ8Z+BXawOr2bzvUfqwIxYmJTo/7J4Y8YNCqdCwZ8kFoETHjWD5EjJLXNNJKCrtV/86vCFcDfp0bG48SiIh8Pd6LWb/T7yb6fMwEzVvJJHINQMDXHConARyixgVyJek6ZQEveCHr9hIAZRtuTh5IResTHDQi6PKvcriJL7trnw7XX7/s6AyyECNNhR3mSHgbNapsWth26EfdpSB17omTp7g1HVefHWCaxHksMPTt2rRmvU6Q5GH7qd6+b3w96ukp8UUs9VBCh/RUEi3lMPi+a97fUL/ZoWRYE08KxOZfJDvlraLk7IBnrtvmAaS+U32HcZmRJp7lu2U7V9y2WLMyFNUgHUAw06Sxqi7ldwv4CqhoXG2CVbgjMJcehQPvusBDNjZ/48oubwrR6kgfNAD9A6YjmW/uwkrh1gWcB4V4Qb5/fOTjH70h9xyvTE4e29Xum3b3PbdrDaZz2+KXH26ajq+l8vOabYN5N8lvo8Z+RSzdBuXuP1Y0HBfSeq1oh/Gte/E7P1JwHT3M1bS0nsgpf8b0s7TtG5icr/ntnWUb9ULXTU7amJCV+G6llK6D9QUat0Wm79p3qzVb9sNbwXzJ/yMPontishhZX79UH/zczYOw1hROTkfSR4ai+iupvbYOsFQKZy115vWwAQA8q9A8jN/p3HQVtR5O9NO/o1BMFcRUDnT0t4WoH9g+8i+3OfvwcR/L1XMBLxf1BLAwQUAAAACACNs3ldfF1+4JYCAACCBQAAWwAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS90cnVzdGVkLWZyYW1lLXJvdXRlci5janOdlMtu2zAQRff+ijFQRBKqyM6yMrzoI22yCAo43gVpQJNjmw1FqiQV13D87x1SsiMDdRfdiA8Mh+feGSppHILzVnKfTAajEcxwiRY1R1hY84wWrGm81CtYo6rRFnBjnIeqoY+saoUVag/e0hoFWHRGveCtdp4pheIzs5RarDBkXlpTgV8jMO4bpmjNKkwcbKQWZgNm8RO5z0Eb34ZW6BxbIQjmGRh7iPPSKywGy0ZzL40GbpF5nLcEX0POGRGjTXekINydn8fKwaEWcxOPwT6D3QBALiEdtkfh9RX8tkaz7HIVnBLAcDqF5ACQ9ILOXnT+SB/gNCgjsywJ1riBOQVfW2tsmtxJ50I9Dp6vQz2YYDVpTrIJCbDoG6uBua3mcPTJ6HjJXetqii9UuFYwADc6FBWmELfh4qKdFMH7SQyJrlQBvCq4kvo50l61G0FLS2/xV1Q3fEg6x2prXqRA65L8sMXXzPdWjLpNJY+F1Fw1Al1aFabOsoOOJVMOJz1OTpxnnW6FFc40lmPWY+cBixeo2YLiIy1ZGEs8/Ggt2xbSxTHlhFSzhVTSS3RZjDjde0NNlKpaPf8AloKIq0KKN5yu+rIFScIL1KvWudEPvrh8GF9+eHzfDe9GhUfnUyn+eom3266OhwvJnUZ5upRtmPT93qVXwQ9WlbCTouTElWvqDJqFIe8cKo9e5X3p5akT+xxMXYaC5cDsytE0DEHIbk8vatJx9dr8pEI57GI3lVd5sKSkBqJGISLzXIby5K2UQ6I90Xu+hhSzo+T/SR3dyzG8qPI+ep+SP0bEdkhuvt/Pnz7Nbr98u366ns2+z5KscEpyTMf51XicHWnitytIoA3b+8lgP6iMaOgvhb9rY72b7s79pCj4D1BLAwQUAAAACACks3ldokUB3N0BAAC3AgAASAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRUFETUVfRk9SX0FHRU5ULnR4dC2RS3LbMBBE9z5FH0CmnEplkyxStMjYLMeUQlHOZ6OCiKGMGAQQfGRrl0PkhDlJBnQ2KBZnpvv1TF01fbNucXX1Dn9//8G2uWnrCuWuX9+XfbPCblOVfY2u/rJrOq5cf0dVfyp3n/uLjoTkwf22L7t+f1t3dTFJCCNRrVfb5Zu3+5YlHur9iutdU93UubWtyq7KjaPyIRYX10lpCU9CY0xmiMoaoVU8F2jpGc90gPP2Jw0xIAWCpFEkHeHE8PQeoxYRP5rN7DrxI6L1ZyQT1NFQltUkAl06LQyCkjQIX+COyCGIidBUsAbJHb2QFBY4pMnhRD4wxQcYmzUTk3lSJkShdYESJ+ZjI5afnbU1BBW4O2ZUmeYMOZHkEDtmjo8EelEhKnPMLZHT8LQykhzxYyKE4/8svEAYrOOiSwetwiP5OZokqYbZ8n8whjlowkgkCzyQV+P5dYciRTuJqAZOlSHncW+1PvDCFuxOgfyJskCkBQxxWnB8Zjjb5APpEdEnvgxumdh69tXIM2qgpRp9Xhu9iMlpCtCWq5fW6PlcWcrTr0Qhotw0eKJzgPVQuXmaY7KSEz5zveLxNTpy1vNA39f3mx5LfF13d3X1kb/a+ls/B2DDIYJOfEEzUHHxD1BLAwQUAAAACACNs3ldrkifwpgTAABVFQAAUwAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRUxFQVNFL2V4YW1wbGUtbG9jYWwtbm90ZXMuemlwlVhlUBvM2g1aKBYgUBqgFHeH4k5xlxZ3KBokIVh5gWItEKCB4m7F3a0NWmiLFXcpLsGh6O398c07tzN3vvfuzs7OszN75vlxzs7Zo6OOhQ0CAAB4vxe92c5ohN5PDADgAdbv6veJva+1m4erPberu621KzfEHWYP5XWzhjg52ENhPM5Qd4ibHsp5ng/YsckZNmyuXGtn7KxNX8BcbY45d6o3KIBUegeucrPbhyfHB1W58taHm2GnXWx0vF9styDV+0x/NofNT0H3LhLeQ6I/cRrYiqDHIdgPCg7H0HAUfGOL+9dNRhmxMnV3vPzSuk3NAXSuFD0ruH0VxshvZTlCCmVRIFRWUcGN4Uw3t/XQVukbV/bt0k7VOkzkg48gSdf4jWi+2px/JtaI5tn96PtZnb33xM431wJND1u/m2qGXY4MKXRuEPhFJlKLfRjkcIpZL7cZFC9HYBJYCJTX63hXgN2wC4n61QAGCOdy76Hgj33UKYi70TvEBjgi12w8HNTwwJLfLQN7qKEwxsT8q5KvnYGKAaD83Fv/ZNZo5UP+PIFmiY5BbqC2FIxYex06q90Cqh3QNyCy/TAUCW3RdVmrY7PSHDUxbjNxLKqw+sD/RljLcExET42+pQAtFrM9b+PU/wvfQq83VRHiFQHCKDgBe8N19IRa+eVFERz3NBcxLt0xevIBLiivb8PstXdzGUopeZyH2Ne5vYYSVV/aadWNaPc8GeaT7GhbHwmggTM3zD0KyV1dA/qVPOS8047ZniTkpx51LabuPiS7/bwX6QtT6d9vN9v2mxYunOmf8McmM9szc5/4ur8MAuj8B0WGbHNNzfABAF1KAIDpv1AEau8Fd7K1/00VJwiPmzO0wsgJOidKdntgifGyMMIuIu+nraCx01aiK+fjfXHkFHKTrb9Mh8mOvgiAAwgsL7/vXADwDqjCYzNLvBTzRn0DOyDVv46Zxayv3mfw/6U+n/D55vBLyiDOmq7awXZ9bnG7LT+zmrKe/nZCiIrjoer721t0YBfOylccY6UjN5iCYbWCBfIoA9miM6tr1/fEUZ7tk63eIc56q+cjVUpNfTXf+pwoRSSyEGTSw8DMhYH/zNaAY7zck3nARrNIYBV/TaTFv4gQzyy2RA87q+FbYkS+zWtewSG5NMXDJ9U9qYk5KYTKTFgu4kreiqCtjKgH4zPz1tGF8WnfALUgglWPkR9ZJSw0NVZRHB/133IxSlURrEAbxKf8jS17N529n48Aa5rb97KvFAUPj7+zpY0ubhK2d1S6x6yv6RFMt5ITVAqNriZ5kVE+e7D8Y9ky+RZlN9522RI0lh4Teb9H9OUHuadVwkKCori4/bFpm1bb2sEGi6rMK1CgX+xbBYEvlPocC1XOonQWMYiIpLWQXMFVcLGc2i8i3x1lr+q4r21bH4NLDgzeCf0Y/47ya27224BQIZOUX0gU9FTA5AsJD5hDM7U8Twc8DhvvIcedMuCzB2hpD2yd/VwSjbbrQ+dMU7i/pN+czG6uBPArK8o3pEu5yuXLkrYalTC8n7djbaDXQ5SnUeXhMrrY5QkZC3+kuRZ6YL031cWWhqs49o1GkUWwHttKCLy4QG3/+qAqYW1l2z0Hjp74uXxmHWjNR3OhVF275OwNz7t+a/0CN9pUtFK+DQmqNamRmI349lHa2GqovoekYnK2zC16s1rHTRCzOksPcVbOnlEnENFUVTmVSctNh5jjTrNnokg0ULnjBxNjnvxMSmNGIJu4CiEHhksDp3sNa6lAK8q9jTn+c3P2fGVC6bvd2fDPGS5dlkG6P7/rrhOSlBpFBbyJPVBlL9jNIOTl4RnuT6hbUb1wFQD79EtR33RxlJHZaK+q9ENX5a+mE+VdDw9Z+AxCWjZOcbsXrfamz6qYzfeLVYMOoRflQSZ28y+GaH1px1yRTaTqqhkPezCm0cVMmHdU3kxrW7JMXQ5cBd+SGk1CYr6AyeBJR0aCKNXE7Zb4PRkhz3wjLHXfBsBzqy3PZ+m6j59Cmxm5Q3S8UB9Z+4+iii/tWpldouqNlBiZJlLDsKIBYcupTkeHCz5zrutKd+PjL/Ap1PvDHx4R4V/3ZYnPlqg8aZJN6dHDFU6XSpM88+IbvLplPUS6nFVkkKOEz+OP1pDibqwmPPq4K+Hd6b6+kT1QwjZiVGmfSz+vSMZjzoxn8l80jzXnMxLYsn7gDqq+f6PFA1YjULU+qUJc+SFWyEj0lJR+9ymm4/Q24bjneW/64sipnHsAFhudUDhxpXCyU0+WXOPdldRkPsv9Pc6S6JMV5Z33/QVC8s9l4WdUO73HX09/8fvWlPqn71ZgAW8dbYzjH9Iz+1GtEQYEJ2o3jn0e5yvYc05SEnHbvEMdQf0D7LfdFB7Vw+2s89k2GRgxF0CvUkDEVXaPlCDC5AKN31rOMRWAlbvhypw6nX8d4JSP2+LxhZ1AFx4fSa41cbS3HjzNPq4O73/jHP29Ap+UnxEuuLIUuWGYFUH7DPpLdxQoqQ4TG1ihdtztHjC+WKU9TpfiM3JwPkhbwhPx8Zg46gabb/biRlsVLuS3y0ZnsKsN4YLami+2nRJKNW0kpaxrQ/AvscO2326zgl1eYXGzJNADQQLVXEeVzzQG30HfADN5xSX0dIiKPKLOtxWUM6MLDvxeZ27S32GXeqUR+ynQ9JFfAb+dMXirtJmRgA6xvS9KF2GGyafvVXNOukkK6fTBPWpiUxhrnmnMBi1FkQE4cknhgdPip5kYMUjB90c9yOJwkdBvlXL1hXrfyDp1X+LzppAKieZSTvBqDJv3M5wsGlV+jnQrdXRHy4734l7eaixWvo46YKBQbxyfw6QomCaLxDQavg60nn/kC1ZK2lQMPw9MKG5UbRX9vd3jZc6EocovS6akvBdlfdniMTTVFiL2cpTj2OaV9Fyres7tawrGYKAJJRHQy8jXsobx4zTuJA8zc0JMS2O1UPIMy530K4u2yo8FX6H6YiI2z5/oasUDcjT86oLCWD2+jD2+OLbZAFaNuJLIcvd/iJ2I4DRt//CKtRIWFfKoCgLqD2oPx+YPAw6jfCpLxJmELFeBlE9Sd0qLZw1U3S4BA1bE/BFlMx9ORi4z+C3mCakdEj0qy8jYWUO6J0M+5RlduW0iX+6oeJZ8u90BlUM8XyGtn/+ECj8hOqlH51DsO0Dd7yNzcO7RFN2PbMK5Ubi0iuqTQrps/eIgocHSU9+p0BJ3aiEHT2lQupbd5hjmyqP6DBLltVn2Mz/W+rO6UTnxQhrHwdQJQhajbJWqRnJxbe229V2ABbeZ1eoOoiI2v4NS43T4pvOT5RUtVRTyeUQw2wwB5rwVB12f4tuiukoMDgdZLH9Bbrcuq9oPY33BadEPVayFW+61rdg1PvTJyJIM4CYhd+W4zGoKzOl4X8PkAuakOjWPCsrmUiQ/Hs71QqboiE4iNiuy6Z6OMQm9gH1bqm4G4sjpCA71f5qinss1OR7tGlLNbOBWbXcuL+cZWaghAlqkVRrdvFRvkkqHeK+VLfVmbRaeNY0loDU5ZofBThwHLllmU4McuZ+VZUWtO4zehKPmby4ecKWSNDpICy2UvVhD69pONlvQtpsE8KbZV7SEp1WNUzgcOqHLI0VqZfCv4lhWRdbwqk5Ow4ZwHqOlw5RJMBQywplfBkyd9VwSeC4wkebTtWrhoF7g0dy2uzrTL72lFfVhtNiQMFs8IfqKujmfH44UXuxYX81KOPD7BPOQxqK//dWoPNmXyZFoqXfThtlM2umcVza3MhVbs+a//lOyppFEpOkcx6wun7r7yPTkKL27I/Sc/krqga91OsEWypOilThmo+RtfuLyFobaMiXxD6D6ETjLNvId6K4BIaiS+sYJ5fZLawJ6w3B27M5kzUPNjG9l8FnkkuILcdpB5a0v7hqMbiOW+iYGl6bzxrOqIWjL7bWg6PwlrBDGIJAZ5HfZfNSyj5l3lv5ri7LTiHuK7lL5uiFEGpCdPlxpR6xYsjHK7ZagmHI5LYHkJzpg/fVdsYa6PdlMLP+uzRO9KlWAebND0jcySPB02Q8o+GwTnkYCdtiZ/rx0fLh6Z/mf7kwqN7nl4W/zfo0LALD8P+7Mx96G19rD47ePDzTUdf/BB/xrqUoUG0n7vgVdERXWKB3MIgtrH1bnQaTaPpjbLpa/l3gl4dZvcIUUOvdZykRfD9mHKh+iSjiqeydccV1mVhq8nfMJRW+Ec0ieZNBiyjtudzhtIzziKvWVnDfom1EPylH5c6UPc33OL7TMDCcvASajtvgNFRHEmkDFLbjLuBHOrmiAi6vscFQvtnv5Lg+KM1JgGf/ecXeB+fW8TG5gvPVh8uFjUsaCpdSHaSgDOWOs2pftybncqHNP+tqYa8w+zmCNA77KgVclW1RUpfCuuKdhKW/UHHUnt25olOC2mjngSrSPVK1YQmCVITMj5PyHabda1Jp+Tsrq8nB2CpwkgOMoXiwvrqSEkPSRL/3bmNJlHC4ZwMdiUB542Z3hizSF6ugrvktCzs1iDH4dq5vH5FKvh68UGD+whPxq48fdeLIfHdmzyUc4VACmfHk95Qad1lH5ainsPLJi5LHHlT4KhZ9iMs3hRXYkUSzWq00Rbyt6RtJgSpI/l5x2YACxS7KKF4ztFE7PSHIijqIFK7wqsZo/Be/jz0YHf+ouAFvbdtafInt89HYJFJ2yv4xdC9Nve6hbZaVArW75QQzTEqaqCJc0/bqVe4P96jrT9vgjT7yQeQMulmK8nyJddM8oI9eDnK2bhEBCTmIT2O+9O2bH7mhLQnGdrDhq98g56b9mVSThAFofwfmyJnz7FvNLXBEynUGtNebumuVCmSYTz8XgVCamwzP7OxDvTzY/z0KbWEW4z/VjXT25+lwHX0bKjuZeeIWS/yXjrcUp9yOiaCMwNYztfk6yP0ogu9OISV8rxIS58kvAs7NuE4iT3VgPzXd2oTRNx4sB8Yz20vxyf9Ynq1s9bWiN6NvD6RKPPX6I/pv5jVN6/+TFpmkVtecLA0PTalLLAovBDLegn1mxcMPupYJwhmGIZP99gw2rWGeg+VKdANmQTNWnv0ilZ3SFJaT7uofJ2c21elcTYQPTxkc8eE2v2U0T96jEFhxTYoMa97mIBo+qHPm81H2SX4+LPhBYeJfieI/5n2rKORblvP39Heb+rSiOf6AmJ4idvS+PI8zN1VC/JpacH7iP5sQVEbIT2WaDc+fGMzCoFajL5sH2VCczpiz2PL22L8F/hWRpr6hToTe0dIwF3fvcF6nb/GzfFM0Fj+iifyroE3sMZpuGWCRic3QrxxXI+nCwFLywE/++SCBm37FTQ/EoeopekSwnlPXUzLshonVyudc5A4GS2OU2XndQ5YzczwPGM0d6GaP6rlinsZWsqPH09bV11h4CRxsYRr9b7wBTi6J9W19xZJJpJ8DqseSiWimcqUrdVYNR5Eoz4+R9sDPzEf4U09HC8k1bwL6BGtdVRD9VpTzPVGRVtbG7DApt6eF70y5TLt3l0HRTHXK7c/TVv8V5R+7ZgvydiED/63QaRio+lnS8xFh6ZhWqaAou5vdRiZ/9c4ZYRmieuwxdJgXkdbDJ80VVCD/LKwK6G9IHOGrRn1tpcsIUeWy+a9GOYmya6oLwW3o5fR3cd0iRRCuCdbng6z7w1kSdQtDG+tve19KPJEcvvhlEIPzZk7/zk+NkxVs+uM6I62Cmv9h5c3HNmmE6aJAfGR5SqOuwZutxCR5YCF68EmweLetBHg7HZeeHziAC17Ug+qOlM6J+nA+TQ/Ct0vbuzMcH/Cc/EdFEuk7b0NZ+jLoAlAPyXz2JgxEdvbv15jGsDjqSucaeoY7xIBDrgtzPSs+YLVk+DwxiOjsVu/uDRDb8a4EATACg+zeJ2P8BiaAwP1d7HlsoNBy5EJvOBwxHn4BK8tT2SxWpkPEp6Z1RQRF8UTXv3SjZjtumgK0DkJez6hFHGdDOx86IowS+wemed2BwDnLG1PjxPrtYQ/ckYkghAXb5lX+f7AFlGVLQs83kh5OqDxOzMua6QOgBoLS9tGvDftVBheZOLrBw3gj/2bsPnxE0HyNmOJ3TkrgTvCBPN+F4RAq0QUSqcWNT9aJF+zqVFeUnGx2l33h+/XKThcd0lMXYk0koq56/yLMjtgEN7h94iL5fJXsWQBVi+kMbOj7DNhLoWT+S+LA9ztbsa4+kv/axkdmaeQEXQF5zkvCdCLdmqA3NONNoQxQikZMRcp+RoDCu1US6jim8jVHVEKeSSEhNEvqKchoWpzF2GjDTU3LW8S7+MQq6B3r7ZagsvVOJJFtRkiAreg0Lck6XzvCCiyvXEuUP0lh4GdsaS3Bu3S2BRmRlNZzUA5Nv1PfxVNqd+jsgrzCzt6KHWkWLhYsZD3yO18nnfwm8EKkXyIMOcIr/fMjywy8c7Hins0ljhCO3UjDSW3GlizGh1I3Vt+JpILjgdrWSUicUSgLJDx9T1PogEDhmOqlX1C8tHl6t2+z2EafPi0/WlEBde/rl6PyJd2byrgnJu0erTHErPlhkM3GXxZi7ZAS15E8T+nxj/NDZMh+T3zm5Tuul/3jdXSQ8KbivMH2Do6OOgQnC+u/h3P+NghDAP4nq/oT7M8j5G44R85/FOn8i/mk+/kZEEfxTK/In5p9P8N+YJCT/y4P8J+6fqvwb14D0f9CojjoO7r+v4fyeBb/bTCf/d/UvUEsDBBQAAAAIAI2zeV2nOdhmrQgAALsJAABNAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFTEVBU0UvZXhhbXBsZS10aW1lci56aXB9lldUE9gWhkMJQkAG6S3Sey+XpgM2eu+OFCkJEkkgkCBVpIc+EIM0g6ABzIAICKFIEVEEkWroIEUEFCFRpEQCDj7c5ZJ79Zx1XvY663v5//3vbWfJxMwLAABYD5+EOzuw/tltBgAgnBEAEDmsQMO9EUg4VAUNQ0BD1BDegTA/KAqtehUVFAjFugXNiHMlze24ihs1qjYCHwfZ41xySNNmRdtlaS5MHKDj7T01CBf7g6jaNge3d8cH9KOZtFrhrMR5HOZ8soKrWComnzpbVejdM+7Y03mOPlijHs9Wq5ef9umttz1Y9lSSBqZUzWdrdE8wUlofrXdiFZx6niEnUSGXtZfrbbPsXpxgje1FureklI0CIaPtecul+xMJqasgDVu5VrMIg0GZmHs0rkjM4JbvxmLhjoRqXqSCSJ2Jl+janUcucagQdhDQQCHXn5jIgvfyFzFvCOR1ximg01Bf3F5O8zdcLXjntuLW/94hvlXBvacYhrufFMvox231euCCrcpXlxKCGX7Mq4F37OrLmTH/yaY65vLbt75hHQ3zdMk6KmFj3exZoCduEnzCSsBchJRwp0yQiFKun3/rZjJbUBNDbHdCAza9e1XFCUhvqZd95VFFFWrRWNyDqgYMRq4iSdUBdez7PPruJuhvupr4r7QnZWuVtz5KXVO3DHPdK5pdCG/c26Zdu0EPaejYR6OajGJWAqjjp0e3XGsKx+qnWgMPAHY/iZpHZ/tH9VBQMyAAIPg/ooZBfdS8kchDTTOdrIOm1TnaVlxrJlim8Wt6YNL5Ng75MTAj3GMYsgPivikYKm2LLeI1PtiTpymZv/bSTV+Mio4miDqxdF7Eo0QgCQtc5bcmbzNdKYz3iYsVISmytzISSy4gQnztQzLO3vVQ2hfsesDNOh7Gw2TR5SDEXtZ9TiOHowmLbqWhbvxZRG9P0ohORu1i/RIYVQQJAd7yU7LkYA/zgj7g85Uq9YvHmkMUlUEg3d14oVN9NF8w0XIyOgnNn+aqhNOhuZXGFPvEzSiCWSgz17kaJpMLH7wi0g3umSKdzaNAQ+/R+REyzf25zJkOJZxS4UKx4/kXZyYoFti8rI2F/T4c/VY6VeBRH8RTXjJgXwjra4/DWQ0h64+r+bKOiE95hpbobCb0ReN3s+2dH9JL4EwU7ZtLCLUWSL2ozebCme2MOU6bggoEl4xVipgtjvqawknjosbPn+V4ZniwbP0+4PZ/7tigDTE1+tgsfIvuKx/JUYOMOr+0Yw+AWiF/NdabnzFgyCZThglBpRR3ytMu0tLLIpWr2rsdKjoxfqbbB00pUaY2wlPrva38adbyxka1kh978Y5X8M7CiDLon9caSUvkdtjscf4q7QPndbjn6me1lmP8w6CsEe3MqZz6kofqUw9GdZebXeA85cECbf4BEYWBrGIv8Mmoy2UqI7WZMJutvjj8HGDBZJLN8vrX4Mtue5EkZno6g2yux8hUVd7qSRWeQYiRRvO7yYJzHHdaRa6viv3sMUGxtfGJw+CwYAIARP+vx2CBEGi4qj8aAYc6dgZ+99mOkh5e5NSfHIIgtyfZfMY1dwVH3K85SRuMSVomP5Om5q23q4lA+xG1xdJtpoYfchw2e5mtX6cMvZ5fsr4pgHwp5hbnCQHk5ugC+mMJZ3YUZQkut4lu108EJboykRZ9PhkkmzGiqYnFTA/H7OaEWy9mVtKQAW0ylTOKsHc1bUqKkN7SGScqZJ/NU11G5PTH9dhaIntBl7ufVIuLdKFo+cmcyq0Tj4FEtIWx5nt/03jeUCWynksHFpAANpkkJ/neCNWYEI0vCBfCbZXgLYh8l4wdcd3Ap2x/aLgnzcB3jBZge3TwAT25f3w2pnF/e3eI/FZ0bq73m6i6Q2IVDKghe8a40mXAsymodO1ZgLPAF/OerZW9rchhre26IYyWPfW5hNY7vUpZh+bNiELL/Gw1oUThmPuop+Wq1BczKWxGSxuau4YVRJokJRppbIBy9J3XV5WzcfT7x2tumnkSxuxXzjwzwYDhkmN9Yz26iMAVqWdwsh3HcHWnh6DU+xk/IAdvEgTpwdXEPK/AE38Hyy5Vjo2UDUTyftaPNW1JDm8Bip2BgQeKl6/f5WousScoTjRlK685/v3kfIV/f04YJ612cB5+b6aJuMnTu9Yh4Jh3Z1PgZ0dwbKYG7B86Av5LR6DQEXAoStUXhUI4TlbfU+e4TnFFO2WSo5y54kj1C9Blx7p8bj5sD5sHyyeKr0WUwPv2xInU9UfMWQPPzzaPeXM7MYGRKlT30QGTge0DEscOV6ll5CNaukl9kTjcjLGEqKRApiVWNxY+1OzUvFZ1Er8L4ixZC3Fv/WNkFut1IBS1OFLKYiWvZVFBOS9HhSgPKqrVF6vWJHQ442vNmZbJQ3Tlx9q5Op2NiwO2/mjjU8BUiQtxSjUnkO4Ei5KT1SYvkh23IvOuHJBKF+eCRk/ffJSaEpDpWU2CD75c1/2oPJh+dzc2J4itm0cZhPj65K+NIG3WDfFhDwy/pLVNvMBVRbNJzhaBLe567AtMLE/wPKzZ1CBGulqrVrOv27jLE0QAovvgVs5r5IjdKqcHq/QWszCnDu/pvlCt0MgiNw/mybOXp8MgyYv2Pe18es9LI3X8nkEK2rLBfB/Jt/x7DE2udFEdSIELLvhEuc5UGq+MKwF5qZv2mer80H0jPWQHHoXoyRRDG6qHkmkVjYT5z97UMGhFxgcNOznKK8gqfTsDkeIiKrAZ/aaJfX5ZiGyzJdGc7wVhnyvhq8IdE9wfEmYXo8jPZsKsU9WmyjGiRtY84mUGWelGYH+psZOlLBxs8Rt8qwTU8NCEfrTIG0zKF4F80xED9g6rFbBJ3T3uMfQiJiHYnX7MzpKBkZfp1zvIfw8hDvD7jeQo6Ojc+wEaZfj1FDxKOZpsPyj6zL/PuaOkox3xg2TJ8vv+sLMEsnz/yXx4pQ4J8d+BgH8BUEsDBBQAAAAIAI2zeV2Gakv8zBMAAG0VAABvAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFTEVBU0UvcGhhbnRvbXRyb25peC1jb21tYW5kLWZsb3dlci1jaGF0LXYzLVVOREVQTE9ZRUQuemlwjVh3MBzc+l4tWERvK1r03rsgOovoXaL3FpaQ1Xsv0UL0togWordYUaMGUdYiuogSIotVbr4/fvP9bmbuvd85c87MOTPnmTlz3ud9zvvogrGwKQAAAN7vwWxpVlclu4MBAKAxAQCW3zvezjaeEC8PiI+Xp0sAn52Xh4eNp73A78nF0cEXwu/q6+Vp9OqTJ0KQRAV1CXx8sLyNnikgZY0O/4i3Lv6mFC9ma9q2JJZ5RjuC6e6p5i+41bfJmRWZ/Mv26hqQTuCiE43vTV3CtM6FgzFScAshtL1VctOw/hWPv6UiwoDrmttcD9Fqgb7nYyUXKmD5YTR1//XsNHXtKvLQxCDE612efqjzc6OauODt2FuBFPJxy/M8H4NHlS41R4ivlMPcEpve0qJGIlqB84+JcQnnHS08ClsNehatiesHdXlPA+CJmcOopTNK5MIcbpCFRIfbVJDW4Sv0Zj5UdT3A8i63Je+UJDeZ/d4gkXBaPgvJFIUQZ908CUtyAp4b4aaCFOyxWwXXy83yVMd37RA/OyBut+h9GiC5ZfmqyqDo2DoLSR0fWzoLufIYTU+mOTfmzPOaWhUwV7IwDV8D3TNtQ2lfzMfkLDhlwpnqSbQnY4I8ESSqMoQfaWpKYQ6YNT0lmS41SWEjnKahyMClqeUnYHtWce7R3N0qPSYKFoEozNJiLaYsE5JSqpUIHFHsjkQdSSLM/JRB796oqe3R2e6Cq0WFolj+VKWiVeOQvTHpgUCORxBJlicL6n7Q5CSYHEzE6FVhy6jEYv/ppuMLVGNo4MuLy+AuaODK91bUCzSjwNR3wklcfymlpko3/bWg1Wss3X8LE2onA5FDbACAmgAAYPqPYfLCwVbAxtv7d5QEG1t5boqThKwZaIUN6rvSH3km9i6qE9xVxb97KuOXT5XIhOcc3xo/kgnW91+pDS8sVdujXIbJ/eSEvrqvoZFNLhHSWMF8OTEusUZIj82cH0yc2gBQr5dyLlN2VydY29RyxWr4ShiB28Y1uhE0WlHi61maiRiebC1a/xYCzZv48eEgbB0Lny5uWKu+Z1RehidHw2aAw43UJ4vOS9G0hU1s3CH7hGKBwaaiqUW93RUz0DpC1DrvwIPckXe+G4PdRF/i6w6V/68T3px3pLm8tq9PcMlf3/OuEI52PtKNKw7JBVkeO34uhlqK1X1mgGkdMFv4vL9qlgeM2nOzxnKB8UQ/mXyOsEI2tOCgFNlpQBGxKdvC1cq1pI2losb5tE8bQSSW54RhyAASrOeF+EFEVKDQkeoXT7HWeJuoP5wnjJLRv2AoLcM4a9xRUsxvbm4W4SBX4cUvUl042U7t48NCG6nh8/vvF8tf69ZnMOKWPSt9B0XCBo15eEPDJkFPIlvmQbZIrGHLxSY4N2pzBl5sl1Wxz2phE4ZGEfDvENghv3MTZY3tbw1Zu+RPa77Z3fDGddAgqxMqDJ8eAZhgxBuQrpXt/KLHYnIkkQzUf/uRhKLt4U/al1D8RP4iEK+V8ZCO7uvcYN7MQ9LCKIhpWs705DAL+Eb+vheElggRjDInHvcj2FhZae3Wt9oHKfCDRwL6t/I5+KyZLofIOnY0RWCHXEUE1dUwz93et0A52FGhV4Y7C1/gSvPu600K6qCt9JSlBHJEqifFtBjYl0PdsKxNa9YSx/TC6isxTxwpiIzhedXZvj7Nz+GfxkNZJjlyap/bkaubItmwIdteQzUBJrBcjAFBykaVZXbsk6DYhalHUwOz369gNPh8i9AWA7Xt7u1KFu0ox9lMjor5x1/YaXOTEANvU29Gy+Vl707RRQ5K1HY0FuqIAC/OipaXEmnP3ElXo4STFglq9slXkPrJwrv9++hj4Ic2r5IyZeHdxhGS08KzrKHjunsxj44bxaIPegkssFLgfNZlpXGCAbidH5rsXQ9+mbykxPc7kTxI7Mx8x3PrltKP8vhmn+1IV69z2H5go2PoSPddXuZn7T6LCEGChTBlu1o0v3AtfhDO8drSk/QBBnO7ftIcj9eC0/R4gccZZcaa/TZPxIAgOnQat6zJGebRmZMggnLKEafXzVDyXVPrQvXHRJJxRQe6BdX0HiVMH6HOvBW/5Z6u5xCpC2XudY6J+G2eyCru2FkQrcPnuU8mL4LLE3Tjps40QOc3NgcKpsgZbxo/Dj3i25tPSBET/vhiSb0mcv0Mq00FY6vKQBKqEH8SEXKBxs1M4Fv4l11weMzByU5yj97+K7cJ3WcjZY+MPt7WY6xZY7y9OGD2H7pZDcSeCZAFIYzh96qvp6LsuVxPfjS2rPjddbcBm4/naXUED1W1xOaur6vusnTZn+E4uOJ2WykjiReTrMEWByMsQPmaD69M6frDx3iFODwqFrOBhyFYLWv0ndt54UBaWCDcb/0o8iTu4vuNt8QD7aNl+TZ0pL8TSXqZLEKrmAn6oAWapZOac3mXegtBMqr1DOjTj8FvbRT4rXNZHhO07tCIxZ63oeOFzg3wGugjcYa+LQXCfZpHMi+SOShiaN8LoAfd9R80CrTDgxUfZk/TNAkXfuNO3pBXNPry5a2Vc9/dH6kytkNkmBALABC6998U9a9UaevjYu/k8Fe2NDx+8ltRbyafPVfP2FCgGpvuDZOuVhCracnMamoY1K4fZEkWQbgMa96hCkLLIYIzxEbuaz2oI+SSGq43+gPlTholJhhLpJppc4wzfYrUWBIn2iEFaARcaFfGkf3UKAziPAnPCQwHcbPlREQo2FVO70GIAfXl4o1V+6lNH7/jOyYIkHDWi8JlMWabjGkVu5D39FwHEuFjiz5dJzRxEeI8cpQ4DlJbk9rExoollF3r907amJNB41gR+a6GYExQwYO29YeHiaek3K+EFeqk+rmvjcrE1YB+bOBkQaPT9BqEjOSyXXPneFIamyBbRbyNNkRP+3GesgO7dJlfeMw3wwjq6Zhs5CjesIIKSFkKNkFmIrhOmfji/qidTxsRlcQ5D/RbtuxUF3h5j0A7uth2Bp6YTBagF/X0ftjrmYdER4cZUIzrS9pfQhMdX3/NhlbMGQt/UKU//p4HG4Op2itRZHBVGm/nRqIi/JjrVnQNpdUGFOtHNpvrUoLpUNx9CvVDtuFN4uMMsCEBRXOsXBap+DsVIujpDFGsntj8UZp6HW82gtX8i0pkYvRhRupVfK5NK5FVRblt21yPz6p9CbLZUdlkAPFjK2iu63q5AKJW9pUzwcAqjtCMJ/xJnfEDme/J6DX/h2UaDk2aYW87dJgMJabtF3apbvzRcz97DmXWJHEkNPmjhtr0yxJDjq8QH7no/PrWzlWRnzhTXliw+Nh2TlUyytcKdPS/z+Sh8nL2C9jb9fE9HsDKwSEOSsLBJT8ZF3rfh91BFFQVKymaV5k6jtvrWXgI6q6zWVh47jVNv5rMMTCzddR5VjZ78GISbWVB5u4/TkDZm4SbTh6kmM88pHmrBt1LBPuIw2RQ+XX9ybdcD8gJktHVBefPIGW8zrOPeJil4zBThhGiC6fwXvrdWyHXAW9XqdlcxWulvZDMgS7Yk366LVWWvM58CFSz3O2hdMl+HPnaCK4nJyxenckyoED02EAglMC5mZeq+42aAzbZU0dTkgloGv9Q+BGA1TONPuncnrw5i9O3o/S479/JhEsPfqX6m0zqv8nE+l/J5OJp7xDA7wzxcPczepSxqUwygTIRzUiz/mShosCknQX+tVrt6cHX1MFCD/Zwa09XTVL9Jd0VlxklTWZ7i8FIavjD4Bq8NxP7zjreHfVTqw915Ye4Y52tfmSC18FH0XeGxOXUY8CMYdsMSXm4GRJurJBHYFBGZGqHyhAwZeRTCceQ0ZQ1Wja9V83Pl53p9yp3IpIwVXhQA70pYqbJE503V61LsyJS41RhNFLko2duZVoGviQs4QfqOXpfnmDV2lsNRH7mEO1dYENrZh/3FwNNPaaABw/Sgbv3UMH2eV/Evp6Zn7y41XFyUuSxx68m89M2k+Keb1YSUX4RU6P/vv6jmAEZ4z24utCoQ7YNraAbyP76dLaod1e4o2h0M+2IIXM7PDnC2AQ790i2p7Ch7Yfrm48He24XBxJ4sNSZq+RjPeHwjl2bbvOJBQLFkCn0Ht9rljxzMoZbf/EexhooPf6GmZ3r/oWmsFgcVgCbv04jnVS1QcE4lTYzuGSouAtBDl/lgSsp9j2Vg383v6J6w2+RwiSygG1D902BZjbam67umZXcddDggTMSmb3cFjC0XZCblPZL5VBGVoJ+r/xqKoPcSSfnKMlv/a1zc3js8AVSuCTRaryBoGSOSTbqeT5v6XkQXVfmr71oOcNT2nnlUSXPgonbVGqzYT+t9koInDOY5oo5dc+U20VDtMyFYXmWlADG+dNQGjfZOt9nImAYl58x9Di8W0mlQKXxJU05l/vokcI7A/7vMLE0tclOIQWPqcpHfQy3T9+URmvOHo209Ha8hAsWY7eBaqVEeuGdVLiQdz+KW9uGrA1snDUvtzcbIq2bakGIL98KsWZMtad5orPnptGPIhVleXiJ36sv7jYvJT2uUE7oMN66CPOIfnkcsDrHXpaef+HBQvR5Y1nsCxniS6b6AJHnwgzK0SSt7cJR41FfECrx2C+eNZI8DHJyZbNRHleJTyuL2kTdTMMPApqjLw2wR08/NZTadwS4cAMLOjqebLTNRHRCEmHCV5zxQ2HVMqDUgx1Wj7wB2Qg38dCsj15VyNAV61sY/zNPRTymIMtJclPWs9jD+UIs4ik+xTY+fRYeghYN5E7GEgZs7b1Fs8x6Gbae0Z30eWfdN787utA/RK3lAWGaJQ4AoHb/f4maLyTQ3YHfztc3yxiR8lacIvjYhEllPteQeQMUF1g9h7pVmMeN1PYmtrbP19D/2PfCCytew3HyJ2ce6eIiuvXL8htOrvP1zst49+5FcJCALzKltZudbu1slikcZck9RLnE+tN0S4g3n2KXrztnO32ja8dEWzz/+eQPKDuoqcSFYeeBfLYYy5smexf4eksJx6orkEfq3AyPJ0FENl/VRehWfOv026+NZzOFI/bU48+GNSXO+XO+i4saFiiDu2s3NgxdNqCrDWY6icccbFN8LMeGPTayiNq0FsMzmZftE5pLrm3lyVVeW7wrqq1Nx879L9Zu05zY2n1ut3K8utBXzrz+mUKQYeJOtyHltfmfqjqajYSFwCPgxJtCChJKk83ehgArYup+iApoppferqHraPrT4YYwP2NKu+V0Z0BkD2rseQHTt3qEx72uo2sbig9qS8iQz1YFgIJGOPIivgjbRXxhD1D0s4lqfClK5QFbIPtUJxUfx4zdMLh7JfWoJFOsz/GCGAgLKIl2x986Wnm/FO9vsFjJTelwqqiM8D0M2KGGV8SRM7yUcRuUeVk9rOpUxLPcZOMQ92Vjrt5H3Axj6nB6djHhQXDszXMB4NL9ygQAqc59a76BvWyD25o9kblWWuPQ54zHcPmpJVabANmLzd4NignCPcbwF3wy3XPCW2jnOLeTLyr2xQbOiNYYybWULC/6xIgFO/yhDutFf0IRap2UaL0txs/P7yaNBIxJ39guGoe7WQCswpPysRpn9/g+xB1vF+HbZrc1jAttrckpUJsX3wG5VqnVMdYpQ963HygWLixe7K646a1aVjXFjJEqKUrsXmEW9bHLQMc+GVRiKSe5a3OZOM1c+C8t72bWtT5OsW6u3Y5+azP51HomYSiQrJ6L5kJW0vFZf5CGCzDnEtDP5TQDQg1T9ByVf04A9iwSM/4yS+NQcUEMc1ZFNAIGrfcnUmWHnsiESeABEB4RguoP7+rl8I0hn2Gs1+YzO+8jw6hxnIzH9BYKR5zmVxVFqjDO9l/pt1UQMd5ylNpqxfhN7re8+jDH+JgZTz4c/q0wJkJzquTx2w2VwpvXR73Vie2ny3VCKx2kHWICYiVOfLv5IFZ+2kAyN7pQ/ybeBGwXCCHxJgNn2HfY6/R+eOxoZxRf0lCPdnb4k6Z6X0D/lhKPReGEbWPx/TfDPzjaH9h0t1JHtVMXhlKnlQ2u9CQ5e6/IJzpeE6YFP3DKAU47NI1pwNqheu+h2FFeUa1t4EHKlYDqLaeW3vGgH91mOlYOVFpFkihdKdHD7qdCzYzOx73qkV9DuIxEyInZvsVfu5AFjUIyFO5mPoyLVaWk6dW0344wz/g7efBcGI51hUFROp41aOkVU0msQ2fmAWC30CgmW0wQ8EbXj7g6t85NrEMhbiYMKEx0JSHCqp3Sn558aeYWttmN15RzL5ZxHfoL6jAXBr/IDCiMRA6aaduiYLWSbxnGIfqv+12btDXN8qEoq58PGy49TwNaxHldgIXSq1EFgQtZDvgTo3gDkLNnuobA3aW1SOWxA7ql4URy6mnbD9HYau5hUEbRTWIICzqeHYWf18ij9asgmIWW0R3UQuYi4inNtoZjfJh75t8MPE3DIApd1Er+cu6d+j26RG6COcNpgjq5mXUSNEvFTrbQppxgGCHkvtayh8c9QTeecIFwbHi8oidyu+rNvmeh1CBCvoH9uYd+BwPhWpnI89YGdO4mBo6N/7ommm5+EPszsl9YmdIs2adE6kaalkF+n+JM2dFoQ85gceiQS6JQLeIcu3EvBHK8vDNzyntTriH3Dh152wbcNOobwN1jas2ee7/gqRefVxcder0trwvGwKTA+s8u3v+18nDAP/P0/gT80+/5G5AD83+7P3+i/VkS/Y2mj/uPCqQ/Af/8Fv4NWAT8Z5/EPxH/FLj/d+H7/0judME49/46gPO7Z/x+io/kf63+BVBLAwQUAAAACACNs3ldUOto46ACAACiBAAATAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRVBPUlRTL0NIQU5HRUxPRy4wMDIubWRdVMtyEzEQvOcrpooLuOI4hFtyMgkULgwJSeDAKWNpvCuslTaS1olz4iP4Qr6EHjkPFwdXeaWZ6Z7u3n1FZ7IWH3tJtGCz6vGjw8Mj+vv7D5mWQyPkY7O3N6aLJFnSWizF5BoX2NOPI8qmlY73aRFLS7lwKpjUp/hLTMmPx3LPXe+FknjhLPRzdoErhULt6Xy2TxwsqlwuLjSUt9UK5ozQ9P3sAPAf3T2g0ToGYu1cs3eWi4sBjKykYwAoLMW1pOwexE6GkHlZAamTwqhmWsgyJqGbIrk8uP71mxuyYmLXY78smSSU5CSfEFsLxBBDkmbwnOrN5hFEUZU17rRPH3WgMv3eAwed/bDwzuA4dS5EqLihEukUEiVnGyDdta6qUtgFXdw71EJWLw2bDXUc3BIzJ1BgIinFRM6Cg1s67KdIl9J7NurIULaYbKtmwEH3wN5vyAXY4n1VBZSJfRK2z+doMk+UjlV7Gc/OKLsm4KaNuYwxiRs8DHWvTJyU9O3gEg6hpdpthyqJkppW2VRQeLNwWGqz9Xet7EEOkI2kE4re0uW7t4eU45BwbiOGfz2/JuzMkC63ZIaUsDGdHsxdWNH0YobBcIFNeYG64CA+0/kVksrIAZJzO1QkhV2FeBcwG2bI+EPQeO549rhHB5CXgQHE1whgL2La/a0IrYDtfP6FVrLJdfAixTtkdJyfRw1ZdgfCYIf0tzFgIeocymCy7rD03OTdqHybUk01li6TkirZ3Mao78MEb6GNy6WamqXnhA66Ovu8m/9lit2TZ9vY8XNCPw2dum6M9IWhiuJet059NK3uqX/xCvz/Gdin0SjEopF5jApMkZewjEbPFU/Q24TohQI/XaZtSlWSGhfkUCNsd3JTNa7S2GgGraz8R6ODvX9QSwMEFAAAAAgAjbN5XXrGLyc3AwAAewUAAEwAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvUkVQT1JUUy9DSEFOR0VMT0cuMDAzLm1kXVTNcts2EL77KXamh9gekVbjW3NSbCXV1HE8sieHZDoRCK6ojUCABUDJyqkP0Sfsk+Rb6seZXER7sbv4fnbxG93yhl3oONJfkmk8vqb///2Puhg2UiNYxbDGB//nkHcdn50V9NYkrqmWyDa7HQVPfeJYpL7rnOBkPH5N559ekw1tZ7JU4iTvyPS15IsRWjGyN+IbQg4/m7ZzTJ9nD2lEsfdZWqaUTcy4NjMOTWYciUfQOQSRSsmuuDUjcsEaVwz9LO9R2uBGZHxNSRoPNH1XowNtTfS4M5Ug8Omaql6c8kPLsE3gACL8LCkrrsWXvxcUIgIgZEVJRv6n55TRb/HllXNtaVcmv0KaNZ3ZMyxp4hyFvELb3q992Hogko04bjihQ2vE4/MNsnGtOCZ1jYb3oWZa/Pnx8enrfPpuOp/e30yvjgYUVZS64dJ+SwvaSl5Rjv2AYxVSPvmU/qDnyYzewy2ac+qCT7hSVfjYscfJKVjS9DmzT1JB9cgNKEeYBBOXYKxNCxt8jgFa17Tscx+ZTG06+IHi+0Br3iWVJugU5IAmHghAGvXireuVFJh2xq4NmL8wHSDDMFfhKA0X6uRgUIDM5xFcAVd8T048ctZv0kuvWgjlyFjLCQMBeA1qI3chas4bMpV2+fkCI46sU6DlAcLBR6pCD3GctJLRK6Eecogvlk6aFXRVVJjBEX69ZecGiUak0xl6LcEU5yjqJIF/F8QPjYyXLN81GGOIewtQ0PX5RYZfvT44WiyjabmISOe4NzwrVJUpDRoTrMaC5N2IfMi/bJ3CpdntT3Jvrl+8Wbydz27fT7/e3M2m909X1olfH2cLN42oNdmuVPJQ6TqhHGNr7I7m17+PSQZsx9eghQFw9rRvdK5wTEKh6qGAbR+jmoGUurfDfKn7Fy/oLi+D5yLZyOzpg6RE77CKHC8vacvVafXpfPE0/fBwN3maPl4th4xCd29xsV/yjF/j0Or4QqhjtejOl8NbZdfQYMg9DCSWEy+dSpsQwr2mMVpLbcDQvIG0CEtNk4fZMEtDLYJHSseXqKab8g4y7sca/nMTD2OiT4/RzcFIQAz8LRumjaTeOJUkLMuzH1BLAwQUAAAACACNs3ldAVVbzjQBAADkAQAATAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRVBPUlRTL0NIQU5HRUxPRy4wMDQubWRVkE1OwzAQhfc9xZNYkpY0QDesKrHpBnXBBRx7mozk2GFsR3THITghJ2GatEgsZ/R+vpk71PUTKHQciIRDB2uCY2cy4efrG03d7Nbb7bp5Xu2dI4dgMk+E/fEA65lCrm6rUeLEjgSOrDeiyxh0SSfPXa+yw+u6jSU4CHkySQ3ehEBSQRuxrWGc44vJeGRKOW1wFJo4lqSQj0ixiCV1Z6OwDqcosHEYtahlz/n8oF0kFCxt0OxwPOdeCe7RNHiLjpZQjCYldXMAp+hnyheECP/vBqGPovIKibtL2Vhaz3ZWV+hjyhqQsvFLABTFlBwHnSzKOL9vJFHEgdwG7z3dvtSRnvwnEoXQ8owzZRhracw3/cCBhzIsZRNJuvSUK/pyinoNTvyZi1A1xxhFaRPJpLKrZ7P6BVBLAwQUAAAACACks3ldcouCcBsBAACuAQAATAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRVBPUlRTL0NIQU5HRUxPRy4wMDUubWQ1kMFOAzEMRO/9ipE4UpaVgBNHikQlxJF7mjitwZsEJ+l2/x5vpd4yznj87Du8B26cE8bxZbMj5TMFRM0TziYimxrH5y24VZKI2r2nWrOiZfQi2YWr42nAjqLr0vD2uUdx/hcpz6DJGhHFNTj1J0vHPSaXgmtZFygJuUoo4tLWVOyVKrKNnpUbraUf8pagVElXtP2uwtrRU+2lZG1WW7/Y0y1twBfNqLmr1Sq1xulYEciL09X011mtK7m24vRiLFRfIXR0foFk7+QhJ1lw6CwBdCnCntuA79tFDJSUksXTpanztsvjzNfw5jiZI8co9jCUjNIPwvVEimLnZZuz7qhGGNu8IgWyQy4UBnxwtSw2Akt2UxFzltvuw+YfUEsDBBQAAAAIAI2zeV3CwqIZqgMAAG8GAABOAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFUE9SVFMvRklOQUxfQVVESVQuMDAyLm1kdVRNkxo3EL3zK7pqD0koxDDE3qrYpzWsY6p2FwrWe8gJITWMjEaaSBrW5JQfkV+YX5JuMWPsQw5TzKD+eP3eU9/AbPxg3BGeMdTGSQszGVIw+oAwxxNa32CAD1IdG3pgMpnCv3//A/scKltt0mAwHK7xZPAVtEz4bjiE6WR6K8pSTEsAOt34Nqh80EYMom2slxo1+GAOuc5kUr6/flncJ2hd8q2qUI9ziWWbmjZxCUd9Qm5HFRjOH4vVCJ6WzyAdGBeTtFbuLILq5+AKg5sbeMFg9oayrFcUdB4MBCz7plQFYgqtSm3gQzhJa/R3qIxLGPqXQzDpDNO3xfQtrO42m/H3pco3RfkGVudUeQe71lhNDCaMKX6LZb5ih7+8LcrbPvwaNqJGyhLB7gD+hCGav1ALgil2uPcBxWw9gybg3ppDlYiSQ8AYDdWQToOJ3pIYGp68RiDWT0bRb+2PmHv8ABi/yrohxpKpCSmnZ4aE8xTKzERoZIyQKsyISRZ1pMifo6zxypAMqjInhErGCuMv3CJ3n05/qNeDYRig8miktmxp/sAz0ihfUCWaZESvUscRvBLdGJmRrApwIT4ksUOChsmJCR0VZfAaLXL6mNqDZUSdxSsfmag/WxOy+9iO+gKTZpLuQOiS701EIf2dGGXjxp8gyhP9faCxCQ0V+N2kT+1unO1FFqU8lwXDr51ZTtlzSjIe9tscyfxn1IVqQ0CXemjfzAq1dGbP1ESiuZajHg5NUptEbXv+7j4s3mXfv9yvFx8X93Oe5O5KYzQHx1iYEhZKLOZ0YZOvCYwiGizKiNC0O2tIr0BSuBSkSpeiq/XyZTG/n1N7OJqLX/Y0iaGhVtKhjbDcQL7IAe5Wi1iQQ5C8m9s1iKoqHh4eC+vJHBfmd3nA+L/115hvV0e+yDlSKWyI1U7aTy3RQ8sHrc7+udRaf366SHB/MjrbgA0yGFzUge2jiXHTeHUUS60/PhYbZThKPMjdFrZN8Oy3WChhSQqROtELXniS1seX6N0WXmUk0kgkZAucjGTCHCXSV9eIwdI14VvvUwXbWhpKZNzbmiCIyBiKnTkIRetDTMWrD1aLvW+dzg7ZvgfDDuXECOtfywkUsJ2MS6GD3KftGJ4rE+lyg78sFTLthRMRsPGBsbDEtGJ5FXdEXTkk83juQAWIIYhtVpRtSLZXGJLZn/Mt792pO7uy2ca86D+TZebL2aaY/DaCckJPCZd9BKR/77i8pK+W7hgeD4eD/wBQSwMEFAAAAAgAjbN5XUpirMVhAgAAxAMAAE4AAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvUkVQT1JUUy9GSU5BTF9BVURJVC4wMDMubWRVU81u2zAMvu8pCOzSBombpsAO7alNvS1olhZuWmA7RZGYhIssCRIdrzvtIfaEe5JRdopuB8MARfH7o97DeHwBeCCDTiNEDD4y/Pn1GybjyYfR+flocvHu3Qge75+qaXkJTcI4aoL1yqCB1XS2/FrMZ4u7YllWX2aL63kxva6W1ez2U1ncls/l/P6hrIqb6+ndg3zFeDw5OT8tflJYwckBI21IxlxMRhuyCCGiQY0p+XhaCGiFrMhJw/MEtIocyWwRkt5hrUA5A0nVQe59mz2kAlbW1oXeKV4BJVDgsIXBIEQffJIZO59YpgS1Jkv8MhgMwXmpNDGi41F/7N2GYo0mo3++f1xCVX4sq3KRpXNsEsugdfR7jEPg1oOlAwI6Ezw5BmVUYIwJWuKdYNde79EMBrDHl7PaG7RnG2S9O1NBaB2UvQL8wegS9Zx6TSJT/8tU5m981FgLTWBMnDp2mW9LkdwWjMckcCJHsCIqA9NiTm4P2dUEPmYC6QqIBS+g5gS8QyCXWFn76g17qXyXU2mixHnwI3L+J9A5GcekbK8DNo3TTN51XBaKsw9HK2GJsSan7CuL5BuhP5R4vWm6W+JhF2X0TZ4/hETbnHNEiyoJ5WyEJCGsgiKTc5FlSapDvOyldlZkdzODm+hb2Ux4mkGqJR5olQxhxjp0kTUSTsO+Vkf0vtupA237Uu5f2y4vWGfLDxS96yxXRtSIIbFXGbwl/XIlywMHSo3IVFpjYJXfjyyetoqOG7Twb14cze7Qhh0ZeUZG8f++tD5akwPbqlpO0qv/UnmLQPYLI4KysmsZ6C9QSwMEFAAAAAgAs7N5XWBX/7FzBAAA7g8AAFAAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvUkVQT1JUUy9URVNULVJFU1VMVFMuMDA1LnR4dK1XTW/jNhC961cM0MO2QCLrW5aBHhbYS9AWW2y76NGgJNrmWiZZkkri/fWdoWzH2EaV6qwvYShy5mk+3huF4aK3ZtGJeqGPbqdkGsbp4qvQG9HxxXotpHDrdaiPq7jIkhV8ttz8xYwUcruCD73uRMMcB8kOfAXvnhcHJsWGWxd+sUq+CwAMd72RYHm3CddKc7l2av1khOM/fhVyo+5go0zD1+iyyH6+Wv8UhP/5C+6/yy/4xCSkCTgEbUFIqMIqzm0QfPwlCP58/zs8cmOFkhCnwQ/wR1/TwRU0zDgj2i2HphNcOrCas70FJbsjuJ1R/XYHmhl6pJV1v3FrGZ6ujdpzE6g9xHD/VisA9AIAbW+YQ4zrg11BHuZRnKcV7rujpqwQYkoFBe3qFQ7CWkwj7NAwbJjoLKJQlreELkF04wdedRyHZVZlUTzpeCOeeQvaqEfRcoMV8neP+3cgFZZJgwVjCUGKCGacfBVKFJZJkaeTSFouBevIgWZbrGPvOEPH/34w4ifPsjKb9NPrlrrEOub6IbvkKEdHrzwZCW5a5UUy7er5/QP0lp9qiFJ3r54kRnHPj8BkCwfV8s6vhta038S9QFRvM/LqCyRhVCRRXEy+wEfkCHQvLDC0iMVP8bmUAGuZdvi395Vp2SOC8vWJyAh9iejfYGEk9vmyXKbThX0mP+xrzWrRCXf0NSsMb++g5shuHPgzdjK5PiPyUV9Sv914faQ0syLP02QSNNIfl6zuMAxCYh12tHohJnQhHSHBcJ7BEOAKAd9ydQRsEkdJPA0W3x4VR7ghY5obz1HIzpeG5Y/olDKPAewIGwLqOk+4EUK+2cAY7jyN0umirnsMiJuFknRh5vERTHGe5+V0tfZyL7GrXwoJjUqp3CDIwEwtnGHmiDlutRJyoIeYlOGGq2NYl1VVTOf9MAifJQe1aMEereMHrLovvCFrnor4c4PHwIqv3CMlBfnfF0frc1nG+WxNfeHH885ANMSfhpNv3NjwQQfi7Eps598ca/sqjqvp7F/4kBujDNSq9X0qsdTMQDJDn8ekUrMOjylkHhXR9DRSD5xxEsJWWD9qkA/hdugFpcXTCetIa8wQJw+QBOu22yOIizxZzhhjzvk5U9tAKdSYNWtwiPt2pIrLqzTPujTWM0mSR9M9c7Is0ddWWJK8TY9azS8K+ISxUb17Yex722ukR0T1+dOvQ7eTLr3Z0FhPJWk0g6cwgVjyB349LQ9sg+k2DhQWYce0PoeVBnmPnSTqpsuvTwFFmGVpMWPaQwcNR572/IJtYhv87mnBKVR41+yuXKFE+la/gPOjd+S/DG63MdaIUT5DYZ3pMcUtbAxF7SzhNHKjXLJjp9iVqwecSxolnVFYtJdK9tFPSMe+i7GR11mWaRFP8wpywTChXIYqgbzg+ZV1KAoHfPTwAXewnsUWueH0/UMyd8vdcZ1bliPRj0NsBcQ8fIL6pe3xA9lChEvN7GmTuMFvnYoDvdN/di+0Pq2dapVfXLmHKglxei3zOPgHUEsDBBQAAAAIAI2zeV3Gx5/tlQEAAHgCAABPAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFUE9SVFMvVkFMSURBVElPTi4wMDMuanNvbn1Ry27bMBC8+ysInROUol5WeipqFzDaxkGRBkgvBB9LmzBNqiRl1w3y7yElH3ppjju7Ozuz87JAqACpo3a2uEMFxlVxkzHJImSAYNLeluUtueLBjV5MnXEwjkmQ6KAjwpjM/eES985SPmojwdPR6hghxLTwktp5gIUAMtUE38yIYtpMCE7168RinQTKvZY7eI+iXP6fwsCOiQv1YIAFoMIdBxY110bHS5bPXdyjJ4ICOw4G0K/NQ0An8FrpZOmsk4sxoqOTCRAsvyfMBsXoPdhI926SVNxvH9HT+sfmy2a9Qh9QLn8+rD49rlfzPBs0FcyYkIe/bz9/Rdv7b88fkXVoYFoiC/Hs/AF5+D0ml9cr3LtzSP9jQsAQmZ1f/u+tOwT2pL2zx6QGcePEIQm37KR3k9yZRxl3TjSCWalzpPSvHmjYM9K0mbABULgqq46RZQu8qXnXkbpkHNcSeN32jZJi2eGmrxrSVEq2veoV6Za4JqqU/TVz7046p529RncAGyj8GVwKKZXpuI9TlOmiYibA4nXxBlBLAwQUAAAACACzs3ldKeSXCH4BAAB8AgAATwAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRVBPUlRTL1ZBTElEQVRJT04uMDA1Lmpzb25lkU9v2zAMxe/5FITPTuG46w7tqUDXoRiGBuifS1EEqkUnxBRKkyh3wbDvXkpJCrS7GCZpvvfj898ZQIOWhDw359B03VnTll7YycbzSjBJWgWTElqdn/Z1yN7i51G/H42GXK27Wr6YRKkIP2KkkdDCwQy67ksLOThvrHa77hSMSx6mw3d7CjZCE64ijhiRh4Np0TODZONgMEFyLLJ/JGrPxxYKkaSjUgTDFl4p4gWU7blnt4NfuGuBPWx8EiBOYpwzNYT99dHbPJR6hRPZYl1Mf+rdDq6rzw4WJ/1JDw831eBhCfe3cHV5/62Fvuu/zheLeX/I0tGWpKoX9CdtafN2HB0xwt3Vj8qVKg/jq94UJZJdIyi+s//j6fYyvzhKG70OOXrntshSOYgtBtRHqYPeMWlKEX9nDcAet78jazgDJIwTDQgmi5/nYI1gFVE/tsRruFzeQMC4pZQKPWT+8H9U6jqX/N8zCe9cQlt9EguuY0VXt2D0FRvdfJ79m70BUEsDBBQAAAAIAI2zeV3OODCzCwUAAEEKAABLAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFUE9SVFMvVkFMSURBVElPTi5qc29ujVbbbts4EH3vVwz81KJ2KsmWZG+fAtttjU2dIHHysBcQFDmyudFtScmtW/TfO9TNSja7WCABAnE4PDNz5px8fwUw4kJgUfJM4OgX+E5f6Bt+5WmRIDOoj0ogE7woK42SqcyUPElQU+zo5vLubjR+euMLRv8jujuwIayiV1iJOlUZTygy5onBNjDjpToi41WZs6qQvEQWK0wkxZvSZt1e7+D2fguvNf5dKY0GCp3LSpQqz2DXJgWeSeAFnRxRglH7TGV7EAeeZZi86UAVXDzyPTJZFYkS9qkWJtP4F9YZn9dRVBGFdsh4oVpIbHW9vP+83u7Wqy5UI0+YqLTGrGSH3JTMpPkjDmroIs3T3ie5oJu6ykqVYgcA/qg8x51BlVFrDrlW36iwBibK9/BxvRuDoCdLHMORJ4rwEfwxhVBFuoQCtVGmRJr6GCQmaAPjuleYFuWpxyIfWXGiF2hMmao77gbv3ABqEK9dH6JKJRI1dRPFo4G34MI2lwgtfKirHIOdF0H0HC+YuO7Ec/u2n+vklIcdUav49LzRXVCNntE4GQ3zax82hgVwQ0G2SgMqE0kl7YxLejyDfn5jWN7er15sQ/eSJTAdljTWBlEPhc5/2KBRxA0ylKpjhOO49e1RN94zBZtJn4kBD+vbzYfNetUNkB+5SniUIGEqcqPKXJ/A5JWm1ikDed3b26nr0DwJsVZyj5eFAufCnUjN47J5WeIRk5zKYRGx2DL5KUCvCUtUqsqaCoa+/95UvM0hoSUDu4fnlWm5DwN5aDu0OygtJwWhOYGwo+5Xz/AY6aPGo8IvEGGc6zMREl5l4tAluc6SEzx4QO1+R7+TLoqupLw0wOmmzEWVUj9R2t7/WVdAVN9bfIxrcbDSYA7c8wNbpRcLZxZPceH47mIq5r7vxMFsFgkM5TRwp9OF6zp+6E/pJ4gdHrhz35tHvi9lEGMYj54+cF4bJhKuUtux0SdiC0XQRgJNHTqlm9gxQxNG5ZdcZUT2WOcpdPmgWdT3kOUlhUxooYEkqqXMULVsrosGTKHVkYvTUJhJKOvyC0U6myQWldOpkY0mHWrUpeYQkwRYq6iyTXwqrVYNld24RzyZ/4ir5dkuSm7f7ej14o1+Q9pqbMeWihhxpbJHeL28qP9405OsKVKT/NiNilWC5h8eNKn1b0JdQ3PxTRU251T4zpw74SIUwvG80J9xjF0ZulPX8zAMPBHOBcpwMXOmYuZGDs4w5KGYymDhR1I8M62JVVbdJXdmKARfYBR6s9hHB4NQRnO67UXzQIpw4QoRylhgEPGFI51wJiN36rtiES78wJFnnWj2gFlvqPnZa9+oPzaWXrSetZ8Niu+3uKE3S3mm4tbybtbb1Wb7ET5stpdXraAsL3eb695BWte0RkcW27hTJ0C79d3AlTLaX9YaTmM0vSsN5ZdAksJYAT4798CxX0g8MI2+toF1/IvXtSN4IcLK8vD03OTGGFkrQlYvBn20/lU7VH2xxgTTi8VboCoyybUk6Ys016dnRlMXZbXN896Ss0C7LBIiq3lpQQ22mt0T+TmcgbwS8oG3dEJ3VjSDpAG0JMz+P7KvX/5tcwMpqQjNjXeiWmiME7U/WKlAIjfJ7fJ2Sd5t4ZD4WiY1vHoydlb/i2IOtMMDF7q5vX7YrMiFNlvYfdrcwd3q1+Yy2eIeST3IzlPedHu7vrpjN1f3Hzdb9vlyu/lAg2YP3ujVj1c/AVBLAwQUAAAACACNs3ldDxEP9PkAAACAAQAAWAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URU1QTEFURVMvZmxvd2VyLWNoYXQvY2FydHJpZGdlLmpzb25Vj01Lw0AQQO/9FUPOJlaP3kJJJdCGQNSLSJhsxuzCfoTdiWkR/7vZpkK9vvd2Z+Z7A5AEIclg8gRJnVfFoWnrw+tzWbXHvCr3RfPSvj0mdzFUfYxGiZadYe+sOqXCGYO2XwOLhi7/3Cawu02+yAflbKy22UO2XWlPQXg18tVURZMGPmuCoOygKV0skQXhbHyPsYNZsYSjCgH22s3kgaV30yBBusDpMhEH6iEvIa/LsI7xk2W1rjhTtzKy7M9Xcq9sT6dMstF/EjtN8Wz2E10QTuwaRs8L/EQdVto5xzuvWAnU/4TAETulF0NhEe+J1iYTEjn52PxsfgFQSwMEFAAAAAgAjbN5XRdnUzPtBAAAFwsAAFQAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL2Zsb3dlci1jaGF0L3dlYi9hcHAuanN9Vl1u4zYQft9TTIDFUmod7m6LvthIC/+oibFeO3WcFosgCGiJtonIlEtSdtysgZ6iR+gV2qc+9Ch7kg5JSZYTN36wpSH5zcw33wwdBCGcfQ+PrwBIrjloo0RsSAvf40xqA6/hDIIHtynJ4nzJpaFzbqKU28fOtp/g6n57ms3xwOuA4AMJG4jHTK69yT87K5dJYcMnaxFylRtvQli1JTXMZZbwFNceYaWytUi4agJ5YII0YJrrbRNmLNW8ASZXUjfh5hZ29vAsl7ERmSximPAHE5gGcKUyhWjuUIigfpkaXO9m0qB7XDWt0h6nTOshW3K0+rM/AMlkKiSHKUsINMtX0oJd3a+1BfdCJhgagoeO5TKpRKwRsKI0VpwZXrAaEFz1DIDdeBADcZ4JfA0WGn/IqXdeA98sshfA9YrJEh13HqKjAfOw5kNCnLOzszMnE0UsCZ9G1/Dlj78tA/tVRwkudumgP/xQrpMfB6NforF73afFVissf4DOGk+DtdUaYt0Dx1zYssIq9+PRwqBjlaXpJFthgPv3Cy7mC2Pd7CoNlcrp5MZgaZzQSpvn4nAHZUkSrTGegdDIAFcBiVMR36Pm9h0DIGYQOHlSq8QQFLci9Bl6ewmLLp8aLF1Wxk5QmJl9LJTtEZ6EdFiQl9DOxyNL/T8Ob3QZDdt991oPzHUL4tzctrxSXekaQC5LyHjB5JwnLWAg+cYSueZKM6ftKZ8Lqamnbue+qwo+p+6eb5NsIy153LPnmOMUF3zkkY7ZihPbj24U0DVLcydIVKO3TNNcBVj4XeEPK4gRGhIecajz6VIY9Mf0VsaVV5c+R9K43d7jM5anxmK+VEcvIEs+hlMLjuKoXJaHT3yH1889z8PT7PqnGAkt2Hu1U0flvOWmI02EZtOUJ6XVQdYmGZmM28Orj/3JpD88//L7n2VDF2MYW0jbeG8opbV6N5BfbBHehDKM2Auq6RPc3VKNMufB6fvvCsC3b6GjRDLnsMgQ8p7zlcbvrQaGPe+wNYXrvgtbA47CLWCjoogweAe6wLJkauv2V3oVCXXwOOuLupSxK/5rjsH3bepklmYbrk7tuOthTlRmG+w/O/Ss6SMzC4pbMhW4R4UuMqwJfAXv39lPkcMeWmPBEZdtmDDQHQh575OjVkrBYU81Chob+5AqPFfzAu7zZzDbFc9mBb5rVDixsrbXqcSLEMxCZRvXRpG9QwJyMbqa3HXavbtxdDn4RCrgJ82J5SuDqCqH0xoZZdLUy1d3faSKUIjP80ka9f1h60BY3dFwGHUnUQ/+/cvdM1cuiaA4UbITUpNd40BWXaZ5EBZ+dhAzEy+w45QKq8LW50uBhuvw5o29UemSa81QX8ijPVXE/q4B32ABq/jrIXbG/d55BNF4PBrbVsIGqfzPhGQpavDxsLXcdf+8twqz79UZTjDtRkw11Pz8qP+VUCZfBWVqB7xdRN0P2IxgS1vryCMKP6rAklgbwYHKLDEnbaXYlgrtfgO13x265ZqBChmnecJ14O6D8Ij47P1wNxxN7to/t/uDdmcQkaM820ygIHsctXuVTo+X+f+P/nTdH0e9w1IdysL+YUAuYJkjQQu25hg1h/W3+4kx9VMIrx2DBcbq2XnCcrPIlPiNJxSGGbQv+8VsUhywL7jCfUIiltAYsjKe6iqN4j9CVdbWq11ov/8DUEsDBBQAAAAIAI2zeV2HuTPHDAMAADEGAABXAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9mbG93ZXItY2hhdC93ZWIvYnJpZGdlLmpzfVTvT9swEP3OX3FIk+JAFsrQvoA6qUA1qrWUlbKvxU2uxSONM9tpx0r/951/pHQw0Q9VbN+99+7d2UcHcPvAFeaQFQJLAzOpIOPKKJHPEVY4BYVljgpVCte4RAU8y7AyGijwgZd5gRoqJZeCgkBjptDodA8ArqQ2sKjpj7LE7Almii8QKK40wjwB07JWGUK73QZRasOLwsrYcrvwGIiCNis+FQVlOeTOTQ9WQqEVu+AG8LchjRrMA4KcalRLAhqdHLfgIu2L8hEqkjJArTnBKvxVozZHCnUlS40wVfKRqts7ONpjs7rMjJAlMCWliWFNdFFNQZpEZSY6o3WBhupUghfQhpbdyQjHQEUaRDmnzRJXMOAVi3cOyWNytw0WN/Ure+qWPM+7S9roC02FoGLRwouNEnhRhF4OgJjRIg3u7ZN7Afz5GfYxzbnh9tN/pdRWMsBGHe/smqfKp0ZkQxSTKaZW5ZmD94J1Ia3cUFQ6R8NCrsjjs62OfRv3Kr9ArsZigbI2zB6nxi9CWgOZIzmJ/0UNe/LRDYdRNdXukEitLJbbJFrWRYOLhe2Tj/qJmWG2DV2lpGK31L1y3mSh3bNmRFfD2/HkfNS7/NqddEej4SiKU12IDFkrgU+tVhw77I3733Yio0llskqAq7lOIFQ30GTX5xb9dvvU9L3tO984BTdKLoTGt1Kji37v+tvEKRt1v9/1Rt3LKI53WyNyYrrPph8/rC+5wbSUKxZvaHV46Odyc+/DA5cFD3yMBQcT8MwxtL8EuQ18qIc4NJqmj8wHvm6e7Rq8rWHX13Fv0B3ejSfD0eTuuvOj0+t3zvtdWxJsdswLFb6MB5ETfEKcIcZK/kd76ItLcjanO/ecrcGN/ikcEwuN+6md9V90oyxo0z0rITqIAo7H2zTX8sK+Hef+MWrDcGo505lC/EPofpTDu6dPwRvkRiOaupx0e0qkayI6oemIE9/IB24op4lIIFx4nTTvUy9/C2izLBa8m0dlBBJeZlgQzXuQLsaB7gAkbpAdjPVkE7OVKHO5ou+/UEsDBBQAAAAIAI2zeV0HHUuSRgMAAEgGAABYAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9mbG93ZXItY2hhdC93ZWIvaW5kZXguaHRtbHVVPZPjRBDN91c0k5Bgy1tFQCBNlUv23qlubS2yuSMdS21ruJFGjEb2OruIlIQ6EmL+AR8RVPFT/Evo0YexYIls9/RMv/f6ddv/JNOpPVcIuS0Uv/PdByhRHgKGJeN+jiLjfoFWQJoLU6MNWGP3ky9YHy1FgQE7SjxV2lgGqS4tlpR1kpnNgwyPMsVJ++MzWUorhZrUqVAY3DOqZ6VVyJ9yUVpdWKNL+QyhLgpRZnD58AOsZF3Dg9InNL7XJftKlu/BoApYbc8K6xyRCucG931kmtY14fNa8Hf+TmdnQitkCakSdU1ZOSrVs0MzRHeGqlK0rsQ1UxIfBsJIMclllmEZMGsaZPzy05++5zK5n8njkO4elOWBjYJWVwSZ7jy9nq+38WqbxOvoa/jrNwinj9H6je9RMoG552G8Ws3XC0J+z/voLZgjmloSHv52Nr0fqnsdCeJZY2rp+EoyNYgDeCV2TrAbOalTncwWTSFLocagu9sTwt4rwkNCv14+wuxa+habLluOIDPXBGEb6kAY04VwG61fXT78fMXraN3dltq3eMblnZmMkPZF7Ts8Nx3opPrPkxNnTpfujHXgq2izgYfH+N0yoYtdzK8LodQgPIRxnCyi9Xwbu5T26IU+VPIZ1UTJQ26dzf6PF1nHdUy4pnTCKH0Y+iGP6FgqaUk0o2ke2tMRC6co9FQ6B41gnHLNeMcHLh9/74G8Q0WdRbB6GKQpbMnuQLFTLuynNZBHzroxQG3Ppj2/Hv5em6KFStPuyLW+uXrCMKAEtxqsOTO+wroWB3Sx8aC2t8ZgU2FoSvnl46+DYLKsGtvW6p4D0VhN0CuFltTQ+z2DQjwrLA+0SNjns9mMQaVEirlW5PiAbYV673je1CajkZz4bSMN0uLaNdYS29aUSMMNbtfR92ZXkLf4Zkk9v3z3i+91iSSDE4B08Pph4qSIpgkZPPfj9/3Qwut4s4X5UwTJ8suvomS5eGkqCp25uU/it9GCunSLpzL6KInGgKk7Go/r5iRtmsM8gms2f5XEb6jdf9xg/qcuX25CCCB8XM4TWCTzh+3VngMPzy1Cty1SIysLtUnd5pPZAafftFuzO+CjBFFV/zr1uq3qdf8bfwNQSwMEFAAAAAgAjbN5XbUcDJBcBQAARw4AAFcAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL2Zsb3dlci1jaGF0L3dlYi9zdHlsZS5jc3OVVtuOqzYUfe9XIEXVmVQh4hqIeanU9/5A1QeDTXAPYGScSVLEv3dvA4lJZs70KJoR2Nj7ttbamygp9eC6+YlsvNhLfC9z3Y62vCYb3/PTIIH3XCrGFdkk9FjkMSycFOctvJflkeK75ldNNpxxzvF7JhqyoWke5hw/ljUjm7JkacLgtaEn3moKKzn1WQgrijM8nEZpMf425PLq9uJf0Z7IZBfMX8dKN/Uul+w2NFSdREu8rOLiVGnie96vWU6L7yclzy0j71S9YTzbrJC1VPM7erjNStlqt6SNqG/kLNxGtrLvaMF33/6QZyW4cv7kl2+7+/poLHaUMXTHD7prxkTf1fRGTkqwDJ4K7grNm54UEBVX476veF0PF8F0RRrRvh1jr7vu0Mvt4jIuH464XNC6eIO998pxnSDqrtttBrvu/GEUwEfZ3X7SXZ0AnbDC3fiJnwRpNtfoAJ/0shbM2YRFHCV5Js+6Fi0n0WPHS7zcj+6hlDW/ZvgPCqd4oYVsCeTu3LTZiXZT2KYqFWXyQkTbc+145hfCpYgTHno7a8U7eqnHRmefK9qyYWWI1uLUrnI2WQHP7dDT2IocfYf9cS8K2Q6migARTg5gLcPollP+qugz1LYZVn9xH+/CP8/ZJGF4PPjjvuIUzQzoH4F3LTu81DLk+2iIa/DWRWSgU2jbtoY4346Vbx2LgtdjCca5YNh2DDMXTo6FUeQf0nH/zlUvVhGbYthWgWtbAF2BjJwDsNPoLcCI7+WfCWKWt6/MMeTfPkAXWqD/CineF0gB4BV+tLjrQp7X2Pjn3GtR3lyosobKEUNCN+f6Ap+/Jjt7ystTpgNEjGxNKVdn0fh22drnlK22QY5gs6zlhathzl5g0YrGeRKuKRj4PDhmX8F8SWkKl/kAwSln0Rr3xxS97qTSigq92A8f9lmQJ0Vp28coqIKwAMVg6c2PPMZPO4A3CADbbYIwSCL/rj4JVnTSpyT8WtHmtIOAFwVnVspR157IZ9XeQjOoAfPpklK3pQ0f/ieiYkyGdc7ptZLA1B9BIQg/gcLqnoaCSs+hQaviRZ79mO6+qYu48tqtMdy5Ebk1LzWhZy3nnBokLhl5Emsbf3ayLIoEaXQMD+MeKIDsp5iRwcKHybqELYzGvU2WgU+yrnMAweRDK1uezWKwoA6bx/EnuBxhvLYXhLgXnn8XkKPF3L2MaHDcP4tm/AyQfRxnlwrQZbLKSae4e1G0ewSEb4S2t0vFFdx4qeRntb7MfPG8WU5dZRZMnzj3UDk07bxeMbMfaO++SIPhfilVMxMPJeqJ/GkSfMl0k0D/0cDMNaiOkFGquP7IIdF2Z20r+FTKu4B7905uqvs63Fg4A+1oIcMKvDHJAiWGfAr9UHUPqZmtazW5QIjRgAoyDfo3MyRNjsGRjflZa4DjvAiylwaHH+B79ntl1IDC+JR4noPdxVlNYvenrDirHsx0UpjBarJNSlmce/dd9CKv+W7yeLU2LGkKnjrehJ1515VlCc3JCMN0819QVArn2d+DRMrrG9nHixMX0GLAhQRHbIB7HzTjD3Qj+4km9wmasCtM9p19IxkfbBq1Emkzbjol3wVW7ZnzdrMK8pABDX/YTI3W9XCP7IWhPs0hk2fNF42zJM4a0xYmEte3RIpUgjFs37XoCCrNG8yK+Ntmr0HcUTP+3nAm6FtDrzMT4gTSvR3mAdtqposrq2Ea9Ws1S4eJ4d80kVrrh/SDwTJEFVmNcqE5/ToZHj/pFPNEZlXiPlPYxu0pN55HgvUEsOh+dO/a5tHyLP2kST6x+4P+twrjVb/DB+ggtpbUtNduUYmarYV//OU/UEsDBBQAAAAIAI2zeV1I9CAE9wAAAHkBAABcAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9zZXJ2aWNlLXN0YXJ0ZXIvY2FydHJpZGdlLmpzb25VkMFOwzAMhu97CqtnWgbHcZqmgSaValKBC0KVm5oRliaV45ZViHcnaYfQrv/32f6T7wVA4tUHtZisINmvi21eVvv8+WFXVI/rYne/LZ+ql9vkKoq6iRKdsO0MpcYpNKl1Qn7GFluKwiaDXNsj5FGA4l8YiL12Njo32TJbzmlDXrHu5EymqdRZM8K0G2pUR2qgHqFjPaAQdMSpQhbWzYHAi2M80F3QgU5CbMNVTzxoRT6bb3BvRc/tvqhOz3RmZIXHSM7pdYvaZu2n/8NYG4ovF+5pirAXV0ooEMJ3NH5Oa+dkw1p06H8BFHZYaxNI+IgVvL4tfha/UEsDBBQAAAAIAI2zeV3OY6FbXAkAAFEWAABeAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9zZXJ2aWNlLXN0YXJ0ZXIvc2VydmljZS9tYWluLm1qc61YaXPbOBL97l8BV6WGZIai5GMzWWnolGwrGe06kteS5yjHq1AkZCGmAAUAfays/77dAC/JSXaOnalyRKLReH29brD58iU5YfqRnDF+S9yTwPzwyJjKBeNRSu7ptKGovGMxJUpHUlPpk4FIaPBJkf39733CBeHLBVlG8W10Q1WwQ16S8ZySuVDaUWTGHmhCKL9jUvAF5bpxF0kWTVNKeLSgikSSkqUUWsQiJSwBCTZjVCrUrHElyWJNpjLiCeM3uXqmDAhcjqlSBJ61zJSGo2J8LzPOQZpE8B6wxJmUoJgMRyQDazpGdUQU6JyKB9TZ3GGLpZCazACyFAvicNDTnqkmHLFgiiqnU4gsIz2vC+FztTrXellfxedqdUXQELG4vOyf+kQz8PLNKJrR3ucMvL2ub4zl41IL2LoTC6400eKWchIWNgfg0+Bfl/3BZNS7+Ll/0puMh//sDcjTE3Fgk92TRDo6ZfJbu0674+7mJkk/ZxR9eY6IQzLIFlMq3a9qOB9ejI2GluOBoTPiGqhBSvkNeOpHcrCPy7vop4Cp7lSJNNPUzcF5uLh55m4YkpZHVjukxK10QqUM7iWDnU5x9Mlw8Lb/bvK+Pxr1B+8+cARQ7aEPTLv78GqdW3Z6PHnbP+uhOxDLJ8F4gcJHr2vI309KGDV2xy+948nFcDgutkgK4O+oax4SJjGHXU7vyeXFmWtjHCyojoJMpl6AUijhgXaopErt++6vk+Ph6W+gdu/V5OD1YX1hMBz3RrCy32p1dqL7iGFWBotbOK5Cu5IUslqxO9qGzKc+WWDOtMQPrdbaq22L57BQbTMCsJ5SjfWsKZyzMoa3r67XnR0tH43bLZplJBWUVEj+MRoOAvPklpoljZK3LKVu7lXfyfTsteOZEGAW7ObbMfZdKaNHDD7+69qFwJxrwl9/UeTNUeUMD6pYinuCju5JKaTrnAwvLi7Px5Oz4Un3bDIad8c9G/zCKqsSYk/iSMdz4kL62JRCbPDwJjBUgbnm9AbD3mDs2PWvJV3tqEl/8HP3rH9aZNxWzh14HdJskrcRS0mcCsQB2O+oJAL+GHUk4+hAJMJmLKTMlrZagYzIGhJ2lvFYM8FJlOm5kOw/NHGjWANLeLUARWDocTabURkgc7gjLYFQcsGnJ8fxiqj4ZLola4q0WEYjJNWZhAOLAITgmWnx8N1322zlRv7U1FYJFUvHhQrxDQn7xp462qlIHrdAmMRSBjWbPZo89XIwyvr9J/CSa/WtnBPBNfaQ8eOSOm0nWi5TBuGFw5t4eIfEcwy7DsGqxmvHLzecGSucNkLITfJN3JyTKJ7TBspJkYJOLhpKC0lh86+N+nmN4RIPUkZGcTabOVBpiJPyxEXFm97Q9EFvewMoHzSFDq41l2nEnkG2/vo91qMm//8F3zge4UfqkcekNEJFQHb1GOrF8sv0+TF4sap6m+utAxD9aGJZkAohJXkY4wx7gJRPttLA1DCk7GqWRjdt5/7B8XN6e2XpbUMXtHZkYaMo5yIjAt0UZ5gUDq9kF0ZuNRMytsy59gJDEK7rhUcrUL5+7gWs1GMIMITzc90Z8Tzjtyq8uu4gn/KwhceCaovNrQkRMSN2M+Hfh+ZVnoYdNnP5UdEQPEt0OcnhG2jrw8lZ9+Id8ps9MFhmau6a3wg3d3DV8cMaXefFBotgpd2jvECLnClKzgYUu7j36WmTqk1iPD1hsoEJ+ASE6YjpJxprZwMtJpMhEBQysCzxrjZMyolzghCdLzo7UlANpnCK9ulDR52LpO55fJ3nIf4EqnKaDnlDHMYT+hDM9SJ1SLtcDxTwBHX3qt50VZf0kUmg88MPpR9TGsRKOdcB43GaJVS5pod7BUGWhX3YOvSdAYySM5HxxJKohTeDzK5BtKVSzBK+UVcJL5gRNDihFtUvTM9dxyLz3liuwIdtqmhv70DUxQb4/UzernyK7iIVS7bU2wIVpNgShwJYz/t9YdwXeBpGludEhfZ9k6i2Sbo4fZOo/wid2YTBrPip1z113kB4KJABTUrdhuygR48o3EZSbK/E9mWxpNJ0FNVGNxRXh3xAVZDUHG8PCp2ggVuqjk7BQiLgviHh3mNHGTNnwcaMhuf2HlFOkACgTHmzf4QncMjSGffyYuYQr9BsD0Atx5WO1YYrW7yVZyeudIqBF69uFMd/vIUEMYQQz8F3rqk6JDRf4hAWHpnqqqjaVElt+ADJYA4xhqvZlfPQ+JwxXtwMG2aUcK6rEikngcPWgb+iWPpt55JX6khxqcz96hSsbnFnkmFF5HM1Hg3ztO+gFe1mc2//h6AF/+8VwxdihS3BBh1ES9Y0USjHOhQ0yqr0eNeDqW8bNGZxPhSbTmTn0gLhF7ScD0fj2in1eSe09bPRQTqlHGjKmdUMJlifSK+2EzpPT7vl6wBeLVxg4uqNrY6jvRZM9M/8vr9f+h0YipJFhoAo2QsC3GAqH8ZEiKazrgEqZkADejMtbcJgspXSxoCaiwpIYTW5/09gKUyVxj9AD8kGlpLrQSxcsaRdHy98dEF72z2+TfGkq9uYPKfw28Vu1x8N84bnrZ8fINIkNFZ0zN+wuBAFQVAzzse/1xvboVry0cLOSZ21LUm8aqysLtDdsQ0QXpquWPxXS7c9m25146vfxZ7npfW30pPvTSrazxppKu5rnlzXyiqhwEdAOGG9WIKFwdz89wcsmQ+2Zj403atW4+9RY9a4Xh28WnsvmmWtuYWar9QVZvBp76yHN7I/CfqPJuI34wiv8/SEzgUZ7z6ERw8BQ5yFJVd71/XE+Atx3SQRox+6TgXBVggc/bxsaiHfiB04dyNe5jtc3vMNy8H89tzPhzXeveXinpPueb90cD4DIf35tkfWxp0qlF9S/LsCuBG+aqKr2+HXjrHjeuXkPLG2Dze39gVcs6Mbw/Fb8/Gbw72D9iH6PQd4YZsL6MFxFboOjOapiKOU4OgBSuAWDtMQS/EanmOHiRT+tY0zSJmCacFt+U7Vc/wi9fJvJGEuGyUJYFTAN/gVyA6a7q79eAbjdB/mjhv8jAYcvvxxr7V/6G18Mzjc+HSldCIynX95+Ljxue0CovWb+egWvlgt1x/4R/u1gT4An5vPrmQORKnm0S1tk0SY+Ng7kjEN7if5zUSxG7yXXDmj/rtx7+I9pAL86g/G0MoLIOB5EDM253aaDxpm6tjA3/Lw4v5fUEsDBBQAAAAIAI2zeV09oZe5CgMAAPsGAABgAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9zZXJ2aWNlLXN0YXJ0ZXIvc2VydmljZS93ZWIvYXBwLmpzfVVRb9MwEH7frzgEkh2Rue+tioS2PoAmQHS8z0sujZljB9vpqEL/O2c7bcdU+pI09nffne/7zmWDR/DBqSqwxdVsBmvZ4bV1aqMMOPw1oA8enB0CQmjpvWnpjXCPrlNGauYhuMEHrMGj26oKoXf2905cVdb4AFrRYwm1rYYOTRBE6HZr1FgF6zh7a2xAz4rFBG+s6y7BK4cy4An/aOvdJXzcP6F9kGHwl/AZESOk35kKmsFUQVkDsle8l6EtwfZxIbKM+wLGK4BM7jCuyWep6BgYqnbCjyCEmIJKaFHW6PwcRnZjTaAaru93PbI5k32vVSUjbvbTW8NKiuNToJji4M+fmHYPeyrxkDmij6mpDBEXeCGIjKrgBSw/AKeoFKIa4G8iyD4VSdFnMPgMK+eoATFQYPwZEz18z/pDI5Umgfm7MQbmHu2Lh8TnMAzOpBoWV/vXbXPYUEjLXzVq0OFYcOwsm9FzdvQCJNsIh72WFd60StcO6URxhxwCPBNFPNhmIhQpPCc6pNLqpdjZPCuN8YszrXKuA7i/gO0J2ouAv8OkGmFjvrT0ksR3UusLRGmfyNL7NSHpcEtgnphzYP0xFCLYO1tJjWuaU7Ph/1TtsLNbvJDxcQiB3FQsJqgI5DfCHzYWh+V/amG3NBQ0aTnVBJF1vdrS/h2pgwZpYCqy7BMrIcuerZYFALoXdjCe1XjG3qOpbI0/vn+6sV1vTaw0nVrVRTl2GFpbz9nt6m51v2Lk9YO3Jzct9lOObHEsxmzKV4dA0aH3coMTfj91TitB04am5n2ZhCj/2zzHijKfvlgkU06BWiWuyHs29cNabmlk0sQczSk0mk1o98k6nLyqo6x6Jx7i6MS770yL/fDYqXDsMW5Tgtzm9CF6l9632EhKRd3JzthKPeAy3oAi/RTkno52VcPfpIUiz248x/+1Yic5vn1d37MyEs4/r79+ET7ZUTU7PsbDzxMpXU7F4pR0ydhZ8S4It3wpW5TsGDndaJiOf7btLA3K8a9oMHJLd5d81DgHMt2JmGj/AlBLAwQUAAAACACNs3ldoPI4K/0BAAAtAwAAZAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URU1QTEFURVMvc2VydmljZS1zdGFydGVyL3NlcnZpY2Uvd2ViL2luZGV4Lmh0bWxVU7GOEzEQ7e8rBjc0ZDfpKHYtoZAiIkqkS0CidOxJ1pzXXuxxcun4Gn6Bnk/hSxjv5k5QWTNvxm/eG7t5Y4Km24DQUe/kQ1MOcMqfW4FelAQqw0ePpEB3KiakVmQ6zd4LOWW96rEVF4vXIUQSoIMn9Fx1tYa61uDFapyNwTvrLVnlZkkrh+2iEJAlh3JZwcb6J9gERmAbCFNTT1DjChDRtSLRzWHqEJmmi3i6ZyqdEk+TdLQDQYq6FWoYqm9JgMETRtnUE8Z09V3QMZhb0aWs52MA7VRKLPqGxxiuQi7Xh6+wWW8/we9fcHj8vD+sPsJmt/ywgf3q8ct6uWrqQTbdQv43Msd8mxwjGDAmmwiUjiElSBiLFSwlkYqUwHqgzibQHEVrzviWe6K9KEIwiq01NqKmEG9VIXtoTiH2YE0rdEQuYs1OHdEB51tRFAm5xSt4Zm/qEZIN4TOzoRr7xhro1bNDf+bliMV8Phc80ffMVIaNeimXzTETBZ6QXwf7nI+9JSH36oL3+yecW8pUo4eFgaVRZuNjcPgayd2A3vozuNGrxJLwz4+fo4PZjX3lTm5T0arZOHkrCpeBCWCa7P5d1Ml61r8NHIds2GIdsqeK9wCsAKNnHo90DfGJ/XUuVbB/8T/7BNkbjHALOcJu/9o+2VzfX0V9fyT19Dn+AlBLAwQUAAAACACNs3ldYjHjfQACAADDAwAAYwAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URU1QTEFURVMvc2VydmljZS1zdGFydGVyL3NlcnZpY2Uvd2ViL3N0eWxlLmNzc4WS3Y6bMBCF7/MUqaJK7apEGJKQmJu+in+GMIqxkW0WKPK71xC6yW5X2kuG8ZxzvhlqjfGTMMrYxIkaGqCS2VtZGe0pObXD1o3OQ5N0+Msx7RIHFquSM3G7WtNpSXckJUcC5TKD7gCqvKrC5mXiZkgc/kF9pdxYCTaJlcCNHKeG2StqmpYtk3JuIOd2CA1DHX8NSY/S17Q4pu1Qrq2s8+a9qswu+fltQHaMvauMZRI7R0n2VqJkDmIUyu3ucDiR4hI2exiBW9NPc9TZKNB9cbTQlAq8j2Ncy8Q8ek/yWFzjXaQsAEJN1gyJNy1Ng2Ic1CTRtYqNlCsjbv+ck0PUTrcR5QI16QGvtY9IlAwbD4NnFth0j0zS9HvZxKn1vYmQGcFz7BSIyM6rm75GD59EPAuei+MDbvYfmyJWLCyhX8F6FEzdV466jgv2YcM7742enrXztBCX/EvtCEi8ace9bmcCn+iLzro4qDWoI+538uUT3PkyVje0MqJzySs65Aom03mFGmj+UOccWAVB4aTQxa36UQHVRsMDxuFxVDPdbfrhmLM0gw9uo4XSRE6VMn3SW9ZSpsc+OoWwUbhtpwXGcjBAWwtLT9hX0dzzdZ2X61oPiRfiJI/hdwMS2Y/4qALrEguyEyCTxniMee+fP6eXiWls2FKb03zDpjXWM+1D2PwFUEsDBBQAAAAIAI2zeV2zCQs/5AAAAF0BAABYAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy93ZWItc3RhcnRlci9jYXJ0cmlkZ2UuanNvblWPQUsDMRBG7/srhj3X2Hr0VkqVwroWtnoRWSbZWRqaTZZkVlvE/27SrIjX9z4eM18FQBnUkQYs76Hcr+tt1bT76uVxV7dP63r3sG0O7etduUhD3aURnXEYDd2wHshnYXGgpDYCKm1P0FAI2lk4/E0+yCeUViuxFMtMOwrK65Fn89z3RluCaxrQdmCcQgNh7jEacxFQO5CoThS98zCmcmCyikSu+smmQip+ksyMLPvLTG617egsjjyYX4nSUPqO/URXhBO7htFzhD2akKl0jjdes45X/RMKR5TaREMhirf34rv4AVBLAwQUAAAACACNs3ldl/wJqi4CAABIBQAAVAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URU1QTEFURVMvd2ViLXN0YXJ0ZXIvd2ViL2FwcC5qc41UTW/bMAy951ew2Abbnes4HbZDvQwo1h0CbF3RZPcKEpMYdSRPkpsURf77KPkrSdNgN4vie3x8pBxUBsFYnXMbZIPhEKaW2ZwDZ5qCYoGAG7YqC7wCqaBEbXJjUXKMQaJdK/0Yw60SCNd3EwNKw1IZC6XGQjGRDLiSdLz5c389m/y+hTF8hnP4kmaDAi0YpGthKNom1HFdSZnLBcXnrDBYB7lyKiwKCjf4ghk7y/ljHalL2XyFdBaKVyuUNvlboX6eYoHcKh0G79x9ELXZhpqtzKn8OqNHcFVJewrQ6XSYeSW5zZUEjVKgDiN4GYDXmFjc2O9KkpeO7uH9y5T8lovwF7PLZF4oImv9GZJjUZSUTNBwtA0vYwjSINpedaA284PLfJ34kFFVr/ygbAPvNJPkbS+6ZLQcTvPhQPaM3w5OmadtECVMiB9PlPDT7w75EPCC4EEMxD7+5k3pa5w1n050PoewOZKOnbo3zGIi1TqMsmaKB60FM3JZt7RJQDoBkNTv0aRvoe9c78LDtuTKmy1qNPi/LTZ+Zkf2/riIe0dOGtrtybwWik0oRT+xIuzJnVNnnVUabaVlPXa3tuTUvmndDRasNP5V7Wxe6PIvugcW0QqO0jSN2pG0oK8w2q3VN+a5VmwTpnEXvWhreZpuCB/HnYZzX6Ut0rGNaU71y4Gd3wDhRtkJS336cV9b+3q2BPyLASaVXdLarJfoHi0Tz2Q/Mbnl2ZlCDJ+8G33oH1BLAwQUAAAACACNs3ldGB/r19gBAABKAwAAWAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URU1QTEFURVMvd2ViLXN0YXJ0ZXIvd2ViL2luZGV4Lmh0bWxlU8Fu2zAMvfcrOJ0bOz0MGApbwJAVRbCiGNJcdlQkOtYiS4bEJPCX7b4vG2XNbbGeJL1HPuqRUvPJBE3TiNDT4ORNkxdwyh9bgV5kAJWRNwDNgKRA9yompFacqVt9EW+EVwO24mLxOoZIAnTwhJ4Dr9ZQ3xq8WI2r+XBrvSWr3Cpp5bC9KypkyaHcVPBk/QleMCUbPOztgLGpC5nDXGYjulYkmhymHpGr9RG7Bal0SkUy6WhHghR1K9Q4Vr+SAIMdRtnUhWN/dTHYHIKZeBmU9aCdSqkVWkVTlMYFwgkPMVyF3Gz3P+Fp+/wd/vyGzdfdfrf99vjQ1OMc39/J/xwwUoSsaQUxJkBFq1bOXrhvoevEa1UX9EnI9ef79XrRM/ay0IczUfDFITPlOKsmUrnzeZpLmJAvGYQafqhzwqYu8MfciAk/5O4y+D6nqfki73xwRTpzU2PgOS4nTlNmqmDf2wTZaQRmpgTc2AGHECcI3k3V4m2UmzCMDgkNhxDGi3JzMM0C6nDPk6QY/HGuqZdgbhGPcSbkq9bSpc56FPI5gEe6hni6BR9AaR3OnuZ9ohC5oFGkKti4kCzrU4/AQ6dozZF3Dvmxz+Bso9y4qfMTyeu/F1OXn/MXUEsDBBQAAAAIAI2zeV0M84lr/QEAAGwDAABYAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy93ZWItc3RhcnRlci93ZWIvc3R5bGVzLmNzc21T2a6jMAx971d0VI3Ue1UQgba04WXmU7KYEhWSyAldBvHvY0p7F+m+hNiJ7bMEjs7FQbnWYRJUAx1wLfBc1c5Gzvb+tgz3EKFLerP5i0a0myBsSAKgqSsp1PmErrearzLBMnasHp34Cg6g63JcvA/S3ZJg/hl74tKhBkwoM0qn70Mn8GQszyovtJ4usIO/VZ2xSQPm1ND8LLs0lTbBt+LOT2h0RTsFiSFEgSuwEXBcpEqgHq5Gx4ZT9XqXZ/62oeLfb9U8k7OJiGuNXq62bM/K7TfsLM+LoviAkW8JxhMsCm36wFnubzQI7iDRXYcWIk1OghdqKkjZDroX9RK0kseHgBNx4Gm5Rzp+JK4zsTLLxkXDXgqkBXTLbExV69R5+KxUrej8ukh3VL9h28t1M3V6m1tdBNlBX9t3ZIbiUci+FTjFoXo2ZsRkmb2QHRXs1JZoyD5GZ8PwUrZu4VadhCfBifkUJVekcFrG+fLwVa9c7oty92x7bciNH3Q+MHXU+ae3pODyYfB3ZaeM6jFQJ+/MZOj89oxtiFYcF/N83rgL4OYZ1E71IbmYYGQL36AVrJQHGP3QGgsf7yjdjWlNiS/apoccP00TIKU6jos/HWgj1h6hBgwJgu4V6KRz0dDYOXwb3oeI9BeYR9I6C79M5x1GsqMS1nTih4NxXPwHUEsDBBQAAAAIAI2zeV1r3aTVnAIAAPoEAABQAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFU1RTL2JyaWRnZS1jbGllbnQudGVzdC5janN1VMlu2zAQvfsr1BMpgGGaroEMpcjitm7TNGgCFIVhGIw4ihlLpEJSTgzB/96h5K0O6oMlzrx5sz2K1A4i563KPOn3MqOdjxoPzi9TC4+1skCJNhKSYCNxv0MI58D6PURnPFyRraHzcg82Lze+3O35crfxVcJP97zBhP5eKIWSTFjMJO8hygoF2keuAjFzkdHFIvJTa+r7KbLY4KqM8z/AOYHoO2tmYAkTbqEzGqcnTS/qUhbKedBgXToar6pwGB1Oa0jHlzY7hAktA0lA8qp2Uzz2HfhhWYJUwgMNOTbUPDd2ILIpzXV6kmvaOFPbLPQWiJkUXiQNNqRnyRHziwoSYsERpmRSciWZmSXe1sDQWBcebaZK05TctZPglTVzJTEN+dTM8aGMRpqNNRmRZ6EII6YCjS/jZYK7fvYJ+Q1FZkrghJU46SIhogpRIA/aM2F122qjdFV7pDS1b1+W+IvjuL9cbkaUW1ECTqhrSEg5mOPL5WoACQ1NsVyHmam8PYUGym6YJN5Oqh0mAnfJ8T8UnM5LnlnA6Z53Bto8KS3NU9JmZzj/W1UCVsmyAoRdHy4wgl1bUyoHS1QSqpPbWg/1miZ3HGnlZ1XATZBHkBx/MErTyUQqqwM54fzw7Nfw4stgcn45HFzdHrb7Oljt4AE1zEjt82N8ruqNtwJa7yIVT0KtpsXPL5HgbG+HNER1l4pLgGrwWIuCnlorFjzHHugGuY2J2f6Kt6k7yfw3bzYVeKva4FFjTYHKw28DXpS2B40i+arIcsxQj48HR2/evnv/4eMx2akR2vq6LDx0zbayegEL12X0eozyZS/FG/dfYo/+wYZid0nNjL76dvPzioevj75X+aKNirnSWVFLcJScXg8n3wd/CKq1F3b/F1BLAwQUAAAACACNs3ld0N1U3lcCAAD/BAAAUAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy9uYXRpdmUtY2xpZW50LnRlc3QuY2pznVLRitswEHzvV/jNEqgOFFqKQwq5xC0pro8muXspJQhrnehOllxJTnIY//tJ9iVN3KOU+k3jnZ3Z2c2VNDawYOxEw6+aa0ChVAxiD4WYUGNAD//14MhYzXNftC8HBfvSoYUZoIVxaEXtboB7KMTjvLOSO2RSmEgDZZ+5gNWTzJGviB4Ul2izYVxLWgIJo2h0s1zMvySbWbpIsvUoF1w+vpXU8j1ED14srG3x0bUuaplbrmQgFGXowCVTh0nT4mZfRrqWC5nBYaakhaNF3gBp+poWjzXYWsugf0ez1ElkncK49RGhsOTGcLkNdsq5LygXJsiFMsBCF543jyefGnqg3AZ9bm60B8itQZ0ZHFVa7TkDbRAmo7tsej9dpNObNBlhJ99rFPwILDgVBj4+h5NAqsBA7iyaSzEB1sEgT4lOOqGmi2dGtdsa20KafosbY6mtTXymokY9xlbXQM6m4h/hkfLwZ4vJFiRoaqGvD7ST8jIT/RLSmexzjL1ph0LYug+PX2Z3zqlAqM8jj04tUSdCwh0IoUKMI9+CnFsM6F9Xt1nkr09uefGEvAlMBmBzmiDuW7tnWTlXvQIp6fG2tlVt1+oRpInfvf/QYifz2p4ubSq7A/3bKBktsvtpuphvlsn3u2S1vlgaA8mp8Fur6NaRr3b0f6spqDBAQGvlxnJlm+x2vZkns3S6TObhHyu65rW428PrE14d4bDzxVB1xVz7oHcXKCme/nWqFYjirmP/7e5o5Z0Au7L86un0TlZdJ+Qu5sQkHXPAyiPunFEhSC0ZFFwC8zO9eQZQSwMEFAAAAAgAjbN5XSI7uvMyCQAAqBkAAFIAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVTVFMvcHJvdmlkZXItYnJpZGdlLnRlc3QuY2pztVhrc9o6Gv7eX6HTD8dmxpim0/1Chu6QhLTsSSDDZWc7mQwjsAJujOyV5FyW5b/vI8myDYSedLs7zRSQ5PfyvM97kb1cMiKViBfKO323SLlUZEMUw8eWdIhg/8xjwXyPpxFr62Wv4Y5RKZlQB4fscquQ2aiELgSjit2I9DGOmDgTcbRkAXmkSRxh/ZpJSZdM7qoNw9bX4XgyG/Uue6Pe4LzXyornm3MjIFx8l5WSBRXKLEPGhsRRm3jZinKVrpVIefzcXKTrNeWRFxBO1wzbN/Vtcl5uM07nCYMAJXJYuaAZncdJrGIm2+TWS5J1uFhR5d2RrVO+lkuovd0QkSZaNJAVkIRNxbjCwleWJCm5jqUkl0n6hF2yvTt9d5/zhYpTTtb0gfnpIxNwAUDAhW2DbN4R4pxLEr16excQmkexKr7nGjfz/bQ8O8fv1/D2tThClkz9wV7axI+jBul8BlKk0+kQ75nGHvkr8fqDSW806F7N/tHtz8a981Fv4pF2bX140xtUW4ETeg0CJMfFLkX60NQkaq5SMElLXGaqtmIF0VytUhH/CyD6Ro6Jgd0Cgk9ncZLo6BxuC7ZIRTTVgGDz2exuLEBhlssVlk7J1p6VL1Kx9WUqnBjvW5oTKlg9QgE5D69i/kAK4uATCmJOVSrCwtx7phar/jqD41S+8AXxc5EEJOaxsgaYU8TGz5oBm9wRsm2cFgcEU7ngMDh9cLxT7FmVYo20v42Hg1AnF1/G9y+QtLaYm/WMCsl8LTacp9FLIzSbQSGfkDRXWQ6BIKl6yTRJ1zbt6jytNu3xmTbCc7ZYFgekG61jQZNQcxh/BQ3bOu24eSh9YBy58vEkIE5OsfQJOQ5mb63f24Ak6RJBYI8KR+ffjZuG4AVYegPr20ZAwjAsE0S7ZcErgZsHFuUiQVxuQNO2SFKRc6SGj4NppmRHZxi0zUP9GMAsC4jeh7OuyOhUh1CxlNpDV4PahtmBKVfgcD9qe/jazHmM380PH06wVwAs2ygP1n7oNQCcvnunme97z90+DEXGpzx5IToRmukTZxF5YC9Ek85E0XyznkrCUyIZElxJbVaNHlW52MwDi4WFwiCha6upMo2qVAis0ScaG2w0MBvLKC+ifIk6W0LSNOvQB7PaXsLoQ5MqpFCmPBsGW/lDgEETX4SaL8EBXZCAe+ccmoFB83Dfcni/eBxqNN7efrgLdW55K6Uy2W61aBaHzyGNW48nLcFkBp+Z/NHTJntWjMIiGXaLUkR1gQ68M4b6IMhr5bGGqE69Ti0fd0WbxDxQr1ePevrKUYkCxIJ7mkh2RJhJQ61Vt6PAs+XuFccNMQxspkyax4KPJ/WDUcrkIFXXFIXO3y9AYodgjaBlAfn3QbdrQaQmiiX9MGMcvI8loaAygEKvKhOL0IhmCp+5hBoi6SOyQYOhuecFhvB+o/P5kO3bTsFvx+5OndubKnNT6AfdXmVuxcji1HFS7rSvn+GklRyir/xfmLnboHeQRx+L75kZKIqh5sUNXFFA5uwezCLsOUsN9g4L+UbYLdyFA4J9ZwslfVdfy1rS3qASVsV2Z7y6vdsGKL6u9lYGaHKdd2+6Z/2r/uTb7KI36PcuWvuxsW02YXypVsGHHc8pd3MdmpRUOIhv1cwILVxpNEBKB8gRr3/RXzddmvz9SW9r/iBISbyAepMaGRNrZJueJOFITBPEjj3CJZ1i82JmMv3xLaHcVFOYPmctPeavyS7Ye9MbXffH4/5wUNn71uDMc/iv/jem70yJbzf/bHrxpTf5edNz/sDRsatcgamcp4oglRYMY8M8VoKKF7AvytKYq19KpoNS5srKmmo2pLkM2TPFPMoMh25Gw7/3L3qj2XQwnt7cDEeTn0saN8BoZ+aY6G0jQQJpazTZ9FzCnhc4RiTo4gXOq0KDWon0Sfp6df+y599uzGXJdafADaGeAgJEj3re9k5Hpnsxu+6Nx90vvXGrXiLfItxexErRzx6gzHA38j9hRGv8unwcjVFNuKopWenuZ22/7OuCXEifXU9xnT3rzabj3mg3m03youJW055bsf1PT4OWA1i4Z8l+IzxKFpsU5fVMn+d5kmwboSb99fCidzUbDCez8+Hgsv9lOrJl5i0C9SVyT1xJt0OJlatln8conwozMOmiy5HzwraeI5V37gbYTXXrKo/5G1ycTKYHCIfKZfvTh5PAXFvKM97mvdH5vv2+7JW2Sb7fIl20Ez90HS4S1vmMKwGwxOXWK/3tTidfZ5fd/lXvwvv9999YWCQO2vYiyXFf8T3XjXfrnm0+1mISxXKRpPoywFmsVoADU77pS/ALY78gxRT+X8xAB13pWOOpj36MZb29sUgGt/bi48aju8P5CIHUnSg4+bMqWmpKH/zf9mZL0fgz8FyGuHZtO6FWMqeLB9QsGgM2g2j0o8L0+ruSGsP1dVxX0+tCodGDSs6Wwkxgu/wurOCwa4nSgCje57i4sXKufUJscSuuho+mzDM0c3gwHV0daw9VYOehk+xs9j2rwgXJCzaYLdEEFKtniMkGb/iHF1T9Y//B4v5nl92tz17vN+Z60D4JijcJJ1udM9XVR/401aroy2qjFvY94xp1yrjEBAYgAsNvmSaPAAihZdwE9k1AbRtFC6iS+aJ7M9kv0BCKyrtmtZGx6PNIXqFMu0poljlC4qH9SCIc2MLdWTKXnRqvDmdPpPDCF53PxZGOqEFbhv+10rexsOv/TsvXIaiG5i3SbgXcv78VkbzdmJc+1Qsh18rcxs7LoJJG2zv8a2y3dRLcx0Kqjq2WbobZc1AyNYnXDDJ9EZz8pfHjfoNp59grlo9mxjkb9TG5zc6m42+t4o2QAbCaoYxN9WAicgv0aJO8uvfIBYpZRFSK/gJ4azHUrzHNqz8X9VdiagjAIhdTyZh+zbTvtD30xqjO9JXRvES0aohTop0qQlxX4M8K+gcWOjxmLowyXnKahDSKenqivtLJwHUa0HkqlC2K9gl/ONcfoZ5nltzXwnu6V7qjjWBj3pp7Xf3TbHk6dTYpoGzbCmlc22EDWkQENB0fyjhrjF5tNG+oIDZ4iIN+IVfnxpNI+bIZRx5MQAG0MS4vWq83tl/Rt/e6b0+rheQotQtkSvp2z8xwPhuOZpP+tf4ynbgK9B9QSwMEFAAAAAgAjbN5XTkscAUJBgAAHRQAAEsAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVTVFMvdGVzdF9jYXJ0cmlkZ2UucHnFWG1v2zYQ/u5fQWQfKK2y3BbYPmQQhjRxsWDpEiTZUCwICEo620wkUiPptwz77zvSlm3JdpqkzSYEkUUdj3fPHe8e6uDg4FTmUAH+k5ZcnfxKLBhrImIslznXebcQqeZ6TpQs5hGRioyUsURIFCgKboWSRGkiwU6VvicZDpr44OCgI8pKaRT0N1QSj60oVqOq/nVnlKx/V9yOULJ+tFBWA1FA/TyWwjrr6ucH0Xht5qbTuTw/vyZJrSm+wHvAmBNjLIw1GFVMIAjjimt0eHnrmAoynNW0NXajbKBVuZhfqMy7G9CMFULes4xrq0U+BBq5ZXv0+vz87Ir26OpFXM1p2ClVvq0cB8eo1Kt3CwXuX+gtiQvFc9AxzHD9hVyAt7DT6eQwIBqmWlhg6H6QFiqNCOTCRoTnefKbkhAedgheIhEq/jBHwE7Pg/An1Xj0ElNhRzWI8Z+i+oj3QER0SqPV6OkFO+l/PDu67p+EhxU35pGZa/3OrDCimoaEG2J0Fm1Jq/3ruDm5sQs33DXABEOPS8w6pywWcqAKYWwQrmXclXPLEyeggeeBmxE77ZKXEDYExYA03iaJg/DQzX+TpLT/x+kZbWo2NvaoG6ubiiM3aa0dNWMcDhvyOBCldCwrISXkdCGswY41bp14CHbCizEmJcY3KxBico3TjuscMkGd9/Fi3NQRdsngxtkUUmZ4WWE+CcNQm8gDA8VgA540CRY5etk/6x9d9TFLYeandK0oMdkwEjT0wLHURTFY++RUxWgXaNv/a8wLl4xxNoLs3uXgUjwNb6geS6eM3mJsIUVHm2aigonI4CtMdVuw6EqF6l7B4O7SwC3Dc7CgSyEx5UTGKp7dt22ukmUF6H+6cEnsqoDXaDGMoOnjpqFRFeRBFUaNp7YZGtzSrOQWfTH4WAAmQ9uUx1bYNnLp8srQMHoh+G1jM3yJRarS6g4y2zbSF5C6vmNeu9qITeZEaBRWeh74ImCb27tKnCsSpiutPs0iikNdt2j37Tt8cruELCVo1OgENozaEDQLw07wjBprTNuKz11hxsDcvL29oSJ3abO59BNUtZOwGe/dSpu4Cuk3DcM/Dc5F2NpAHtyN5S+5MMu1LjCB+BD6WivdKp57sP3Ac3Ka448WlLRnS8yBHXg27bWYPKAhZ84Wu9fmr6lPKc+TRlOMmnN76EmPV1V8ZzZitBulSxjCbAuqiF79ctR9/8OPBGs4KYXxe5DuQHCryvC8jUjdCBas4r8BxPGCyBGEHcgYwL1qYzuzL0bn96VLxAf5hbi49GJW8wlow4v/GZg47oHJeAVfxOQp++op3msYFGI4qreIYcoBIR6ApYAECLCiZtiJMlWiqDGOiLaQ+Y4ckRGqKOaklsKQ1GpyUkKZgiblGOtjCqQGmIyNkEN8a7njMhvqFgsj65qoeyey5G6xMxidIcF0JLIRgVmFZwVDuM5GYgKehoXxmhKtKH894kjvis0jE87uyfoEkI3W4RoPBmgwcuc2dV2Fo00rF1Mi4sgl2csuH5ohelhzNWqV6qZiGKMTqCGlnyn5nvgYfzr6zD6envXJG/IubJnh7Y5V6itnyyY0ZgkYKjQiBwZoY2aTI59FGEifNgE9vjz25ycMyRJ5FzeyygwatlLrWZuU0HfvySfxob079+aoR3KDnm6xonFViIwvthLDY5Se7920O04fe0PoTwZfCtOsV3IpBi5/3AkS+9Pf/7Qa8DPEn7yzdwGlHsFoqpUcLrGx82p/uS+THUzjcU7paMh6/g31q9DbxAn1kKZ174zreC9zsoaLqfug3O5g2E01FpYcz8AVT0UhrPCM9NWc21wHfbyhLmXwxI8ckt6+gouLprho0ULWpOhxyvXN+KyzAOtt1/AB4OMV3n5+LpMNKg8owhqDnGBDXHQ9CzNc5qp/fNm/TniatWY9C8AtXrwz+acakwW9eZWG/py6svl9IvzCh4ntbxDuct8hZP0Rwh3+d32E8BBsHv8lml4VPIOgxTEwtB6irsh7yKRXHy5ku7t8o8rUEQPCmLObMZIkhDI8S2JyM7rwYN2RcRTR/BdQSwMEFAAAAAgAqbN5XakdTKt/BQAASg8AAFEAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVTVFMvdGVzdF9kZWZhdWx0X3JlbGVhc2UucHnFVltv2zYUfs+v8PpCqqCZy9oOdaCHLHHRbl2SJWkfFhgCTR3ZnCVKJSk7dpD/vkNKdu3WTWOs2ABD5uVcv3PhUUVVGteptXIOrGMdB0WVqRxYpxJunKsh69h6WJlSgrW4nuPnb1tq1hkL29wvVODYu7q4uIlbLn6J/zRJ/EWSRNyALfMp0IhXwoB29vZwsHdzcfE+9lz7xC+v96Uwzqh0BLyak72r/pv29u3F9U2C2/5V//y0v39yetq/vOmfJQcvjg7InsyFtZ0zyESduyvIQVigS4/4DX5O8STq7XVSyDoW3IeKWsgzf9LxC+7ipdtI7hERZn6mDEhXmjmNjgORSNNTlK3rhps7Lptte59u+t7SaFFA1GiWuQqn7LkwIxv1DLja6DV4uak1vUWIOdyBrJ0YYhysM9SjE7HnhUDVzrDAPmBSVCgAkrJ2Ve3iG1MDc3DXrFqdhZhAo3SidBqTGQwJU7hIoSi7Hm8SYDBxsNebSDTMSCBHQka63RQRJKzxcYmFtWBc/1Mtcmp444gsU2AHzHDrUjAmOl76Fxj3VdpY5IOSpE2wEi2cmkJi2qCtolI15gTro+NF3MoIVnPMN3K8bnAl5ISwytuKWBC22MFKVFbEPqF5XorUUvqlKt4a161yobmnJD6dRZp4rGm0RVdxS1omMrgldiyOXr4iA9YWDG8O6KKRMpwjIiiGj+EuVSNE51syC6VVURfnAbOPYKxCWwaMHPAXHOtgg+mNyBFPZMLUSmvpkPQKtc3JwHs8U268LFv+l6re4D9dRB1hO1lvTco7TUkhtMp8IQXXWRYyOldfmXleBvIlWlhmTumR3cbmy86JEazCGnYhpt+vBWwD+wSRN0K6rhVZ6BVRuFo0f0FaxNZSnJFDfsAPyPdqZqe0+dpaopEKlXXx80yW2rqOiA18qrGV0CUlFu8Um1907AlKxD8vR/S364tzFG0QMZXNqeBTMLg4QUvctXdnk/1osPRo3csoip59hqgpre70sOv9cZbLvy1ZB+jHgbFO6VnpWj0FIlQQ3ZJgx1ssArAfvXsK0iYdn4RkZldQksx7Ij/vpZlXrsSz2TfhZrI0sP32CG+rOIQAHycsm8yG0vRVcT3XcpP650HUxM51JrHkI9BghIPfYX4plAn0BNKjly8PX6NBVT2MJxy/uZJIgsns31t67+YV9IitJgprozSFcD1SQUEeImbiVc9hLr63cgyF6BHsdHrCPdLdukpRY1eOhdaQ8+khYauX813aM3xtx1oqf9qsWLAGo2DwbLVmBqrSKv/g9Xyclxu2rP8PJu9VfG3HVl5dQtHDzQMTsUfZNzj6a51lYHhmyoKGQyl0qZXENLr/P4ydwPwNVheYCovM9VZ2PjU4mOgYnAh/EYNVVGb8+vRt/48T1gasZ5hVIyw9LKue5H5NdZ3n7BE4DEpEK4yaNmkUcVdeh1ZAyRBlvnpBoofjWdsS2u5/SDE5mGCb8OFT8Do0Bf8k/IIvgjPz+62cZGZKPSLf419mPtwpR4+iBymcHFNf8/cqoz+1Zvo9V1rmNY4KlJxcXl5dfDx5jxPbnx/eXfXPsDO5sSlnHSR82NqiZspDsmpQ4baB6XPTesK7/CP7+2pWQeKpkpBgdmCeKJfkpQ/b1lnFz1fdloFsH1w2n8zGisdGmQ0Dt7zxCx8c6+zWqWGr4GB/t9T5nOyg52mD0cqWNQANZLWFxOIAkEybsWWXSW9HwPxKYXcWeQ5pt9W3mgB2gXPNBV0mJYqaGeV2mlIXPLC0Q96QTAAq8uXY9G9yoOHdHCXZUs+aAxIDlcgyx/75CPy02vcZvI8VzH3htdaHQZf89/m8UYTNOJmk2MrcY/ZvH0A3Xbl/2DkIXzn+hSN7/wBQSwMEFAAAAAgAjbN5XT/XtaRrAgAAMAYAAFgAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVTVFMvdGVzdF9wcm92aWRlcl9jYXBhYmlsaXR5X3YzLnB51ZRNbxoxEIbv/Arf7K2WpU2qHpA4JBGpkEhAheZQhEZm1xsc/FXbQGiU/94xhAhQ2pyzBxaPx+OZZ2deqZ31kSyNjFGEmBPH41zJWU7CJuTkIViTkyi0q6USjR+Dwbjz4lEM8c0A0gZAVngRrFoJlhWOe2FimHyZNjBIkfwLaYLwkX3OQ/QshWnR8WDQH9Esa9TealJyH72s7gWRu5Q0N7LGlMAucjLk5YLfi6731mNqdulLAY5vlOVVTv5I5wS+y7koF4ArmG2wmkapeAjkchv27pztiyzG+HPFg8jaDYJPJWqS7MDLUrgYYHUO5ZxHFoSqX3zSoztPNOAdmtM2HV7cdvsjGPZ/fu/dws3Fbe+6OxrD3RnNqazQoVZ2LXwzBUKT4Vqg8XprJFc7o1+aKLf2tZjhGqn5zW7VkqYSj8U8aoUbiXGg7afTnTbl9NO3r885LbnjM6lklMlxQpXSxfbq6fNr/qmcAongh+j+XnLFDhAznU2Og0zzwyjZMSkvHkSJpJZmYezagBNeyxCkNR8ZmufrZjrVTI0QwiG7tYzzQ4A/uAwisMO+zNrkGOgxstUZ4BjFDeCtAQFqjjMBK65k9YGZvd1evXDSW/kpjdJqp0QUsMseksQojmtvl6ZCJXCnUGad3Zjv1aN7M+xfjLuj1mH92au7NLXtnAgCm2X/HoZ0YJKITnPq5txEq6O3Rj42MVespqLvHt5jxgiJ83/8k64WSbwCKuhO8AAYxUzTF6BZ8Uu6a/x3tCstblymQnoDLCVJLq/Y28m29vyLdBWq7DvTLWsCkHoHoNOhAKk7AWj7VTOTgWWNv1BLAwQUAAAACACNs3ldpRLgPtECAAD9BgAATgAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy90ZXN0X3JlbGVhc2VfcGxhbi5wea1VO2/bMBDe/Su0UQJkOkE72fBQpC4QIK2DxO1iGMJZPNlMKZIhKTtp0f/eY+SHnAeQIYsoirz7HsejZG2NC0mjZQjoQ574R58nFsJayWWeBKxtJRXmyZ03uncznc7Gu0V+TWNaFHG5KDLu0Bu1wTTjFhzqsBt6lJDHEC61RxfSs9wHl8ZMAzabTq9uWZb1ZEujBBecFCvMHSoEj4VVoHulAu+T2wBagBPpniyf0eOCdmXDXiKwSjyGnzb1qKr4JYkvPNR2vFdBAREH3ONX6bAMxj2m2ajdB0JcEKRu2gQxjpfth2yfy44PBLnGbWGduaM0KdvikuXM7wj2Izma7wkn7fzEtwOGhhqzfGfH5Pv11ZfZhCxpBS2VWe70OAyN00eH+B9pLYo2kc23Dmjqxt9AkR9tdIQt6AUaFY6uuHHXWx4fbZInsCxnZ/wzP//EslHri49Vm9w3oFI3jxqXCmewYotngvvt0mnczDUYw2yzVNKv0U20M0rVdDBu8L6hKgi2OIn4YcKlTpmXKw2kGFnuunK0KRSuoHwsrJE6oNsJe5lhoCBGDFj+Tr1zVoOWFcX8dIpYdU00W71yIPBo41aGddJBvQHp0ae/QDU4cc64WLL34ObsnJ/xM9bFk3oDSopibXz4eMg+KLuGE8AAtT14+TbU5KFEG6TRryEtmTYhoWPJjp52IKhZNlJ0Qapxe3gH7Hiq4zXDRvU4jlwZED6t6GoBUQR8CGmWjeo5bbewlEoGiZ4txnNGJ4qXawhsMar41smA7fanLKKprU/rLPvIqsVk4sCf+n9QKql/94lJn5yspfdkk9/pEW+Q+st8ucYa2JA9hfOjEc8Tbc7J1sPypaCQ5/fN3mHPhnNmLGqQsUvJvUhiyOJ1SeLdRpaYOGo/mnv2L3ut09/bMruNbDE/Iff8cmj96rogulWldwIpMX2hSciqwvgf6UvBPrqE/wFQSwMEFAAAAAgAjbN5XW6wO7LKBAAAZw0AAFEAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVTVFMvdGVzdF9zZXJ2aWNlX3J1bnRpbWUucHnFVv9P4zYU/71/hdX9YGekaWFomzhFGoJsh8agK7lJp66qTOIS37l2sB2gqvjf9+wkhS65aTvdtiCU+sv79nmf916Gw+GFUYJalqMrlTNkmH7gGbzX6iNDlhlrUGW4vEM5N6Uy9FYwlFNLEZU5kgoVyliQyjSzJhoOhwO+LpW26INRsv2tzGCl1RqV1BaC36JmewrL9opm7S9TVJaL3aq6LbXKmDHtjmXrcsXF7n4luXV+1iYqLcBCxLRWurXzNk2nidvYu6LZfQVi7aVZvQzdsSqZHAxm19cpir2XZLl0JpfLAMQArwdGgqikmklr5oeLQXKVzt7DXS8yRjhNfplenqbJzbjBc2Qs1Zbpdj1eUy6j9QeDB4PBD20IkfnIy3dSQLSkhiF6LHhWECwhNzgIEXZJij4YRG8NGH+DMiqlAvgq2ZM6HAwyQY1BKSwuVUbFTX2H7Cy6kzNqWHAyQPDkbOUllxZ0yGWmq3wJETvnlyXThhvLJMgbJlaNiHv8bYgfC2dk5DSM/N4IowNE8DFGX6NvJ8FO4JHbYpdJcMLlgOrNOdcss0pvSICo8Tx7MdL6d6uUJcH+vnuYfAAXlIngB9dKRpkqQVHfvagqQTcjW/zru4ur5U0y++3iLFmm1z8nV/ikDgfA3jucXs9SOMMT/OeT89P0FE6ct89dc46+4NcLkaOp4xeZ10kNkbGaeAIFC7fIVWXj17cvpknY0fqpB+SB+x15wPrJxqmuWOjij+G/6+lXQCEB+CP6oHhuUEHlnat8LgF2DoxhYoP4Chm6LqELrCgXQESoUUePqow6Ctsa9lq7pyvkqFufRvWLzJ3bUY0CwDFv/r8P5pNFN+UtvhGU1ppLl9LgTb3zSLkllq+Zg/O4G6wHC1gcuTAI3hVPHQtykjkCWdwVFVwyyOgrT6Er0NxtQ1uAdPKyh3ZrarMCxDSLVpUQfkn0PpNmyen5e8+0mPyeHwTADqe1q6zBziv5L2DxPQZi3EABQEX3OwUjoNLS2wmBNJZ496I7raqSHAbBoFPK0IOJo0iI1swWKo/xT0mKHUXzUoGGGI9pycdgnRnYdhUWXykJJKaVLTyfexpBAY5CrwKst/hpdF9xOWrbsK/stsKfHYxOEWLCMLR97oPZzzpuPALOdD/ajck5PlMSOqQdpZuS4YVribQsBc+o5UqO3VDEvQq8mdhPzSiv1qUhbieAXpZBl+ihUzu+4nZykRUurC1PxuPDo++iCfwdnmwduM/bFs5nwLDxNG7ef6ezNLmpX00WvHcdWas3/fj4ft9MVqLbUfvCQ9ftYc6U/dJ1vJ5c7hKUGLWVCWu0hKK5IX7fMRQqMGc1Zj2t/ylj5asPAmfWfyr0221s+huR07lnst7u2NzTVNeC74JxM7j2znsB8/UHY5tpm9xXVJBdmXjW/0iBra4fhseTb7oxflI6gC8VN3RcLS3C+aIrWocIUPo21dhsK3N6fQOl6ZO/xW6c4BN8Qx+gS9IV9BnUfCbgnhHYcckbOpocdq8695Y8j0Fb7SsGn3mOF58ZJ8BUy4eN5n8A2F+GDnH6FBwd7WuEQUmF6MnqZzbk11MmE8q8SNajvt38F2n35QE9Ty6TNMFhX58f44NWswP4aDL5Yhz/33LzB1BLAwQUAAAACACNs3ldUo7iSXUCAABtBQAAVwAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy90cnVzdGVkLWZyYW1lLXJvdXRlci50ZXN0LmNqc41Ty24bIRTd5yvYMaMwk0e7YjTpInXUbFrJzS6KKgzXNg0GB5jU1oh/LzAeN06dKBuE4D7OPedcbrTzqPfgfGgtPHXSQoG1EUDTGy4bniOYc2D9q4jh8cx5K3kKPRlie26BebiznfMgbixbwdR0HuyLDnV99u3Hz7tf08nNZDr5fj0580N4NU/xlc0JNf/tUt0EpcC7CJQjkBSgvfRbgrTxaM22yjCBOLMRjVjArSAowvHWKIeWJsLiTCmHCXNbzYuyvepP0IB3YYxo+0AQPEuVLw60cO39Q7qBjpdmjM242rcGLGJNhGYZAO1TQ5rboU1sl0rV684ti03ZWPCd1Yn4jafYPOLQhEBStgVn1DPcxm4xH8T1OBF1lrdX6WjbBPlLLwXFEYmq5BhcSYGJjngonsYPTECzWXynkTsgnK3ZTCrpJTh6j5Va1XzJPH4IVHdK5fZp9DuTZ6KFM53lQHbkRs4yMcMQ/eFnKE9QKPc8CeZZ23Ml9SO9IH67hgT1CZOEmc+qi8tP1WdMzJriga4BCWF24RJzexUpnhu7iJMZvwRb7X8wWVvzHE1gKd4wiUOIvQdD1tFkTBXsD5M7wUawNClMErZQkjlTDsrmICdrpEAv/JKclx+pmJQYKyaS/0tKJe/PH+o98loKckS2snmdF6lOiTueU6MjxXdBOxVq8ziiCPu9EdJlE6CX+iOmBVoxFdldxa/br/HFxq1aaGNBHFuTuV3F5WgUDKsEoj3/8FocrESuOpQ4Pd1vQmhQ3IC33Z+yimx5o+GfsbOK7zi7JAeOTq1D9ukxMeOIWUv6nnOrywPfjjZ0ONU9lGcYMjsp9fwLUEsDBBQAAAAIAKSzeV21z4EO9REAAJszAABGAAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RPT0xTL2NhcnRyaWRnZS5webVa63LbxpL+z6eYOD8A2CR0sePd0GGqGIlOuJFlrSn7nBNZhQKJITkRbguAsiitqs477D7heZL9umdwoyhKdXZX5TKBuXT39L178P13e6s825uqeE/G1yJdF8skft158eLFkSrW4kTFV8I+cvnBEecyi1Tsh+LLazHzsyJTwUKK6UqFgcz2VJynclYkmbC/HIo/xmciny1l5DtuZ1L4ceBnQS9U08zP1iKJw/U7ESdilsQxNqkkFkUiiqWskQCQH69Fmqlrv5Ail9m1mkmXiOvMsyQSnjdfFatMep5QUZpkBdbHSeETtLxTDmWL1M9yWb4v/XwJKsrXP/MkLp9Tv2hOZdWefLkqVFi9AUP1vK4Q3ap0rkKpSSvWqYoXJVnDeN3pTI5+G30YioGwzoano5OJd3by+dfxqfdheDp+P5qce18Orc74GAsy6c6SKAUwO7Mu/N7tfu/HS/Pbu7w76L49vP/6h+V0fhv99cFyrPF782Hv/eXd2zd62YfhX73R6fmn8WiC5Yf7+zxy/vF8eIL314fipTjYP3xjfnjy/fhkhLmDbXNnw/PfCM6b/c5k+H7kffp8ej7+QMvvrG9yavWFTb97VldY7rKIQsvBE0Z6RoS8wjzrVdGfueXcd74nxUrSoqfiPqsIFELlIkhmq0jGhQygdak/VSHpZuSvxVTi9P+xkjnm3rH2LJO8ENEK/+UScofiAMoi8+NCqMLtfHntHQ3Phr+MT8bnmh13VhhG7mzpF9Z9ZzI6nWDiiz6MC5Ng8vDrhsnMD6u3NEuCFastD6Uy0r8Hh/p3fkO/KvCy3DdPMjj84YeDH+ltlskA51F+mLukgDSWS4wW5v2+05mFfp6LM3925S/kKMuSzP7ihyv96PQ7An8plnQ6nUDORaAW4IId+IXfF9N1IXNH9H6GrmZ6KWCvsrjUfjdf+oc/vOXljruUN2a7Y6CRInuxH0nv2g9VYNNjn4Ax0GmShIYA8MlYjXsGSzxLcnVzhgHe4TQx27RLD8NMAxHK2Lz9NBCVWtGM9fWrBdcAgcWCVpjBm/391jADL/9oCc2lrso9f5on4aqQtlON0wYXhpsV+TcF8ix3z3IeQPDD0M7lgp/p12DDapaqazliDq9EU4YIN0+hjLYFaA/BgV926ojBQGhuaN4uVnCEHnGYRhus1SxVc0a7TQJmBTPVV7lsa8fc+hzn/lxCIDzKgumLO9r5XXZvjhsm34SmBxr9TWa2U2KFr7UxBPUONI9yc1o6a2UYDrlla89dqGLPohkcXbxisK/4GdMEpcVrXvwU9WdJoW1CaFMgSKXvJ260jqJZGfmxmkNvveTKjvrkZlk/AzUrWsxUOWITQtBM2lGXp/kYkbuQkJ2OUpDtdwOhnfROSq3RDYU5OKNH/XhFmGE6rB9MN+hUYDmPEId1XW1loI7mxsfufAX/5BezJc3u5qGF6MGuD27x8B9//6+3rwXLeOZjJTxc5oPsLO8LhJKuQKDoiuU6Xcr4nWBxQf/TpR/D12ZqZojEaEV5toJ8IlmTj0ljIs1AsJvGc/LoVwr+eZVScMyFASteIES8oJO/aMSKF48yyxBFOkEBpsm26EIPX0INM5XaT7DtqEplAgV7RlxhtwM6KbgoOGtDRJrJuboBrtUcv2BM89gXWXHJq6DFyHAqrvHro6fg2Tb1PNQ0II12Y742UybmKesaMVFkz3dZcV+pyZ2Gff/yToMp3QSyl7w+Aplf/ugRaG3DqtgN03byBHDy9OyIn8XBj/u7xfDBGA1be65JRHpY+NCvA9fFfjH5bdhD3GL4NT2a4UYTaeoJ+9WsAJKKDdgXtbAb4MQv0oUuzEfOrvJVVKJwVSGjvKlZW/x6HRIM1zbDkJFsvxU6tsrvL1mCfBLxHo4xgEpSnl3L0/jGe+sBxoacyiO0tQ05ZMPHlGueQ1JDGBUj374RyCb8QM5UBE/edDotCkGdVeVyCvxmEdRIMcf6d9FedbnreNjSFaHKazWkeN5YcWNOTrH5hhBuZoPETp4gWE6pwPoFwYFewH898DSHrIn2cIgU169F8xx9cXFJ0C++viiTz68vLk1RxBmsv0IhlqlbrmXIE5XZbEMxr+SaaL2wsDiZkFJRloI0qzjKgIbS1ct+k2HamrGtK94j9UTqBcDEJ357hsTvsBe6Vgp7TtuIBGTpqO1AINLy3I9SWBYS5D+hpKUhmSQwMoE7T1bZTHqpvw4TP7DN4n6dS+KXQ3mxArAL8i3aw1xAgF2d316aw5nNlInqJzeTyP+upUltIln4HgGuV4g90j7j9HXG3fRt1Q5KJsmgbZ0uNIfzdRSiJn4qtEz4oA2LbXk1H3xZrEI/ExvU1JSDaBpxiU+5XZOQST/wCnkD77wq5r1/LfPPLXESe4x73k1rm4ZKyn4skilxrZURAOj/YVIwkSGJpcwEEP+J4c2SUYNn/+dlUPGWMDfD8MX+5UW/d3DZ5Ei9lcQHgWihtoefKdUqAyTeZIGKqaWx4Zv7wnpFBUCNwEhIRzfUl/eVJafErZxdRWO9my3CZGpbL62ms8Fx0kdIfZS7emku/IwNc6mmiF5BSWHqOA+gM3/akElpVbySmy44ra3kaVI+UlFfsUyzgqjKS1fZiGCZDEnKUPUQbvBaekVSegrH9XMvpWLTrtdvBGBsq+emBhKMhp2H3ToyOfYp5Shl6+Ppg7yn9EHezKQMcmqTfFC/ED9bSPl4Fxi6BPapNukyy4D8r/riWjvyLh4o/pFRmbyCyLqioGOSr/vW9ouyaCHIumbZmNe7aPpOV5imwp86jaRmSlh5ZYm2jYbrKvNc2Tcxi/c4qPgODNPK9hLVi6sIm1Ib67oG+DU1LgDdoS20n11asIrSvIZf8p/7Uk/UOeTbwlAiPqtIoYTQgoBB2of7+0at9qizBbFgMkXEl4GzEYsMYkOkiUy3Kk3lIxGpK75lPqazPrdAwNvzbCV1S4SUqt9iXrey9O3RrllSkEetRIcC8dIU02C3QSkkxVpLxylq23CHqtyko0ZfbOFrFzKmZtPgsMsuxkMMzwdMOGqIWRLIKoIA6dT6St2oly+Zdq0Npompkk5pSSpxf6EDjz8aO6JktmyAun+olKzDnlLXD8CoOYmQnCOTGVRrxmfe8ej9yfB8dFyvCOW1DAc/IkPLxW2tAqSwsKIuuyAZFw1vSZwodXfD/SgQ2iBpHM8Tk2/jnAwOynL4tisO+N++/rfRxlEuQqzMYj/0/KLIAHI/Odjff/vmjfjpJ3HwdmNxeRCvWKeyib9x3NaWW/cbcjVJblhV52up6ZTCLBtQ1Z3jJN0DbOPLps2OX6P50ZLbVhE1BDl1NtmuwDFS34ubOjG+dWmUkmztoigA3FQB42F6ziBMHs0vTtthPO1o6R5hsxSsjLwRLchQmdqaiCKBlyCRtTSJtIWOwuS08W9EEFrplm9tvYhgN2TZhV+4E2/8/sO5Xt3Wlp9R9b7dUKi52dvYfHL6e5uOx3hhAjnfreiiFwk8zjRVAUzc2o6pbGLud2uMn0a/Os9DeZrEZY76XKwV27xc3cpHo+pjGLdE1g0cWq6vBhuYNunQy7YGlV34RyZcIC+ZLZF2VLS83kYLq51LLjoOHlMYEzR5aauQ1CPPSJuOUQahoCtkLYQGHd+LiZyt4EeQdJKHC9ViWVTkU1bBAcN0uI0MTeScSkgSBYqsvHS8cBuQS49BPuqWWmlgei7DuYmqCL3XksoaGU1lRhEG89peTz+eU0IPQ80QoJrMuG1C0xUo1OzpApR9wdGnIxGpnNsVDR7MQIzCMTngXqR1Wq39Aue1VctsI262/ZYu+UtoLK+Dp0kb3fizgnLbWIoW9C1tRPqL6OqkRoOKpfZkVUqQooohcnbSa5aTdE18QxhCIcWXEkz91m6yXspl0nM0sHLDVPcjHyeYK6yi846PqyylKn8edqKoGZNua2u2RfUMWoZQ4kaPMF9SBUGXfzm1bcvrDyqh2tUEV13pBduiabxdwmI2CLjfRjjtfgZln2NZloYySgvTZSSwTdE3sj3KsBv1/S2XKHaEksx5RMYNuZFwI50vPk3aXzYlpJnHylCXJePjtuDIS/HZCRe9RFVp4Yj/fJCB3j+HRamKY3KvXC9TX0Wx1yEfhDCDGULQIKNK/yreUq1U0fGwE2toNxWP4Smdgmsxh89SwipvwZ4VGzZ6nsYL9cUd4N63dI1TtzsruUJSTrk2XwHj2YgLr3xB0a+vKjBUtlJ4tHy57D6gzILLpWyaFuomTDkAIHzZriMEw9GPBJ4DJbsGzNQBaQv8smLS+SVWcygFCMo59dWx1ago701eGstvnilu7CtUHXyt2aXbL/NU3XV2Iey8UDG3NzeLLIgzDckpbvQDW1d6/+TNGHJXuqqsr8X0BRjpGEAZEcJFgauw0gaRKCeBpaRAr0C2h0Q4f6pbdNyA4oekjGuhd5YdGA3OmLyuFoG94gNw2/r7CXKeMuO6kBhMWSR/cmGqQ9Msq9a1WoIa7pbmztZbugp3w19oOzVQ9TcxCDXpusiktDX4rmGNaWC2u5fmnFu6r86j/UxjMFR0GvZXFmPusXlwF2iusDTsZn28ozCm6pvrYC6QceZBSdQmMhi+hBr14Mog40W+G+dd2bbpWzNK5F3z6ZRbbb8+sLr1CcZwGXQnbK1SyhI+IJ3H1pi7Yb1cLeBGe1Vu0bUiFatoFZ3y/JfSR1j77htUTHr+iNC2p/7Fuq9Z4bzig28/t3Fr+vTVFbyK7epzlAwaCLGU31y5w2zBX+6c8YwNe5plKiVLGFjP/8Bscvy7+Mff/5s+FyvrK5gmZdygU1VVYL7iLh+jcv0g8DCg33LCXAysJIVMS4ZpUWvC4bmomltNeZ/eZFsYxfqlDFNQCwVF+u2Tk2uQxh97+WK6ioNQBqJteASWAfqGDXW3nC4UE5hqPjCNjGYL23l0e/XtwJa5Xo/Nglzr3F+FOO6HtTCcFdUV9679xKTmfrdczGq6hUGUalUc+kLfqRCPTAjAETXPlO7W9bTnq3mHlLKFYIMeA2bXkl4vWTUppipi53LKXLHen2kVzOHXYKXQg+oU7ym3pWTXNkD1NzBsa0KbYe7spom/FOvRZd5uVCg0UdShXArlwp+t96go0h9TvuPiqf7GzCAWzMHdyA2z4RjqnKBEB1pENS/MPJ/P59S5hyi5SheZH1Rqwq2mLZLn8Yei99viJb8yC1fkSfjLs8pUNdwN4pFclNc82SKvTZl/aF3ZtUdC07oPoSk3STkaks22c7kqmjfTE95ijLGrAajAPOjeeDP10MvJPLZkSw/+Wjs9bid5nlPfStKBcGDzQ1HkfPThjHqDk83mQqaIMUefRtQ4tNrBlf5kuHF8tsj2+at84uGJWp3o8m8aJlPduqRGeBnWTYE34H2s4R5/oFl+YMfjZF4b7aB4ngwe9CuBob0MZryVQIw7tYSxiPOc5jp39i2wHcqQCJVOFl5Zbq1LFRsU6gs/GwCKS+Unf1xn0xs9YEsZypH3xM1b2PIP8it9zGalUTGgZszDeqL6qpjReITmYc2hcTTXuPQfs6xrwnVXq2tpyJ4xZOcBtDKrGGgh7j2SrTykdF5t3ZLiPrayeSdJZV0j8avWbMnyvhv8U1lRJez/9+Ro+8lZWlsS50+axRVbRJCpefEOkr1WyBy2dIKavNQ6WjGdr9PMWOvKdxdm0hcyqJTMhQG9406NTl2MssD/myUbzQn6I6MwPiq6omJBv+jkuKuBeslVI4FqnIE2N+mn9ydp//i/IZdvNghNklKv7GZq8U3GvD/XafgWf0OfKbCpPd5/rCCXAjDQS+BVWm9rSN15t0qi35WYKZl+KGnj1j+fTsa/no6OvU+jk9FwMvKOhqfH42O4eqtLju+xfZ9G//55/KmxD7Hj1OoaOtvbyF/2zb6Tj0fDE+/j6cnfPKQX3uczQgUgw+O/bUGoNzWKFzK5+og7YpDODfq7oW3GhIe+H3NO68beaZQpGj115tNC2B8nrEddUX8h3xW/y7V5YrT/Nvl4eizpvtOMlp3tX/zAXIexZAGzJt1wbnz6ZXgyPu5b/AGZjSWOvt0d5OvczQs4qwbfTZl02KyZ9jsdcMnTX3R7zCbPo9rJ8wynCBL0v7B1ReV0/gdQSwMEFAAAAAgApLN5XXyXsPJpBwAAIhAAAEkAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVE9PTFMvcmVsZWFzZV9wbGFuLnB5lVdbc9u4FX7Xr0DSmYIcU5Dt7e60dNiOYytbzyaSxnbyEK+HA5GQhJoEWQCUJWfz3/ccgKQlW+lM/SATwMG5fOeKv7wZNUaP5lKNhFqTemtXlfpp8Pbt2+liUUgliOJWrgXJuLZa5ktBtCgEN4LUWgDFcmUZuayEIZPpLTFyqSJSN/NCmhWpNFlqriyxujGWAdOBLOtKW8L1subaiIisuFkVch6R/5gKrmrYMlsTkSdZL2QhBgtdlaTmFolIe3sGy45Tr9fgejybJvSTNOamrrKH4TTPP3wa1StQoCqtrpTcMKdZRgdfxtc3V9NJogXLqrIGQYGmwb/i4z/uTob/uL87hp9vx9HP38Pf2f+1/ZWGg0EuFqQuuArmRQWWlVKlq8rYiEhlLC8KkadroY2sVDKplAjjAYE/qRZV0pvDspXIHlKAIZ1vrTCOV+gIM5knSHxHZU7vzwjwatctV3rvGS6I39aNsrIU9P5NQh/FnMZEcwke/MKLRoy1rnRAJ97NcDw0Qq9lJkhT59wKYpraIS0NUZUlAkxw7hU5DTs5eCCNM09lIgA9ImN1iBGARy3cbNEURclttkKK/3HaIRYe0vQG5UNcNqXQMiOtzRA5/22k3lXqFdqdCQi6x3xH/ddavLrvNLZNDdFS8hrObQQnzNSFtAFlNAzDd8n++Ssee9SHzLvgKpcO+BKShszBUvEoQC4E8rNJndnP1kJUwDEJaAZp+zC0QgOKvKARzSq1FttKD7OimdODQscbaaxUS0ARvQ/8uyzPQKwSRQevIdIaUoglz7ZdnoNyj5V+WBTVY6eOz01ZudWjtKsun9lXWX/AdJMVe49xfTX1kR0SbsjTnldoyZVcQLwxrA3UB5kiT0zxUoBgGxy0pY1k3thq2IZwrzwni4Jb8vVqdkYarGE8e3D6VY0lw2FRZbwYVqrYtobgH9Y5uUko7XdQvkl29dhVuxAqcBThmwS/vymWAZKLqsiDkCww6NEMR/I9jA9FgBHDrCoKmaNLuDHCuhJodrRCPtLDgUnewtEfdynApElzqQMXulxtg0rnQRa+++kUN/zinyenv+AqSxIaU8c5Q86SocdQT3cblgVfpnMIgL+e+A2snQCrSe22Fp1/gt7VV7P05nZ6Pb6Mdrcuxx8+nt+OLzumsJ8a+SRGJd8EJ9EOV9wF7Y6Pjw+g1LpZbKzmmUXrHE4Q7FB5OOQeVuIOijLBEGJFxXMTPDEteB54vx69iLJwz5eI2AMaVTpYHnyG+ZY4VlZvIb386qLKBS7g35WyAvqedenprKSMUcfljgp3675zx/pNsga1IMHb2Fi3dAiLofdsjSabIDwUKF2kO8OhIMiFzJzYfRQ6e3KRFdzr5frAyFcKKHfDGquFwYJiPAx7eQgU0I649TawpYD6lfGazyWUMglqRnf3zs4dCftmvArMXco2bnaof5zVta7WMhf7opzqarljqjP3xz7fuRyGZz1Tk+TeuH7jBUtU3FMYaM8lp5Divt6y58b9Es/1CXXYdLi1dFc53saq3bbBnf7Zy48wr/tGefLOFZT+FLrNaRdIdZ9+tKohaSUE4wZ+fVTVePJ8Dy8hJ4ibHW5tvdone6FZawWA6ZJlr8v/3auX33XH96ggJO8Bd14pCGywXf3YrS32c6iGCV1ZW5t4NFpCrW7mWCJG9AgnviM6aluVGeXVo0J3j3z4Wr5EfI/ocE2PID3OiBtdRLvpF/TM54/fZFCo/GUtbKMV+dZ5Om79PG9kAYqyVugQ5zx0cUSBn20MEH6e3Fz9Ohlfphfnk8urS6h16b+nN7fp+cXFeHZ7PrkYp7MxnEx+9bdAi1u+pLH/jLopzu2BDRF1Ck6gDtPYfUZ9zfqsCxojQkf+MqDhW95wv6pFtNWXxt8oRKBcQM18vgxS4CY9arnvxmgMuMCOnwLAuBY1UEGqC0TkSzuIxP2YC+kjenEfeAFjPu1HBWAx8yP5rRvJnWp1ZSSU8C2N0aUAyoqf/vwLjdvHAfNrPyiwldjkcimw3wEltAgaY9i5wx48GsPHd6elLJvSV49eVXrM/sZOj0F2P1D1Z68mth3lx0pDWy6hhl9302Z8qxu0T1d5k2HYXkOd2fZ2S5ULSMfcXXGQnNcY7Lx4yeEZhY/gP2M/wfR3DZEn1WeF8C870u/+gYEnXcevk+5Bxc71skEFZ7jSQS5MpmXtan6a5lWWpuFZzXiep7ylDCgGfYQtPMGX1evz4RBgHKJvadSN2Qmqcoi0x2/Yj6gHqGDe2hH5kitPaubMwTumHa+gbz63EZgPmsIm7pXFMWtdfW+fSmHEWR+NnL2e43s2bjTlDLRhWDUDuqFuEF3E7j3K8qasAy8rWkTS+TE5Dc8W7FFLKwL6u9qbFCVa1+U/uR5/HJ/fjMns4/mEzCC0z2EWimnkBPprYpOJ2pLguTZG0xv//zex9R/d8PSe5+307HQUcSfw/cfpxW+Os4iQMoEXNDMWypQOz9pCdrpb1Y4H0MnSFEe7NIWpL00xmtIUXoZ4VWzgheLjKxz8CVBLAwQUAAAACACNs3ldGlrCzKMBAACJAgAATAAAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9UT09MUy92ZXJpZnlfYmFja3BhY2sucHlNUl9r2zAQf9enuHoPliBVoGOlZPjB61YWlm2Fjr6EYOT4PKuxJKNTQ0zZd59kJ2NCQtKd7n5/0Lur5Sv5Za3tEu0RhjF0zr5nWZY9o9ftCK3uETpFHRJoC8oCnoJX+4AN3OswwkbbAzR4xN4N6KFW+8MQl4Sfbdtri+BsP8rYkLXeGRhU6HpdgzaD8wEe43VOJIz/EtSpmw+37Hx7IWcvZxqJMe9cKFIxr6pEsaqE9EiuPyIXclAebThvzBSpXPZONcR5qlzmn8r7b49xye/lj/XDl6df8ulrGQFlepqnXqqpQpTK89fQXt/lQjD03nkqtjvWOg9WGVxEMwacvIjemG1u0NToKd9JHdAQFysGcSTRxQScqqaQbsG6MGWkpkkDFxD7XiI0mmjfYQ7ObvApN1Grx4CxvZAdnhr9GylwcVVc2MyoacycpRoGtA1P6IJF6Dl8Jue1jTIfyvVmlS8gTfnitOXzI7FI3IrouqTQxJj4mM540oHfCDZXt/8Mhedys/68grceLTfb7OxIthN/IFp8HWXMf2rf4f5AUS6RzAX7C1BLAQIUAxQAAAAIAKSzeV2GZxMWRgQAAPgHAABEAAAAAAAAAAAAAACkgQAAAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvMDBfU1RBUlRfSEVSRS5tZFBLAQIUAxQAAAAIALOzeV1om2gMLQ4AAHwcAABRAAAAAAAAAAAAAACkgagEAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvQkFDS1BBQ0suTUFOSUZFU1QuU0hBMjU2Lmpzb25QSwECFAMUAAAACACNs3ldh7kzxwwDAAAxBgAAUQAAAAAAAAAAAAAApIFEEwAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0JSSURHRV9DTElFTlQvY2xpbmstYnJpZGdlLmpzUEsBAhQDFAAAAAgAjbN5XRm8uncEAgAA5gMAAFEAAAAAAAAAAAAAAKSBvxYAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9CUklER0VfQ0xJRU5UL2NsaW5rLW5hdGl2ZS5qc1BLAQIUAxQAAAAIAI2zeV3dBY5wpwkAAGwTAABRAAAAAAAAAAAAAACkgTIZAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wMV9DQVJUUklER0VfQ09OVFJBQ1QubWRQSwECFAMUAAAACACNs3ld7SX4+i8IAABoEQAASgAAAAAAAAAAAAAApIFIIwAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0RPQ1MvMDJfV0FMS1RIUk9VR0gubWRQSwECFAMUAAAACACNs3ldnhJZOQwIAADXDwAAVQAAAAAAAAAAAAAApIHfKwAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0RPQ1MvMDNfTE9DQUxfU0VSVklDRV9QUk9UT0NPTC5tZFBLAQIUAxQAAAAIAI2zeV1grDqxVQUAAPUJAABTAAAAAAAAAAAAAACkgV40AABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wNF9TRUNVUklUWV9BTkRfUFJJVkFDWS5tZFBLAQIUAxQAAAAIAKSzeV3vG0wXBgcAAIMNAABMAAAAAAAAAAAAAACkgSQ6AABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wNV9BR0VOVF9IQU5ET0ZGLm1kUEsBAhQDFAAAAAgAjbN5XV5rB2iQBwAA2A4AAE4AAAAAAAAAAAAAAKSBlEEAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9ET0NTLzA2X1RST1VCTEVTSE9PVElORy5tZFBLAQIUAxQAAAAIAKSzeV19d6+BwgUAAJkKAABQAAAAAAAAAAAAAACkgZBJAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wN19SRUxFQVNFX0NIRUNLTElTVC5tZFBLAQIUAxQAAAAIAI2zeV0jhdFdFwMAAN0FAABWAAAAAAAAAAAAAACkgcBPAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wOF9DT01QQVRJQklMSVRZX0FORF9URVJNUy5tZFBLAQIUAxQAAAAIAKSzeV1oXEjM8AcAAKIPAABdAAAAAAAAAAAAAACkgUtTAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8wOV9DVVJSRU5UX1RFUk1JTkFMX0NPTVBBVElCSUxJVFkubWRQSwECFAMUAAAACACks3ldyGw6DrAFAAANCwAAWAAAAAAAAAAAAAAApIG2WwAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0RPQ1MvMTBfU0lHTkVEX1VQREFURVNfQU5EX0xPQURFUi5tZFBLAQIUAxQAAAAIAI2zeV0K+AIHZwUAAIoKAABXAAAAAAAAAAAAAACkgdxhAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvRE9DUy8xMV9IT1NUX0JSSURHRV9SRVFVSVJFTUVOVFMubWRQSwECFAMUAAAACACks3ldA+X47kwLAADwFgAAUQAAAAAAAAAAAAAApIG4ZwAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0RPQ1MvMTJfUFJPVklERVJfQlJJREdFX1YzLm1kUEsBAhQDFAAAAAgApLN5XfU4I/vBBwAAxA8AAFgAAAAAAAAAAAAAAKSBc3MAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9ET0NTLzEzX05BVElWRV9DQVJUUklER0VfU1RBTkRBUkQubWRQSwECFAMUAAAACACks3ldXgCoLpQAAADKAAAAWgAAAAAAAAAAAAAApIGqewAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0hPU1RfUkVGRVJFTkNFL0FDQ0VQVEVEXzA0MjAvUkVBRE1FLm1kUEsBAhQDFAAAAAgApLN5XR+JawH/DgAA5SgAAFkAAAAAAAAAAAAAAKSBtnwAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9BQ0NFUFRFRF8wNDIwL2NvcmUuY2pzUEsBAhQDFAAAAAgApLN5XVhLTvfUBAAAdwkAAGAAAAAAAAAAAAAAAKSBLIwAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9BQ0NFUFRFRF8wNDIwL2V4dHJhY3Qtc2FmZS5weVBLAQIUAxQAAAAIAKSzeV3EkVd8FAYAAI4NAABlAAAAAAAAAAAAAACkgX6RAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvSE9TVF9SRUZFUkVOQ0UvQUNDRVBURURfMDQyMC9uYXRpdmUtdjEtYXNzZXRzLmNqc1BLAQIUAxQAAAAIAKSzeV0prkdQ7AcAAPcUAABjAAAAAAAAAAAAAACkgRWYAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvSE9TVF9SRUZFUkVOQ0UvQUNDRVBURURfMDQyMC9uYXRpdmUtdjEtd2lyZS5janNQSwECFAMUAAAACACks3ld6Fiis4EEAAAaDAAAZwAAAAAAAAAAAAAApIGCoAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L0hPU1RfUkVGRVJFTkNFL0FDQ0VQVEVEXzA0MjAvc2VsZi11cGRhdGUtcG9saWN5LmNqc1BLAQIUAxQAAAAIAKSzeV3NqKy1jAMAAAAHAABeAAAAAAAAAAAAAACkgYilAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvSE9TVF9SRUZFUkVOQ0UvQUNDRVBURURfMDQyMC90cmFuc3BvcnQuY2pzUEsBAhQDFAAAAAgAjbN5XbydHvhlBwAAXg4AAFYAAAAAAAAAAAAAAKSBkKkAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9SMzEwX0lOVEVHUkFUSU9OLm1kUEsBAhQDFAAAAAgAjbN5XfZSbKZFCwAAyx4AAFYAAAAAAAAAAAAAAKSBabEAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS9wcm92aWRlci1icmlkZ2UuY2pzUEsBAhQDFAAAAAgAjbN5XXxdfuCWAgAAggUAAFsAAAAAAAAAAAAAAKSBIr0AAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9IT1NUX1JFRkVSRU5DRS90cnVzdGVkLWZyYW1lLXJvdXRlci5janNQSwECFAMUAAAACACks3ldokUB3N0BAAC3AgAASAAAAAAAAAAAAAAApIExwAAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFQURNRV9GT1JfQUdFTlQudHh0UEsBAhQDFAAAAAgAjbN5Xa5In8KYEwAAVRUAAFMAAAAAAAAAAAAAAKSBdMIAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRUxFQVNFL2V4YW1wbGUtbG9jYWwtbm90ZXMuemlwUEsBAhQDFAAAAAgAjbN5Xac52GatCAAAuwkAAE0AAAAAAAAAAAAAAKSBfdYAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRUxFQVNFL2V4YW1wbGUtdGltZXIuemlwUEsBAhQDFAAAAAgAjbN5XYZqS/zMEwAAbRUAAG8AAAAAAAAAAAAAAKSBld8AAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRUxFQVNFL3BoYW50b210cm9uaXgtY29tbWFuZC1mbG93ZXItY2hhdC12My1VTkRFUExPWUVELnppcFBLAQIUAxQAAAAIAI2zeV1Q62jjoAIAAKIEAABMAAAAAAAAAAAAAACkge7zAABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvUkVQT1JUUy9DSEFOR0VMT0cuMDAyLm1kUEsBAhQDFAAAAAgAjbN5XXrGLyc3AwAAewUAAEwAAAAAAAAAAAAAAKSB+PYAAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRVBPUlRTL0NIQU5HRUxPRy4wMDMubWRQSwECFAMUAAAACACNs3ldAVVbzjQBAADkAQAATAAAAAAAAAAAAAAApIGZ+gAAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFUE9SVFMvQ0hBTkdFTE9HLjAwNC5tZFBLAQIUAxQAAAAIAKSzeV1yi4JwGwEAAK4BAABMAAAAAAAAAAAAAACkgTf8AABDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvUkVQT1JUUy9DSEFOR0VMT0cuMDA1Lm1kUEsBAhQDFAAAAAgAjbN5XcLCohmqAwAAbwYAAE4AAAAAAAAAAAAAAKSBvP0AAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRVBPUlRTL0ZJTkFMX0FVRElULjAwMi5tZFBLAQIUAxQAAAAIAI2zeV1KYqzFYQIAAMQDAABOAAAAAAAAAAAAAACkgdIBAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvUkVQT1JUUy9GSU5BTF9BVURJVC4wMDMubWRQSwECFAMUAAAACACzs3ldYFf/sXMEAADuDwAAUAAAAAAAAAAAAAAApIGfBAEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFUE9SVFMvVEVTVC1SRVNVTFRTLjAwNS50eHRQSwECFAMUAAAACACNs3ldxsef7ZUBAAB4AgAATwAAAAAAAAAAAAAApIGACQEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1JFUE9SVFMvVkFMSURBVElPTi4wMDMuanNvblBLAQIUAxQAAAAIALOzeV0p5JcIfgEAAHwCAABPAAAAAAAAAAAAAACkgYILAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvUkVQT1JUUy9WQUxJREFUSU9OLjAwNS5qc29uUEsBAhQDFAAAAAgAjbN5Xc44MLMLBQAAQQoAAEsAAAAAAAAAAAAAAKSBbQ0BAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9SRVBPUlRTL1ZBTElEQVRJT04uanNvblBLAQIUAxQAAAAIAI2zeV0PEQ/0+QAAAIABAABYAAAAAAAAAAAAAACkgeESAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL2Zsb3dlci1jaGF0L2NhcnRyaWRnZS5qc29uUEsBAhQDFAAAAAgAjbN5XRdnUzPtBAAAFwsAAFQAAAAAAAAAAAAAAKSBUBQBAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URU1QTEFURVMvZmxvd2VyLWNoYXQvd2ViL2FwcC5qc1BLAQIUAxQAAAAIAI2zeV2HuTPHDAMAADEGAABXAAAAAAAAAAAAAACkga8ZAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL2Zsb3dlci1jaGF0L3dlYi9icmlkZ2UuanNQSwECFAMUAAAACACNs3ldBx1LkkYDAABIBgAAWAAAAAAAAAAAAAAApIEwHQEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9mbG93ZXItY2hhdC93ZWIvaW5kZXguaHRtbFBLAQIUAxQAAAAIAI2zeV21HAyQXAUAAEcOAABXAAAAAAAAAAAAAACkgewgAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL2Zsb3dlci1jaGF0L3dlYi9zdHlsZS5jc3NQSwECFAMUAAAACACNs3ldSPQgBPcAAAB5AQAAXAAAAAAAAAAAAAAApIG9JgEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9zZXJ2aWNlLXN0YXJ0ZXIvY2FydHJpZGdlLmpzb25QSwECFAMUAAAACACNs3ldzmOhW1wJAABRFgAAXgAAAAAAAAAAAAAApIEuKAEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9zZXJ2aWNlLXN0YXJ0ZXIvc2VydmljZS9tYWluLm1qc1BLAQIUAxQAAAAIAI2zeV09oZe5CgMAAPsGAABgAAAAAAAAAAAAAACkgQYyAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL3NlcnZpY2Utc3RhcnRlci9zZXJ2aWNlL3dlYi9hcHAuanNQSwECFAMUAAAACACNs3ldoPI4K/0BAAAtAwAAZAAAAAAAAAAAAAAApIGONQEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy9zZXJ2aWNlLXN0YXJ0ZXIvc2VydmljZS93ZWIvaW5kZXguaHRtbFBLAQIUAxQAAAAIAI2zeV1iMeN9AAIAAMMDAABjAAAAAAAAAAAAAACkgQ04AQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL3NlcnZpY2Utc3RhcnRlci9zZXJ2aWNlL3dlYi9zdHlsZS5jc3NQSwECFAMUAAAACACNs3ldswkLP+QAAABdAQAAWAAAAAAAAAAAAAAApIGOOgEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy93ZWItc3RhcnRlci9jYXJ0cmlkZ2UuanNvblBLAQIUAxQAAAAIAI2zeV2X/AmqLgIAAEgFAABUAAAAAAAAAAAAAACkgeg7AQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL3dlYi1zdGFydGVyL3dlYi9hcHAuanNQSwECFAMUAAAACACNs3ldGB/r19gBAABKAwAAWAAAAAAAAAAAAAAApIGIPgEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFTVBMQVRFUy93ZWItc3RhcnRlci93ZWIvaW5kZXguaHRtbFBLAQIUAxQAAAAIAI2zeV0M84lr/QEAAGwDAABYAAAAAAAAAAAAAACkgdZAAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVNUExBVEVTL3dlYi1zdGFydGVyL3dlYi9zdHlsZXMuY3NzUEsBAhQDFAAAAAgAjbN5XWvdpNWcAgAA+gQAAFAAAAAAAAAAAAAAAKSBSUMBAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy9icmlkZ2UtY2xpZW50LnRlc3QuY2pzUEsBAhQDFAAAAAgAjbN5XdDdVN5XAgAA/wQAAFAAAAAAAAAAAAAAAKSBU0YBAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy9uYXRpdmUtY2xpZW50LnRlc3QuY2pzUEsBAhQDFAAAAAgAjbN5XSI7uvMyCQAAqBkAAFIAAAAAAAAAAAAAAKSBGEkBAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy9wcm92aWRlci1icmlkZ2UudGVzdC5janNQSwECFAMUAAAACACNs3ldOSxwBQkGAAAdFAAASwAAAAAAAAAAAAAApIG6UgEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFU1RTL3Rlc3RfY2FydHJpZGdlLnB5UEsBAhQDFAAAAAgAqbN5XakdTKt/BQAASg8AAFEAAAAAAAAAAAAAAKSBLFkBAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy90ZXN0X2RlZmF1bHRfcmVsZWFzZS5weVBLAQIUAxQAAAAIAI2zeV0/17WkawIAADAGAABYAAAAAAAAAAAAAACkgRpfAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVTVFMvdGVzdF9wcm92aWRlcl9jYXBhYmlsaXR5X3YzLnB5UEsBAhQDFAAAAAgAjbN5XaUS4D7RAgAA/QYAAE4AAAAAAAAAAAAAAKSB+2EBAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9URVNUUy90ZXN0X3JlbGVhc2VfcGxhbi5weVBLAQIUAxQAAAAIAI2zeV1usDuyygQAAGcNAABRAAAAAAAAAAAAAACkgThlAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVEVTVFMvdGVzdF9zZXJ2aWNlX3J1bnRpbWUucHlQSwECFAMUAAAACACNs3ldUo7iSXUCAABtBQAAVwAAAAAAAAAAAAAApIFxagEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RFU1RTL3RydXN0ZWQtZnJhbWUtcm91dGVyLnRlc3QuY2pzUEsBAhQDFAAAAAgApLN5XbXPgQ71EQAAmzMAAEYAAAAAAAAAAAAAAKSBW20BAENJVFkuTElOSy5URVJNSU5BTC5DQVJUUklER0UuREVWRUxPUEVSLkJBQ0tQQUNLLjAwNS9UT09MUy9jYXJ0cmlkZ2UucHlQSwECFAMUAAAACACks3ldfJew8mkHAAAiEAAASQAAAAAAAAAAAAAApIG0fwEAQ0lUWS5MSU5LLlRFUk1JTkFMLkNBUlRSSURHRS5ERVZFTE9QRVIuQkFDS1BBQ0suMDA1L1RPT0xTL3JlbGVhc2VfcGxhbi5weVBLAQIUAxQAAAAIAI2zeV0aWsLMowEAAIkCAABMAAAAAAAAAAAAAACkgYSHAQBDSVRZLkxJTksuVEVSTUlOQUwuQ0FSVFJJREdFLkRFVkVMT1BFUi5CQUNLUEFDSy4wMDUvVE9PTFMvdmVyaWZ5X2JhY2twYWNrLnB5UEsFBgAAAABDAEMAIiIAAJGJAQAAAA=="},"catalog.py":{"sha256":"e917237e0154a848019cc44fe4100efbc3bdae0942ff6af016be1f34f99afa54","base64":"IiIiRGV0ZXJtaW5pc3RpYyBjb250ZW50LWFkZHJlc3NlZCByZWZlcmVuY2Ugc2hlbGYuIE5vIExMTSwgbmV0d29yaywgb3IgZXhlY3V0YWJsZSBsb2FkaW5nLiIiIgppbXBvcnQgaGFzaGxpYixqc29uLG9zLHJlLHN0YXQsdGVtcGZpbGUKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCgpkZWYgc2hhKGIpOnJldHVybiBoYXNobGliLnNoYTI1NihiKS5oZXhkaWdlc3QoKQpkZWYgcmVxdWlyZShvayxjb2RlKToKICAgIGlmIG5vdCBvazpyYWlzZSBWYWx1ZUVycm9yKGNvZGUpCmRlZiBwcml2YXRlX2RpcihwKToKICAgIHAubWtkaXIobW9kZT0wbzcwMCxleGlzdF9vaz1UcnVlKQogICAgcz1wLmxzdGF0KCk7cmVxdWlyZShzdGF0LlNfSVNESVIocy5zdF9tb2RlKSBhbmQgcy5zdF91aWQ9PW9zLmdldHVpZCgpIGFuZCBub3Qgcy5zdF9tb2RlJjBvMDc3LCdQUklWQVRFX0RJUkVDVE9SWV9SRVFVSVJFRCcpCmRlZiByZWFkKHAsbGltaXQ9MioxMDI0KjEwMjQpOgogICAgZmQ9b3Mub3BlbihwLG9zLk9fUkRPTkxZfG9zLk9fTk9GT0xMT1d8b3MuT19OT05CTE9DSykKICAgIHRyeToKICAgICAgICBzPW9zLmZzdGF0KGZkKTtyZXF1aXJlKHN0YXQuU19JU1JFRyhzLnN0X21vZGUpIGFuZCBzLnN0X3VpZD09b3MuZ2V0dWlkKCkgYW5kIHMuc3Rfc2l6ZTw9bGltaXQsJ0ZJTEVfU0NPUEUnKQogICAgICAgIHdpdGggb3MuZmRvcGVuKGZkLCdyYicsY2xvc2VmZD1GYWxzZSkgYXMgZjpiPWYucmVhZChsaW1pdCsxKQogICAgICAgIHJlcXVpcmUobGVuKGIpPD1saW1pdCwnRklMRV9MSU1JVCcpO3JldHVybiBiCiAgICBmaW5hbGx5Om9zLmNsb3NlKGZkKQpkZWYgcHV0KHAsYik6CiAgICBmZCx0bXA9dGVtcGZpbGUubWtzdGVtcChwcmVmaXg9Jy5hcnRpZmFjdC0nLGRpcj1wLnBhcmVudCkKICAgIHRyeToKICAgICAgICB3aXRoIG9zLmZkb3BlbihmZCwnd2InKSBhcyBmOmYud3JpdGUoYik7Zi5mbHVzaCgpO29zLmZzeW5jKGYuZmlsZW5vKCkpCiAgICAgICAgdHJ5Om9zLmxpbmsodG1wLHApCiAgICAgICAgZXhjZXB0IEZpbGVFeGlzdHNFcnJvcjpyZXF1aXJlKHJlYWQocCk9PWIsJ0VYSVNUSU5HX0NPTlRFTlRfTUlTTUFUQ0gnKQogICAgICAgIGQ9b3Mub3BlbihwLnBhcmVudCxvcy5PX1JET05MWXxvcy5PX0RJUkVDVE9SWSkKICAgICAgICB0cnk6b3MuZnN5bmMoZCkKICAgICAgICBmaW5hbGx5Om9zLmNsb3NlKGQpCiAgICBmaW5hbGx5Om9zLnVubGluayh0bXApCmRlZiBrZXkoayk6CiAgICByZXF1aXJlKGlzaW5zdGFuY2UoayxzdHIpIGFuZCByZS5mdWxsbWF0Y2gocidbYS16MC05XVthLXowLTkuLV17MCw3OX0nLGspLCdJTlZBTElEX1JFRkVSRU5DRScpO3JldHVybiBrCmNsYXNzIFNoZWxmOgogICAgZGVmIF9faW5pdF9fKHNlbGYscm9vdCk6CiAgICAgICAgc2VsZi5yb290PVBhdGgocm9vdCk7cHJpdmF0ZV9kaXIoc2VsZi5yb290KQogICAgICAgIHNlbGYuYmxvYnM9c2VsZi5yb290LydzaGEyNTYnO3NlbGYucmVmcz1zZWxmLnJvb3QvJ3JlZnMnO3ByaXZhdGVfZGlyKHNlbGYuYmxvYnMpO3ByaXZhdGVfZGlyKHNlbGYucmVmcykKICAgIGRlZiByZWdpc3RlcihzZWxmLHJlY29yZCxiKToKICAgICAgICBrPWtleShyZWNvcmRbJ2tleSddKTtwaW49cmVjb3JkWydzaGEyNTYnXTtyZXF1aXJlKHJlLmZ1bGxtYXRjaCgnW2EtZjAtOV17NjR9JyxwaW4pIGFuZCBsZW4oYik9PXJlY29yZFsnc2l6ZSddIGFuZCBzaGEoYik9PXBpbiwnQVJUSUZBQ1RfUElOJykKICAgICAgICBtZXRhPShqc29uLmR1bXBzKHJlY29yZCxzb3J0X2tleXM9VHJ1ZSxpbmRlbnQ9MikrJ1xuJykuZW5jb2RlKCkKICAgICAgICB0YXJnZXQ9c2VsZi5yZWZzLyhrKycuanNvbicpOwogICAgICAgIGlmIHRhcmdldC5leGlzdHMoKSBvciB0YXJnZXQuaXNfc3ltbGluaygpOnJlcXVpcmUocmVhZCh0YXJnZXQpPT1tZXRhLCdSRUZFUkVOQ0VfQ09ORkxJQ1QnKQogICAgICAgIHB1dChzZWxmLmJsb2JzL3BpbixiKTtwdXQodGFyZ2V0LG1ldGEpCiAgICAgICAgcmV0dXJuIHNlbGYubG9va3VwKGspCiAgICBkZWYgbG9va3VwKHNlbGYsayk6CiAgICAgICAgcj1qc29uLmxvYWRzKHJlYWQoc2VsZi5yZWZzLyhrZXkoaykrJy5qc29uJyksMTYzODQpKTtwaW49clsnc2hhMjU2J107cmVxdWlyZShyWydrZXknXT09ayBhbmQgcmUuZnVsbG1hdGNoKCdbYS1mMC05XXs2NH0nLHBpbiksJ1JFRkVSRU5DRV9JTlZBTElEJykKICAgICAgICBiPXJlYWQoc2VsZi5ibG9icy9waW4pO3JlcXVpcmUobGVuKGIpPT1yWydzaXplJ10gYW5kIHNoYShiKT09cGluLCdBUlRJRkFDVF9QSU4nKTtyZXR1cm4gcixiCg=="},"revision_base.py":{"sha256":"60d4dbd3d75ff077b95020c39599b071fce35477614e6029c124818441b62118","base64":"IiIiVHJ1c3RlZCByZWFkLW9ubHkgYmFzZWxpbmUgcmVzb2x1dGlvbi4gTmV2ZXIgZXhlY3V0ZXMgY2FydHJpZGdlIGFzc2V0cy4iIiIKaW1wb3J0IGlvLGpzb24scmUsc3lzLHppcGZpbGUKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmZyb20gY2F0YWxvZyBpbXBvcnQgU2hlbGYscmVhZCxzaGEscmVxdWlyZQpmcm9tIGNhbmRpZGF0ZSBpbXBvcnQgQVNTRVQsSUQsVkVSCgpkZWYgcmVzb2x2ZShzaGVsZixpbnN0YWxsZWQsY2lkKToKICAgIHJlcXVpcmUoYm9vbChJRC5mdWxsbWF0Y2goY2lkKSkgYW5kIGNpZCBub3QgaW4geydjbGluay10ZXJtaW5hbCcsJ2NvbnZleW9yLWNsdWInLCdtb2RlbC1mYWN0b3J5JywncGhhbnRvbXRyb25peC1jb21tYW5kJ30sJ0lEX1NDT1BFJykKICAgIHJvb3Q9aW5zdGFsbGVkL2NpZDtyZXF1aXJlKHJvb3QuaXNfZGlyKCkgYW5kIG5vdCByb290LmlzX3N5bWxpbmsoKSwnSU5TVEFMTEVEX01JU1NJTkcnKQogICAgcmF3PXJlYWQocm9vdC8nbWFuaWZlc3QuanNvbicsNjU1MzYpO209anNvbi5sb2FkcyhyYXcpO3Y9bVsndmVyc2lvbiddO3JlcXVpcmUobVsnaWQnXT09Y2lkIGFuZCBtWydydW50aW1lJ109PSd3ZWInIGFuZCBtWydlbnRyeSddPT0nd2ViL2luZGV4Lmh0bWwnIGFuZCBub3QgbS5nZXQoJ2NhcGFiaWxpdGllcycpIGFuZCBWRVIuZnVsbG1hdGNoKHYpLCdCQVNFX1NDT1BFJykKICAgIHJlcXVpcmUoc2hlbGYuaXNfZGlyKCkgYW5kIG5vdCBzaGVsZi5pc19zeW1saW5rKCksJ1NIRUxGX01JU1NJTkcnKQogICAgcmVjb3JkLGI9U2hlbGYoc2hlbGYpLmxvb2t1cChjaWQrJy4nK3YpO3JlcXVpcmUocmVjb3JkWydzaGEyNTYnXT09c2hhKGIpLCdCQVNFX1BJTicpCiAgICB3aXRoIHppcGZpbGUuWmlwRmlsZShpby5CeXRlc0lPKGIpKSBhcyB6OgogICAgICAgIHJlcXVpcmUoei5yZWFkKCdtYW5pZmVzdC5qc29uJyk9PXJhdyBhbmQgc2V0KHoubmFtZWxpc3QoKSk9PXNldChtWydmaWxlcyddKXx7J21hbmlmZXN0Lmpzb24nfSBhbmQgbGVuKHoubmFtZWxpc3QoKSk9PWxlbihzZXQoei5uYW1lbGlzdCgpKSksJ0JBU0VfTUFOSUZFU1QnKQogICAgICAgIGFzc2V0cz17fQogICAgICAgIGZvciBuLGggaW4gbVsnZmlsZXMnXS5pdGVtcygpOgogICAgICAgICAgICByZXF1aXJlKGJvb2woQVNTRVQuZnVsbG1hdGNoKG4pKSwnQkFTRV9BU1NFVCcpO3A9cm9vdC9uO3JlcXVpcmUoYWxsKG5vdCB4LmlzX3N5bWxpbmsoKSBmb3IgeCBpbiBwLnBhcmVudHMgaWYgeCE9cm9vdC5wYXJlbnQgYW5kIHJvb3QgaW4geC5wYXJlbnRzKSwnQkFTRV9QQVRIJyk7ZGF0YT16LnJlYWQobik7cmVxdWlyZShzaGEoZGF0YSk9PWggYW5kIHJlYWQocCw2NTUzNik9PWRhdGEsJ0JBU0VfRFJJRlQnKTthc3NldHNbbl09ZGF0YS5kZWNvZGUoJ3V0ZjgnKQogICAgICAgIHJlcXVpcmUoc3VtKGxlbih4LmVuY29kZSgpKSBmb3IgeCBpbiBhc3NldHMudmFsdWVzKCkpPD0yNDAwMCwnQkFTRV9JTlBVVF9MSU1JVCcpCiAgICBhLGJ2LGM9bWFwKGludCx2LnNwbGl0KCcuJykpO3JlcXVpcmUoYzw5OTk5OTksJ1ZFUlNJT05fTElNSVQnKTtncmFudD17J2lkJzpjaWQsJ25hbWUnOm1bJ25hbWUnXSwndmVyc2lvbic6Zid7YX0ue2J2fS57YysxfScsJ2luc3RhbGxlZF92ZXJzaW9uJzp2LCdiYXNlX3NoYTI1Nic6cmVjb3JkWydzaGEyNTYnXX0KICAgIHJldHVybiB7J2dyYW50JzpncmFudCwnZmlsZXMnOmFzc2V0cywnYmFzZWxpbmUnOnN0cihzaGVsZi8nc2hhMjU2Jy9yZWNvcmRbJ3NoYTI1NiddKX0KaWYgX19uYW1lX189PSdfX21haW5fXyc6CiAgICB0cnk6cHJpbnQoanNvbi5kdW1wcyhyZXNvbHZlKFBhdGgoc3lzLmFyZ3ZbMV0pLFBhdGgoc3lzLmFyZ3ZbMl0pLHN5cy5hcmd2WzNdKSxlbnN1cmVfYXNjaWk9RmFsc2UpKQogICAgZXhjZXB0IEV4Y2VwdGlvbjpzeXMuZXhpdCgxKQo="}};
let ce007Service=null;
function ce007PrivateDir(p){const st=fs.lstatSync(p);if(!st.isDirectory()||st.isSymbolicLink()||(st.mode&0o077)!==0||st.uid!==process.getuid())throw Error('ENGINEERING_PRIVATE_DIRECTORY');}
function ce007Dir(p){try{fs.mkdirSync(p,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}ce007PrivateDir(p);}
function ce007CheckBundle(dir){ce007PrivateDir(dir);const names=Object.keys(ce007Bundle).sort();if(JSON.stringify(fs.readdirSync(dir).sort())!==JSON.stringify(names))throw Error('ENGINEERING_BUNDLE_MEMBERS');for(const n of names){const p=path.join(dir,n),s=fs.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||(s.mode&0o077)!==0||s.uid!==process.getuid()||crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')!==ce007Bundle[n].sha256)throw Error('ENGINEERING_BUNDLE_PIN');}}
function ce007Initialize(){
 const root=path.join(PROFILE_ROOT,'command-development-service');ce007Dir(root);
 const dir=path.join(root,'v2-013');
 if(!fs.existsSync(dir)){
   const stage=fs.mkdtempSync(path.join(root,'.bundle-'));try{for(const [n,v] of Object.entries(ce007Bundle)){const data=Buffer.from(v.base64,'base64');if(crypto.createHash('sha256').update(data).digest('hex')!==v.sha256)throw Error('ENGINEERING_EMBEDDED_PIN');const fd=fs.openSync(path.join(stage,n),'wx',0o600);try{fs.writeFileSync(fd,data);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}ce007CheckBundle(stage);fs.renameSync(stage,dir);}finally{if(fs.existsSync(stage))fs.rmSync(stage,{recursive:true,force:true});}
 }
 ce007CheckBundle(dir);
 const state=path.join(root,'jobs');ce007Dir(state);
 const {createNativeBridge}=require(path.join(dir,'native_bridge.cjs'));
 ce007Service=createNativeBridge({legacy:{handle:async()=>null},scope:ce007Scope,stateDir:state,bundleDir:dir,
  shelfRoot:path.join(app.getPath('home'),'.local','share','phantomtronix','command-artifacts'),installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
  exists:id=>fs.existsSync(path.join(PANELS_ROOT,'plugins',id))||fs.existsSync(path.join(PROFILE_ROOT,'panels','installed-plugins',id)),
  approve:async a=>{if(!windowMain||windowMain.isDestroyed())return false;const r=await dialog.showMessageBox(windowMain,{type:'question',title:'Miss Flower — cartridge engineering',message:'Authorize development of '+a.grant.name+'?',detail:(a.grant.base_sha256?'Revise existing static utility '+a.grant.id+' from '+a.grant.installed_version+' to '+a.grant.version+'. ':'Create a new static utility cartridge, '+a.grant.id+' '+a.grant.version+'. ')+'One OpenAI '+a.model+' request; estimated maximum $0.03, not a provider billing guarantee. No automatic retry, installation or publication. Keep Command open.\n\nHuman request: '+a.request,buttons:['Cancel','Authorize one development request'],defaultId:0,cancelId:0,noLink:true});return r.response===1;}
 });
}
const ce007Dispatch=Object.freeze({async handle(req){
 const old=await dh025Recovery.handle(req);if(old!==null)return old;
 // Only natural-language engineering intake triggers initialization. Existing ordinary chat stays unchanged.
 if(!ce007IsDevelopment(req.text))return null;
 req.authorize();
 try{if(!ce007Service)ce007Initialize();return await ce007Service.handle(req);}catch(e){return {text:'C.Link: Engineering request stopped. No installation or publication occurred. Saved job records, if any, remain available.'};}
}});

const providerAdapters = new ProviderAdapterRegistry({transport:ce007Scope.transport,secretStore:providerSecrets,usageLedger:apiUsage,defaultUsageContext:{companionId:'clink-system',missionId:MISSION,workerId:null,purpose:'api_request'},logger:log});
const universalCompanion = new UniversalCompanionPrimary({adapterRegistry:providerAdapters,backpackManager,missionId:MISSION,logger:log});
const companionTurnSeat = new CompanionTurnSeat({primary:universalCompanion,backpackManager});
if(!activationColdRecovery.ok)companionTurnSeat.disable('STARTUP_ACTIVATION_RECOVERY_FAILED');
const contextBuilder = new CompanionContextBuilder({profileRoot:PROFILE_ROOT,seed:COMPANION_STORE_SEED,bootId:TERMINAL_SESSION_ID,logger:log});
const contextBuilderBootState = contextBuilder.initialize();
function alphaShadowRunner(){return new AlphaShadowRunner({adapterRegistry:providerAdapters,context:contextBuilder.build(),usageContext:{companionId:'alpha007',missionId:MISSION,workerId:null,purpose:'alpha_reasoning'},logger:log});}
function alphaPrimaryRunner(){return new AlphaPrimaryRunner({adapterRegistry:providerAdapters,contextBuilder,bootId:TERMINAL_SESSION_ID,missionId:MISSION,logger:log});}
const apiPrimarySoak = new ApiPrimarySoak({profileRoot:PROFILE_ROOT,bootId:TERMINAL_SESSION_ID,contextFingerprint:contextBuilderBootState.contextFingerprint,logger:log});
const readOnlyWorkers = new ReadOnlyWorkerExperiment({profileRoot:PROFILE_ROOT,adapterRegistry:providerAdapters,contextBuilder,usageLedger:apiUsage,missionId:R8_MISSION,logger:log});
const round9 = new Round9Reconciliation({profileRoot:PROFILE_ROOT,adapterRegistry:providerAdapters,contextBuilder,usageLedger:apiUsage,r8Experiment:readOnlyWorkers,bootId:TERMINAL_SESSION_ID,missionId:MISSION,logger:log});
let alphaRecentTurns=[];
function primaryTransportReady(){
  const status=providerSecrets.status('openai');
  return status.configured===true&&status.storage==='SECURE_OS_USER';
}
function grokUserCompanionReady(){
  const status=providerSecrets.status('xai');
  return status.configured===true&&status.storage==='SECURE_OS_USER'&&status.state==='READY';
}
function grokUserCompanionSnapshot(extra={}){
  return {
    schema:'CLINK_GROK_USER_COMPANION_SHADOW_V1',
    status:grokUserCompanionReady()?'READY':'NOT_CONFIGURED',
    mode:'EXPLICIT_SHADOW_COMMAND',provider:'xai',model:'grok-4.3',
    companionId:String(backpackManager.snapshot()?.userCompanion?.id||''),
    continuityAuthority:'USER_COMPANION_BACKPACK',providerConversationAuthority:false,persistProviderSessionIds:false,
    technicalRelay:'HOSTED_SPECIALIST_TABS',repairExecution:'OFF',defaultRoutingChanged:false,
    ...extra
  };
}
function apiPrimarySnapshot(extra={}){
  const status=primaryTransportReady()?'READY':'NOT_CONFIGURED';
  return {
    schema:'CLINK_API_PRIMARY_STATE_V1',status,mode:'API_PRIMARY',provider:'openai',model:'gpt-5.6-luna',
    continuityAuthority:'CLINK_BACKPACK',providerConversationAuthority:false,persistProviderSessionIds:false,
    humanSurface:'CLINK_TERMINAL',hostedBrowser:'FALLBACK',repairExecution:'OFF',bootId:TERMINAL_SESSION_ID,
    contextFingerprint:contextBuilder.snapshot().contextFingerprint,soak:apiPrimarySoak.snapshot(),...extra
  };
}

const packageStore = new RelayPackageStore({ profileRoot:PROFILE_ROOT, logger:log });
function relayLog(event, data = {}) {
  log(event,data);
  clearTimeout(broadcastTimer);
  broadcastTimer = setTimeout(() => broadcast(), 25);
}
const relay = new AgentRelay({ admissionGate:admitRepairProposal, packageStore, logger:relayLog });

let a007HostedFieldProbeStarted=false;
const A007_HOSTED_FIELD_PROBE=process.env.CLINK_A007_HOSTED_FIELD_PROBE==='1';
let a007GrokFieldProbeStarted=false;
const A007_GROK_FIELD_PROBE=process.env.CLINK_A007_GROK_FIELD_PROBE==='1';

const coreState = {
  build:BUILD,
  mission:MISSION,
  core:{status:'BOOTING',detail:'Vanilla Terminal core is starting.'},
  repair:{status:'READY',detail:'Browser-owned reasoning is active; repair execution is OFF.',mode:'BROWSER_CONTROL_EXECUTION_DISABLED'},
  panels:{
    status:'NOT_STARTED',attempt:0,quarantined:false,detail:'PANELS OS has not started.',plugins:[],
    providerProbe:{status:'R28B_PRIMARY_OPERATING_SURFACE',detail:'R27A2 field-proven browser/auth baseline preserved; Core owns provider workspace/chat lifecycle and six canonical slots.'},
    providerRuntime:{}
  },
  companion:bootstrapBackpackState.userCompanion?{status:'DISCOVERED',detail:'Companion is waiting for lifecycle.'}:{status:'NO_COMPANION_LOADED',detail:'Load and activate a canonical backpack in Settings > Companions.'},
  companionCore:companionOrchestrator.snapshot(),
  providerLifecycle:{status:'NOT_STARTED',detail:'C.LINK REASONING provider workspace lifecycle has not synchronized yet.',progress:null,lastError:''},
  inlineAuth:{status:'IDLE',detail:'Hosted provider authentication is not active.',url:'',title:''},
  messageQualification:restoredQualification(),
  apiProviders:{mode:'API_PRIMARY_OPENAI_WITH_HOSTED_FALLBACK',round:9,storage:'MAIN_PROCESS_SAFE_STORAGE',primaryProvider:'openai',browserFallback:'HOSTED_CHATGPT_WEB_MANUAL',rounds1to8Field:'PASS',adapters:providerAdapters.defaults()},
  apiPrimary:apiPrimarySnapshot({fieldStatus:'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status}),
  apiWorkers:{...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD},
  round9:round9.snapshot(),
  apiShadow:{status:'FIELD_PROVEN_R4D',detail:API_R4_FIELD.detail,provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null},
  grokUserCompanion:grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:null}),
  apiContext:{...contextBuilderBootState,fieldEvidence:API_R5_FIELD,reconstruction:{status:'FIELD_PROVEN_R5',detail:'Round 5 restart and reconstruction are field-proven.',...API_R5_FIELD.reconstruction}},
  apiUsage:apiUsage.summary(),
  relay:relay.snapshot()
};

function snapshot() {
  coreState.dualBackpacks=backpackManager.snapshot();
  coreState.relay = relay.snapshot();
  coreState.companionCore = companionOrchestrator.snapshot();
  coreState.apiUsage = apiUsage.summary();
  coreState.apiWorkers = {...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD};
  coreState.round9 = round9.snapshot();
  coreState.apiPrimary = apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null,fieldStatus:coreState.apiPrimary?.fieldStatus||'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status});
  coreState.grokUserCompanion = grokUserCompanionSnapshot({fieldStatus:coreState.grokUserCompanion?.fieldStatus||'SHADOW_FIELD_PENDING',lastTurn:coreState.grokUserCompanion?.lastTurn||null});
  return JSON.parse(JSON.stringify(coreState));
}
function broadcast() {
  if (windowMain && !windowMain.isDestroyed()) windowMain.webContents.send('clink:state-changed', snapshot());
}
function refreshCompanionState() {
  const apiReady=primaryTransportReady();
  const hostedProvider=(coreState.panels.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  coreState.apiPrimary=apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null,fieldStatus:coreState.apiPrimary?.fieldStatus||'R7_FIELD_PROVEN',fieldEvidence:API_R7_FIELD,hiveRelease:HIVE_R7_RELEASE.status});
  const hostedReady=coreState.providerLifecycle?.status==='READY';
  coreState.companion={
    status:(apiReady||hostedReady)?'READY':'DEGRADED',
    detail:apiReady
      ? `Companion API PRIMARY is ready through OpenAI; hosted browser is FALLBACK. Hosted lifecycle=${coreState.providerLifecycle?.status||'NOT_STARTED'}; repair execution OFF.`
      : (hostedReady
        ? 'Hosted ChatGPT reasoning is READY on this seat; API PRIMARY is not configured, so ordinary turns use the persistent hosted provider.'
        : 'No reasoning transport is ready yet. API PRIMARY is not configured and hosted browser lifecycle is not READY.')
  };
  coreState.apiPrimary.hostedBrowserStatus=hostedProvider?.status==='READY'?'AVAILABLE':'STANDBY';
}

function setPanels(state) {
  coreState.panels = state;
  refreshCompanionState();
  broadcast();
  const provider=(state.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  // Quin fork: no automatic provider authentication probing on initial boot.
  // Only an explicit Human action starts the inherited provider lifecycle.

}


function layoutWebPlugin(){
  if(!webPluginView||!windowMain||windowMain.isDestroyed())return;
  const [width,height]=windowMain.getContentSize();
  webPluginView.setBounds({x:0,y:60,width:Math.max(1,width),height:Math.max(1,height-60)});
}
function closeWebPlugin(){
  ce007Scope.cancel();dh025Recovery.cancel('CARTRIDGE_CLOSED');developmentAcceptance.cancel();
  cartridgeVoiceHost?.revoke();
  if(activeWebService){servicePlugins.stop(activeWebService);activeWebService=null;}
  if(!webPluginView)return;
  try{windowMain?.contentView.removeChildView(webPluginView);}catch(_){}
  try{webPluginView.webContents.close();}catch(_){}
  webPluginView=null;webPluginId=null;
}
function layoutInlineAuthView(){
  if(!windowMain||windowMain.isDestroyed()||!inlineAuthView)return;
  const [width,height]=windowMain.getContentSize();
  const left=Math.round(width*0.385)+12;
  const top=190;
  const rightPad=12;
  const bottomPad=72;
  inlineAuthView.setBounds({
    x:left,
    y:top,
    width:Math.max(520,width-left-rightPad),
    height:Math.max(320,height-top-bottomPad)
  });
}
function removeInlineAuthView(){
  if(inlineAuthPoll){clearInterval(inlineAuthPoll);inlineAuthPoll=null;}
  if(!inlineAuthView)return;
  try{if(windowMain&&!windowMain.isDestroyed())windowMain.contentView.removeChildView(inlineAuthView);}catch(_){}
  try{inlineAuthView.webContents.close();}catch(_){}
  inlineAuthView=null;inlineAuthActive=false;
}
async function inlineAuthSnapshot(){
  if(!inlineAuthView)return null;
  try{return await inlineAuthView.webContents.executeJavaScript(`(() => {
    const visible=el=>{if(!el)return false;const s=getComputedStyle(el),r=el.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;};
    const prompt=[document.querySelector('#prompt-textarea'),...document.querySelectorAll('div.ProseMirror[contenteditable="true"],textarea,[contenteditable="true"]')].find(visible)||null;
    const loginSignals=(/\\/auth\\/login/i.test(location.pathname)?3:0)+([...document.querySelectorAll('button,a')].filter(visible).filter(el=>/log in|sign up|continue with google|continue with apple|continue with phone/i.test(String(el.innerText||el.textContent||el.getAttribute('aria-label')||''))).length);
    return {url:location.href,title:document.title||'',path:location.pathname||'',promptVisible:!!prompt,loginSignals};
  })()`,true);}catch(_){return null;}
}
async function finishInlineAuthSuccess(snapshot){
  if(!inlineAuthActive)return;
  writeProviderAuthState({
    status:'AUTHENTICATED',
    lastAuthSuccessAt:new Date().toISOString(),
    lastAuthSuccessUrl:snapshot?.url||'',
    lastAuthSuccessTitle:snapshot?.title||'',
    loginPolicy:'HUMAN_EXPLICIT_ONLY'
  });
  await flushProviderSession('AUTH_SUCCESS');
  log('provider.inline-auth.success',{url:snapshot?.url||'',title:snapshot?.title||'',persistent:true});
  coreState.inlineAuth={status:'PASS',detail:'Hosted ChatGPT authentication restored and persisted inside C.Link.',url:snapshot?.url||'',title:snapshot?.title||''};
  removeInlineAuthView();refreshCompanionState();broadcast();
  setTimeout(()=>syncProviderLifecycle(true).catch(error=>log('provider.inline-auth.resync.error',{error:String(error.message||error)})),900);
}
async function startInlineAuthRecovery(reason='AUTH_REQUIRED'){
  if(inlineAuthActive||!windowMain||windowMain.isDestroyed()||!browserRuntime)return;
  inlineAuthActive=true;
  writeProviderAuthState({
    status:'AUTH_IN_PROGRESS',
    lastAuthAttemptAt:new Date().toISOString(),
    lastAuthAttemptReason:reason,
    loginPolicy:'HUMAN_EXPLICIT_ONLY'
  });
  const ses=browserRuntime.getSession();
  inlineAuthView=new WebContentsView({webPreferences:{session:ses,contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
  inlineAuthView.setBackgroundColor('#111111');
  windowMain.contentView.addChildView(inlineAuthView);layoutInlineAuthView();
  inlineAuthView.webContents.setWindowOpenHandler(({url})=>{
    try{const u=new URL(url);if(u.protocol==='https:')setTimeout(()=>{try{inlineAuthView?.webContents.loadURL(url);}catch(_){}},0);}catch(_){}
    return{action:'deny'};
  });
  const report=async()=>{
    const snap=await inlineAuthSnapshot();if(!snap)return;
    coreState.inlineAuth={status:'ACTIVE',detail:'ChatGPT inside Quin. Sign in here only if the existing persistent session requires it.',url:snap.url||'',title:snap.title||''};
    refreshCompanionState();broadcast();
    const ok=String(snap.url||'').startsWith('https://chatgpt.com/')&&!String(snap.url||'').includes('/auth/login')&&snap.promptVisible&&Number(snap.loginSignals||0)===0;
    if(ok)await finishInlineAuthSuccess(snap);
  };
  inlineAuthView.webContents.on('dom-ready',()=>report().catch(()=>{}));
  // For manual opening, probe the inherited persistent session FIRST.
  // Do not force a new authentication or repeatedly visit /auth/login.
  const loginUrl=reason==='HUMAN_EXPLICIT'?'https://chatgpt.com/':'https://chatgpt.com/auth/login';
  coreState.inlineAuth={status:'ACTIVE',detail:'ChatGPT open inside Quin. Using existing persistent session; sign in only if required.',url:loginUrl,title:''};
  if(reason!=='HUMAN_EXPLICIT') coreState.providerLifecycle={...coreState.providerLifecycle,status:'AUTH_REQUIRED',detail:`Hosted provider authentication required: ${reason}`,lastError:reason};
  log('provider.inline-auth.opened',{reason,mode:'INLINE_MAIN_WINDOW',popup:false,targetUrl:loginUrl});refreshCompanionState();broadcast();
  inlineAuthView.webContents.on('did-navigate',(_event,url)=>{log('provider.inline-auth.navigation',{url:String(url||''),kind:'DOCUMENT'});report().catch(()=>{});});
  inlineAuthView.webContents.on('did-navigate-in-page',(_event,url)=>{log('provider.inline-auth.navigation',{url:String(url||''),kind:'IN_PAGE'});report().catch(()=>{});});
  await inlineAuthView.webContents.loadURL(loginUrl);
  inlineAuthPoll=setInterval(()=>report().catch(()=>{}),1000);
}

async function syncProviderLifecycle(force=false){
  // Do not start hosted provider lifecycle or hydration without a real Companion.
  if(!backpackManager.snapshot()?.userCompanion)return{ok:false,error:'NO_COMPANION_LOADED',providerInvoked:false};
  if(lifecycleSyncPromise&&!force)return lifecycleSyncPromise;
  if(!providerReady())throw new Error('COMPANION_PROVIDER_NOT_READY');
  lifecycleSyncPromise=(async()=>{
    const bags=backpackManager.refresh();
    companionOrchestrator.initialize(bags);
    coreState.companionCore=companionOrchestrator.snapshot();
    const startedAt=new Date().toISOString();
    coreState.providerLifecycle={status:'RUNNING',detail:'Locating/creating C.LINK REASONING and synchronizing six canonical chats.',progress:null,lastError:'',startedAt};refreshCompanionState();broadcast();
    try{
      const plan=companionOrchestrator.lifecyclePlan();
      const hydration={userCompanion:backpackManager.hydrationPacket('userCompanion'),systemControl:backpackManager.hydrationPacket('systemControl')};
      const result=await panels.requestLifecycle(plan,{stallTimeoutMs:120000,hydration,onProgress:progress=>{
        if(progress?.stage==='WORKSPACE_READY'&&progress?.data?.projectId&&progress?.data?.projectUrl){
          companionOrchestrator.recordWorkspace({
            projectId:progress.data.projectId,
            projectUrl:progress.data.projectUrl,
            status:'READY',
            health:'HEALTHY'
          });
          log('provider.lifecycle.workspace.persisted',{
            projectId:progress.data.projectId,
            projectUrl:progress.data.projectUrl,
            phase:'WORKSPACE_READY'
          });
        }
        coreState.providerLifecycle={...coreState.providerLifecycle,status:'RUNNING',progress,detail:progress?.detail||'Synchronizing provider lifecycle.',lastEventAt:new Date().toISOString()};refreshCompanionState();log('provider.lifecycle.progress',progress||{});broadcast();
      }});
      companionOrchestrator.applyLifecycleResult(result||{});
      for(const item of Array.isArray(result?.scratch)?result.scratch:[])if(item?.ok&&item?.id&&item?.conversationUrl)companionOrchestrator.recordScratchConversation(item.id,item.conversationUrl,{providerConversationId:item.conversationId,projectId:item.projectId,projectUrl:item.projectUrl});
      const registry=companionOrchestrator.snapshot();
      const allReady=Object.values(registry.chats||{}).length===6&&Object.values(registry.chats||{}).every(chat=>chat.status==='READY'&&chat.health==='HEALTHY');
      coreState.providerLifecycle={status:allReady&&result?.status==='READY'?'READY':'DEGRADED',detail:allReady?'C.LINK REASONING and all six canonical chats are READY.':'Provider lifecycle completed with one or more degraded canonical chats.',progress:null,lastError:'',result,startedAt,completedAt:new Date().toISOString()};
      coreState.companionCore=registry;refreshCompanionState();log('provider.lifecycle.complete',{status:coreState.providerLifecycle.status,result});broadcast();
      if(A007_HOSTED_FIELD_PROBE&&coreState.providerLifecycle.status==='READY'&&!a007HostedFieldProbeStarted){
        a007HostedFieldProbeStarted=true;
        setTimeout(async()=>{
          log('a007.hosted.field-probe.start',{round:288,prompt:'Hello. Who are you?'});
          let probe;
          try{probe=await hostedCompanionMessage('Hello. Who are you?');}
          catch(error){probe={ok:false,error:String(error.message||error)};}
          log('a007.hosted.field-probe.complete',{
            round:288,ok:probe?.ok===true,mode:String(probe?.mode||''),
            reply:String(probe?.reply||'').slice(0,2000),error:String(probe?.error||'')
          });
        },350);
      }
      if(A007_GROK_FIELD_PROBE&&coreState.providerLifecycle.status==='READY'&&grokUserCompanionReady()&&!a007GrokFieldProbeStarted){
        a007GrokFieldProbeStarted=true;
        setTimeout(async()=>{
          const prompt='I want to know whether Grok is ready to become my everyday User Companion in C.Link. This is a technical decision, so do not decide it alone. Use your specialist tabs to challenge the migration, protect Alice\'s continuity and authority, reduce my operator steps, and then give me one final recommendation. Do not change anything on the machine.';
          log('a007.grok.field-probe.start',{round:306,promptChars:prompt.length,provider:'xai',model:'grok-4.3',repairExecution:'OFF'});
          let probe;
          try{probe=await grokUserCompanionMessage(prompt);}
          catch(error){probe={ok:false,error:String(error.message||error)};}
          log('a007.grok.field-probe.complete',{
            round:306,ok:probe?.ok===true,mode:String(probe?.mode||''),
            reply:String(probe?.reply||'').slice(0,3000),error:String(probe?.error||''),
            conclusion:probe?.conclusion||null,resolutionState:probe?.resolutionState||null
          });
          broadcast();
        },700);
      }
      return{ok:coreState.providerLifecycle.status==='READY',result,registry};
    }catch(error){
      const message=String(error.message||error);
      if(/AUTH_REUSE_INDETERMINATE|REAUTH_FORBIDDEN|AUTH_REUSE_CHALLENGE_TIMEOUT/.test(message)){
        const authState=readProviderAuthState();
        const persistenceFault=!!authState.lastAuthSuccessAt;
        writeProviderAuthState({
          status:persistenceFault?'SESSION_PERSISTENCE_FAULT':'AUTH_REQUIRED',
          lastAuthRequiredAt:new Date().toISOString(),
          lastAuthRequiredReason:message,
          persistenceFault,
          loginPolicy:'HUMAN_EXPLICIT_ONLY'
        });
        coreState.providerLifecycle={
          status:'AUTH_REQUIRED',
          detail:persistenceFault
            ? 'The persistent hosted session unexpectedly requires authentication. C.Link will not retry automatically.'
            : 'Hosted ChatGPT sign-in is required inside C.Link.',
          progress:null,lastError:message,startedAt,completedAt:new Date().toISOString(),
          persistenceFault
        };
        refreshCompanionState();
        log('provider.lifecycle.auth-required',{
          error:message,mode:'INLINE_MAIN_WINDOW',activation:'HUMAN_EXPLICIT',
          persistenceFault,lastAuthSuccessAt:authState.lastAuthSuccessAt||null
        });
        broadcast();
        return{ok:false,error:'INLINE_AUTH_REQUIRED',registry:companionOrchestrator.snapshot()};
      }
      coreState.providerLifecycle={status:'FAIL',detail:message,progress:null,lastError:message,startedAt,completedAt:new Date().toISOString()};refreshCompanionState();log('provider.lifecycle.fail',{error:message});broadcast();return{ok:false,error:message,registry:companionOrchestrator.snapshot()};
    }finally{lifecycleSyncPromise=null;}
  })();
  return lifecycleSyncPromise;
}


function companionContextSnapshot() {
  const relayPackage = packageStore.snapshot();
  return {
    schema: 'CLINK_COMPANION_TURN_CONTEXT_V1',
    canonical: CANONICAL_COMPANION_CONTEXT,
    runtime: {
      build: BUILD,
      mission: MISSION,
      coreStatus: coreState.core.status,
      panelsStatus: coreState.panels.status,
      companionStatus: coreState.companion.status,
      repairExecution: 'OFF',
      browserControl: 'ON',
      activeRelayPackage: relayPackage?.relayId ? relayPackage : { status: 'NONE' },
      dualBackpacks: backpackManager.snapshot(),
      reasoningRegistry: companionOrchestrator.snapshot(),
      providerLifecycle: coreState.providerLifecycle,
      messageQualification: coreState.messageQualification
    }
  };
}

function providerReady() {
  const provider=(coreState.panels.plugins||[]).find(p=>p.id==='reasoning-provider-chatgpt-web');
  return coreState.panels.status==='READY' && provider?.status==='READY';
}

function normalizeIncident(value, fallbackText='') {
  const source=value&&typeof value==='object'?value:{};
  const cleanList=v=>Array.isArray(v)?v.map(x=>String(x||'').slice(0,1800)).slice(0,32):[];
  return {
    summary:String(source.summary || fallbackText || 'Human requested specialist problem-solving relay.').slice(0,5000),
    failureFingerprint:String(source.failureFingerprint || `HUMAN_PROBLEM_${Date.now()}`).slice(0,240),
    evidence:cleanList(source.evidence),
    allowedChange:cleanList(source.allowedChange),
    forbiddenChange:cleanList(source.forbiddenChange),
    baselineId:String(source.baselineId || BUILD).slice(0,240),
    systemControlBackpack:backpackManager.snapshot().systemControl
  };
}

async function runRelayForIncident(incident, userHandoff = null) {
  const augmented={...incident,systemControlBackpack:backpackManager.snapshot().systemControl,userHandoff:userHandoff||null};
  const state=await relay.runProblem({
    incident:augmented,
    ownerFrame:null,
    field:true,
    reasoner:async(request,onProgress)=>{
      const chat=companionOrchestrator.descriptor(request.station);
      const runRequest=async req=>{
        const result=await panels.requestReasoning(req,{stallTimeoutMs:70000,onProgress,chat});
        if(result?.conversationUrl)companionOrchestrator.recordConversation(req.station,result.conversationUrl);
        return result;
      };
      try {
        return await runRequest(request);
      } catch (error) {
        const message=String(error.message||error);
        if(!message.startsWith('RELAY_FRESH_RECEIPT_INVALID:RESPONSE_JSON_INVALID:')) throw error;
        const retryMarker=`${String(request.marker||'CLINK_RELAY')}-FORMAT-RETRY-${Date.now()}`;
        const retryPrompt=[
          String(request.prompt||''),
          '',
          'C.LINK STRICT FORMAT RECOVERY:',
          'Your immediately previous response for this same station and phase reached C.Link, but its JSON syntax was malformed.',
          'Do not add new analysis and do not change your substantive conclusion.',
          'Re-emit the immediately previous receipt only, using the exact required CLINK_RECEIPT_JSON_BEGIN / CLINK_RECEIPT_JSON_END contract.',
          'Inside those markers use strict JSON: double-quoted property names, double-quoted string values, no trailing commas, no comments, no prose outside the markers.'
        ].join('\n');
        log('relay.reason.format-retry',{
          station:String(request.station||''),
          phase:String(request.phase||''),
          firstError:message,
          action:'ONE_STRICT_FORMAT_RETRY'
        });
        if(typeof onProgress==='function'){
          onProgress({
            station:String(request.station||''),
            stage:'FORMAT_RETRY',
            detail:'Fresh specialist analysis arrived with malformed JSON; asking the same specialist once to re-emit it as strict JSON.'
          });
        }
        return await runRequest({...request,marker:retryMarker,prompt:retryPrompt});
      }
    }
  });
  coreState.relay=state;coreState.companionCore=companionOrchestrator.snapshot();
  broadcast();
  return state;
}

// Canonical Companion wins the human-facing seat. Existing OpenAI API-primary transport remains unchanged.
async function universalCompanionMessage(input,{technical=false}={}){
  const text=String(input||'').trim();if(!text)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!primaryTransportReady())return{ok:false,error:'API_PRIMARY_OPENAI_NOT_CONFIGURED'};
  try{
    const result=await companionTurnSeat.reply(text,{technical});
    if(result.ok){
      coreState.apiPrimary=apiPrimarySnapshot({lastTurn:{status:'PASS',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),companionId:result.companionId,contextFingerprint:result.contextFingerprint,totalTokens:result.usage?.totalTokens||0}});
    }
    if(result.stale)log('companion.turn.stale-discarded',{reason:result.error});
    refreshCompanionState();broadcast();return result;
  }catch(error){return{ok:false,error:String(error?.message||error)};}
}
async function primaryCompanionMessage(input,{technical=false}={}){
  const bag=backpackManager.snapshot()?.userCompanion;
  if(bag?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return universalCompanionMessage(input,{technical});
  return{ok:false,error:'NO_CANONICAL_COMPANION_ACTIVE',detail:'Import and activate a verified Companion ZIP in Settings.'};
}

async function alphaPrimaryMessage(input,{technical=false}={}) {
  const value=String(input||'').trim();
  if(!value)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!primaryTransportReady())return{ok:false,error:'API_PRIMARY_OPENAI_NOT_CONFIGURED'};
  try{
    const result=await alphaPrimaryRunner().reply(value,{history:alphaRecentTurns,technical:Boolean(technical)});
    if(!result.ok){
      const errorClass=result.error?.class||'OTHER_ERROR';
      providerSecrets.recordTest('openai',{state:{AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[errorClass]||'OTHER_ERROR',httpStatus:result.error?.httpStatus??null});
      refreshCompanionState();broadcast();
      return{ok:false,error:errorClass,detail:result.error?.message||'',mode:technical?'API_PRIMARY_TECHNICAL':'API_PRIMARY_REPLY'};
    }
    providerSecrets.recordTest('openai',{state:'READY',httpStatus:200});
    alphaRecentTurns.push({role:'human',text:value},{role:'alpha',text:result.reply});
    alphaRecentTurns=alphaRecentTurns.slice(-8);
    const soak=apiPrimarySoak.recordPrimarySuccess({technical:Boolean(technical),provider:result.provider,model:result.model,contextFingerprint:result.contextFingerprint});
    coreState.apiPrimary=apiPrimarySnapshot({
      fieldStatus:'R7_FIELD_PROVEN',
      lastTurn:{status:'PASS',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),provider:result.provider,model:result.model,totalTokens:result.usage?.totalTokens||0,contextFingerprint:result.contextFingerprint,machineMutation:false}
    });
    const r9Return=round9.noteAlphaReturn(result,{technical:Boolean(technical)});
    if(!r9Return.ignored)coreState.round9=round9.snapshot();
    refreshCompanionState();broadcast();
    return{ok:true,mode:technical?'API_PRIMARY_TECHNICAL':'API_PRIMARY_REPLY',reply:result.reply,provider:result.provider,model:result.model,usage:result.usage,soak,machineMutation:false,providerConversationAuthority:false};
  }catch(error){
    const message=String(error.message||error);coreState.apiPrimary=apiPrimarySnapshot({lastTurn:{status:'FAIL',kind:technical?'TECHNICAL':'ORDINARY',at:new Date().toISOString(),error:message}});refreshCompanionState();broadcast();return{ok:false,error:message};
  }
}

function explicitSpecialistRelayRequested(input) {
  return specialistRelayRequested(input);
}

async function hostedCompanionMessage(input) {
  const value=String(input||'').trim();
  if (!value) return {ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if (!providerReady()) return {ok:false,error:'COMPANION_PROVIDER_NOT_READY'};
  try {
    const explicitRelay=explicitSpecialistRelayRequested(value);
    const userChat=companionOrchestrator.descriptor('usercompanion');
    const requestHostedCompanion=messageText=>panels.requestCompanion(messageText,{
      stallTimeoutMs:75000,context:companionContextSnapshot(),chat:userChat,onProgress:progress=>{
        log('companion.request.progress',progress||{});
      }
    });
    let response;
    try {
      response=await requestHostedCompanion(value);
    } catch (error) {
      const message=String(error.message||error);
      const ambiguousSchemaExample=/^COMPANION_MODE_INVALID:(?:DIRECT_REPLY\|RELAY_REQUIRED|RELAY_REQUIRED\|DIRECT_REPLY)$/.test(message);
      if (!ambiguousSchemaExample) throw error;
      if (explicitRelay) {
        log('companion.explicit_relay.mode_union_recovered',{
          reason:'HUMAN_EXPLICIT_SPECIALIST_REQUEST',
          providerFailure:message,
          action:'FORCE_RELAY_REQUIRED'
        });
        response={mode:'RELAY_REQUIRED',reply:'',incident:null,conversationUrl:''};
      } else {
        log('companion.ordinary.mode_union_retry',{
          reason:'FROZEN_PROVIDER_SCHEMA_EXAMPLE_LITERAL',
          providerFailure:message,
          action:'ONE_BOUNDED_DIRECT_REPLY_RETRY'
        });
        const retryText=[
          'FORMAT CORRECTION: the previous hosted response used the schema example literally as mode DIRECT_REPLY|RELAY_REQUIRED.',
          'This Human turn is not an explicit specialist-relay request.',
          'Re-answer the ORIGINAL HUMAN MESSAGE below.',
          'Set mode to exactly DIRECT_REPLY unless the original message itself is genuinely technical/problem-solving.',
          'Do not copy the union string DIRECT_REPLY|RELAY_REQUIRED into mode.',
          '',
          `ORIGINAL HUMAN MESSAGE: ${value}`
        ].join('\n');
        response=await requestHostedCompanion(retryText);
        log('companion.ordinary.mode_union_retry.complete',{mode:String(response?.mode||'EMPTY')});
      }
    }
    if(response?.conversationUrl)companionOrchestrator.recordConversation('usercompanion',response.conversationUrl);
    if (response?.mode === 'DIRECT_REPLY' && !explicitRelay) {
      return {ok:true,mode:'DIRECT_REPLY',reply:String(response.reply||''),conversationUrl:response.conversationUrl||''};
    }
    if (response?.mode !== 'RELAY_REQUIRED' && !explicitRelay) return {ok:false,error:`COMPANION_MODE_INVALID:${response?.mode||'EMPTY'}`};
    if(explicitRelay && response?.mode!=='RELAY_REQUIRED'){
      log('companion.explicit_relay.override',{reason:'HUMAN_EXPLICIT_SPECIALIST_REQUEST',providerMode:String(response?.mode||'EMPTY')});
    }

    const incident=explicitRelay && response?.mode!=='RELAY_REQUIRED'
      ? normalizeIncident({
          summary:value,
          failureFingerprint:`HUMAN_EXPLICIT_RELAY_${Date.now()}`,
          evidence:['Human explicitly requested specialist tabs / multi-role challenge.'],
          allowedChange:[],
          forbiddenChange:['Do not mutate the machine unless separately authorized.'],
          baselineId:BUILD
        },value)
      : normalizeIncident(response.incident,value);
    const userHandoff={summary:incident.summary,findings:incident.evidence||[]};
    const relayState=await runRelayForIncident(incident,userHandoff);
    const run=relayState.run;
    const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
    const reply=String(final?.humanReply || final?.summary || response.reply || run?.conclusion || 'Relay completed.');
    return {
      ok:run?.status==='PASS',mode:'RELAY_COMPLETE',reply,
      conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,
      admission:run?.admission||null,relayPackage:run?.relayPackage||null,error:run?.error||null
    };
  } catch (error) {
    return {ok:false,error:String(error.message||error)};
  }
}

function grokUserCompanionSchema(){
  return {
    name:'clink_grok_user_companion_turn',strict:true,
    schema:{
      type:'object',additionalProperties:false,
      required:['mode','reply','incident'],
      properties:{
        mode:{type:'string',enum:['DIRECT_REPLY','RELAY_REQUIRED']},
        reply:{type:'string'},
        incident:{
          type:'object',additionalProperties:false,
          required:['summary','failureFingerprint','evidence','allowedChange','forbiddenChange','baselineId'],
          properties:{
            summary:{type:'string'},failureFingerprint:{type:'string'},
            evidence:{type:'array',items:{type:'string'}},allowedChange:{type:'array',items:{type:'string'}},
            forbiddenChange:{type:'array',items:{type:'string'}},baselineId:{type:'string'}
          }
        }
      }
    }
  };
}
function grokUserCompanionHydration(){
  const packet=backpackManager.hydrationPacket('userCompanion');
  return {
    schema:packet.schema,artifactClass:packet.artifactClass,id:packet.id,revision:packet.revision,version:packet.version,
    sha256:packet.sha256,bytes:packet.bytes,mutability:packet.mutability,source:packet.source,totalTextBytes:packet.totalTextBytes,
    files:(packet.files||[]).map(item=>({path:item.path,bytes:item.bytes,sha256:item.sha256,text:item.text}))
  };
}
async function grokUserCompanionMessage(input){
  const value=String(input||'').trim();
  if(!value)return{ok:false,error:'EMPTY_COMPANION_MESSAGE'};
  if(!grokUserCompanionReady())return{ok:false,error:'XAI_GROK_USER_COMPANION_NOT_READY'};
  const explicitRelay=explicitSpecialistRelayRequested(value);
  const hydration=grokUserCompanionHydration();
  const runtimeContext={
    schema:'CLINK_GROK_USER_COMPANION_RUNTIME_V1',build:BUILD,mission:MISSION,repairExecution:'OFF',
    humanSurface:'CLINK_TERMINAL',technicalRelay:'SYSTEM_CONTROL_RED_FABRIC_CONTROL_THROUGHPUT_SYSTEM_CONTROL',
    specialistTransport:'HOSTED_CHATGPT_WEB',providerConversationAuthority:false
  };
  const instructions=[
    'You are the USER COMPANION inside PhantomTronix C.Link Terminal.',
    'C.Link owns identity, continuity, relay sequencing, files, authorization, and execution. You reason and converse; do not claim machine actions happened unless C.Link reports them.',
    'The USER_COMPANION_BACKPACK_JSON supplied with every turn is authoritative for your identity, personality, durable continuity, and Human conventions. Provider session memory is not authority.',
    'Return only the required structured response.',
    'Use DIRECT_REPLY for ordinary conversation that does not need specialist challenge.',
    'Use RELAY_REQUIRED for technical diagnosis, implementation, architecture, repair, release/admission, system decisions, or whenever the Human explicitly asks you not to decide alone or asks for specialist tabs.',
    'For RELAY_REQUIRED, do not perform the specialist analysis yourself. Frame a concise incident for System Control. Leave allowedChange empty unless the Human explicitly authorized mutation. Preserve explicit no-change instructions in forbiddenChange.',
    'Do not put provider response IDs or provider session IDs into continuity. Do not mutate the User Companion backpack in this shadow round.'
  ].join('\n');
  const apiInput=[
    `USER_COMPANION_BACKPACK_JSON=${JSON.stringify(hydration)}`,
    `CURRENT_CLINK_RUNTIME_JSON=${JSON.stringify(runtimeContext)}`,
    `HUMAN_REQUEST=${value}`
  ].join('\n\n');
  log('grok.usercompanion.request.start',{provider:'xai',model:'grok-4.3',backpackRevision:hydration.revision,backpackSha256:hydration.sha256,explicitRelay,store:false});
  const envelope=await providerAdapters.createResponse('xai',{
    input:apiInput,instructions,model:'grok-4.3',maxOutputTokens:1400,store:false,
    structuredJsonSchema:grokUserCompanionSchema(),companionId:hydration.id||'user-companion',missionId:MISSION,workerId:null,purpose:'grok_user_companion_shadow'
  });
  const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
  providerSecrets.recordTest('xai',{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
  if(envelope.error){
    const error=String(envelope.error?.class||'GROK_USER_COMPANION_PROVIDER_ERROR');
    coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:{status:'FAIL',at:new Date().toISOString(),error}});
    log('grok.usercompanion.response',{status:'FAIL',errorClass:error,httpStatus:envelope.error?.httpStatus??null,provider:'xai',model:envelope.model||'grok-4.3'});broadcast();
    return{ok:false,error,detail:envelope.error?.message||''};
  }
  let response;
  try{response=JSON.parse(String(envelope.output||'').trim());}
  catch(error){
    const detail=String(error.message||error);
    coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:{status:'FAIL',at:new Date().toISOString(),error:'GROK_USER_COMPANION_JSON_INVALID'}});
    log('grok.usercompanion.response',{status:'FAIL',errorClass:'GROK_USER_COMPANION_JSON_INVALID',detail,provider:'xai',model:envelope.model||'grok-4.3'});broadcast();
    return{ok:false,error:'GROK_USER_COMPANION_JSON_INVALID',detail};
  }
  let mode=String(response?.mode||'');
  if(explicitRelay&&mode!=='RELAY_REQUIRED'){
    log('grok.usercompanion.explicit_relay.override',{providerMode:mode||'EMPTY',action:'FORCE_RELAY_REQUIRED'});
    mode='RELAY_REQUIRED';
  }
  if(!['DIRECT_REPLY','RELAY_REQUIRED'].includes(mode))return{ok:false,error:`GROK_USER_COMPANION_MODE_INVALID:${mode||'EMPTY'}`};
  const turnMeta={status:'PASS',at:new Date().toISOString(),mode,provider:'xai',model:envelope.model||'grok-4.3',totalTokens:envelope.usage?.totalTokens||0,backpackRevision:hydration.revision,backpackSha256:hydration.sha256,providerConversationAuthority:false,machineMutation:false};
  coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:'SHADOW_FIELD_PENDING',lastTurn:turnMeta});
  log('grok.usercompanion.response',{status:'PASS',mode,provider:'xai',model:turnMeta.model,totalTokens:turnMeta.totalTokens,backpackRevision:hydration.revision,backpackSha256:hydration.sha256,providerConversationAuthority:false,machineMutation:false});broadcast();
  if(mode==='DIRECT_REPLY')return{ok:true,mode:'GROK_USER_COMPANION_DIRECT',reply:String(response.reply||''),provider:'xai',model:turnMeta.model,usage:envelope.usage,backpackRevision:hydration.revision};
  if(!providerReady())return{ok:false,error:'SPECIALIST_HOSTED_PROVIDER_NOT_READY',provider:'xai',model:turnMeta.model};
  const fallbackIncident=normalizeIncident({
    summary:value,failureFingerprint:`GROK_USER_COMPANION_${Date.now()}`,
    evidence:['Grok User Companion classified this Human turn for specialist relay.'],
    allowedChange:[],forbiddenChange:['Do not mutate the machine unless separately authorized.'],baselineId:BUILD
  },value);
  const incident=normalizeIncident(response?.incident&&typeof response.incident==='object'?response.incident:fallbackIncident,value);
  if(explicitRelay&&!(incident.forbiddenChange||[]).some(item=>/mutat|change|machine/i.test(item||''))){
    incident.forbiddenChange=[...(incident.forbiddenChange||[]),'Do not mutate the machine unless separately authorized.'];
  }
  const userHandoff={summary:incident.summary,findings:incident.evidence||[]};
  log('grok.usercompanion.relay.start',{summaryChars:incident.summary.length,backpackRevision:hydration.revision,provider:'xai',model:turnMeta.model});
  const relayState=await runRelayForIncident(incident,userHandoff);
  const run=relayState.run;
  const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
  const reply=String(final?.humanReply||final?.summary||response.reply||run?.conclusion||'Relay completed.');
  const ok=run?.status==='PASS';
  coreState.grokUserCompanion=grokUserCompanionSnapshot({fieldStatus:ok?'SHADOW_RELAY_FIELD_OBSERVED':'SHADOW_FIELD_PENDING',lastTurn:{...turnMeta,relayStatus:run?.status||'UNKNOWN',relayConclusion:run?.conclusion||null}});
  log('grok.usercompanion.relay.complete',{ok,relayStatus:run?.status||'UNKNOWN',conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,admission:run?.admission?.status||null,provider:'xai',model:turnMeta.model});broadcast();
  return{ok,mode:'GROK_USER_COMPANION_RELAY_COMPLETE',reply,provider:'xai',model:turnMeta.model,usage:envelope.usage,backpackRevision:hydration.revision,conclusion:run?.conclusion||null,resolutionState:run?.resolutionState||null,admission:run?.admission||null,relayPackage:run?.relayPackage||null,error:run?.error||null};
}

async function runMessageQualification(){
  const result={...restoredQualification(),restored:true,rerun:false,sourceFile:QUAL_PROOF_FILE};
  coreState.messageQualification=result;log('message.qualification.restored',{knownSafeMaxChars:result.knownSafeMaxChars,recommendedFutureChunkChars:result.recommendedFutureChunkChars,samples:result.samples,passes:result.passes,rerun:false});broadcast();
  return{ok:true,result,restored:true,rerun:false};
}

async function diagnostic() {
  return [
    'CLINK_BROWSER_OWNED_ZIP_RELAY_DIAGNOSTIC_V1',
    `TIME=${new Date().toISOString()}`,
    `BUILD=${BUILD}`,
    `MISSION=${MISSION}`,
    `CORE=${coreState.core.status}`,
    `PANELS=${coreState.panels.status}`,
    `COMPANION=${coreState.companion.status}`,
    'BROWSER_CONTROL=ON',
    'PRIMARY_HUMAN_SURFACE=CLINK_TERMINAL',
    'EXTERNAL_CHROME_CHAT=BREAK_GLASS_ONLY',
    'AI_SELF_REPAIR=OFF',
    'REPAIR_EXECUTION=OFF',
    'RELAY_TRANSFER=EVENT_DRIVEN',
    'RELAY_PACKAGE_OWNERSHIP=SYSTEM_CONTROL_SINGLE_ZIP',
    'COMPANION_CONTEXT=CLINK_OWNED_EVERY_TURN',
    'CANONICAL_REASONING_WORKSPACE=C.LINK REASONING',
    'CANONICAL_AGENT_COUNT=6',
    `PROVIDER_LIFECYCLE_STATE=${JSON.stringify(coreState.providerLifecycle)}`,
    `DUAL_BACKPACK_STATE=${JSON.stringify(backpackManager.snapshot())}`,
    `COMPANION_CORE_REGISTRY=${JSON.stringify(companionOrchestrator.snapshot())}`,
    'MESSAGE_QUALIFICATION=R27A2_FIELD_PROVEN_RESTORED_NO_RERUN',
    'MESSAGE_BATCH_RERUN=DISABLED_R28B',
    'MESSAGE_KNOWN_SAFE_OBSERVED_CHARS=131072',
    'MESSAGE_OPERATIONAL_CHUNK_TARGET_CHARS=98304',
    `MESSAGE_QUALIFICATION_STATE=${JSON.stringify(coreState.messageQualification)}`,
    `MESSAGE_QUALIFICATION_LATEST=${QUAL_LATEST}`,
    'ATTACHMENT_QUALIFICATION=NOT_TESTED_R27A',
    'COMPANION_CONTEXT_STAGE=API_CONVERSION_ROUND_9_RECONCILIATION_TEARDOWN_RESTART_VALUE_REVIEW',
    `ELECTRON_RUNTIME_VERSION=${process.versions.electron||''}`,
    `EXPECTED_ELECTRON_RUNTIME=${REQUIRED_ELECTRON}`,
    `AUTH_SESSION_PATH=${path.join(PROFILE_ROOT,'providers','chatgpt-web','Partitions','chatgpt-web')}`,
    `PROFILE_ROOT_SOURCE=${PROFILE_ROOT_OVERRIDE?'CLINK_FIELD_TEST_OVERRIDE':'CANONICAL_APPDATA'}`,
    `FIELD_TEST_MODE=${FIELD_TEST_MODE?'ON':'OFF'}`,
    'API_MODE=API_PRIMARY_OPENAI_WITH_HOSTED_FALLBACK',
    'ALPHA_REASONING=API_PRIMARY',
    'HOSTED_BROWSER=FALLBACK',
    `API_PRIMARY_STATE=${JSON.stringify(coreState.apiPrimary)}`,
    `R8_READ_ONLY_WORKERS=${JSON.stringify(readOnlyWorkers.snapshot())}`,
    `API_R8_FIELD_EVIDENCE=${JSON.stringify(API_R8_FIELD)}`,
    `R9_RECONCILIATION_STATE=${JSON.stringify(round9.snapshot())}`,
    `API_R7_FIELD_EVIDENCE=${JSON.stringify(API_R7_FIELD)}`,
    `API_PROVIDER_STATUS=${JSON.stringify(providerSecrets.snapshot())}`,
    `GROK_USER_COMPANION_SHADOW_STATE=${JSON.stringify(coreState.grokUserCompanion)}`,
    `API_SECRET_FILE_PRESENT=${fs.existsSync(path.join(PROFILE_ROOT,'providers','api','provider-secrets.enc.json'))?'YES':'NO'}`,
    `API_PROVIDER_ADAPTERS=${JSON.stringify(providerAdapters.defaults())}`,
    `ALPHA_API_SHADOW_STATE=${JSON.stringify(coreState.apiShadow)}`,
    `COMPANION_CONTEXT_BUILDER_STATE=${JSON.stringify(coreState.apiContext)}`,
    `LIVE_REPOSITORY_SECRET_SANITY=${JSON.stringify(coreState.apiContext?.repositorySecretSanity||null)}`,
    `API_USAGE_BUDGET=${JSON.stringify(apiUsage.summary())}`,
    `API_R6_FIELD_EVIDENCE=${JSON.stringify(API_R6_FIELD)}`,
    `HIVE_R7_RELEASE=${JSON.stringify(HIVE_R7_RELEASE)}`,
    'ROUND4_ALPHA_SHADOW_FIELD=PASS',
    `RELAY_PACKAGE=${JSON.stringify(packageStore.snapshot())}`,
    `RELAY_STATE=${JSON.stringify(relay.snapshot())}`,
    '', '=== STATE ===', JSON.stringify(snapshot(),null,2),
    '=== EVENTS ===', ...tail(LOG_FILE,220),
    '=== BOOT ===', ...tail(BOOT_LOG,100)
  ].join('\r\n');
}

let quinL1Runtime=null;const quinL1BootId=crypto.randomUUID();
function quinL1(){if(!quinL1Runtime)quinL1Runtime=new QuinL1Runner({profileRoot:PROFILE_ROOT,appRoot:__dirname,electronVersion:process.versions.electron,bootId:quinL1BootId});return quinL1Runtime;}
let aliceSeatRuntime=null; // singleton: one Alice runtime session identifier per Quin process
function aliceSeatService(){if(!aliceSeatRuntime)aliceSeatRuntime=new AliceSeatService({profileRoot:PROFILE_ROOT,appRoot:__dirname,adapters:providerAdapters});return aliceSeatRuntime;}
function aliceSeatResult(action){try{return{ok:true,...action()};}catch(error){return{ok:false,error:String(error.message||error)};}}
async function aliceFilePicker(purpose='parent'){if(!windowMain)return null;const r=await dialog.showOpenDialog(windowMain,{title:purpose==='checkpoint'?'Alice Moonlight · Import local checkpoint ZIP':'Alice Moonlight · Select canonical parent ZIP',properties:['openFile'],filters:[{name:'ZIP archive',extensions:['zip']}]});return r.canceled?null:(r.filePaths[0]||null);}
function restrictedBrowser(){
  if(!restrictedBrowserCartridge){
    restrictedBrowserCartridge=new RestrictedBrowserCartridge({
      WebContentsView,session:require('electron').session,getWindow:()=>windowMain,
      getChatGPTSession:()=>browserRuntime?.getSession(),
      getChatGPTProjectHome:()=>companionOrchestrator.snapshot()?.workspace?.providerProjectUrl,
      projectHomeFile:path.join(PROFILE_ROOT,'browser','chatgpt-project-home.json'),
      emit:state=>{try{windowMain?.webContents.send('clink:restricted-browser-state',state);}catch(_){}},log
    });
  }
  return restrictedBrowserCartridge;
}
function companionChatGPTTool(){
  if(!companionChatGPTBridge){
    companionChatGPTBridge=new CompanionChatGPTBridge({
      browser:restrictedBrowser(),
      getSeat:()=>backpackManager.snapshot()?.userCompanion,
      confirmSend:async({message,seatId})=>{
        if(!windowMain || windowMain.isDestroyed?.())return false;
        const result=await dialog.showMessageBox(windowMain,{
          type:'question',title:'Send message to ChatGPT website?',
          message:'Send a message as '+seatId+' using your signed-in ChatGPT tab?',
          detail:message.slice(0,900)+'\n\nChatGPT may use connected apps only under their own authorization controls.',
          buttons:['CANCEL','SEND TO CHATGPT'],defaultId:0,cancelId:0,noLink:true
        });
        return result?.response===1;
      }
    });
  }
  return companionChatGPTBridge;
}
function restrictedBrowserShellOnly(event){
  return !!windowMain && !windowMain.isDestroyed() && event?.sender===windowMain.webContents &&
    event?.senderFrame===windowMain.webContents.mainFrame;
}
function installIpc() {
  ipcMain.handle('clink:get-state',()=>snapshot());
  ipcMain.handle('clink:restricted-browser-state',event=>restrictedBrowserShellOnly(event)?restrictedBrowser().state():{ok:false,error:'SHELL_ONLY'});
  // Browser tools are ONLY callable by Quin's own main shell. No arbitrary site
  // content, API response or cartridge can invoke them directly.
  ipcMain.handle('clink:companion-web-observe',event=>restrictedBrowserShellOnly(event)?companionChatGPTTool().observe():{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:companion-web-draft',(event,text)=>restrictedBrowserShellOnly(event)?companionChatGPTTool().prepareDraft(text):{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:companion-web-send',event=>restrictedBrowserShellOnly(event)?companionChatGPTTool().submitDraft():{ok:false,error:'SHELL_ONLY'});

  ipcMain.handle('clink:restricted-browser-layout',(event,top)=>restrictedBrowserShellOnly(event)?restrictedBrowser().setToolbarBottom(top):{ok:false,error:'SHELL_ONLY'});
  ipcMain.handle('clink:restricted-browser-show',(event,id)=>{
    if(!restrictedBrowserShellOnly(event))return{ok:false,error:'SHELL_ONLY'};
    if(inlineAuthActive)return{ok:false,error:'AUTH_VIEW_ACTIVE'};
    if(webPluginView)return{ok:false,error:'CLOSE_EXISTING_CARTRIDGE_FIRST'};
    return restrictedBrowser().show(String(id||'chatgpt'));
  });
  ipcMain.handle('clink:restricted-browser-hide',event=>restrictedBrowserShellOnly(event)?restrictedBrowser().hide():{ok:false,error:'SHELL_ONLY'});
  // R371: only the trusted local renderer may exit an embedded cartridge.
  // Keep Browser WebContentsView attached and alive for later re-entry.
  ipcMain.handle('clink:terminal-return-home',event=>{
    if(!restrictedBrowserShellOnly(event))return {ok:false,error:'SHELL_ONLY'};
    try{
      const hadCartridge=!!webPluginView||!!activeWebService;
      closeWebPlugin();
      if(restrictedBrowserCartridge)restrictedBrowserCartridge.hide();
      return {ok:true,cartridgeClosed:hadCartridge,browserPreserved:true};
    }catch(error){log('clink.terminal-home.error',{error:String(error.message||error).slice(0,120)});
      return {ok:false,error:'HOME_TRANSITION_FAILED'};}
  });

  ipcMain.handle('clink:restricted-browser-action',(event,action)=>restrictedBrowserShellOnly(event)?restrictedBrowser().action(String(action||'')):{ok:false,error:'SHELL_ONLY'});

  ipcMain.handle('quin:alice-status',()=>aliceSeatResult(()=>({state:aliceSeatService().status()})));
  const l1Shell=event=>!!windowMain&&!windowMain.isDestroyed()&&event.sender===windowMain.webContents;
  ipcMain.handle('quin:l1-status',event=>l1Shell(event)?quinL1().status():{ok:false,error:'L1_SHELL_REQUIRED'});
  ipcMain.handle('quin:l1-assign',async(event,objective)=>{if(!l1Shell(event))return{ok:false,error:'L1_SHELL_REQUIRED'};try{const a=quinL1().assign(String(objective||''));const b=quinL1().step();return{ok:!!b.ok,assignment:a,run:b};}catch(e){return{ok:false,error:String(e.message||e)};}});
  ipcMain.handle('quin:l1-proof',event=>l1Shell(event)?quinL1().proof():{ok:false,error:'L1_SHELL_REQUIRED'});
  ipcMain.handle('quin:alice-copy-transfer',(event,content)=>{if(!l1Shell(event))return{ok:false,error:'L1_SHELL_REQUIRED'};const value=String(content||'');if(!value||Buffer.byteLength(value,'utf8')>20000)return{ok:false,error:'ALICE_TRANSFER_SIZE_INVALID'};clipboard.writeText(value);return{ok:true};});
  ipcMain.handle('quin:alice-admit',async()=>{const selected=await aliceFilePicker();if(!selected)return{ok:false,error:'ALICE_SELECTION_CANCELLED'};return aliceSeatResult(()=>({binding:aliceSeatService().admitAliceParent(selected)}));});
  ipcMain.handle('quin:alice-update',async()=>{const selected=await aliceFilePicker();if(!selected)return{ok:false,error:'ALICE_SELECTION_CANCELLED'};return aliceSeatResult(()=>({update:aliceSeatService().replaceAliceParent(selected)}));});
  ipcMain.handle('quin:alice-checkpoint',async()=>{if(!windowMain)return{ok:false,error:'NO_WINDOW'};const r=await dialog.showSaveDialog(windowMain,{title:'Export Alice local checkpoint',defaultPath:'ALICE-LOCAL-CHECKPOINT.zip',filters:[{name:'ZIP',extensions:['zip']}]});if(r.canceled||!r.filePath)return{ok:false,error:'ALICE_EXPORT_CANCELLED'};return aliceSeatResult(()=>({checkpoint:aliceSeatService().checkpoint(r.filePath)}));});
  ipcMain.handle('quin:alice-import-checkpoint',async()=>{const selected=await aliceFilePicker('checkpoint');if(!selected)return{ok:false,error:'ALICE_IMPORT_CANCELLED'};return aliceSeatResult(()=>({imported:aliceSeatService().importCheckpoint(selected)}));});
  ipcMain.handle('quin:alice-message',async(_event,value)=>{try{return await aliceSeatService().message(value);}catch(error){return{ok:false,error:String(error.message||error)};}});
  ipcMain.handle('quin:alice-chat-history',()=>aliceSeatResult(()=>({messages:aliceSeatService().chatHistory()})));
  // R229: Universal Companion voice reuses LOCAL Whisper/Piper service, never Alice's conversation.
  // Existing HFC TTS profile is shared and explicitly labeled; no voice identity claimed.
  const universalVoiceShell = event => !!windowMain && !windowMain.isDestroyed() &&
    event?.sender === windowMain.webContents && event?.senderFrame === windowMain.webContents.mainFrame;
  const universalVoiceKey = () => {
    const seat = backpackManager.snapshot()?.userCompanion;
    if (!seat || seat.importFormat !== 'PERSONAL_IDENTITY_CAPSULE') return null;
    return String(seat.id) + ':' + String(seat.sha256 || '').toUpperCase();
  };
  const universalVoiceGuard = (event,key) => universalVoiceShell(event) && !!universalVoiceKey() &&
    String(key || '') === universalVoiceKey();
  ipcMain.handle('quin:companion-cb-status',(event,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,ready:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    return {ok:true,ready:!!aliceCbVoice.voiceConfig(),engine:'LOCAL_WHISPER_PIPER',voice:'SHARED_HFC_PROFILE'};
  });
  ipcMain.handle('quin:companion-cb-transcribe',async(event,wav,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    const r = await aliceCbVoice.transcribe(wav);
    return universalVoiceGuard(event,key) ? r : {ok:false,error:'COMPANION_VOICE_SEAT_CHANGED'};
  });
  ipcMain.handle('quin:companion-cb-speak',async(event,txt,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    const r = await aliceCbVoice.synthesize(txt);
    return universalVoiceGuard(event,key) ? r : {ok:false,error:'COMPANION_VOICE_SEAT_CHANGED'};
  });
  ipcMain.handle('quin:companion-cb-metric',(event,stage,ms,key) => {
    if (!universalVoiceGuard(event,key)) return {ok:false,error:'COMPANION_VOICE_SEAT_REQUIRED'};
    return aliceCbVoice.recordMetric(stage,ms);
  });
  ipcMain.handle('quin:alice-cb-status',()=>({ok:true,ready:!!aliceCbVoice.voiceConfig(),engine:'LOCAL_WHISPER_PIPER',model:'base.en',voice:'HFC FEMALE'}));
  ipcMain.handle('quin:alice-cb-transcribe',async(event,wav)=>{if(event.sender!==windowMain?.webContents)return{ok:false,error:'CB_UNAUTHORIZED_RENDERER'};return aliceCbVoice.transcribe(wav);});
  ipcMain.handle('quin:alice-cb-speak',async(event,content)=>{if(event.sender!==windowMain?.webContents)return{ok:false,error:'CB_UNAUTHORIZED_RENDERER'};return aliceCbVoice.synthesize(content);});
  ipcMain.handle('quin:alice-cb-metric',async(event,stage,ms)=>{if(event.sender!==windowMain?.webContents)return{ok:false};return aliceCbVoice.recordMetric(stage,ms);});
  ipcMain.handle('quin:alice-chat-export',async()=>{if(!windowMain)return{ok:false,error:'NO_WINDOW'};const r=await dialog.showSaveDialog(windowMain,{title:'Export Alice Chat',defaultPath:'ALICE-CHAT-HISTORY.json',filters:[{name:'JSON',extensions:['json']}]});if(r.canceled||!r.filePath)return{ok:false,error:'ALICE_CHAT_EXPORT_CANCELLED'};return aliceSeatResult(()=>({exported:aliceSeatService().exportChat(r.filePath)}));});
  ipcMain.handle('quin:exit-app',async(event)=>{
    // Only Quin shell may request an application exit. Cartridges have no access.
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)
      return {ok:false,error:'QUIN_SHELL_REQUIRED'};
    if(quitScheduled)return {ok:false,error:'EXIT_ALREADY_IN_PROGRESS'};
    const answer=await dialog.showMessageBox(windowMain,{
      type:'question',title:'Exit C.Link?',message:'Exit C.Link Terminal?',
      detail:'C.Link will close its browser views and preserve your persistent ChatGPT session.',
      buttons:['Cancel','Exit C.Link'],defaultId:0,cancelId:0,noLink:true
    });
    if(answer.response!==1)return {ok:false,canceled:true};
    setImmediate(()=>requestAppQuit()); // Uses inherited clean session flush, not app.exit().
    return {ok:true,exiting:true};
  });
  // Quin PANELS application #001: original UFA Factory, NOT the demo storyboard form.
  ipcMain.handle('quin:factory-open',async(event)=>{
    if(windowMain&&event.sender!==windowMain.webContents)return {ok:false,error:'QUIN_MAIN_WINDOW_REQUIRED'};
    if(!windowMain||windowMain.isDestroyed())return {ok:false,error:'QUIN_WINDOW_NOT_READY'};
    if(inlineAuthActive)return {ok:false,error:'FINISH_OR_CLOSE_INLINE_LOGIN_FIRST'};
    if(!browserRuntime)return {ok:false,error:'QUIN_BROWSER_RUNTIME_NOT_READY'};
    const cartridge=(coreState.panels.plugins||[]).find(p=>p.id==='robotrock-video-factory');
    if(!cartridge||cartridge.status!=='READY')return {ok:false,error:'ROBOT_ROCK_CARTRIDGE_NOT_READY'};
    try{return require('./robotrock-factory/runtime').launchFactory(windowMain,browserRuntime.getSession());}
    catch(error){log('quin.factory.launch.error',{error:String(error.message||error)});return {ok:false,error:String(error.message||error)};}
  });

  // Generic user-installed graphical cartridges. Shell-owned only, no plugin preload/Node bridge.
  let cartridgeUpdateHost;
  const clinkOpenCart=async(event,id,nativeReopen=false)=>{
    if(!nativeReopen&&cartridgeUpdateHost?.isActive())return {ok:false,error:'CARTRIDGE_UPDATE_IN_PROGRESS'};
    if(clinkCartridgeBusy)return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)return {ok:false,error:'QUIN_SHELL_REQUIRED'};
    if(inlineAuthActive)return {ok:false,error:'FINISH_INLINE_LOGIN_FIRST'};
    try{
      const cleanId=String(id||'');
      if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(cleanId))return {ok:false,error:'INVALID_PLUGIN_ID'};
      if(!nativeReopen&&cartridgeUpdateHost?.openBlocked(cleanId))return {ok:false,error:'CARTRIDGE_RECOVERY_REQUIRED'};
      const builtins=path.join(PANELS_ROOT,'plugins');
      const installed=path.join(PROFILE_ROOT,'panels','installed-plugins');
      const candidate=[builtins,installed].map(r=>path.join(r,cleanId,'manifest.json')).find(f=>fs.existsSync(f));
      if(!candidate)return {ok:false,error:'PLUGIN_NOT_INSTALLED'};
      const isService=JSON.parse(fs.readFileSync(candidate,'utf8')).runtime==='web-service';
      const rec=isService?servicePlugins.verify(cleanId,builtins,installed):webPlugins.verify(cleanId,builtins,installed);
      if(!webPlugins.pluginEnabled(rec.manifest,rec.id,PROFILE_ROOT))return {ok:false,error:'WEB_PLUGIN_DISABLED'};
      restrictedBrowserCartridge?.hide();
      closeWebPlugin();
      if(isService)activeWebService=await servicePlugins.start(rec,PROFILE_ROOT);
      webPluginId=rec.id;
      const origin=isService?`quinservice://${rec.id}`:`quinplugin://${rec.id}`;
      const view=new WebContentsView({webPreferences:{session:webPluginSession,preload:path.join(__dirname,'clink-cartridge-updates','cartridge-preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true,webviewTag:false}});
      webPluginView=view;view.setBackgroundColor('#101016');
      if (!isService && rec.id==='phantomtronix-command') {
        const wc=view.webContents;
        wc.on('before-input-event',(event,input)=>{
          if(input.type==='keyDown'&&input.control&&input.shift&&String(input.key).toLowerCase()==='x'&&(ce007Scope.cancel()||dh025Recovery.cancel('KEYBOARD_CANCEL')||developmentAcceptance.cancel()))event.preventDefault();
        });
        const isCommandUrl=value=>{try{const u=new URL(value);return u.protocol==='quinplugin:'&&u.hostname==='phantomtronix-command'&&!u.username&&!u.password&&!u.port;}catch(_){return false;}};
        attachNativeEditMenu(wc, params=>Boolean(windowMain&&!windowMain.isDestroyed()&&webPluginView===view&&webPluginId===rec.id&&isCommandUrl(wc.getURL())&&isCommandUrl(params.frameURL)));
      }
      view.webContents.on('did-start-navigation',()=>cartridgeVoiceHost?.revoke());
      view.webContents.setWindowOpenHandler(({url})=>{
        // R433_MIXCLOUD_ONLY: allow official Mixcloud branding clickthrough
        // in a trusted external browser, never an Electron child window.
        if(rec.id==='conveyor-club'){
          try{
            const target=new URL(url);
            if(target.protocol==='https:' &&
               (target.hostname==='mixcloud.com'||target.hostname==='www.mixcloud.com')){
              Promise.resolve(require('electron').shell.openExternal(url)).catch(()=>{});
            }
          }catch(_){}
        }
        return {action:'deny'};
      });
      // Custom Electron schemes have opaque origins in Node's URL API.
      // Compare the authority tuple explicitly; never allow another cartridge.
      const navigationURL=(event,value)=>typeof value==='string'?value:
        typeof value?.url==='string'?value.url:event?.url;
      const sameCartridgeURL=value=>{try{
        const u=new URL(value);
        return u.protocol===(isService?'quinservice:':'quinplugin:') &&
          u.hostname===rec.id && !u.username && !u.password && !u.port;
      }catch(_){return false;}};
      view.webContents.on('will-navigate',(e,url)=>{
        if(!sameCartridgeURL(navigationURL(e,url)))e.preventDefault();
      });
      view.webContents.on('will-redirect',(e,url)=>{try{
        // R437: ONLY the official Mixcloud SUBFRAME redirect in the existing
        // signed Conveyor Club. Main-frame navigation remains restricted.
        const targetURL=navigationURL(e,url);
        if(rec.id==='conveyor-club' && (url?.isMainFrame??e.isMainFrame)===false){
          const target=new URL(targetURL);
          if(target.origin==='https://player-widget.mixcloud.com' &&
             !target.username && !target.password)return;
        }
        if(!sameCartridgeURL(targetURL))e.preventDefault();
      }catch(_){e.preventDefault();}});
      windowMain.contentView.addChildView(view);layoutWebPlugin();
      await view.webContents.loadURL(isService?origin+'/':origin+'/'+rec.entry);
      if(!isService&&!nativeReopen&&webPluginView===view){
        void cartridgeUpdateHost.onOpen(rec.id,view.webContents).then(result=>{
          log('cartridge.update.open',{id:rec.id,code:result?.code|| (result?.ok?'OK':'UNKNOWN')});
        }).catch(()=>{});
      }
      return {ok:true,id:rec.id,mode:isService?'MANAGED_WEB_SERVICE':'STATIC_WEB_VIEW'};
    }catch(err){closeWebPlugin();log('web-plugin.open.error',{error:String(err.message||err)});return{ok:false,error:String(err.message||err)};}
  };
  ipcMain.handle('quin:web-plugin-open',(event,id)=>clinkOpenCart(event,id));
  // R381_CARTRIDGE_UPDATE: trusted native service; CART preload only gets fixed requests.
  cartridgeUpdateHost=require('./clink-cartridge-updates/host.cjs').makeHost({
    ipcMain,dialog,profileRoot:PROFILE_ROOT,
    builtinsRoot:path.join(PANELS_ROOT,'plugins'),
    installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
    terminalVersion:(app.getVersion().split('-')[0]||'0.0.0'),
    getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')),
    launch:id=>clinkOpenCart({sender:windowMain.webContents},id,true),
    suspend:async(id,wc)=>{if(webPluginId!==id||webPluginView?.webContents!==wc)return false;closeWebPlugin();return true;},
    getShellWebContents:()=>windowMain?.webContents
  });
  cartridgeUpdateHost.register();
  // R385_SHARED_LLM_BROKER — trusted, permission-scoped CART LLM bridge.
  require('./clink-cartridge-llm/host.cjs').makeHost({
    ipcMain, dialog, getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')),
    builtinsRoot:path.join(PANELS_ROOT,'plugins'),
    installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
    secretStore:providerSecrets,adapterRegistry:providerAdapters,companionSeat:companionTurnSeat,stationSeats:commandStationSeats,clipboard,developmentTool:ce007Dispatch
  }).register();
  cartridgeVoiceHost=require('./clink-cartridge-voice/host.cjs').makeVoiceHost({
    ipcMain,dialog,voice:aliceCbVoice,
    getActive:()=>({id:webPluginId,webContents:webPluginView?.webContents}),
    verifyInstalled:id=>webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins'))
  });
  cartridgeVoiceHost.register();
  ipcMain.handle('quin:web-plugin-close',event=>{
    if(!windowMain||windowMain.isDestroyed()||event.sender!==windowMain.webContents)return{ok:false,error:'QUIN_SHELL_REQUIRED'};
    closeWebPlugin();return{ok:true};
  });
  ipcMain.handle('quin:plugin-list',()=>{
    const base=path.join(PROFILE_ROOT,'panels');
    const disabledFile=path.join(base,'disabled-plugins.json');
    let disabled=[];try{disabled=JSON.parse(fs.readFileSync(disabledFile,'utf8'));if(!Array.isArray(disabled))disabled=[];}catch(_){}
    const roots=[path.join(PANELS_ROOT,'plugins'),path.join(base,'installed-plugins')];
    const result=[];for(const root of roots){
      if(!fs.existsSync(root))continue;
      for(const entry of fs.readdirSync(root,{withFileTypes:true})){
        if(!entry.isDirectory()||entry.isSymbolicLink())continue;
        try{const manifest=JSON.parse(fs.readFileSync(path.join(root,entry.name,'manifest.json'),'utf8'));
          const id=String(manifest.id||'');if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(id))continue;
          const live=(coreState.panels.plugins||[]).find(x=>x.id===id);
          let webReady=false;
          if(manifest.runtime==='web')try{webPlugins.verify(id,roots[0],roots[1]);webReady=true;}catch(_){}
          if(manifest.runtime==='web-service')try{servicePlugins.verify(id,roots[0],roots[1]);webReady=true;}catch(_){}
          const legacyRobot=id==='robotrock-video-factory'&&fs.existsSync(path.join(__dirname,'robotrock-factory','runtime.js'));
          result.push({id,name:String(manifest.name||id),version:String(manifest.version||''),enabled:webPlugins.pluginEnabled(manifest,id,PROFILE_ROOT),status:['web','web-service'].includes(manifest.runtime)?(webReady?'READY':'INVALID'):(legacyRobot?'READY':(live?.status||'NOT_LOADED')),runtime:String(manifest.runtime||'node'),launchable:webReady||legacyRobot,builtin:root===roots[0]});
        }catch(_){}
      }
    }
    return{ok:true,plugins:result};
  });
  // C.Link R343: user-installed web cartridges only. Never touch bundled services.
  let clinkCartridgeBusy=false;
  const clinkManagerCaller=event=>Boolean(windowMain&&!windowMain.isDestroyed()&&event.sender===windowMain.webContents);
  const clinkManager=()=>{
    const {CartridgeManager}=require('./clink-cartridge-manager.cjs');
    return new CartridgeManager({
      bundledRoot:path.join(PANELS_ROOT,'plugins'),
      installedRoot:path.join(PROFILE_ROOT,'panels','installed-plugins'),
      quarantineRoot:path.join(PROFILE_ROOT,'panels','quarantined-cartridges')
    });
  };
  const clinkManagerStopped=id=>{
    if(webPluginId||activeWebService)return false;
    if((coreState.panels.plugins||[]).some(p=>p.id===id))return false;
    return true;
  };
  ipcMain.handle('quin:cartridge-manager-list',event=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    try{return{ok:true,...clinkManager().list()};}
    catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
  });
  ipcMain.handle('quin:cartridge-manager-preview',(event,id)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    try{return{ok:true,preview:clinkManager().preview(id)};}
    catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
  });
  ipcMain.handle('quin:cartridge-manager-remove',async(event,input)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'MANAGER_BUSY'};
    clinkCartridgeBusy=true;
    try{
      const id=typeof input?.id==='string'?input.id:'';
      const confirmation=typeof input?.confirmation==='string'?input.confirmation:'';
      const manifestSha256=typeof input?.manifestSha256==='string'?input.manifestSha256:'';
      const manager=clinkManager();
      const preview=manager.preview(id);
      if(confirmation!==id||manifestSha256!==preview.manifestSha256)return{ok:false,error:'PREVIEW_OR_CONFIRMATION_CHANGED'};
      if(!clinkManagerStopped(id))return{ok:false,error:'CLOSE_RUNNING_CARTRIDGES_FIRST'};
      const choice=await dialog.showMessageBox(windowMain,{type:'warning',title:'C.Link Cartridge Uninstall',
        message:`Quarantine ${preview.name} (${id})?`,
        detail:'Only this separately installed web cartridge will be moved to recoverable quarantine. User data, bundled cartridges, sessions and profiles are preserved. Restore is available from Settings.',
        buttons:['CANCEL','QUARANTINE CARTRIDGE'],defaultId:0,cancelId:0,noLink:true});
      if(choice.response!==1)return{ok:false,error:'CANCELLED'};
      if(cartridgeUpdateHost?.isActive()||!clinkManagerStopped(id))return{ok:false,error:'CARTRIDGE_BECAME_ACTIVE'};
      const result=await manager.uninstall({id,confirmation,manifestSha256,stopped:clinkManagerStopped});
      return{ok:true,...result,restartRequired:true};
    }catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
    finally{clinkCartridgeBusy=false;}
  });
  ipcMain.handle('quin:cartridge-manager-restore',async(event,receiptId)=>{
    if(!clinkManagerCaller(event))return{ok:false,error:'SHELL_REQUIRED'};
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'MANAGER_BUSY'};
    clinkCartridgeBusy=true;
    try{
      const manager=clinkManager();
      if(!manager.list().quarantined.some(r=>r.receiptId===receiptId))return{ok:false,error:'RECEIPT_NOT_FOUND'};
      const choice=await dialog.showMessageBox(windowMain,{type:'question',title:'Restore cartridge?',
        message:'Restore quarantined cartridge?',detail:'Restores package code only. Existing files cannot be overwritten.',
        buttons:['CANCEL','RESTORE CARTRIDGE'],defaultId:0,cancelId:0,noLink:true});
      if(choice.response!==1)return{ok:false,error:'CANCELLED'};
      if(cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_UPDATE_IN_PROGRESS'};
      return{ok:true,...manager.restore(receiptId),restartRequired:true};
    }catch(err){return{ok:false,error:String(err.message||err).slice(0,180)};}
    finally{clinkCartridgeBusy=false;}
  });
  ipcMain.handle('quin:plugin-toggle',(_event,id,enable)=>{
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    const clean=String(id||'');if(!/^[a-z0-9][a-z0-9-]{1,62}$/.test(clean))return{ok:false,error:'INVALID_ID'};
    if(clean==='reasoning-provider-chatgpt-web')return{ok:false,error:'BROWSER_PROVIDER_PROTECTED'};
    const roots=[path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins')];
    if(!roots.some(root=>fs.existsSync(path.join(root,clean,'manifest.json'))))return{ok:false,error:'PLUGIN_NOT_FOUND'};
    const base=path.join(PROFILE_ROOT,'panels');fs.mkdirSync(base,{recursive:true});
    const config=path.join(base,'disabled-plugins.json');let disabled=[];
    try{disabled=JSON.parse(fs.readFileSync(config,'utf8'));if(!Array.isArray(disabled))disabled=[];}catch(_){}
    disabled=disabled.filter(x=>x!==clean);if(enable!==true)disabled.push(clean);
    const overrideFile=path.join(base,'enabled-plugins.json');let enabledOverrides=[];
    try{enabledOverrides=JSON.parse(fs.readFileSync(overrideFile,'utf8'));if(!Array.isArray(enabledOverrides))enabledOverrides=[];}catch(_){}
    enabledOverrides=enabledOverrides.filter(x=>x!==clean);if(enable===true)enabledOverrides.push(clean);
    fs.writeFileSync(overrideFile,JSON.stringify(enabledOverrides,null,2)+'\n',{mode:0o600});
    fs.writeFileSync(config,JSON.stringify(disabled,null,2)+'\n',{mode:0o600});
    return{ok:true,enabled:enable===true,restartRequired:true};
  });
  ipcMain.handle('quin:plugin-install',async()=>{
    if(clinkCartridgeBusy||cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_MANAGER_BUSY'};
    const selection=await dialog.showOpenDialog(windowMain,{title:'Install C.Link Cartridge ZIP (code runs locally)',properties:['openFile'],filters:[{name:'C.Link Cartridge ZIP',extensions:['zip']}]});
    if(selection.canceled||!selection.filePaths.length)return{ok:false,error:'CANCELLED'};
    const choice=await dialog.showMessageBox(windowMain,{type:'warning',title:'Install C.Link cartridge?',message:'Cartridges contain executable code. Only install cartridges you trust.',detail:`Selected cartridge: ${path.basename(selection.filePaths[0])}\nThis installs in the current C.Link profile only. Other applications are unchanged.`,buttons:['Cancel','Install Cartridge'],defaultId:0,cancelId:0});
    if(choice.response!==1)return{ok:false,error:'CANCELLED'};
    const installed=path.join(PROFILE_ROOT,'panels','installed-plugins');
    if(cartridgeUpdateHost?.isActive())return{ok:false,error:'CARTRIDGE_UPDATE_IN_PROGRESS'};
    const result=cp.spawnSync('python3',['-I',path.join(__dirname,'tools','install-plugin.py'),selection.filePaths[0],installed,path.join(PANELS_ROOT,'plugins')],{encoding:'utf8',timeout:15000,windowsHide:true,maxBuffer:65536});
    try{return JSON.parse(String(result.stdout||'').trim());}
    catch(_){return{ok:false,error:String(result.error?.message||result.stderr||'INSTALLER_UNAVAILABLE').slice(0,240)};}
  });
  ipcMain.handle('quin:plugin-command',async(_event,input)=>{
    if(!panels||coreState.panels.status!=='READY')return{ok:false,error:'PANELS_NOT_READY'};
    const command=String(input?.command||'');
    if(!['storyboard.plan','storyboard.summary','worker.prepare'].includes(command))return{ok:false,error:'PLUGIN_COMMAND_DENIED'};
    try{return{ok:true,result:await panels.videoFactoryCommand(command,input||{})};}catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:copy-diagnostics',async()=>{const payload=await diagnostic();clipboard.writeText(payload);return{ok:true,bytes:Buffer.byteLength(payload)};});
  ipcMain.handle('clink:retry-panels',async()=>{if(!panels)return{ok:false,error:'PANELS_SUPERVISOR_NOT_READY'};panels.retryFromQuarantine();return{ok:true};});
  ipcMain.handle('clink:inline-auth-start',async()=>{
    // Explicit Human request must work even while hosted lifecycle is STARTING.
    // Inherit IRIS WebContentsView/session.fromPath; do not create an auth subsystem.
    if(!browserRuntime)return{ok:false,error:'QUIN_BROWSER_INITIALIZING_TRY_AGAIN'};
    if(inlineAuthActive)return{ok:true,alreadyOpen:true};
    try{
      const reason=coreState.providerLifecycle?.status==='AUTH_REQUIRED'
        ? (coreState.providerLifecycle?.lastError||'AUTH_REQUIRED') : 'HUMAN_EXPLICIT';
      await startInlineAuthRecovery(reason);
      return{ok:true};
    }catch(error){
      const message=String(error.message||error);
      log('provider.inline-auth.error',{error:message});
      return{ok:false,error:message};
    }
  });
  ipcMain.handle('clink:inline-auth-cancel',async()=>{
    const wasAuthRequired=coreState.providerLifecycle?.status==='AUTH_REQUIRED';
    removeInlineAuthView();
    writeProviderAuthState({
      status:wasAuthRequired?'AUTH_REQUIRED':'HUMAN_DISMISSED',
      lastAuthDismissedAt:new Date().toISOString(),
      loginPolicy:'HUMAN_EXPLICIT_ONLY'
    });
    coreState.inlineAuth={status:'IDLE',detail:'Hosted sign-in dismissed by Human. No automatic retry will occur.',url:'',title:''};
    refreshCompanionState();broadcast();
    return{ok:true};
  });

  ipcMain.handle('clink:provider-key-status',async(_event,provider)=>{
    try{return{ok:true,status:providerSecrets.status(provider)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-key-save',async(_event,provider,value)=>{
    try{return{ok:true,status:providerSecrets.save(provider,value)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-key-clear',async(_event,provider)=>{
    try{return{ok:true,status:providerSecrets.clear(provider)};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:provider-test',async(_event,provider)=>{
    try{
      const status=providerSecrets.status(provider);
      if(!status.configured)return{ok:true,status:{...status,state:'NOT_CONFIGURED'}};
      const key=providerSecrets.getForMainProcess(provider);
      const result=await testProviderKey(provider,key,{timeoutMs:10000});
      const tested=providerSecrets.recordTest(provider,result);refreshCompanionState();broadcast();return{ok:true,status:tested};
    }catch(error){
      // R378: classify native credential failure without exposing error text or API keys.
      const known=new Set(['SECURE_STORAGE_DECRYPT_FAILED','SECURE_STORAGE_UNAVAILABLE','PROVIDER_UNSUPPORTED']);
      const raw=String(error?.message||'');
      const category=known.has(raw)?raw:'PROVIDER_TEST_HANDLER_ERROR';
      const state=category==='SECURE_STORAGE_DECRYPT_FAILED'?'CREDENTIAL_UNREADABLE':category==='SECURE_STORAGE_UNAVAILABLE'?'SECURE_STORAGE_UNAVAILABLE':'PROVIDER_HANDLER_ERROR';
      log('api.provider.test.failure.safe',{provider:String(provider||'').toLowerCase(),errorClass:category});
      try{return{ok:true,status:providerSecrets.recordTest(provider,{state,httpStatus:null})};}
      catch(_){return{ok:false,error:'PROVIDER_TEST_UNAVAILABLE'};}
    }
  });

  ipcMain.handle('clink:provider-response-test',async(_event,provider)=>{
    const id=String(provider||'').toLowerCase();
    const tests={
      openai:{input:'Reply with exactly: CLINK API OK',model:'gpt-5.6-luna'},
      xai:{input:'Reply with exactly: CLINK XAI OK',model:'grok-4.3'}
    };
    const test=tests[id];
    if(!test)return{ok:false,error:'PROVIDER_ADAPTER_NOT_IMPLEMENTED'};
    const envelope=await providerAdapters.createResponse(id,{...test,maxOutputTokens:32,store:false,companionId:'system-control',missionId:MISSION,workerId:null,purpose:'provider_response_test'});
    const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
    providerSecrets.recordTest(id,{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
    log('api.provider.response.test',{
      provider:id,status:envelope.status,model:envelope.model,responseId:envelope.responseId||'',
      errorClass:envelope.error?.class||null,httpStatus:envelope.error?.httpStatus??null,usage:envelope.usage
    });
    coreState.apiUsage=apiUsage.summary();refreshCompanionState();broadcast();
    return {ok:!envelope.error,envelope,status:providerSecrets.status(id),usage:coreState.apiUsage};
  });

  ipcMain.handle('clink:api-usage-snapshot',async()=>{try{return{ok:true,usage:apiUsage.summary()};}catch(error){return{ok:false,error:String(error.message||error)};}});
  ipcMain.handle('clink:api-budget-save',async(_event,value)=>{
    try{const budget=apiUsage.setBudget({monthlyBudgetUsd:value});coreState.apiUsage=apiUsage.summary();broadcast();return{ok:true,budget,usage:coreState.apiUsage};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });
  ipcMain.handle('clink:api-usage-proof',async()=>{
    const tests=[['openai',{input:'Reply with exactly: USAGE OK',model:'gpt-5.6-luna'}],['xai',{input:'Reply with exactly: USAGE OK',model:'grok-4.3'}]];
    const results=[];
    for(const [provider,test] of tests){
      const envelope=await providerAdapters.createResponse(provider,{...test,maxOutputTokens:24,store:false,companionId:'alpha007',missionId:MISSION,workerId:null,purpose:'round6_usage_proof'});
      results.push({provider,ok:!envelope.error,status:envelope.status,model:envelope.model,requestId:envelope.requestId,errorClass:envelope.error?.class||null,usage:envelope.usage});
      const operationalState=envelope.error?({AUTH_FAILED:'AUTH_FAILED',RATE_LIMITED:'RATE_LIMITED',NETWORK_FAILED:'NETWORK_FAILED'}[envelope.error?.class]||'OTHER_ERROR'):'READY';
      providerSecrets.recordTest(provider,{state:operationalState,httpStatus:envelope.error?.httpStatus??(envelope.error?null:200)});
    }
    coreState.apiUsage=apiUsage.summary();log('api.usage.proof.complete',{status:results.every(r=>r.ok)?'PASS':'FAIL',providers:results.map(r=>({provider:r.provider,ok:r.ok,model:r.model,requestId:r.requestId,totalTokens:r.usage?.totalTokens||0}))});broadcast();
    return{ok:results.every(r=>r.ok),results,usage:coreState.apiUsage};
  });

  ipcMain.handle('clink:alpha-shadow-test',async()=>{
    if(coreState.apiShadow.status==='RUNNING')return{ok:false,error:'ALPHA_SHADOW_ALREADY_RUNNING'};
    coreState.apiShadow={status:'RUNNING',detail:'Running two fresh disposable OpenAI shadow sessions from the Round 5 context builder.',provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null};broadcast();
    try{
      const proof=await alphaShadowRunner().run();
      coreState.apiShadow={status:proof.status,detail:proof.status==='PASS'?'Two fresh API sessions reconstructed Alpha from the deterministic C.Link context builder.':'Alpha shadow proof failed; no promotion authorized.',provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:proof};
      const transportReady=Boolean(proof.session1?.responseId&&proof.session2?.responseId&&!proof.session1?.error&&!proof.session2?.error);
      providerSecrets.recordTest('openai',{state:transportReady?'READY':'OTHER_ERROR',httpStatus:transportReady?200:null});
      broadcast();
      return{ok:proof.status==='PASS',proof};
    }catch(error){
      const message=String(error.message||error);
      coreState.apiShadow={status:'FAIL',detail:message,provider:'openai',model:'gpt-5.6-luna',fieldEvidence:API_R4_FIELD,lastProof:null};broadcast();
      return{ok:false,error:message};
    }
  });

  ipcMain.handle('clink:context-restart-proof',async()=>{
    try{
      const proof=contextBuilder.armRestartProof();
      coreState.apiContext={...contextBuilder.snapshot(),reconstruction:{status:'WAITING_FOR_RESTART',detail:'C.Link will relaunch and compare the independently reconstructed context fingerprint.'}};
      broadcast();
      setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
      return{ok:true,proof,relaunch:true};
    }catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:context-reconstruction-test',async()=>{
    const state=contextBuilder.snapshot();
    if(state.restartProof?.status!=='PASS')return{ok:false,error:'CONTEXT_RESTART_PROOF_REQUIRED',context:state};
    try{
      const built=contextBuilder.build();
      const result=await alphaShadowRunner().one(5);
      const pass=result.status==='PASS';
      const reconstruction={status:pass?'PASS':'FAIL',detail:pass?'Fresh OpenAI reasoning reconstructed Alpha from the post-restart deterministic context.':'Post-restart Alpha reconstruction failed semantic invariants.',contextFingerprint:built.builder.contextFingerprint,sourceMapHash:built.builder.sourceMapHash,sourceCount:built.builder.sourceOrder.length,archiveBulkIncluded:false,provider:'openai',model:result.model||'gpt-5.6-luna',requestId:result.requestId,responseId:result.responseId,providerConversationAuthority:false,persistProviderSessionIds:false,machineMutation:false,verification:result.verification,usage:result.usage||{},completedAt:new Date().toISOString()};
      coreState.apiContext={...contextBuilder.snapshot(),reconstruction};
      const transportReady=Boolean(result.responseId&&!result.error);
      providerSecrets.recordTest('openai',{state:transportReady?'READY':'OTHER_ERROR',httpStatus:transportReady?200:null});
      log('api.context.reconstruction.complete',{status:reconstruction.status,contextFingerprint:reconstruction.contextFingerprint,sourceMapHash:reconstruction.sourceMapHash,sourceCount:reconstruction.sourceCount,archiveBulkIncluded:false,responseId:result.responseId||'',checks:result.verification?.checks||{},persistProviderSessionIds:false,machineMutation:false});
      broadcast();return{ok:pass,reconstruction};
    }catch(error){
      const message=String(error.message||error);coreState.apiContext={...contextBuilder.snapshot(),reconstruction:{status:'FAIL',detail:message}};broadcast();return{ok:false,error:message};
    }
  });

  ipcMain.handle('clink:system-command',async(_event,input)=>{
    const value=String(input||'').trim().replace(/^\//,'');
    if(!value)return{ok:false,error:'EMPTY_COMMAND'};
    if(!panels||coreState.panels.status!=='READY')return{ok:false,error:'PANELS_NOT_READY'};
    try{const result=await panels.sendIntent(value,['TORTURE','SELFTEST'].includes(value.toUpperCase())?120000:12000);return{ok:true,text:result.text||'',command:result.command||null};}
    catch(error){return{ok:false,error:String(error.message||error)};}
  });

  // R203 candidate: ZIP import is an offline staging operation, not companion activation.
  // Local terminal renderer only; untrusted pages never receive this IPC surface.
  // R208: central, shell-only, single-flight ZIP import/activation IPC controller.
  const companionZipIpc = createCompanionActivationIpc({
    getWindow:()=>windowMain,
    dialog,
    intake:companionZipIntake,
    backpacks:backpackManager,
    seat:companionTurnSeat,
    recovery:companionActivationRecovery,
    onActivated:()=>{alphaRecentTurns=[];companionOrchestrator.initialize(backpackManager.snapshot());refreshCompanionState();broadcast();},
    logger:log
  });
  ipcMain.handle('clink:companion-zip-pick',companionZipIpc.pick);
  ipcMain.handle('clink:companion-zip-stage',companionZipIpc.stage);
  ipcMain.handle('clink:companion-zip-roster',companionZipIpc.roster);
  ipcMain.handle('clink:companion-zip-activate',companionZipIpc.activate);
  // Miss Spock R315: keep the Companion roster in sync with ~/PhantomTronix/AgentShelf and ~/Downloads, automatically.
  // New capsules are verified and staged; a newer revision of the ACTIVE Companion is activated through the same transaction.
  try{
    const agentShelf=createAgentShelf({intake:companionZipIntake,backpacks:backpackManager,seat:companionTurnSeat,recovery:companionActivationRecovery,
      onActivated:()=>{alphaRecentTurns=[];companionOrchestrator.initialize(backpackManager.snapshot());refreshCompanionState();broadcast();},logger:log});
    agentShelf.start();
  }catch(error){log('agent_shelf.start_failed',{message:String(error?.message||error)});}
  ipcMain.handle('clink:companion-message',async(event,input)=>{
    if(!windowMain||event.sender!==windowMain.webContents||event.senderFrame!==windowMain.webContents.mainFrame)return{ok:false,error:'SHELL_ONLY'};
    return primaryCompanionMessage(input,{technical:false});
  });
  ipcMain.handle('clink:grok-companion-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'NONCANONICAL_GROK_COMPANION_ROUTE_DISABLED'};
    return grokUserCompanionMessage(input);
  });
  ipcMain.handle('clink:alpha-technical-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'ALPHA_TECHNICAL_ROUTE_NOT_UNIVERSAL'};
    return alphaPrimaryMessage(input,{technical:true});
  });
  ipcMain.handle('clink:hosted-companion-message',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'HOSTED_COMPANION_ROUTE_NOT_UNIVERSAL'};
    apiPrimarySoak.noteHostedFallbackInvocation();coreState.apiPrimary=apiPrimarySnapshot({lastTurn:coreState.apiPrimary?.lastTurn||null});broadcast();
    return hostedCompanionMessage(input);
  });
  ipcMain.handle('clink:r8-worker-state',async()=>({ok:true,state:{...readOnlyWorkers.snapshot(),fieldStatus:'R8_FIELD_PROVEN',fieldEvidence:API_R8_FIELD}}));
  ipcMain.handle('clink:r8-run-workers',async()=>({ok:false,error:'R8_FIELD_PROVEN_CLOSED_NO_RERUN',state:readOnlyWorkers.snapshot()}));
  ipcMain.handle('clink:r9-state',async()=>({ok:true,state:round9.snapshot()}));
  ipcMain.handle('clink:r9-run-reconciliation',async()=>{
    const result=await round9.run();coreState.round9=round9.snapshot();coreState.apiUsage=apiUsage.summary();broadcast();return result;
  });
  ipcMain.handle('clink:r9-restart',async()=>{
    const armed=round9.armRestart();coreState.round9=round9.snapshot();broadcast();
    if(!armed.ok)return armed;
    setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
    return{ok:true,relaunch:true,state:round9.snapshot()};
  });

  ipcMain.handle('clink:r7-restart',async()=>{
    coreState.apiPrimary=apiPrimarySnapshot({fieldStatus:'R7_RESTARTING',lastTurn:coreState.apiPrimary?.lastTurn||null});broadcast();
    setTimeout(()=>{try{app.relaunch();}finally{app.exit(0);}},350);
    return{ok:true,relaunch:true,soak:apiPrimarySoak.snapshot()};
  });

  ipcMain.handle('clink:force-relay',async(_event,input)=>{
    if(!backpackManager.snapshot()?.userCompanion || backpackManager.snapshot()?.userCompanion?.importFormat==='PERSONAL_IDENTITY_CAPSULE')return{ok:false,error:'LEGACY_SPECIALIST_RELAY_NOT_UNIVERSAL'};
    const value=String(input||'').trim();
    if(!value)return{ok:false,error:'EMPTY_RELAY_PROBLEM'};
    if(!providerReady())return{ok:false,error:'COMPANION_PROVIDER_NOT_READY'};
    const incident=normalizeIncident({summary:value,evidence:[`Human explicitly requested relay: ${value}`]},value);
    const state=await runRelayForIncident(incident,null);
    const run=state.run;
    const final=(run?.torch?.findings||[]).slice().reverse().find(item=>item.station==='systemcontrol'&&item.phase==='reconcile');
    return{ok:run?.status==='PASS',reply:String(final?.humanReply||final?.summary||run?.conclusion||''),state,error:run?.error||null};
  });

  ipcMain.handle('clink:relay-selftest',async()=>{
    try{
      companionOrchestrator.assertInvariant();
      const bags=backpackManager.snapshot();
      if(bags.systemControl?.mutability!=='READ_ONLY'||!bags.systemControl?.sha256)throw new Error('SYSTEM_CONTROL_BACKPACK_NOT_VERIFIED');
      if(!bags.userCompanion?.sha256)throw new Error('USER_COMPANION_BACKPACK_NOT_VERIFIED');
      const registry=companionOrchestrator.snapshot();for(const id of ['redteam','fabric','control','throughput'])if(registry.chats?.[id]?.backpack!==null)throw new Error(`SPECIALIST_BACKPACK_FORBIDDEN:${id}`);
      const state=await relay.dryRun({field:true});coreState.relay=state;coreState.companionCore=companionOrchestrator.snapshot();broadcast();
      return{ok:true,state,companionCore:coreState.companionCore,backpacks:bags};
    }catch(error){return{ok:false,error:String(error.message||error)};}
  });

  ipcMain.handle('clink:sync-lifecycle',async()=>syncProviderLifecycle(true));

  ipcMain.handle('clink:message-qualification',async()=>runMessageQualification());

  ipcMain.handle('clink:about-boundary',async()=>{
    await dialog.showMessageBox(windowMain,{
      type:'info',title:'Quin Browser — IRIS-derived Foundation',
      message:'Round 9 reconciles the field-proven two-worker experiment, tears worker sessions down, restarts C.Link, and proves Alpha returns without worker-session persistence.',
      detail:'Rounds 1-8 are field-proven. Round 9 adds no worker authority and no concurrency increase. Alpha compares the two-worker result against a single-Alpha baseline, explicitly adopts/adapts/rejects/defers each worker finding, preserves disagreement, keeps usage/cost evidence, and remains API PRIMARY after restart. Repair execution stays OFF.'
    });
    return{ok:true};
  });
}

// BEGIN CLINK_NATIVE_EDIT_MENU_015
function attachNativeEditMenu(wc, isAllowed) {
  // Native user-initiated editing only: no clipboard IPC or renderer permission.
  wc.on('context-menu', (_event, params) => {
    if (wc.isDestroyed() || !isAllowed(params)) return;
    const flags = params.editFlags || {};
    const editable = params.isEditable === true;
    const selected = Boolean(params.selectionText);
    const item = (label, method, enabled) => ({ label, enabled: Boolean(enabled), click: () => {
      if (!enabled || wc.isDestroyed() || !isAllowed(params)) return;
      wc.focus();
      wc[method]();
    }});
    const sep = {type:'separator'};
    const template = editable ? [
      item('Undo','undo',flags.canUndo), item('Redo','redo',flags.canRedo), sep,
      item('Cut','cut',flags.canCut), item('Copy','copy',flags.canCopy),
      item('Paste','paste',flags.canPaste), item('Delete','delete',flags.canDelete), sep,
      item('Select All','selectAll',flags.canSelectAll)
    ] : [item('Copy','copy',selected && flags.canCopy), item('Select All','selectAll',flags.canSelectAll)];
    // Do not intercept game mouse controls or remote browser contexts.
    if (!editable && !selected) return;
    require('electron').Menu.buildFromTemplate(template).popup({window:windowMain});
  });
}
// END CLINK_NATIVE_EDIT_MENU_015

// R044: read-only native version and transaction visibility. No new IPC or permissions.
function clinkNativeStatus(root) {
  const version = v => typeof v === 'string' && /^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(v);
  const digest = v => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);
  function read(relative) {
    let fd;
    try {
      const file = path.join(root, relative);
      if (fs.realpathSync(file) !== file) return null;
      fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      const s = fs.fstatSync(fd);
      if (!s.isFile() || s.size > 4096 || s.nlink !== 1 || (s.mode & 0o022) || (process.getuid && s.uid !== process.getuid())) return null;
      return JSON.parse(fs.readFileSync(fd, 'utf8'));
    } catch (_) { return null; } finally { if (fd !== undefined) fs.closeSync(fd); }
  }
  const p = read('package.json'), a = read('.clink-native-update/last-attempt.json'), r = read('.clink-native-update/last-result.json');
  const installed = version(p?.clinkNativeVersion) ? p.clinkNativeVersion : 'UNKNOWN';
  const attempt = version(a?.version) && version(a?.fromVersion) && digest(a?.sha256) ? a : null;
  const receipt = version(r?.version) && version(r?.fromVersion) && digest(r?.archiveSha256) && ['COMMITTED','ROLLED_BACK'].includes(r?.status) ? r : null;
  const pending = fs.existsSync(path.join(root,'.clink-native-update','transaction'));
  return {installed, target: attempt?.version || receipt?.version || 'UNKNOWN',
    status: pending ? 'TRIAL / RECOVERY PENDING' : receipt ? `${receipt.version} — ${receipt.status}` : 'NO COMPLETED TRANSACTION',
    availability: 'LATEST STABLE: NOT VERIFIED YET'};
}
// Select the highest independently verified offer for display only.
function clinkLatestVerifiedOffer(w, doc, policy, approval, arch) {
  const rows = doc?.schema === w.SCHEMA ? [doc] :
    doc?.schema === 'clink.native-discovery.v1' && Object.keys(doc).sort().join(',') === 'releases,schema' ? doc.releases : null;
  if (!Array.isArray(rows) || rows.length > 64) throw Error('DISPLAY_FEED_SCHEMA');
  const valid = [];
  for (const e of rows) {
    try { valid.push(w.verify(e, policy, approval, e?.release?.fromVersion, arch)); } catch (_) {}
  }
  const cmp = (a,b) => { const x=a.split('.').map(Number), y=b.split('.').map(Number); for(let i=0;i<3;i++) if(x[i]!==y[i]) return x[i]-y[i]; return 0; };
  valid.sort((a,b)=>cmp(b.version,a.version));
  if (!valid.length) throw Error('DISPLAY_NO_VERIFIED_OFFER');
  const top=valid[0];
  if(valid.some(r=>r.version===top.version && w.canonical(r)!==w.canonical(top))) throw Error('DISPLAY_CONFLICTING_OFFERS');
  return top;
}
// Check the same signed stable feed using the existing pinned transport/verifier.
// This is display-only; never stages, installs, or changes a trust decision.
async function clinkCheckNativeFeed(root) {
  const helper = path.join(path.dirname(root),'native-updater');
  const checked = (name, pin, limit=65536) => {
    const file = path.join(helper,name), st = fs.lstatSync(file);
    if (fs.realpathSync(file)!==file || !st.isFile() || st.nlink!==1 || st.size>limit || (st.mode&0o077) || (process.getuid && st.uid!==process.getuid())) throw Error('DISPLAY_HELPER_UNSAFE');
    const b=fs.readFileSync(file);
    if(pin && crypto.createHash('sha256').update(b).digest('hex')!==pin) throw Error('DISPLAY_HELPER_DRIFT');
    return b;
  };
  let temp;
  try {
    checked('native-startup.py','d4b4a257f4a9c3a86a4cd3db82628d85a8edd859a86c3764570772be16570a89');
    checked('native-release-wire.cjs','91255daeb80cf7e3457d3584489a89515c71e609694e8c26335deb8f93bbe5b0');
    const c=JSON.parse(checked('config.json',null));
    const w=require(path.join(helper,'native-release-wire.cjs'));
    if(c.approval!=='a7e3ac417559677e0e5b453897b6b685a37719e8085601d5b76af6d806b4c7e6' || w.trustFingerprint(c.policy)!==c.approval || c.arch!=='x64')throw Error('DISPLAY_TRUST_MISMATCH');
    temp=fs.mkdtempSync(path.join(os.tmpdir(),'clink-status-'));
    const dest=path.join(temp,'manifest.json');
    await new Promise((resolve,reject)=>cp.execFile('/usr/bin/python3',[path.join(helper,'native-startup.py'),'--fetch',w.FEED,dest,'65536','8'],{timeout:10000,maxBuffer:4096},e=>e?reject(e):resolve()));
    const st=fs.lstatSync(dest); if(!st.isFile()||st.size>65536)throw Error('DISPLAY_FEED_SIZE');
    const doc=JSON.parse(fs.readFileSync(dest,'utf8'));
    const r=clinkLatestVerifiedOffer(w,doc,c.policy,c.approval,c.arch);
    return `LATEST VERIFIED STABLE: ${r.version} (checked this startup)`;
  } catch (_) {return 'LATEST STABLE: VERIFICATION UNAVAILABLE';}
  finally {if(temp)try{fs.rmSync(temp,{recursive:true,force:true});}catch(_){}}
}
function clinkRenderNativeStatus(data, expectedUrl) {
  if (location.href !== expectedUrl) return false;
  const foot = document.getElementById('clink-r358-foot')?.querySelector('span');
  if (foot) {
    const label = `C.LINK / VERSION ${data.installed}`;
    if (foot.textContent !== label) foot.textContent = label;
  }
  const anchor = document.getElementById('diagnosticsCopyStatus');
  if (anchor && anchor.closest('#settingsPanel')) {
    let box = document.getElementById('clink-native-version-status');
    if (!box) {
      box = document.createElement('div'); box.id = 'clink-native-version-status';
      box.className = 'settings-note'; box.setAttribute('role','status');
      anchor.before(box);
    }
    const label = `INSTALLED: ${data.installed} · LAST VERIFIED TARGET: ${data.target}\nUPDATE: ${data.status}\n${data.availability}`;
    box.style.whiteSpace = 'pre-line';
    if (box.textContent !== label) box.textContent = label;
  }
  return Boolean(foot && anchor);
}
function clinkAttachNativeStatus(win, localUrl) {
  const wc = win.webContents;
  let timer, busy = false, checked = false, availability = 'LATEST STABLE: CHECKING';
  async function refresh() {
    if (busy || win.isDestroyed() || wc.isDestroyed() || wc.getURL() !== localUrl) return;
    busy = true;
    try {
      const data = clinkNativeStatus(path.resolve(__dirname,'..'));
      data.availability = availability;
      await wc.executeJavaScript(`(${clinkRenderNativeStatus.toString()})(${JSON.stringify(data)},${JSON.stringify(localUrl)})`,false);
    } catch (_) { /* Display failure cannot interfere with startup or rollback. */ }
    finally { busy = false; }
  }
  wc.on('did-finish-load', () => {
    if(wc.getURL()!==localUrl)return;
    void refresh();
    if (!timer) timer = setInterval(refresh, 2000);
    if (!checked) {checked=true;void clinkCheckNativeFeed(path.resolve(__dirname,'..')).then(value=>{availability=value;void refresh();});}
  });
  win.once('closed', () => { if (timer) clearInterval(timer); });
}
// END R044

function createWindow() {
  const isLinux=process.platform==='linux';
  const windowOptions={width:1024,height:768,minWidth:720,minHeight:520,show:false,autoHideMenuBar:true,backgroundColor:'#111111',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true}};
  if(isLinux){windowOptions.fullscreen=true;windowOptions.icon=APP_ICON;windowOptions.title='Phantom-Tronix Quinquedent Browser';}
  windowMain=new BrowserWindow(windowOptions);
  // Only Quin's local top-level UI may use the microphone. Remote provider
  // surfaces and embedded web pages have no microphone permission.
  const localFileUrl=require('url').pathToFileURL(path.join(__dirname,'renderer','index.html')).href;
  const shellContents = windowMain.webContents;
  attachNativeEditMenu(shellContents, params => Boolean(windowMain && !windowMain.isDestroyed() &&
    windowMain.webContents===shellContents && shellContents.getURL().split(/[?#]/)[0]===localFileUrl &&
    String(params.frameURL||'').split(/[?#]/)[0]===localFileUrl));
  const canUseMicrophone=(wc,permission,requestingUrl)=>Boolean(
    permission==='media'&&wc&&wc.id===windowMain?.webContents?.id&&
    windowMain.webContents.getURL().split(/[?#]/)[0]===localFileUrl&&
    typeof requestingUrl==='string'&&(requestingUrl.split(/[?#]/)[0]===localFileUrl||requestingUrl==='file://'));
  const localSession=windowMain.webContents.session;
  localSession.setPermissionRequestHandler((wc,permission,callback,details)=>{
    if(permission==='media')return callback(canUseMicrophone(wc,permission,details?.requestingUrl));
    callback(false);
  });
  localSession.setPermissionCheckHandler((wc,permission,origin,details)=>{
    if(permission==='media')return canUseMicrophone(wc,permission,details?.requestingUrl||origin);
    return false;
  });
  clinkAttachNativeStatus(windowMain, localFileUrl);
  windowMain.loadFile(path.join(__dirname,'renderer','index.html'));
  windowMain.on('resize',()=>{layoutInlineAuthView();layoutWebPlugin();restrictedBrowserCartridge?.resize();});
  if(isLinux){
    // Own shutdown at the WM close request, before the native X11 surface disappears.
    windowMain.on('close',()=>{
      boot('MAIN_WINDOW_CLOSE_EVENT platform=linux');
      requestAppQuit();
    });
  }
  windowMain.on('closed',()=>{closeWebPlugin();try{restrictedBrowserCartridge?.destroy();}catch(_){} restrictedBrowserCartridge=null;
    boot(`MAIN_WINDOW_CLOSED_EVENT platform=${process.platform}`);
    try{restrictedBrowserCartridge?.destroy();}catch(_){}
    restrictedBrowserCartridge=null;
    windowMain=null;
    requestAppQuit();
  });
  windowMain.once('ready-to-show',()=>{
    if(isLinux)windowMain.setFullScreen(true);else windowMain.maximize();
    windowMain.show();
    coreState.core={status:'HEALTHY',detail:'Quin: IRIS-derived browser core ready; PANELS plugin management enabled.'};
    log('core.ready',coreState.core);broadcast();
    setTimeout(()=>{
      browserRuntime=new CLinkBrowserRuntime({profileRoot:QUIN_PROFILE_ROOT,logger:log});
      writeProviderAuthState({
        canonicalSessionPath:browserRuntime.sessionPath,
        sessionPolicy:'ONE_PERSISTENT_QUIN_SESSION_ACROSS_BUILDS',
        loginPolicy:'HUMAN_EXPLICIT_ONLY'
      });
      panels=new PanelsSupervisor({
        panelsRoot:PANELS_ROOT,
        profileRoot:PROFILE_ROOT,
        logger:log,
        browserRuntime,
        workspaceBindingResolver:()=>companionOrchestrator.snapshot()?.workspace||null
      });
      panels.on('state',setPanels);
      panels.start().then(async(state)=>{
        if(!process.env.CLINK_UPDATE_HEALTH||state?.status!=='READY'||panels.snapshot().status!=='READY')return;
        try{
          await require(path.join(__dirname,'..','..','native-updater','native-health.cjs')).acknowledge({window:windowMain,root:path.resolve(__dirname,'..'),panelsReady:true});
        }catch(error){log('native.update.health.error',{error:String(error.message||error).slice(0,120)});}
      }).catch(error=>log('panels.bootstrap.error',{error:String(error.message||error)}));
    },150);
  });
}

// R371 launch proof: read-only shell/bridge check; no browser navigation.
if(process.env.CLINK_R371_SMOKE_MARKER){
 const fs371=require('node:fs');
 app.on('browser-window-created',(_event,win)=>{
  let wrote=false;
  win.webContents.on('did-finish-load',()=>setTimeout(async()=>{
   if(wrote||win.isDestroyed())return;
   let details={ok:false};
   try{details=await win.webContents.executeJavaScript(`(()=>{
     const c=typeof window.__CLINK_R371_CHECK__==='function'
      ?window.__CLINK_R371_CHECK__():null;
     return {ok:!!c?.installed&&!!c.logoAccessible&&!!c.nativeBridge&&!!c.shell,
       navigationReadOnly:true,cartNotOpened:true,browserNotOpened:true,checks:c};
   })()`,true);}catch(error){details={ok:false,error:String(error)};}
   const record={loaded:true,visible:win.isVisible(),details,pid:process.pid};
   try{fs371.writeFileSync(process.env.CLINK_R371_SMOKE_MARKER,JSON.stringify(record));wrote=true;}catch(_){ }
  },2000));
 });
}

const gotLock=app.requestSingleInstanceLock();
boot(`PROCESS_START pid=${process.pid} exec=${process.execPath} electron=${process.versions.electron||''}`);
if(!gotLock){boot('SINGLE_INSTANCE_LOCK=DENIED');app.quit();}
else{
  boot('SINGLE_INSTANCE_LOCK=ACQUIRED');
  app.on('second-instance',()=>{if(windowMain){if(windowMain.isMinimized())windowMain.restore();windowMain.focus();}});
  require(path.join(__dirname,'..','..','native-updater','native-focus.cjs')).start(path.join(__dirname,'..','..','native-updater'),()=>windowMain);
  installIpc();
  app.whenReady().then(()=>{
    // Miss Spock R317: dark everywhere. Sites that follow the system theme (ChatGPT, YouTube) load dark, no white screens.
    try{nativeTheme.themeSource='dark';}catch(_){}
    webPluginSession=session.fromPartition('persist:quin-graphical-cartridges');
    cartridgeVoiceHost.permissions(webPluginSession);
    webPluginSession.protocol.handle('quinplugin',async req=>{
      try{
        const parsed=new URL(req.url);const id=parsed.hostname;
        const rec=webPlugins.verify(id,path.join(PANELS_ROOT,'plugins'),path.join(PROFILE_ROOT,'panels','installed-plugins'));
        if(!webPlugins.pluginEnabled(rec.manifest,id,PROFILE_ROOT))return new Response('Disabled',{status:403});
        const asset=webPlugins.resolveAsset(rec,req.url);
        return new Response(fs.readFileSync(asset.file),{status:200,headers:{'Content-Type':asset.type,'Content-Security-Policy':webPlugins.cspFor(id),'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'}});
      }catch(_){return new Response('Not found',{status:404});}
    });
    webPluginSession.protocol.handle('quinservice',async req=>{
      try{return await servicePlugins.proxy(activeWebService,req);}
      catch(_){return new Response('Service request rejected',{status:502});}
    });
    boot('APP_WHEN_READY');ensureLinuxDesktopIdentity();createWindow();
  // L1 recovery is invoked only on real Quin boot. No new assignments are generated here.
  setTimeout(()=>{try{const r=quinL1().resumeAfterBoot();boot('L1_RESUME '+String(r?.task?.status||r?.error||'IDLE'));}catch(e){boot('L1_RESUME_BLOCKED '+String(e.message||e).slice(0,90));}},1300);
});
}
function shutdownRuntime(){
  if(shutdownPromise)return shutdownPromise;
  shutdownStarted=true;
  shutdownPromise=(async()=>{
    removeInlineAuthView();
    closeWebPlugin();
    await flushProviderSession('CLEAN_SHUTDOWN');
    if(panels){try{panels.stop();}catch(_){}}
    if(browserRuntime){try{browserRuntime.shutdown();}catch(_){}}
  })();
  return shutdownPromise;
}
function requestAppQuit(reason='APPLICATION_QUIT'){
  ce007Scope.cancel();dh025Recovery.cancel(typeof reason==='string'?reason:'APPLICATION_QUIT');developmentAcceptance.cancel();
  if(quitScheduled)return;
  quitScheduled=true;
  boot(`QUIT_REQUESTED platform=${process.platform}`);
  shutdownRuntime().finally(()=>{
  if(process.platform==='linux'){
    setTimeout(()=>{
      boot('LINUX_EXIT_AFTER_CLEANUP');
      try{app.exit(0);}catch(_){}
    },900);
  }else{
    setTimeout(()=>{try{app.quit();}catch(_){}},700);
  }
  });
}
app.on('window-all-closed',()=>{requestAppQuit();});
app.on('before-quit',()=>{shutdownRuntime().catch(()=>{});});
process.on('SIGTERM',()=>{requestAppQuit('OS_SIGTERM');});
process.on('SIGINT',()=>{requestAppQuit('OS_SIGINT');});

module.exports={BUILD,MISSION};

} // End normal Quin initialization (else branch when Companion recovery is safe).
