'use strict';
// Miss Spock R397 source-only adapter: trusted native STATUS and CHECK.
// No network credential, downloader, installer, filesystem write, or publisher approval here.
// Caller supplies no ID, URL, signing key, path or native policy.
// Electron integration MUST wire requireMainFrame to its actual authenticated main-frame sender.
const core=require('./core.cjs');
const wire=require('./native-v1-wire.cjs');
const MAX_METADATA_BYTES=32768;
function requireOps(ops){
 const required=['requireMainFrame','installedVersion','terminalVersion',
   'readTrustedPolicy','readApprovedFingerprint','fetchPinnedMetadata'];
 for(const k of required)if(typeof ops?.[k]!=='function')throw Error('HOST_OPERATION_MISSING_'+k);
}
function versionOrNull(v){
 if(v===null)return null;
 if(typeof v!=='string')throw Error('INVALID_NATIVE_INSTALLED_VERSION');
 core.semcmp(v,v);
 return v;
}
function errorResult(id,errorCode,installedVersion,approved=false){
 return Object.freeze({ok:false,cartridgeId:id,installedVersion,
   updateAvailable:false,approved,code:errorCode,offlinePlayable:installedVersion!==null});
}
function makeTrustedNativeCheck(ops,id=wire.ID){
 if(typeof id!=='string'||!/^[a-z0-9][a-z0-9-]{1,62}$/.test(id))throw Error('INVALID_NATIVE_ID');
 requireOps(ops);
 async function nativeState(sender){
   // Never read the CART identity from game JavaScript: owner comes from the native frame.
   await ops.requireMainFrame(sender,id);
   const installed=versionOrNull(await ops.installedVersion(id));
   const policy=await ops.readTrustedPolicy(id);
   const fingerprint=await ops.readApprovedFingerprint(id);
   if(policy===null||policy===undefined||fingerprint===null||fingerprint===undefined){
     return {installed,approved:false,policy:null,fingerprint:null};
   }
   try {
     wire.validateApprovedTrust(policy,fingerprint,id);
     return {installed,approved:true,policy,fingerprint};
   } catch(error){
     // A mismatched trust store must fail closed, but offline PLAY remains available.
     return {installed,approved:false,policy:null,fingerprint:null};
   }
 }
 async function status(sender){
   const s=await nativeState(sender);
   return Object.freeze({ok:true,cartridgeId:id,installedVersion:s.installed,
     approved:s.approved,channel:s.approved?'stable':null,offlinePlayable:s.installed!==null});
 }
 async function check(sender){
   const s=await nativeState(sender);
   if(!s.approved)return errorResult(id,'CHANNEL_NOT_APPROVED',s.installed);
   let body;
   try {
     // Fetch is injected by the trusted native host, never from CART Javascript.
     body=await ops.fetchPinnedMetadata(s.policy.manifestUrl,MAX_METADATA_BYTES);
   } catch(error){return errorResult(id,'CHECK_OFFLINE_OR_UNAVAILABLE',s.installed,true);}
   let envelope;
   try {
     if(typeof body==='string')body=Buffer.from(body,'utf8');
     if(!Buffer.isBuffer(body)||body.length===0||body.length>MAX_METADATA_BYTES)
       throw Error('UNSAFE_METADATA_LENGTH');
     envelope=JSON.parse(body.toString('utf8'));
   }catch(error){return errorResult(id,'INVALID_METADATA_JSON',s.installed,true);}
   try {
     const host=await ops.terminalVersion();
     // Verify actual Ed25519 signed bytes, ID, origin, publisher and minimum host
     // WITHOUT the monotonic check; this permits a correctly signed unchanged
     // release to report "up to date" rather than a false error.
     const signed=wire.verifyNativeV1(envelope,s.policy,s.fingerprint,id,null,host);
     if(s.installed!==null&&core.semcmp(signed.version,s.installed)<0)return errorResult(id,'SIGNED_RELEASE_DOWNGRADE_REJECTED',s.installed,true);
     const newer=s.installed===null||core.semcmp(signed.version,s.installed)>0;
     return Object.freeze({ok:true,cartridgeId:id,installedVersion:s.installed,
       approved:true,channel:'stable',updateAvailable:newer,
       version:signed.version,offlinePlayable:s.installed!==null});
   }catch(error){return errorResult(id,'INVALID_OR_INCOMPATIBLE_SIGNED_RELEASE',s.installed,true);}
 }
 return Object.freeze({status,check});
}
module.exports={makeTrustedNativeCheck,MAX_METADATA_BYTES};
