'use strict';
// R400 native trusted stage verifier. Use AFTER exact signed ZIP SHA/size and
// strict C.Link extract-safe.py. Reject unpinned files and verify EVERY runtime
// SHA-256 from the PANELS_PLUGIN_MANIFEST_V2 manifest before issuing a stage
// receipt. No game-provided path, ID, or manifest can authorize a release.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const ID='conveyor-club';
const VALID_NAME=/^[\x20-\x7e]+$/;
function deny(ok,reason){if(!ok)throw Error('R400_ASSET_'+reason);}
function verifyAssetStage(stage,version,id=ID){
  deny(typeof id==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(id),'CARTRIDGE_ID');
  deny(typeof stage==='string'&&path.isAbsolute(stage),'ABSOLUTE_STAGE_REQUIRED');
  deny(fs.existsSync(stage)&&fs.lstatSync(stage).isDirectory()&&!fs.lstatSync(stage).isSymbolicLink(),'STAGE_DIRECTORY');
  const manifestPath=path.join(stage,'manifest.json');
  deny(fs.existsSync(manifestPath)&&fs.lstatSync(manifestPath).isFile()&&!fs.lstatSync(manifestPath).isSymbolicLink(),'MANIFEST_PATH');
  const mb=fs.readFileSync(manifestPath);
  deny(mb.length>0&&mb.length<=1024*1024,'MANIFEST_SIZE');
  let m;try{m=JSON.parse(mb.toString('utf8'));}catch{throw Error('R400_ASSET_MANIFEST_JSON');}
  deny(m&&m.schema==='PANELS_PLUGIN_MANIFEST_V2'&&m.id===id&&m.version===version&&m.runtime==='web','MANIFEST_IDENTITY');
  deny(typeof m.entry==='string'&&m.entry.startsWith('web/')&&!m.entry.includes('\\')&&!m.entry.includes('..'),'ENTRY_PATH');
  deny(m.files&&typeof m.files==='object'&&!Array.isArray(m.files),'FILES_MAP');
  const keys=Object.keys(m.files);
  deny(keys.length>0&&keys.length<=6000,'FILES_COUNT');
  const expected=new Set();
  for(const name of keys){
    deny(typeof name==='string'&&name.length>0&&name.length<=250&&VALID_NAME.test(name)&&!name.startsWith('/')&&!name.startsWith('~')&&!name.includes('\\')&&!name.includes(':')&&!name.includes('//'),'FILE_PATH');
    const parts=name.split('/');deny(parts.every(x=>x!==''&&x!=='.'&&x!=='..'),'FILE_TRAVERSAL');
    deny(name!=='manifest.json','MANIFEST_NOT_RUNTIME');
    deny(typeof m.files[name]==='string'&&/^[0-9a-f]{64}$/.test(m.files[name]),'FILE_SHA_FORMAT');
    deny(!expected.has(name.toLowerCase()),'CASE_COLLISION');
    expected.add(name.toLowerCase());
  }
  deny(Object.prototype.hasOwnProperty.call(m.files,m.entry),'ENTRY_NOT_PINNED');
  let count=0,bytes=0;
  function walk(directory,prefix){
    for(const e of fs.readdirSync(directory,{withFileTypes:true})){
      const rel=prefix?prefix+'/'+e.name:e.name;
      const full=path.join(directory,e.name);
      deny(!e.isSymbolicLink(),'SYMLINK');
      if(e.isDirectory()){walk(full,rel);continue;}
      deny(e.isFile(),'SPECIAL_FILE');
      if(rel==='manifest.json')continue;
      deny(Object.prototype.hasOwnProperty.call(m.files,rel),'UNPINNED_RUNTIME_FILE');
      const stat=fs.lstatSync(full);
      deny(stat.size<=100*1024*1024,'FILE_TOO_LARGE');
      bytes+=stat.size;deny(bytes<=512*1024*1024,'STAGE_TOO_LARGE');
      const digest=crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
      deny(digest===m.files[rel],'MISMATCH_'+rel.slice(0,50));
      count++;
    }
  }
  walk(stage,'');
  deny(count===keys.length,'MISSING_RUNTIME_ASSETS');
  return Object.freeze({ok:true,cartridgeId:id,version,manifestVerified:true,
    assetHashesVerified:true,assetCount:count,assetBytes:bytes});
}
module.exports={verifyAssetStage};
