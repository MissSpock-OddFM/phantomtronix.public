'use strict';
// R400 native source integration. Reuses C.Link R392 real host, strict signed
// R396 wire, R397 read API, R398 install gate and R383 commitStaged transaction.
// This is engineering source ONLY, not installed or Human-authorized publisher.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const core=require('./core.cjs'),wire=require('./native-v1-wire.cjs');
const {makeTrustedNativeCheck}=require('./native-v1-check-service.cjs');
const {makeNativeV1InstallGate}=require('./native-v1-install-gate.cjs');
const {verifyAssetStage}=require('./native-v1-assets.cjs');
const {makeElectronHealthGate}=require('./native-electron-health.cjs');
const {recoverScheduled,readSchedule}=require('./native-scheduled-recovery.cjs');
const {makeNativeSignedProvenance}=require('./native-signed-provenance.cjs');
const {makeNativeProcessLock}=require('./native-process-lock.cjs');
function assert(x,msg){if(!x)throw Error('R400_'+msg);}
function ensureDir(p){
 assert(path.isAbsolute(p),'RELATIVE_NATIVE_DIRECTORY');
 fs.mkdirSync(p,{recursive:true,mode:0o700});
 const s=fs.lstatSync(p);assert(s.isDirectory()&&!s.isSymbolicLink(),'UNSAFE_NATIVE_DIRECTORY');
}
function makeNativeV1Bridge(h,ID=wire.ID){
 assert(typeof ID==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(ID),'INVALID_NATIVE_ID');
 assert(ID===wire.ID||typeof h.confirmReopened==='function','NATIVE_HEALTH_REQUIRED');
 const required=['caller','versionFor','findNativePolicy','approval','terminalVersion',
   'net','verifyCandidateStage','progress','record','getActive','suspend','launch',
   'verifyInstalled','onEvent','stagingRoot','backupRoot','transactionRoot','installedRoot','journal'];
 for(const key of required)assert(h[key]!==undefined,'MISSING_NATIVE_'+key);
 const stages=new Map(),scheduled=new Set();
 const scheduleFile=path.join(h.transactionRoot,ID+'.scheduled.json');
 const processLock=makeNativeProcessLock(h.transactionRoot,ID);
 // Native shell-controlled trust is the sole origin of signing credentials;
 // the CART may not contribute publisher, repository, URL or signing keys.
 const provenance=makeNativeSignedProvenance({
   transactionRoot:h.transactionRoot,cartridgeId:ID,
   readTrustedPolicy:()=>policy(),
   readApprovedFingerprint:()=>h.approval(ID),
   terminalVersion:()=>typeof h.terminalVersion==='function'?h.terminalVersion():h.terminalVersion
 });
 let activeLockTicket=null;
 // Acquire the SAME durable cross-process mutex before recovery. If another
 // host owns it, preserve game files and fail closed (offline PLAY still works).
 let startupRecovery;
 const startupTicket=processLock.acquire();
 if(!startupTicket.ok){
   startupRecovery={ok:false,blocked:true,code:'CROSS_PROCESS_LOCK_PRESENT'};
 }else{
   try{
     const hasNativeEvidence=fs.existsSync(scheduleFile)||fs.existsSync(h.journal(ID));
     const diskSchedule=readSchedule(scheduleFile,ID);
     const signed=hasNativeEvidence?provenance.verify({schedule:diskSchedule,required:true}):null;
     // If a source process died AFTER deleting both journals, preserve any
     // orphan signed receipt: it may represent a completed but unacknowledged
     // game update. Human-supervised recovery is then required.
     if(!hasNativeEvidence && fs.existsSync(provenance.file))
       throw Error('R404_ORPHAN_SIGNED_PROVENANCE');
     startupRecovery=recoverScheduled({
       installedRoot:h.installedRoot,backupRoot:h.backupRoot,
       transactionRoot:h.transactionRoot,stagingRoot:h.stagingRoot,cartridgeId:ID
     });
     if(startupRecovery.ok&&signed)
       provenance.clearCompleted({
         sourceVersion:signed.proof.sourceVersion,
         targetVersion:signed.proof.targetVersion
       });
   }catch(error){
     startupRecovery={ok:false,blocked:true,code:'RECOVERY_EVIDENCE_INVALID'};
   }
   if(startupRecovery.ok===true)processLock.release(startupTicket);
   else activeLockTicket=startupTicket; // retain lock while recovery is blocked.
 }
 const recoveryBlocked=startupRecovery.ok!==true;
 // Actual C.Link creates a new WebContentsView on each clinkOpenCart launch;
 // probe the NEW frame and frozen original game state before journal success.
 const nativeHealth=ID===wire.ID?makeElectronHealthGate({
   getActive:h.getActive,readInstalledVersion:h.versionFor,
   sleep:ms=>new Promise(resolve=>setTimeout(resolve,ms))
 }):null;
 function policy(){
   const p=h.findNativePolicy(ID);
   return p?{schema:'clink.self-update-channel.v1',cartridgeId:ID,channel:p.channel,
     publisher:p.publisher,repository:p.repository,
     publicKeyPem:p.publicKeyPem,manifestUrl:p.manifestUrl}:null;
 }
 function requireFrame(event,id){
   const rec=h.caller(event);assert(id===ID&&rec.id===ID,'WRONG_MAIN_FRAME');
   return rec;
 }
 const native={
  requireMainFrame:async(event,id)=>requireFrame(event,id),
  installedVersion:async(id)=>{assert(id===ID,'WRONG_ID');return h.versionFor(id)},
  terminalVersion:async()=>typeof h.terminalVersion==='function'?h.terminalVersion():h.terminalVersion,
  readTrustedPolicy:async(id)=>{assert(id===ID,'WRONG_ID');return policy()},
  readApprovedFingerprint:async(id)=>{assert(id===ID,'WRONG_ID');return h.approval(id)},
  fetchPinnedMetadata:async(url,max)=>h.net.fetchLimited(url,max),
  pendingTransaction:async(id)=>{
    assert(id===ID,'WRONG_ID');
    return recoveryBlocked||scheduled.size>0||h.legacyBusy?.()===true||
       fs.existsSync(h.journal(ID))||fs.existsSync(scheduleFile)||
       fs.existsSync(provenance.file);
  },
  stageVerifiedArchive:async(req)=>{
    assert(req.cartridgeId===ID&&typeof req.url==='string'&&
      /^[a-f0-9]{64}$/.test(req.sha256),'STAGE_RELEASE');
    assert(req.size>0&&Number.isSafeInteger(req.size),'STAGE_SIZE');
    // R398 installed gate already verified signed envelope. Verify AGAIN
    // under native shell trust before persisting the provenance receipt.
    assert(req.signedEnvelope&&req.approvedFingerprint===h.approval(ID),
      'SIGNED_RELEASE_APPROVAL_REQUIRED');
    const verified=wire.verifyNativeV1(req.signedEnvelope,policy(),
      req.approvedFingerprint,ID,req.installedVersion,
      typeof h.terminalVersion==='function'?h.terminalVersion():h.terminalVersion);
    assert(verified.version===req.version&&req.signedEnvelope.release.sha256===req.sha256&&
      req.signedEnvelope.release.size===req.size&&
      req.signedEnvelope.release.artifactUrl===req.url,
      'SIGNED_ARCHIVE_MISMATCH');
    for(const name of ['saves','user-data','userdata','player-data'])
      assert(!fs.existsSync(path.join(h.installedRoot,ID,name)),'PACKAGE_SAVE_DATA_PRESENT');
    ensureDir(h.stagingRoot);
    const token=crypto.randomUUID();
    const root=path.join(h.stagingRoot,token);
    fs.mkdirSync(root,{mode:0o700});
    const zip=path.join(root,'package.zip'),expanded=path.join(root,'expanded');
    try{
      h.progress(h.getActive()?.webContents,'DOWNLOADING');
      await h.net.downloadLimited(req.url,zip,req.size,req.sha256,
         (done,total)=>h.progress(h.getActive()?.webContents,'DOWNLOADING',done,total));
      h.progress(h.getActive()?.webContents,'VERIFYING');
      // Real R392 core uses pinned C.Link Python extractor, rejecting traversal,
      // symlinks, bombs, duplicates, unsafe file kinds, wrong ID/version.
      core.verifyStage(zip,expanded,{cartridgeId:ID,version:req.version},
        path.join(__dirname,'extract-safe.py'));
      h.verifyCandidateStage(expanded,ID,req.version);
      // Extractor DOES NOT verify m.files SHA256; this NEW check is essential.
      const proof=verifyAssetStage(expanded,req.version,ID);
      stages.set(token,{root,expanded,req,proof,approvalFingerprint:h.approval(ID)});
      return Object.freeze({ok:true,stageToken:token,cartridgeId:ID,
        version:req.version,bytesVerified:req.size,sha256Verified:req.sha256,
        manifestVerified:proof.manifestVerified,assetHashesVerified:proof.assetHashesVerified});
    }catch(error){
      try{fs.rmSync(root,{recursive:true,force:true})}catch{}
      throw error;
    }
  },
  discardStagedArchive:async(token)=>{
    const item=stages.get(token);assert(item,'UNKNOWN_STAGE_TOKEN');
    stages.delete(token);
    fs.rmSync(item.root,{recursive:true,force:true});
  },
  scheduleVerifiedSwap:async(req)=>{
    assert(req.cartridgeId===ID&&scheduled.size===0,'SCHEDULE_BUSY');
    const item=stages.get(req.stageToken);
    assert(item&&item.req.version===req.version&&
      item.req.installedVersion===req.expectedInstalledVersion,'SCHEDULE_STAGE_MISMATCH');
    assert(!fs.existsSync(scheduleFile)&&!fs.existsSync(h.journal(ID))&&
      !fs.existsSync(provenance.file),'TRANSACTION_ALREADY_PRESENT');
    ensureDir(h.transactionRoot);ensureDir(h.backupRoot);
    // This durable SCHEDULE record precedes renderer acknowledgment. A crash
    // while pending is not success: leave the schedule/journal for safe recovery.
    const transactionId=crypto.randomUUID();
    provenance.create({
      sourceVersion:req.expectedInstalledVersion,targetVersion:req.version,
      transactionId,stageToken:req.stageToken,
      envelope:item.req.signedEnvelope,
      approvalFingerprint:item.req.approvedFingerprint
    });
    core.atomicJson(scheduleFile,{schema:'clink.r400.schedule.v1',cartridgeId:ID,
      previousVersion:req.expectedInstalledVersion,version:req.version,
      stageToken:req.stageToken,transactionId});
    provenance.flushSchedule();
    stages.delete(req.stageToken);scheduled.add(transactionId);
    const original=h.getActive(),wc=original?.webContents;
    setTimeout(async()=>{
      let suspended=false,committed=false;
      try{
        const active=h.getActive();
        assert(active&&active.id===ID&&active.webContents===wc&&wc&&!wc.isDestroyed(),'ACTIVE_CART_CHANGED');
        assert(h.versionFor(ID)===req.expectedInstalledVersion,'VERSION_CHANGED');
        const signed=provenance.verify({
          schedule:readSchedule(scheduleFile,ID),required:true
        });
        assert(signed.proof.transactionId===transactionId&&
          signed.proof.approvalFingerprint===h.approval(ID),
          'SIGNED_PROVENANCE_CHANGED');
        const p=policy(),approved=h.approval(ID);
        wire.validateApprovedTrust(p,approved,ID);
        assert(approved===item.approvalFingerprint,'APPROVAL_CHANGED');
        for(const name of ['saves','user-data','userdata','player-data'])
          assert(!fs.existsSync(path.join(h.installedRoot,ID,name)),'PACKAGE_SAVE_DATA_PRESENT');
        if(nativeHealth)nativeHealth.captureBeforeRestart(ID);
        else h.captureBeforeRestart?.(ID);
        assert(await h.suspend(ID,wc)===true,'SUSPEND_FAILED');
        suspended=true;
        h.onEvent('CART_SUSPENDED_FOR_UPDATE',ID);
        const receipt=await core.commitStaged({stage:item.expanded,installedRoot:h.installedRoot,
          backupRoot:h.backupRoot,targetId:ID,version:req.version,journalFile:h.journal(ID),
          verify:(dir,id,version)=>{h.verifyCandidateStage(dir,id,version);verifyAssetStage(dir,version,id)},
          launch:async(target)=>{
            h.verifyInstalled(target);
            const startup=await h.launch(target);
            if(startup!==true&&startup?.ok!==true)return false;
            // Real Electron must implement a fresh authenticated frame health
            // acknowledgment. Missing callback => FAIL and rollback, never success.
            const healthy=await (typeof h.confirmReopened==='function'
              ? h.confirmReopened(target,req.version,transactionId)
              : nativeHealth.confirmReopened(target,req.version,transactionId));
            const good=healthy===true&&h.versionFor(ID)===req.version;
            if(!good){const live=h.getActive();if(live?.id===ID&&live.webContents)await h.suspend(ID,live.webContents);}
            return good;
          }});
        committed=true;
        h.record(ID,{ok:true,code:'UPGRADED_VERIFIED',previous:req.expectedInstalledVersion,
          version:receipt.version,rollbackAvailable:!!receipt.previous,transactionId});
        h.onEvent('CART_UPDATED',ID+':'+req.version);
      }catch(error){
        h.record(ID,{ok:false,code:'FAILED_OR_ROLLED_BACK',transactionId,
          error:String(error?.message||error).slice(0,130),
          installedVersion:core.manifestVersion(h.installedRoot,ID)});
        h.onEvent('CART_UPDATE_FAILED',String(error?.message||error).slice(0,130));
        if(suspended&&!committed){
          try{await h.launch(ID)}catch(err){h.onEvent('RESTORE_REOPEN_FAILED',String(err?.message||err).slice(0,100));}
        }
      }finally{
        scheduled.delete(transactionId);
        // Never destroy evidence or a staged package while core journal
        // remains: interrupted backup needs recovery on next start.
        if(!fs.existsSync(h.journal(ID))){
          try{fs.rmSync(item.root,{recursive:true,force:true})}catch{}
          try{fs.rmSync(scheduleFile,{force:true})}catch{}
        }
        // A lock survives until BOTH scheduled and native journals are gone.
        // If interrupted, preserve lock and journal for supervised recovery.
        if(!fs.existsSync(scheduleFile)&&!fs.existsSync(h.journal(ID)) &&
           fs.existsSync(provenance.file)){
          try{provenance.clearCompleted({
            sourceVersion:req.expectedInstalledVersion,targetVersion:req.version
          })}
          catch(err){h.onEvent('SIGNED_PROVENANCE_CLEANUP_REQUIRED',String(err?.message||err))}
        }
        if(activeLockTicket && !fs.existsSync(scheduleFile) &&
          !fs.existsSync(h.journal(ID))&&!fs.existsSync(provenance.file)){
          try{processLock.release(activeLockTicket);activeLockTicket=null}
          catch(err){h.onEvent('CROSS_PROCESS_LOCK_CLEANUP_REQUIRED',String(err?.message||err))}
        }
      }
    },Math.max(20,h.delayInstallMs||250));
    return Object.freeze({ok:true,scheduled:true,installed:false,transactionId});
  }
 };
 const read=makeTrustedNativeCheck(native,ID);
 const gated=makeNativeV1InstallGate(native,ID);
 return Object.freeze({
  status:async(event)=>{
    const s=await read.status(event);
    return {...s,supported:true,updating:scheduled.size>0,
      recoveryBlocked,recoveryCode:startupRecovery.code,
      lastResult:h.lastResult?.(ID)||null};
  },
  check:async(event)=>{
    if(recoveryBlocked){
      requireFrame(event,ID);
      return {ok:false,cartridgeId:ID,installedVersion:h.versionFor(ID),
        updateAvailable:false,offlinePlayable:true,code:'RECOVERY_REQUIRED'};
    }
    const r=await read.check(event);
    if(r.ok&&r.updateAvailable)h.progress(h.getActive()?.webContents,'AVAILABLE');
    return r;
  },
  install:async(event)=>{
    requireFrame(event,ID);
    if(recoveryBlocked)return {ok:false,scheduled:false,installed:false,code:'RECOVERY_REQUIRED'};
    let ticket;
    try{ticket=processLock.acquire()}
    catch{return {ok:false,scheduled:false,installed:false,code:'PROCESS_LOCK_INVALID'}}
    if(!ticket.ok)return {ok:false,scheduled:false,installed:false,code:'UPDATE_PROCESS_LOCK_HELD'};
    activeLockTicket=ticket;
    let result;
    try{result=await gated.install(event)}
    catch(error){
      result={ok:false,scheduled:false,installed:false,code:'INSTALL_VALIDATION_FAILED'};
    }
    // On validation/network failure before scheduling, no persistent update
    // state exists; release mutex. Unknown journal/schedule retains lock.
    if(!(result.ok===true&&result.scheduled===true) &&
      !fs.existsSync(scheduleFile)&&!fs.existsSync(h.journal(ID))&&
      !fs.existsSync(provenance.file)){
      try{processLock.release(ticket);activeLockTicket=null}
      catch{return {ok:false,scheduled:false,installed:false,code:'LOCK_CLEANUP_REQUIRED'}}
    }
    return result;
  },
  isBusy:()=>recoveryBlocked||scheduled.size>0||activeLockTicket!==null,
  isActive:()=>scheduled.size>0||(!recoveryBlocked&&activeLockTicket!==null),
  processLockFile:processLock.lockFile,
  startupRecovery,
  scheduleFile
 });
}
module.exports={makeNativeV1Bridge};
