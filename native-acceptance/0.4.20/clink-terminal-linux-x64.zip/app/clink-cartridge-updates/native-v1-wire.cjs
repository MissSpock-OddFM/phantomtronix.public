'use strict';
// R396: PRE-INSTALLATION shared wire adapter for the existing R391 C.Link core.
// This file is NOT an update host, installer or channel approval mechanism.
// It authenticates the caller-provided ID against a trusted shell origin; never
// accept ID/key/repo/URL from game JavaScript or make network calls in this module.
const crypto = require('node:crypto');
const core = require('./core.cjs');
const SCHEMA = 'clink.signed-update.v1';
const ID = 'conveyor-club'; // legacy default, never a renderer-selected target
const CART_ID = /^[a-z0-9][a-z0-9-]{1,62}$/;
const RELEASE_KEYS = [
  'artifactUrl','cartridgeId','channel','minClinkVersion','prerelease',
  'publisher','repository','sha256','size','version'
];
const ENVELOPE_KEYS = ['release','schema','signature'];
const VERSION = /^(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})$/;
function check(x, error){if(!x)throw Error('R396_'+error);}
function exact(value, expected, kind){
  check(value && typeof value === 'object' && !Array.isArray(value),kind+'_NOT_OBJECT');
  const found=Object.keys(value).sort();
  const required=expected.slice().sort();
  check(found.length===required.length && found.every((x,i)=>x===required[i]),kind+'_KEYS');
}
function expectedFeed(policy){
  check(policy && typeof policy.repository==='string','POLICY_REPO');
  const id=policy.cartridgeId;
  check(typeof id==='string' && CART_ID.test(id),'POLICY_ID');
  const route=id===ID?'latest/download':('download/'+id+'-stable');
  return 'https://github.com/'+policy.repository+'/releases/'+route+'/update-manifest.json';
}
function expectedArchive(repo, version, id=ID){
  check(typeof id==='string' && CART_ID.test(id),'ARCHIVE_ID');
  const tag=id===ID?'v'+version:id+'-v'+version;
  return 'https://github.com/'+repo+'/releases/download/'+tag+'/'+id+'.zip';
}
function validateApprovedTrust(trust, approvedFingerprint, authenticatedId){
  check(typeof authenticatedId==='string'&&CART_ID.test(authenticatedId),'CALLER_ID');
  check(trust && trust.schema==='clink.self-update-channel.v1','TRUST_SCHEMA');
  check(trust.cartridgeId===authenticatedId && trust.channel==='stable','TRUST_ID_CHANNEL');
  check(typeof trust.publisher==='string' && trust.publisher.length>0 && trust.publisher.length<=99,'TRUST_PUBLISHER');
  check(typeof trust.repository==='string' && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(trust.repository),'TRUST_REPO');
  check(typeof trust.publicKeyPem==='string' && trust.publicKeyPem.length<1000,'TRUST_KEY');
  const key=crypto.createPublicKey(trust.publicKeyPem);
  check(key.asymmetricKeyType==='ed25519','TRUST_ED25519');
  check(trust.manifestUrl===expectedFeed(trust),'TRUST_JSON_FEED');
  core.allowGithub(trust.manifestUrl, trust.repository,'metadata');
  const fingerprint=core.sha(key.export({type:'spki',format:'der'}));
  const canonical={cartridgeId:authenticatedId,channel:'stable',publisher:trust.publisher,
    repository:trust.repository,manifestUrl:trust.manifestUrl,keyFingerprint:fingerprint};
  const want=core.sha(Buffer.from(core.canonical(canonical),'utf8'));
  check(typeof approvedFingerprint==='string' && approvedFingerprint===want,'APPROVAL_REQUIRED');
  return Object.freeze({targetId:authenticatedId,channel:'stable',repository:trust.repository,
    publisher:trust.publisher, publicKeyPem:trust.publicKeyPem, manifestUrl:trust.manifestUrl,
    approvalFingerprint:want});
}
function verifyNativeV1(envelope, trust, approvedFingerprint, authenticatedId, installedVersion, terminalVersion){
  const p=validateApprovedTrust(trust,approvedFingerprint,authenticatedId);
  exact(envelope,ENVELOPE_KEYS,'ENVELOPE');
  check(envelope.schema===SCHEMA,'SIGNED_SCHEMA');
  exact(envelope.release,RELEASE_KEYS,'RELEASE');
  const r=envelope.release;
  check(r.cartridgeId===authenticatedId && r.channel==='stable' && r.prerelease===false,'RELEASE_ID_CHANNEL');
  check(typeof r.version==='string' && VERSION.test(r.version),'RELEASE_VERSION');
  check(typeof r.minClinkVersion==='string' && VERSION.test(r.minClinkVersion),'TERMINAL_VERSION');
  check(r.repository===p.repository && r.publisher===p.publisher,'RELEASE_TRUST');
  check(Number.isSafeInteger(r.size) && r.size>0 && r.size<=268435456,'RELEASE_SIZE');
  check(typeof r.sha256==='string' && /^[a-f0-9]{64}$/.test(r.sha256),'RELEASE_SHA');
  check(r.artifactUrl===expectedArchive(p.repository,r.version,authenticatedId),'RELEASE_ARCHIVE_PATH');
  core.allowGithub(r.artifactUrl,p.repository,'artifact');
  check(typeof envelope.signature==='string' && /^[A-Za-z0-9+/]{86}==$/.test(envelope.signature),'SIGNATURE_ENCODING');
  const sig=Buffer.from(envelope.signature,'base64');
  check(sig.length===64 && sig.toString('base64')===envelope.signature,'SIGNATURE_CANONICAL_BASE64');
  check(installedVersion===null || VERSION.test(installedVersion),'INSTALLED_VERSION');
  check(typeof terminalVersion==='string' && VERSION.test(terminalVersion),'HOST_VERSION');
  // Actual legacy C.Link R391 core verifies Ed25519 over core.canonical(release),
  // signed version and minimum host; all additional strict checks above are fail-closed.
  const verified=core.verifyManifest(envelope,p,installedVersion,terminalVersion);
  return Object.freeze({...verified,cartridgeId:authenticatedId,channel:'stable'});
}
module.exports={SCHEMA,ID,expectedFeed,expectedArchive,validateApprovedTrust,verifyNativeV1};
