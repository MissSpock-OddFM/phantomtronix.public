'use strict';
// R404: durable, native-owned signed RELEASE provenance companion to the
// immutable original C.Link transaction journal. Never accept CART inputs.
// This receipt does not modify core.commitStaged() format or the game ZIP.
// Test-only keys must NEVER become production publisher authorization.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const core=require('./core.cjs'),wire=require('./native-v1-wire.cjs');
const SCHEMA='clink.native-signed-provenance.v1';
const V=/^(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})$/;
const TOKEN=/^[a-zA-Z0-9_-]{16,128}$/;
const KEYS=['schema','cartridgeId','sourceVersion','targetVersion','transactionId',
 'stageToken','envelope','releaseSha256','approvalFingerprint','publisher',
 'repository','channel','feedUrl','archiveSha256','archiveSize','keySpkiSha256'];
function check(ok,code){if(!ok)throw Error('R404_PROVENANCE_'+code)}
function exact(o,keys,code){
 check(o&&typeof o==='object'&&!Array.isArray(o),'BAD_'+code);
 const actual=Object.keys(o).sort();
 check(actual.length===keys.length&&actual.every((k,i)=>k===keys.slice().sort()[i]),
   'KEYS_'+code);
}
function sha(data){return crypto.createHash('sha256').update(data).digest('hex')}
function makeNativeSignedProvenance({transactionRoot,readTrustedPolicy,
 readApprovedFingerprint,terminalVersion,cartridgeId:ID='conveyor-club'}={}){
 check(typeof ID==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(ID),'INVALID_ID');
 check(typeof transactionRoot==='string'&&path.isAbsolute(transactionRoot),'ABSOLUTE_ROOT');
 check(typeof readTrustedPolicy==='function'&&typeof readApprovedFingerprint==='function'&&
  typeof terminalVersion==='function','NATIVE_CALLBACKS');
 const file=path.join(transactionRoot,ID+'.signed-provenance.json');
 function safeRoot(){
  fs.mkdirSync(transactionRoot,{recursive:true,mode:0o700});
  const st=fs.lstatSync(transactionRoot);
  check(st.isDirectory()&&!st.isSymbolicLink()&&
    fs.realpathSync(transactionRoot)===path.resolve(transactionRoot),'UNSAFE_ROOT');
 }
 function flushNativeRecord(recordFile){
  safeRoot();
  check(recordFile===file||recordFile===path.join(transactionRoot,ID+'.scheduled.json'),
    'UNEXPECTED_RECORD_PATH');
  const st=fs.lstatSync(recordFile);
  check(st.isFile()&&!st.isSymbolicLink()&&st.size>0&&st.size<=16384,
    'RECORD_NOT_FLUSHABLE');
  let fd;
  try{
    fd=fs.openSync(recordFile,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));
    fs.fsyncSync(fd);
  }finally{if(fd!==undefined)fs.closeSync(fd)}
  // Flush the directory rename as well (Ubuntu native host). Power-loss
  // uncertainty remains fail closed if the underlying disk cannot confirm.
  let dirfd;
  try{dirfd=fs.openSync(transactionRoot,fs.constants.O_RDONLY);fs.fsyncSync(dirfd)}
  finally{if(dirfd!==undefined)fs.closeSync(dirfd)}
  return true;
 }
 function readFile(){
  safeRoot();
  if(!fs.existsSync(file))return null;
  const st=fs.lstatSync(file);
  check(st.isFile()&&!st.isSymbolicLink()&&st.size>0&&st.size<=16384,'UNSAFE_FILE');
  let data;try{data=JSON.parse(fs.readFileSync(file,'utf8'))}
  catch{throw Error('R404_PROVENANCE_INVALID_JSON')}
  return data;
 }
 function validate(r,{schedule=null,requireSchedule=false}={}){
  exact(r,KEYS,'RECORD');
  check(r.schema===SCHEMA&&r.cartridgeId===ID,'RECORD_ID');
  check(typeof r.sourceVersion==='string'&&V.test(r.sourceVersion)&&
    typeof r.targetVersion==='string'&&V.test(r.targetVersion)&&
    core.semcmp(r.targetVersion,r.sourceVersion)>0,'VERSIONS');
  check(typeof r.transactionId==='string'&&TOKEN.test(r.transactionId)&&
    typeof r.stageToken==='string'&&TOKEN.test(r.stageToken),'TRANSACTION_ID');
  check(typeof r.approvalFingerprint==='string'&&/^[a-f0-9]{64}$/.test(r.approvalFingerprint),
    'APPROVAL_FORMAT');
  check(typeof r.releaseSha256==='string'&&/^[a-f0-9]{64}$/.test(r.releaseSha256),
    'RELEASE_HASH_FORMAT');
  check(typeof r.keySpkiSha256==='string'&&/^[a-f0-9]{64}$/.test(r.keySpkiSha256),
    'KEY_HASH_FORMAT');
  const policy=readTrustedPolicy(ID),approved=readApprovedFingerprint(ID);
  check(approved===r.approvalFingerprint,'APPROVAL_REVOKED_OR_CHANGED');
  const trust=wire.validateApprovedTrust(policy,approved,ID);
  const signed=wire.verifyNativeV1(r.envelope,policy,approved,ID,
    r.sourceVersion,terminalVersion());
  const rel=r.envelope.release;
  check(signed.version===r.targetVersion,'SIGNED_VERSION');
  check(r.releaseSha256===sha(Buffer.from(core.canonical(rel),'utf8')),'RELEASE_DIGEST');
  const spki=crypto.createPublicKey(policy.publicKeyPem).export({format:'der',type:'spki'});
  check(r.keySpkiSha256===sha(spki),'SIGNING_KEY_DIGEST');
  check(r.publisher===trust.publisher&&r.repository===trust.repository&&
    r.channel==='stable'&&r.feedUrl===trust.manifestUrl,'PUBLISHER_FEED');
  check(r.archiveSha256===rel.sha256&&r.archiveSize===rel.size,'FROZEN_ARCHIVE');
  if(schedule){
   check(schedule.schema==='clink.r400.schedule.v1'&&
      schedule.cartridgeId===ID&&schedule.previousVersion===r.sourceVersion&&
      schedule.version===r.targetVersion&&schedule.transactionId===r.transactionId&&
      schedule.stageToken===r.stageToken,'SCHEDULE_BINDING');
  }else check(!requireSchedule,'SCHEDULE_REQUIRED');
  return Object.freeze({ok:true,cartridgeId:ID,sourceVersion:r.sourceVersion,
    targetVersion:r.targetVersion,transactionId:r.transactionId,
    releaseSha256:r.releaseSha256,archiveSha256:r.archiveSha256,
    approvalFingerprint:r.approvalFingerprint,publisher:trust.publisher,
    repository:trust.repository});
 }
 function create({sourceVersion,targetVersion,transactionId,stageToken,
     envelope,approvalFingerprint}={}){
  safeRoot();
  check(!fs.existsSync(file),'ALREADY_EXISTS_RECOVERY_REQUIRED');
  const p=readTrustedPolicy(ID),approved=readApprovedFingerprint(ID);
  check(approved===approvalFingerprint,'APPROVAL_CHANGED');
  const trust=wire.validateApprovedTrust(p,approved,ID);
  const verified=wire.verifyNativeV1(envelope,p,approved,ID,sourceVersion,terminalVersion());
  check(targetVersion===verified.version,'TARGET_VERSION');
  const rel=envelope.release;
  const pub=crypto.createPublicKey(p.publicKeyPem).export({type:'spki',format:'der'});
  const r={schema:SCHEMA,cartridgeId:ID,sourceVersion,targetVersion,
   transactionId,stageToken,envelope,releaseSha256:sha(Buffer.from(core.canonical(rel),'utf8')),
   approvalFingerprint:approved,publisher:trust.publisher,repository:trust.repository,
   channel:'stable',feedUrl:trust.manifestUrl,archiveSha256:rel.sha256,
   archiveSize:rel.size,keySpkiSha256:sha(pub)};
  validate(r);
  // Exclusive create: pre-existing evidence is never overwritten.
  // Atomic rename is used only after O_EXCL reserve in the *native process
  // mutex*. Do not enable a second process installer without this mutex.
  core.atomicJson(file,r);
  flushNativeRecord(file);
  const found=readFile();
  validate(found);
  return Object.freeze({file,receipt:found,proof:validate(found)});
 }
 function verify({schedule=null,required=true}={}){
  const r=readFile();
  if(!r){check(!required,'MISSING_RECEIPT');return null}
  const proof=validate(r,{schedule,requireSchedule:!!schedule});
  return Object.freeze({file,receipt:r,proof,fileSha256:sha(fs.readFileSync(file))});
 }
 function clearCompleted({sourceVersion,targetVersion}={}){
  const full=verify({required:true});
  check(!fs.existsSync(path.join(transactionRoot,ID+'.scheduled.json'))&&
    !fs.existsSync(path.join(transactionRoot,ID+'.json')),'JOURNAL_STILL_EXISTS');
  check(sourceVersion===full.proof.sourceVersion&&
    targetVersion===full.proof.targetVersion,'TRANSACTION_CHANGED');
  const st=fs.lstatSync(file);
  check(st.isFile()&&!st.isSymbolicLink(),'UNSAFE_FILE');
  fs.unlinkSync(file);
  return true;
 }
 return Object.freeze({file,create,verify,clearCompleted,readFile,flushSchedule:()=>flushNativeRecord(path.join(transactionRoot,ID+'.scheduled.json'))});
}
module.exports={makeNativeSignedProvenance,SCHEMA};
