'use strict';
// C.Link R381: browserless, capability-scoped updater for an active graphical CARTRIDGE.
// All outgoing network operations originate in main process; CART does not get HTTP/FS keys.
const fs=require('node:fs');const path=require('node:path');const crypto=require('node:crypto');
const core=require('./core.cjs');
const transport=require('./transport.cjs');
function makeHost({ipcMain,dialog,getActive,launch,profileRoot,builtinsRoot,installedRoot,verifyInstalled,terminalVersion,transportOverride,suspend,getShellWebContents}){
 const net=transportOverride||transport;
 const panel=path.join(profileRoot,'panels');
 const approvalsFile=path.join(panel,'cartridge-update-approvals.json');
 // R387 native operator-approved local play. Exact target is host-owned, never renderer-selected.
 // Future launchers require native pairing registration; no arbitrary target string from a CART.
 const trustedLocalTargets=Object.freeze({'conveyor-club-launcher':'conveyor-club-vector-v28-3-s09-playtest'});
 const localApprovalsFile=path.join(panel,'cartridge-local-play-approvals.json');
 const stagingRoot=path.join(panel,'cartridge-update-staging');
 const backupRoot=path.join(panel,'cartridge-update-backups');
 const transactionRoot=path.join(panel,'cartridge-update-transactions');
 function transactionFile(targetId){return path.join(transactionRoot,targetId+'.json');}
 function recoverFor(targetId){core.check(!busy,'UPDATER_BUSY');if(self?.hasNativeRecovery(targetId)){core.check(!fs.existsSync(transactionFile(targetId)),'SIGNED_RECOVERY_REQUIRED');return {recovered:false};}return core.recoverTransaction({installedRoot,backupRoot,targetId,journalFile:transactionFile(targetId)});}
 let busy=false;const selfBusy={busy:false};const checks=new Map();
 function caller(event){
  const rec=getActive();const wc=rec&&rec.webContents;
  core.check(wc&&!wc.isDestroyed()&&event.sender===wc&&event.senderFrame===wc.mainFrame,'UNTRUSTED_CARTRIDGE_CALLER');
  core.check(typeof rec.id==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(rec.id),'NO_ACTIVE_CARTRIDGE');
  const u=new URL(wc.getURL());core.check(u.protocol==='quinplugin:'&&u.hostname===rec.id,'WRONG_CARTRIDGE_ORIGIN');
  return {id:rec.id,wc};
 }
 function policyFor(id){
  const root=[installedRoot,builtinsRoot].map(d=>path.join(d,id)).find(d=>fs.existsSync(path.join(d,'manifest.json')));
  core.check(!!root,'LAUNCHER_NOT_INSTALLED');
  core.check(!fs.lstatSync(root).isSymbolicLink(),'UNSAFE_LAUNCHER_ROOT');
  // This native verifier is C.Link’s existing code-integrity gate.
  verifyInstalled(id);
  const file=path.join(root,'update-channel.json');
  const raw=core.readJsonSafe(file);core.check(!!raw,'NO_APPROVED_RELEASE_CHANNEL_DECLARED');
  return core.validatePolicy(raw,id);
 }
 function approvalKey(policy){return core.sha(Buffer.from(core.canonical({launcherId:policy.launcherId,targetId:policy.targetId,channel:policy.channel,publisher:policy.publisher,repository:policy.repository,manifestUrl:policy.manifestUrl,keyFingerprint:policy.keyFingerprint})));}
 function isApproved(policy){const a=core.readJsonSafe(approvalsFile)||{};return a[policy.launcherId]===approvalKey(policy);}
 async function approve(policy){if(isApproved(policy))return true;
  const reply=await dialog.showMessageBox({type:'question',title:'C.Link Cartridge Updates',message:'Allow signed stable updates for '+policy.launcherId+'?',detail:`Publisher: ${policy.publisher}\nPublic repository: ${policy.repository}\nGame cartridge: ${policy.targetId}\nChannel: STABLE\nSigning key fingerprint:\n${policy.keyFingerprint}\n\nThis approves native C.Link downloads only from the listed release channel. No development builds, network permission or GitHub token are granted to the cartridge.`,buttons:['CANCEL','ALLOW STABLE UPDATES'],defaultId:0,cancelId:0,noLink:true});
  if(reply.response!==1)return false;
  const a=core.readJsonSafe(approvalsFile)||{};a[policy.launcherId]=approvalKey(policy);core.atomicJson(approvalsFile,a);return true;
 }
 function progress(wc,stage,done=0,total=0){try{if(!wc.isDestroyed())wc.send('clink:cart-update:progress',{stage,done,total});}catch{}}
 function localVersion(policy){return core.manifestVersion(installedRoot,policy.targetId);}
 // The signed remote channel is not an authorization prerequisite for local play.
 function localTargetFor(id){
  let targetId=trustedLocalTargets[id]||null, signedPolicy=null;
  // Existing approved remote pairings remain valid local bindings for older CART launchers.
  const root=[builtinsRoot,installedRoot].map(d=>path.join(d,id)).find(d=>fs.existsSync(path.join(d,'manifest.json')));
  core.check(!!root,'LAUNCHER_NOT_INSTALLED');
  core.check(!fs.lstatSync(root).isSymbolicLink(),'UNSAFE_LAUNCHER_ROOT');
  const validated=verifyInstalled(id);
  const mf=fs.readFileSync(path.join(root,'manifest.json'));
  const manifest=JSON.parse(mf.toString('utf8'));
  core.check(manifest.id===id,'LAUNCHER_ID_MISMATCH');
  if(!targetId){
   // An approved signed-channel declaration also provides an exact local target pair.
   const raw=core.readJsonSafe(path.join(root,'update-channel.json'));
   if(raw){signedPolicy=core.validatePolicy(raw,id);targetId=signedPolicy.targetId;}
  }
  core.check(!!targetId,'LOCAL_TARGET_NOT_APPROVED');
  return {launcherId:id,targetId,manifestHash:core.sha(mf),signedPolicy};
 }
 function localGame(binding){
  const id=binding.targetId;
  const root=[builtinsRoot,installedRoot].map(d=>path.join(d,id)).find(d=>fs.existsSync(path.join(d,'manifest.json')));
  if(!root)return {ok:false,code:'TARGET_NOT_INSTALLED',installedVersion:null,targetId:id};
  try{
   core.check(!fs.lstatSync(root).isSymbolicLink(),'UNSAFE_TARGET_ROOT');
   const rec=verifyInstalled(id);
   const m=rec?.manifest || core.readJsonSafe(path.join(root,'manifest.json'));
   core.check(m&&m.id===id,'TARGET_MANIFEST_INVALID');
   const disabled=core.readJsonSafe(path.join(panel,'disabled-plugins.json'));
   const enabled=core.readJsonSafe(path.join(panel,'enabled-plugins.json'));
   if((Array.isArray(disabled)&&disabled.includes(id)) || (m.enabled===false&&!(Array.isArray(enabled)&&enabled.includes(id)))){
    return {ok:false,code:'TARGET_DISABLED',installedVersion:m.version||null,targetId:id};
   }
   return {ok:true,code:'TARGET_READY',installedVersion:core.manifestVersion(installedRoot,id) || m.version || null,targetId:id};
  }catch(e){return {ok:false,code:'TARGET_VERIFICATION_FAILED',targetId:id,installedVersion:null};}
 }
 function localApprovalKey(binding){return core.sha(Buffer.from(core.canonical({launcherId:binding.launcherId,targetId:binding.targetId,launcherManifestHash:binding.manifestHash})));}
 function localPlayApproved(binding){
  if(binding.signedPolicy&&isApproved(binding.signedPolicy))return true;
  const a=core.readJsonSafe(localApprovalsFile)||{};return a[binding.launcherId]===localApprovalKey(binding);
 }
 async function approveLocalPlay(binding){
  if(localPlayApproved(binding))return true;
  const reply=await dialog.showMessageBox({type:'question',title:'C.Link — Local Cartridge Launch',
   message:'Allow '+binding.launcherId+' to open '+binding.targetId+'?',
   detail:'LOCAL PLAY ONLY. This pairs one installed launcher with one verified, installed game.\nNo GitHub access, API keys, remote update approval, or network permissions are granted.\nChanging the launcher identity or manifest requires approval again.',
   buttons:['CANCEL','ALLOW LOCAL PLAY'],defaultId:0,cancelId:0,noLink:true});
  if(reply.response!==1)return false;
  // Caller and installed files are rechecked by the IPC handler after dialog.
  const a=core.readJsonSafe(localApprovalsFile)||{};a[binding.launcherId]=localApprovalKey(binding);core.atomicJson(localApprovalsFile,a);
  return true;
 }
 function localStatusFor(id){
  const binding=localTargetFor(id),game=localGame(binding);
  if(!game.ok)return {...game,ok:false,error:game.code,localVersion:game.installedVersion};
  return {ok:true,code:localPlayApproved(binding)?'LOCAL_READY':'LOCAL_APPROVAL_REQUIRED',
   localPlayApproved:localPlayApproved(binding),remoteChannelApproved:!!(binding.signedPolicy&&isApproved(binding.signedPolicy)),
   targetId:binding.targetId,installedVersion:game.installedVersion,localVersion:game.installedVersion};
 }
 async function checkUpdate(event){const {id,wc}=caller(event);const policy=policyFor(id);recoverFor(policy.targetId);
  if(!await approve(policy))return{ok:false,error:'RELEASE_CHANNEL_NOT_APPROVED',localVersion:localVersion(policy)};
  const local=localVersion(policy);progress(wc,'CHECKING');
  try{
   const meta=JSON.parse((await net.fetchLimited(policy.manifestUrl,32768)).toString('utf8'));
   let release;try{release=core.verifyManifest(meta,policy,local,terminalVersion);}catch(e){if(e.message==='NOT_NEWER')return{ok:true,updateAvailable:false,localVersion:local,channel:'stable'};throw e;}
   checks.set(id,{release,policyHash:approvalKey(policy),at:Date.now()});
   progress(wc,'AVAILABLE');return{ok:true,updateAvailable:true,localVersion:local,version:release.version,channel:'stable'};
  }catch(e){progress(wc,'OFFLINE_OR_CHECK_FAILED');return{ok:false,error:('CHECK_FAILED_'+e.message).slice(0,90),offlinePlayable:!!local,localVersion:local};}
 }
 async function installUpdate(event){const {id,wc}=caller(event);if(busy||selfBusy.busy)return{ok:false,error:'UPDATER_BUSY'};const policy=policyFor(id);recoverFor(policy.targetId);
  if(self?.hasNativeRecovery(policy.targetId))return{ok:false,error:'USE_NATIVE_SAME_CART_UPDATER'};
  if(!isApproved(policy))return{ok:false,error:'RELEASE_CHANNEL_NOT_APPROVED'};
  const job=checks.get(id);core.check(job&&job.policyHash===approvalKey(policy)&&Date.now()-job.at<600000,'SIGNED_CHECK_REQUIRED');
  const release=job.release;busy=true;checks.delete(id);
  let staging=null;
  try{
   const src=core.manifestVersion(installedRoot,policy.targetId);
   if(src&&core.semcmp(release.version,src)<=0)throw Error('NOT_NEWER');
   core.check(!getActive()?.id||getActive().id!==policy.targetId,'CANNOT_UPDATE_RUNNING_GAME');
   // Runtime saves live in the C.Link profile, not package code. Until a cartridge
   // explicitly proves that separation, suspicious in-package save folders block updates.
   const codeDir=path.join(installedRoot,policy.targetId);
   for(const candidate of ['saves','user-data','userdata','player-data'])if(fs.existsSync(path.join(codeDir,candidate)))throw Error('SAVE_DATA_INSIDE_CARTRIDGE_BLOCKS_UPDATE');
   fs.mkdirSync(stagingRoot,{recursive:true,mode:0o700});
   const jobRoot=path.join(stagingRoot,crypto.randomUUID());fs.mkdirSync(jobRoot,{mode:0o700});staging=jobRoot;
   const zip=path.join(jobRoot,'release.zip');const expanded=path.join(jobRoot,'expanded');
   progress(wc,'DOWNLOADING');
   await net.downloadLimited(release.artifactUrl,zip,release.size,release.sha256,(n,t)=>progress(wc,'DOWNLOADING',n,t));
   progress(wc,'VERIFYING');
   core.verifyStage(zip,expanded,release,path.join(__dirname,'extract-safe.py'));
   const checkStage=(d,expectedId,expectedVersion)=>{const m=core.readJsonSafe(path.join(d,'manifest.json'));core.check(m&&m.id===expectedId&&m.version===expectedVersion&&m.runtime==='web','CART_MANIFEST_INVALID');
    const entry=m.entry||m.entrypoint||m.entryFile||'index.html';core.check(typeof entry==='string'&&!entry.includes('..')&&!entry.startsWith('/')&&fs.existsSync(path.join(d,entry)),'CART_ENTRY_MISSING');};
   progress(wc,'INSTALLING');
   const result=await core.commitStaged({stage:expanded,installedRoot,backupRoot,targetId:policy.targetId,version:release.version,journalFile:transactionFile(policy.targetId),verify:checkStage,launch:async target=>{
     try{verifyInstalled(target);const opened=await launch(target);return opened;}catch{return false;}
   }});
   progress(wc,'STARTED');return {ok:true,version:result.version,launched:true,rollbackAvailable:!!result.previous};
  }catch(e){progress(wc,'FAILED_OR_ROLLED_BACK');return{ok:false,error:String(e.message||e).slice(0,150),offlinePlayable:!!localVersion(policy)};}
  finally{busy=false;if(staging)fs.rmSync(staging,{recursive:true,force:true});}
 }
 async function launchLocal(event){
  const {id}=caller(event),binding=localTargetFor(id);recoverFor(binding.targetId);
  const game=localGame(binding);
  if(!game.ok)return {...game,ok:false,error:game.code};
  if(!await approveLocalPlay(binding))return {ok:false,code:'LOCAL_TARGET_NOT_APPROVED',error:'LOCAL_TARGET_NOT_APPROVED',targetId:binding.targetId};
  // Dialog is asynchronous: ensure the calling frame and both CART identities still match.
  const now=caller(event);core.check(now.id===id,'LAUNCHER_CHANGED_DURING_APPROVAL');
  const latest=localTargetFor(id);core.check(latest.targetId===binding.targetId&&latest.manifestHash===binding.manifestHash,'LAUNCHER_CHANGED_DURING_APPROVAL');
  const checked=localGame(latest);if(!checked.ok)return{...checked,error:checked.code};
  const r=await launch(binding.targetId);
  return{ok:!!r?.ok,code:r?.ok?'LAUNCHED':'LOCAL_LAUNCH_FAILED',
    error:r?.ok?undefined:'LOCAL_LAUNCH_FAILED',targetId:binding.targetId,
    version:checked.installedVersion,installedVersion:checked.installedVersion,launched:!!r?.ok};
 }
 let self;
 function register(){
  self=require('./self-update-host.cjs').makeSelfHost({ipcMain,dialog,getActive,getShellWebContents,suspend,launch,profileRoot,installedRoot,verifyInstalled,terminalVersion,transportOverride:net,legacyBusy:()=>busy});
  self.register();
  Object.defineProperty(selfBusy,'busy',{get:()=>self.isBusy()});
  // On restart, restore every interrupted transaction before the launcher can play.
  if(fs.existsSync(transactionRoot)){
   core.check(!fs.lstatSync(transactionRoot).isSymbolicLink()&&fs.lstatSync(transactionRoot).isDirectory(),'UNSAFE_TRANSACTION_ROOT');
   const files=fs.readdirSync(transactionRoot).filter(n=>n.endsWith('.json'));
   core.check(files.length<=128,'TOO_MANY_PENDING_UPDATES');
   for(const name of files){
    // R521: signed-updater metadata, not legacy journals.
    if(/^[a-z0-9][a-z0-9-]{1,62}\.(?:scheduled|signed-provenance)\.json$/.test(name))continue;
    const id=name.slice(0,-5);core.check(/^[a-z0-9][a-z0-9-]{1,62}$/.test(id),'INVALID_TRANSACTION_FILE');
    if(self.hasNativeRecovery(id))continue; // signed recovery owns this journal
    try{core.recoverTransaction({installedRoot,backupRoot,targetId:id,journalFile:transactionFile(id)});}
    catch(e){console.error('C.Link cartridge recovery blocked for '+id+': '+String(e.message||e).slice(0,100));}
   }
  }
  for(const [ch,fn] of [
  ['clink:cart-update:check',checkUpdate],['clink:cart-update:install',installUpdate],['clink:cart-update:play',launchLocal],
  ['clink:cart-update:status',async event=>{
    const {id}=caller(event),binding=localTargetFor(id);recoverFor(binding.targetId);
    const local=localStatusFor(id);
    // Expose the remote-channel status independently, never approve it during status() or play().
    try{const remote=policyFor(id);return {...local,approved:isApproved(remote),channel:remote.channel};}
    catch(e){if(e.message!=='NO_APPROVED_RELEASE_CHANNEL_DECLARED')throw e;
      return {...local,approved:false,channel:null,remoteCode:'NO_APPROVED_RELEASE_CHANNEL_DECLARED'};}
  }]
 ])ipcMain.handle(ch,async(event)=>{try{return await fn(event);}catch(e){const code=String(e.message||e).slice(0,120);return{ok:false,code,error:code};}});}
 return {register,policyFor,approvalKey,onOpen:(id,wc)=>self.onOpen(id,wc),openBlocked:id=>!!self?.openBlocked(id),isActive:()=>!!self?.isActive()||busy};
}
module.exports={makeHost};
