'use strict';
// R401: fail-closed crash reconciliation BEFORE accepting another game update.
// Uses the authentic C.Link core.recoverTransaction() and its immutable journal.
// A scheduled receipt is never evidence of completed installation.
const fs=require('node:fs'),path=require('node:path');
const core=require('./core.cjs');
const SEMVER=/^\d+\.\d+\.\d+$/;
const TOKEN=/^[A-Za-z0-9_-]{16,128}$/;
function check(b,reason){if(!b)throw Error('R401_RECOVERY_'+reason);}
function safeDir(p,create=false){
 check(typeof p==='string'&&path.isAbsolute(p),'ABSOLUTE_ROOT');
 if(create)fs.mkdirSync(p,{recursive:true,mode:0o700});
 if(!fs.existsSync(p))return false;
 const stat=fs.lstatSync(p);
 check(stat.isDirectory()&&!stat.isSymbolicLink(),'UNSAFE_DIRECTORY');
 return true;
}
function safeFile(p){
 if(!fs.existsSync(p))return false;
 const stat=fs.lstatSync(p);
 check(stat.isFile()&&!stat.isSymbolicLink(),'UNSAFE_JOURNAL_FILE');
 check(stat.size>0&&stat.size<=4096,'JOURNAL_TOO_LARGE');
 return true;
}
function readSchedule(file,ID='conveyor-club'){
 check(typeof ID==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(ID),'INVALID_ID');
 if(!safeFile(file))return null;
 let record;try{record=JSON.parse(fs.readFileSync(file,'utf8'))}
 catch{throw Error('R401_RECOVERY_INVALID_SCHEDULE_JSON')}
 const want=['schema','cartridgeId','previousVersion','version','stageToken','transactionId'].sort();
 check(record&&typeof record==='object'&&!Array.isArray(record)&&
  Object.keys(record).sort().join('|')===want.join('|'),'SCHEDULE_KEYS');
 check(record.schema==='clink.r400.schedule.v1'&&record.cartridgeId===ID,'SCHEDULE_IDENTITY');
 check(typeof record.previousVersion==='string'&&SEMVER.test(record.previousVersion)
  &&typeof record.version==='string'&&SEMVER.test(record.version),'SCHEDULE_VERSIONS');
 check(core.semcmp(record.version,record.previousVersion)>0,'SCHEDULE_NOT_NEWER');
 check(typeof record.stageToken==='string'&&TOKEN.test(record.stageToken),'STAGE_TOKEN');
 check(typeof record.transactionId==='string'&&TOKEN.test(record.transactionId),'TRANSACTION_ID');
 return record;
}
function cleanStage(root,token){
 if(!safeDir(root))return false;
 check(TOKEN.test(token),'STAGE_TOKEN');
 const target=path.join(root,token);
 check(path.dirname(target)===path.resolve(root),'STAGE_OUTSIDE_ROOT');
 if(!fs.existsSync(target))return false;
 const stat=fs.lstatSync(target);
 check(stat.isDirectory()&&!stat.isSymbolicLink(),'UNSAFE_STAGE_DIRECTORY');
 // Safe extractor only wrote files/directories; reject symlinks and special files
 // in the stage before removing anything.
 function verifyTree(dir){
  for(const e of fs.readdirSync(dir,{withFileTypes:true})){
   check(!e.isSymbolicLink(),'UNSAFE_STAGE_SYMLINK');
   if(e.isDirectory())verifyTree(path.join(dir,e.name));
   else check(e.isFile(),'UNSAFE_STAGE_ENTRY');
  }
 }
 verifyTree(target);
 fs.rmSync(target,{recursive:true,force:false});
 return true;
}
function recoverScheduled({installedRoot,backupRoot,transactionRoot,stagingRoot,cartridgeId:ID='conveyor-club'}={}){
 check(typeof ID==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(ID),'INVALID_ID');
 safeDir(installedRoot);safeDir(backupRoot);safeDir(transactionRoot);safeDir(stagingRoot);
 const scheduledFile=path.join(transactionRoot,ID+'.scheduled.json');
 const nativeJournal=path.join(transactionRoot,ID+'.json');
 // Read and validate schedule before ANY filesystem mutation.
 const scheduled=readSchedule(scheduledFile,ID);
 const nativePresent=safeFile(nativeJournal);
 if(!nativePresent&&!scheduled)return Object.freeze({ok:true,recovered:false,code:'NO_PENDING_UPDATES'});
 if(nativePresent){
  // The native journal explicitly identifies previous backup, target and version.
  // Never reconstruct arbitrary rollback paths from the renderer or schedule.
  let native;
  try{native=core.recoverTransaction({installedRoot,backupRoot,targetId:ID,journalFile:nativeJournal})}
  catch{return Object.freeze({ok:false,recovered:false,blocked:true,code:'NATIVE_ROLLBACK_INCOMPLETE'});}
  if(scheduled){
   const actual=core.manifestVersion(installedRoot,ID);
   if(actual!==scheduled.previousVersion)
    return Object.freeze({ok:false,recovered:true,blocked:true,code:'RECOVERED_UNEXPECTED_VERSION'});
   try{cleanStage(stagingRoot,scheduled.stageToken);fs.unlinkSync(scheduledFile)}
   catch{return Object.freeze({ok:false,recovered:true,blocked:true,code:'SCHEDULE_CLEANUP_INCOMPLETE'});}
  }
  return Object.freeze({ok:true,recovered:true,code:'NATIVE_ROLLBACK_RECOVERED',action:native.action});
 }
 // Only a queued schedule with no native journal remains. If old game is still
 // installed, no swap occurred; discard only the validated transaction stage.
 const installed=core.manifestVersion(installedRoot,ID);
 if(installed===scheduled.previousVersion){
  try{cleanStage(stagingRoot,scheduled.stageToken);fs.unlinkSync(scheduledFile)}
  catch{return Object.freeze({ok:false,recovered:false,blocked:true,code:'SCHEDULE_CLEANUP_INCOMPLETE'});}
  return Object.freeze({ok:true,recovered:true,code:'UNSTARTED_SCHEDULE_CANCELLED'});
 }
 // NEW+missing journal is ambiguous: core may have committed and lost power
 // before removing schedule. Never erase backups or claim new install success.
 if(installed===scheduled.version)
  return Object.freeze({ok:false,recovered:false,blocked:true,code:'NEW_VERSION_NEEDS_HEALTH_RECONCILIATION'});
 return Object.freeze({ok:false,recovered:false,blocked:true,code:'UNKNOWN_INSTALLED_VERSION'});
}
module.exports={recoverScheduled,readSchedule,cleanStage};
