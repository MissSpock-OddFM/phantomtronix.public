'use strict';
const fs=require('node:fs');
const crypto=require('node:crypto');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const {fetchLimited,downloadLimited}=require('./transport.cjs');
const MAX_ZIP=400*1024*1024;
const SEMVER=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$/;
const ID=/^[a-z0-9][a-z0-9-]{1,62}$/;
function check(ok,code){if(!ok)throw Error(code);}
function sha(buf){return crypto.createHash('sha256').update(buf).digest('hex');}
function canonical(v){if(Array.isArray(v))return '['+v.map(canonical).join(',')+']'; if(v&&typeof v==='object'){const keys=Object.keys(v).sort();return '{'+keys.map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}';}return JSON.stringify(v);}
function semcmp(a,b){check(SEMVER.test(a)&&SEMVER.test(b),'BAD_VERSION');const x=a.split('-')[0].split('.').map(Number),y=b.split('-')[0].split('.').map(Number);for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]<y[i]?-1:1;return 0;}
function allowGithub(url,repo,kind){let u;try{u=new URL(url);}catch{throw Error('BAD_URL');}check(u.protocol==='https:'&&u.username===''&&u.password===''&&u.search===''&&u.hash==='','UNSAFE_URL');
 const p='/'+repo+'/releases/';
 if(kind==='metadata'){check(u.hostname==='github.com'&&u.pathname.startsWith(p),'UNAPPROVED_METADATA_URL');}
 else{check(u.hostname==='github.com'&&u.pathname.startsWith(p+'download/')&&/\.zip$/i.test(u.pathname),'UNAPPROVED_RELEASE_URL');}
 return u.href;
}
function readJsonSafe(file,maxBytes=16384){try{const st=fs.lstatSync(file);check(st.isFile()&&!st.isSymbolicLink()&&st.size<maxBytes,'BAD_CONFIG_FILE');return JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){if(e.code==='ENOENT')return null;throw e;}}
function atomicJson(file,value){const dir=path.dirname(file);fs.mkdirSync(dir,{recursive:true,mode:0o700});const tmp=path.join(dir,'.'+path.basename(file)+'-'+crypto.randomUUID());let fd;try{fd=fs.openSync(tmp,'wx',0o600);fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);fs.closeSync(fd);fd=null;fs.renameSync(tmp,file);}finally{if(fd!==undefined&&fd!==null)fs.closeSync(fd);try{fs.unlinkSync(tmp);}catch{}}}
function validatePolicy(policy,launcherId){check(policy&&policy.schema==='clink.update-channel.v1','BAD_CHANNEL_POLICY');check(ID.test(launcherId)&&policy.launcherId===launcherId,'LAUNCHER_POLICY_MISMATCH');check(ID.test(policy.targetId)&&policy.targetId!==launcherId,'BAD_TARGET_ID');check(/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(policy.repository),'BAD_REPO');check(policy.channel==='stable','NONSTABLE_CHANNEL_DENIED');check(typeof policy.publisher==='string'&&policy.publisher.length>0&&policy.publisher.length<100,'BAD_PUBLISHER');check(typeof policy.publicKeyPem==='string'&&policy.publicKeyPem.length<1000,'BAD_PUBLISHER_KEY');const key=crypto.createPublicKey(policy.publicKeyPem);check(key.asymmetricKeyType==='ed25519','PUBLISHER_KEY_MUST_ED25519');allowGithub(policy.manifestUrl,policy.repository,'metadata');return {...policy,keyFingerprint:sha(key.export({type:'spki',format:'der'}))};}
function verifyManifest(metadata,policy,installedVersion,terminalVersion){check(metadata&&metadata.schema==='clink.signed-update.v1'&&metadata.release&&typeof metadata.signature==='string','BAD_SIGNED_METADATA');const data=metadata.release;const key=crypto.createPublicKey(policy.publicKeyPem);
 check(crypto.verify(null,Buffer.from(canonical(data),'utf8'),key,Buffer.from(metadata.signature,'base64')),'BAD_PUBLISHER_SIGNATURE');
 check(data.channel==='stable'&&!data.prerelease&&data.repository===policy.repository,'WRONG_RELEASE_CHANNEL');check(data.publisher===policy.publisher&&data.cartridgeId===policy.targetId,'PUBLISHER_OR_ID_MISMATCH');
 check(SEMVER.test(data.version)&&SEMVER.test(data.minClinkVersion),'INVALID_RELEASE_VERSION');check(semcmp(data.minClinkVersion,terminalVersion)<=0,'INCOMPATIBLE_TERMINAL');
 check(typeof data.sha256==='string'&&/^[a-f0-9]{64}$/.test(data.sha256),'INVALID_SHA256');check(Number.isInteger(data.size)&&data.size>0&&data.size<=MAX_ZIP,'RELEASE_TOO_LARGE');allowGithub(data.artifactUrl,policy.repository,'artifact');
 check(installedVersion===null||semcmp(data.version,installedVersion)>0,'NOT_NEWER');return data;}
function safeDirectory(dir){check(!fs.existsSync(dir)||(!fs.lstatSync(dir).isSymbolicLink()&&fs.lstatSync(dir).isDirectory()),'UNSAFE_DIRECTORY');}
function manifestVersion(installedRoot,id){const file=path.join(installedRoot,id,'manifest.json');const m=readJsonSafe(file,1024*1024);if(!m)return null;check(m.id===id&&SEMVER.test(m.version),'BAD_CURRENT_MANIFEST');return m.version;}
function verifyStage(zip,stage,release,extractScript){safeDirectory(stage);const r=spawnSync('python3',['-I',extractScript,zip,stage,release.cartridgeId,release.version],{encoding:'utf8',timeout:90000,maxBuffer:4096,windowsHide:true});check(r.status===0,'ZIP_REJECTED:'+String(r.stderr||'').slice(0,140));return true;}
function assertSafeRoots(installedRoot,backupRoot,targetId){check(ID.test(targetId),'BAD_TARGET_ID');const checked=[installedRoot,backupRoot];for(const x of checked){check(path.isAbsolute(x),'RELATIVE_ROOT');safeDirectory(x);}check(path.resolve(installedRoot)!==path.resolve(backupRoot),'ROOTS_COLLIDE');}
// R383: persistent, fail-closed update transaction. Do not discard a known-good backup
// until the newly installed CART has passed the launch check. A process interruption
// leaves a small journal, never a privileged recovery instruction from the CART.
function assertJournal(journalFile,targetId){
 check(typeof journalFile==='string'&&path.isAbsolute(journalFile),'JOURNAL_NOT_ABSOLUTE');
 check(path.basename(journalFile)===targetId+'.json','JOURNAL_NAME_MISMATCH');
 const dir=path.dirname(journalFile);safeDirectory(dir);
}
function clearJournal(file){if(file&&fs.existsSync(file))fs.unlinkSync(file);}
function rollbackOne({installedRoot,backupRoot,targetId,previous,version}){
 assertSafeRoots(installedRoot,backupRoot,targetId);
 const current=path.join(installedRoot,targetId);
 const backup=previous?path.join(backupRoot,previous):null;
 check(!previous||new RegExp('^'+targetId+'-[0-9]+-[a-f0-9]{6}$').test(previous),'JOURNAL_PREVIOUS_INVALID');
 const existsCurrent=fs.existsSync(current),existsBackup=!!backup&&fs.existsSync(backup);
 if(existsCurrent)check(!fs.lstatSync(current).isSymbolicLink()&&fs.lstatSync(current).isDirectory(),'UNSAFE_CURRENT');
 if(existsBackup)check(!fs.lstatSync(backup).isSymbolicLink()&&fs.lstatSync(backup).isDirectory(),'UNSAFE_BACKUP');
 if(previous&&!existsBackup){
  if(!existsCurrent)throw Error('RECOVERY_BACKUP_AND_GAME_MISSING');
  const present=manifestVersion(installedRoot,targetId);
  if(present===version)throw Error('RECOVERY_BACKUP_MISSING_NEW_VERSION_PRESENT');
  // Transaction was interrupted before the old game was moved.
  return 'OLD_VERSION_ALREADY_PRESENT';
 }
 if(existsCurrent){
  const failed=path.join(backupRoot,targetId+'-failed-'+crypto.randomUUID());
  fs.renameSync(current,failed);
 }
 if(existsBackup)fs.renameSync(backup,current);
 return previous?'RESTORED_PREVIOUS':'REMOVED_UNCONFIRMED_FIRST_INSTALL';
}
function recoverTransaction({installedRoot,backupRoot,targetId,journalFile}){
 assertSafeRoots(installedRoot,backupRoot,targetId);
 assertJournal(journalFile,targetId);
 if(!fs.existsSync(journalFile))return{recovered:false};
 const record=readJsonSafe(journalFile);
 check(record&&record.schema==='clink.update-transaction.v1'&&record.targetId===targetId&&SEMVER.test(record.version),'INVALID_RECOVERY_JOURNAL');
 check(record.previous===null||typeof record.previous==='string','INVALID_RECOVERY_REFERENCE');
 const action=rollbackOne({...record,installedRoot,backupRoot,targetId});
 clearJournal(journalFile);
 return{recovered:true,action};
}
function commitStaged({stage,installedRoot,backupRoot,targetId,version,verify,launch,journalFile=null,onTransition=null}){
 assertSafeRoots(installedRoot,backupRoot,targetId);check(SEMVER.test(version),'BAD_VERSION');safeDirectory(stage);
 check(typeof verify==='function','NO_VERIFICATION');verify(stage,targetId,version);
 fs.mkdirSync(installedRoot,{recursive:true,mode:0o700});fs.mkdirSync(backupRoot,{recursive:true,mode:0o700});
 const current=path.join(installedRoot,targetId);check(!fs.existsSync(current)||(!fs.lstatSync(current).isSymbolicLink()&&fs.lstatSync(current).isDirectory()),'UNSAFE_CURRENT');
 const previous=fs.existsSync(current)?targetId+'-'+Date.now()+'-'+crypto.randomBytes(3).toString('hex'):null;
 // For old unit-test callers, a journal is optional. The native host always supplies one.
 if(journalFile){assertJournal(journalFile,targetId);check(!fs.existsSync(journalFile),'RECOVERY_REQUIRED_BEFORE_INSTALL');
  atomicJson(journalFile,{schema:'clink.update-transaction.v1',targetId,version,previous});}
 let modified=false;
 const transition=(phase)=>{if(typeof onTransition==='function')onTransition(phase);};
 const rollback=()=>{
  if(modified||journalFile){rollbackOne({installedRoot,backupRoot,targetId,previous,version});}
  clearJournal(journalFile);
 };
 try{
  if(previous){fs.renameSync(current,path.join(backupRoot,previous));modified=true;transition('OLD_BACKED_UP');}
  fs.renameSync(stage,current);modified=true;transition('NEW_INSTALLED');
  verify(current,targetId,version);
  const launched=launch?launch(targetId):true;
  return Promise.resolve(launched).then(ok=>{
    check(ok===true||ok?.ok===true,'LAUNCH_FAILED');clearJournal(journalFile);
    return{ok:true,version,previous};
  }).catch(e=>{try{rollback();}catch(re){e.message+='; ROLLBACK_INCOMPLETE:'+re.message;}throw e;});
 }catch(e){try{rollback();}catch(re){e.message+='; ROLLBACK_INCOMPLETE:'+re.message;}throw e;}
}
// Legacy compatibility helper retained for external callers, but not used for
// R383's native recovery, which requires the exact journal and named backup.
function recoverInterrupted(installedRoot,backupRoot,targetId){const target=path.join(installedRoot,targetId);if(fs.existsSync(target))return false;if(!fs.existsSync(backupRoot))return false;const candidates=fs.readdirSync(backupRoot).filter(n=>n.startsWith(targetId+'-')&&!n.includes('-failed-')).sort().reverse();if(!candidates.length)return false;fs.renameSync(path.join(backupRoot,candidates[0]),target);return true;}
module.exports={sha,canonical,semcmp,validatePolicy,verifyManifest,readJsonSafe,atomicJson,manifestVersion,verifyStage,commitStaged,recoverInterrupted,recoverTransaction,allowGithub,MAX_ZIP,check};
