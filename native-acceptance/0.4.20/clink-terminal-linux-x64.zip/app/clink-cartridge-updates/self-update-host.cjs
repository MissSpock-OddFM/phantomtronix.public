'use strict';
// R392 C.Link one-CART native update service. Native trusted policy only; no CART-selected URLs/paths/IDs.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const core=require('./core.cjs');
const policyCore=require('./self-update-policy.cjs');
const transport=require('./transport.cjs');
const {makeNativeV1Bridge}=require('./native-v1-bridge.cjs');
const {makeNativeSupervisedRecovery}=require('./native-supervised-recovery.cjs');
const {makeNativeSignedProvenance}=require('./native-signed-provenance.cjs');
const {makeGenericHealth}=require('./native-generic-health.cjs');
const ID=/^[a-z0-9][a-z0-9-]{1,62}$/;
function makeSelfHost({ipcMain,dialog,getActive,getShellWebContents,suspend,launch,profileRoot,installedRoot,
  verifyInstalled,terminalVersion,transportOverride,legacyBusy=()=>false,
  policyOverride=null,delayInstallMs=250,onEvent=()=>{},confirmReopened=null}){
 const net=transportOverride||transport;
 const panel=path.join(profileRoot,'panels');
 const stagingRoot=path.join(panel,'cartridge-update-staging');
 const backupRoot=path.join(panel,'cartridge-update-backups');
 const transactionRoot=path.join(panel,'cartridge-update-transactions');
 const approvalsFile=path.join(panel,'cartridge-self-update-approvals.json');
 const resultFile=path.join(panel,'cartridge-self-update-results.json');
 // This file is part of the trusted NATIVE application, never read from the CART ZIP.
 // It remains deliberately absent until the Human approves a publisher, origin and key.
 const policiesFile=path.join(__dirname,'self-update-trusted-channels.json');
 const jobs=new Map();
 let busy=false;
 function caller(event){
  const rec=getActive(),wc=rec?.webContents;
  core.check(wc&&!wc.isDestroyed()&&wc===event.sender&&wc.mainFrame===event.senderFrame,'UNTRUSTED_CARTRIDGE_CALLER');
  core.check(typeof rec.id==='string'&&ID.test(rec.id),'NO_ACTIVE_CARTRIDGE');
  const url=new URL(wc.getURL());
  core.check(url.protocol==='quinplugin:'&&url.hostname===rec.id&&!url.username&&!url.password&&!url.port,'WRONG_CARTRIDGE_ORIGIN');
  verifyInstalled(rec.id);
  return {id:rec.id,wc};
 }
 function versionFor(id){
  core.check(ID.test(id),'INVALID_ID');
  const ver=core.manifestVersion(installedRoot,id);
  if(ver!==null){const rec=verifyInstalled(id);core.check(rec?.root===path.join(installedRoot,id),'NOT_USER_INSTALLED_CART');}
  return ver;
 }
 function findNativePolicy(id){
  const root=policyOverride||core.readJsonSafe(policiesFile,256*1024);
  if(!root)return null;
  core.check(root.schema==='clink.self-update-native-policies.v1'&&root.channels&&
    typeof root.channels==='object'&&!Array.isArray(root.channels),'INVALID_NATIVE_POLICY_FILE');
  const raw=Object.hasOwn(root.channels,id)?root.channels[id]:null;
  return raw?policyCore.normalizeNativePolicy(raw,id):null;
 }
 function approval(id){const a=core.readJsonSafe(approvalsFile,64*1024)||{};
  return (typeof a[id]==='string'?a[id]:null);}
 function approved(id,p){return !!p&&approval(id)===p.approvalFingerprint;}
 function journal(id){return path.join(transactionRoot,id+'.json');}
 function progress(wc,stage,done=0,total=0){
  try{if(wc&&!wc.isDestroyed())wc.send('clink:cart-self-update:progress',{stage,done,total});}catch{}
 }
 function record(id,value){
  try{const all=core.readJsonSafe(resultFile,256*1024)||{};
    all[id]={...value,at:new Date().toISOString()};core.atomicJson(resultFile,all);
  }catch(e){onEvent('SELF_UPDATE_RESULT_WRITE_FAILED',String(e.message||e).slice(0,100));}
 }
 function lastResult(id){try{return (core.readJsonSafe(resultFile,256*1024)||{})[id]||null;}catch{return null;}}
 async function status(event){
  const {id}=caller(event),version=versionFor(id),p=findNativePolicy(id);
  return {...policyCore.status(id,version,p?{schema:'clink.self-update-channel.v1',cartridgeId:p.cartridgeId,
    channel:p.channel,publisher:p.publisher,repository:p.repository,publicKeyPem:p.publicKeyPem,
    manifestUrl:p.manifestUrl}:null,approval(id)),
    supported:true,updating:busy,lastResult:lastResult(id)};
 }
 async function approveFromShell(event,id){
  const shell=getShellWebContents?.();
  core.check(shell&&!shell.isDestroyed()&&event.sender===shell&&event.senderFrame===shell.mainFrame,'SHELL_REQUIRED');
  core.check(ID.test(id),'INVALID_ID');
  const p=findNativePolicy(id);
  if(!p)return {ok:false,error:'NO_APPROVED_RELEASE_CHANNEL_DECLARED'};
  if(approved(id,p))return {ok:true,approved:true};
  const r=await dialog.showMessageBox({type:'question',title:'C.Link Cartridge Self Updates',
   message:'Allow signed STABLE updates for '+id+'?',
   detail:'Publisher: '+p.publisher+'\nRepository: '+p.repository+'\nRelease feed: '+p.manifestUrl+
     '\nPinned Ed25519 key: '+p.keyFingerprint+ '\n\nUpdates replace only this verified CART. No CART network or filesystem access is granted.',
   buttons:['CANCEL','ALLOW SIGNED STABLE UPDATES'],defaultId:0,cancelId:0,noLink:true});
  if(r.response!==1)return {ok:false,error:'HUMAN_DECLINED'};
  const latest=findNativePolicy(id);
  core.check(latest&&latest.approvalFingerprint===p.approvalFingerprint,'CHANNEL_CHANGED_DURING_APPROVAL');
  const a=core.readJsonSafe(approvalsFile,64*1024)||{};a[id]=p.approvalFingerprint;core.atomicJson(approvalsFile,a);
  return {ok:true,approved:true};
 }
 async function check(event){
  const {id,wc}=caller(event),p=findNativePolicy(id),localVersion=versionFor(id);
  if(!p)return {ok:false,error:'NO_APPROVED_RELEASE_CHANNEL_DECLARED',offlinePlayable:!!localVersion};
  if(!approved(id,p))return {ok:false,error:'RELEASE_CHANNEL_NOT_APPROVED',offlinePlayable:!!localVersion};
  if(busy||legacyBusy())return {ok:false,error:'UPDATER_BUSY',offlinePlayable:!!localVersion};
  progress(wc,'CHECKING');
  try{
   const metadata=JSON.parse((await net.fetchLimited(p.manifestUrl,32768)).toString('utf8'));
   let release;
   try{release=policyCore.verifySignedCandidate(id,localVersion,terminalVersion,
     {schema:'clink.self-update-channel.v1',cartridgeId:id,channel:p.channel,publisher:p.publisher,
      repository:p.repository,publicKeyPem:p.publicKeyPem,manifestUrl:p.manifestUrl},p.approvalFingerprint,metadata);}
   catch(e){if(e.message==='NOT_NEWER')return {ok:true,updateAvailable:false,
     installedVersion:localVersion,channel:'stable'};throw e;}
   jobs.set(id,{release,approval:p.approvalFingerprint,webContents:wc,at:Date.now()});
   progress(wc,'AVAILABLE');
   return {ok:true,updateAvailable:true,installedVersion:localVersion,version:release.version,channel:'stable'};
  }catch(e){progress(wc,'OFFLINE_OR_CHECK_FAILED');return {ok:false,
    error:('CHECK_FAILED_'+String(e.message||e)).slice(0,120),offlinePlayable:!!localVersion};}
 }
 function verifyCandidateStage(dir,id,version){
  const m=core.readJsonSafe(path.join(dir,'manifest.json'),1024*1024);
  core.check(m&&m.schema==='PANELS_PLUGIN_MANIFEST_V2'&&m.id===id&&m.version===version&&m.runtime==='web','CART_MANIFEST_INVALID');
  const entry=m.entry||m.entrypoint||m.entryFile||'index.html';
  core.check(typeof entry==='string'&&!entry.startsWith('/')&&
    !entry.includes('..')&&!entry.includes('\\')&&fs.existsSync(path.join(dir,entry)),'CART_ENTRY_MISSING');
  for(const forbidden of ['saves','user-data','userdata','player-data']){
   if(fs.existsSync(path.join(dir,forbidden)))throw Error('PACKAGE_SAVE_DATA_FORBIDDEN');
  }
 }
 async function install(event){
  const {id,wc}=caller(event),p=findNativePolicy(id),local=versionFor(id);
  if(!p)return {ok:false,error:'NO_APPROVED_RELEASE_CHANNEL_DECLARED',offlinePlayable:!!local};
  if(!approved(id,p))return {ok:false,error:'RELEASE_CHANNEL_NOT_APPROVED',offlinePlayable:!!local};
  if(busy||legacyBusy())return {ok:false,error:'UPDATER_BUSY',offlinePlayable:!!local};
  const job=jobs.get(id);
  if(!job||job.webContents!==wc||job.approval!==p.approvalFingerprint||Date.now()-job.at>600000)
   return {ok:false,error:'SIGNED_CHECK_REQUIRED'};
  jobs.delete(id);busy=true;
  let staging=null;
  try{
   core.check(local!==null&&core.semcmp(job.release.version,local)>0,'NOT_NEWER');
   const currentCode=path.join(installedRoot,id);
   for(const name of ['saves','user-data','userdata','player-data']){
    if(fs.existsSync(path.join(currentCode,name)))throw Error('SAVE_DATA_INSIDE_CARTRIDGE_BLOCKS_UPDATE');
   }
   if(fs.existsSync(journal(id)))throw Error('RECOVERY_REQUIRED_RESTART');
   fs.mkdirSync(stagingRoot,{recursive:true,mode:0o700});
   staging=path.join(stagingRoot,crypto.randomUUID());fs.mkdirSync(staging,{mode:0o700});
   const zip=path.join(staging,'package.zip'),expanded=path.join(staging,'expanded');
   progress(wc,'DOWNLOADING');
   await net.downloadLimited(job.release.artifactUrl,zip,job.release.size,job.release.sha256,
      (n,t)=>progress(wc,'DOWNLOADING',n,t));
   progress(wc,'VERIFYING');
   core.verifyStage(zip,expanded,job.release,path.join(__dirname,'extract-safe.py'));
   verifyCandidateStage(expanded,id,job.release.version);
   // Acknowledge to the existing renderer while its IPC frame is still alive.
   // The queued trusted main-process transaction later suspends the old view.
   progress(wc,'READY_TO_RESTART');
   setTimeout(async()=>{
     let suspended=false;
     try{
       const active=getActive();
       core.check(active&&active.id===id&&active.webContents===wc&&!wc.isDestroyed(),'ACTIVE_CART_CHANGED');
       const latest=findNativePolicy(id);
       core.check(latest&&latest.approvalFingerprint===p.approvalFingerprint&&approved(id,latest),'APPROVAL_CHANGED');
       core.check(versionFor(id)===local,'INSTALLED_VERSION_CHANGED');
       core.check(await suspend(id,wc)===true,'SUSPEND_FAILED');
       suspended=true;
       onEvent('CART_SUSPENDED_FOR_UPDATE',id);
       const receipt=await core.commitStaged({stage:expanded,installedRoot,backupRoot,targetId:id,
          version:job.release.version,journalFile:journal(id),verify:verifyCandidateStage,
          launch:async target=>{verifyInstalled(target);return await launch(target);}});
       record(id,{ok:true,code:'UPGRADED',previous:local,version:receipt.version,
         rollbackAvailable:!!receipt.previous});
       onEvent('CART_UPDATED',id+':'+receipt.version);
     }catch(e){
       record(id,{ok:false,code:'FAILED_OR_ROLLED_BACK',error:String(e.message||e).slice(0,130),
         installedVersion:core.manifestVersion(installedRoot,id)});
       onEvent('CART_UPDATE_FAILED',String(e.message||e).slice(0,130));
       if(suspended){try{await suspend(id,getActive()?.webContents);}catch{}
        try{await launch(id);}catch(err){onEvent('RESTORE_REOPEN_FAILED',String(err.message||err).slice(0,100));}}
     }finally{
       busy=false;
       if(staging)try{fs.rmSync(staging,{recursive:true,force:true});}catch{}
     }
   },Math.max(20,delayInstallMs));
   return {ok:true,scheduled:true,version:job.release.version,offlinePlayable:true};
  }catch(e){
   busy=false;
   if(staging)try{fs.rmSync(staging,{recursive:true,force:true});}catch{}
   return {ok:false,error:String(e.message||e).slice(0,130),offlinePlayable:!!local};
  }
 }
 // Trusted native routing: no renderer-selected target, no additional IPC.
 const bridges=new Map(),supervisors=new Map(),frameRuns=new WeakMap();
 function bridgeFor(id){
  core.check(typeof id==='string'&&ID.test(id),'INVALID_ID');
  if(!bridges.has(id)){
   const health=id==='conveyor-club'?null:makeGenericHealth({id,getActive,verifyInstalled,readInstalledVersion:versionFor});
   bridges.set(id,makeNativeV1Bridge({caller,versionFor,findNativePolicy,approval,terminalVersion,
    net,verifyCandidateStage,progress,record,lastResult,getActive,suspend,launch,verifyInstalled,onEvent,
    stagingRoot,backupRoot,transactionRoot,installedRoot,journal,legacyBusy,delayInstallMs,
    confirmReopened:health?health.confirmReopened:confirmReopened,
    captureBeforeRestart:health?.captureBeforeRestart},id));
  }
  return bridges.get(id);
 }
 function supervisorFor(id){
  core.check(typeof id==='string'&&ID.test(id),'INVALID_ID');
  if(supervisors.has(id))return supervisors.get(id);
  const supervisedProvenance=makeNativeSignedProvenance({transactionRoot,cartridgeId:id,
    readTrustedPolicy:()=>{const p=findNativePolicy(id);return p?{schema:'clink.self-update-channel.v1',cartridgeId:id,channel:p.channel,publisher:p.publisher,repository:p.repository,publicKeyPem:p.publicKeyPem,manifestUrl:p.manifestUrl}:null;},
    readApprovedFingerprint:()=>approval(id),terminalVersion:()=>typeof terminalVersion==='function'?terminalVersion():terminalVersion});
  const shellSupervisor=makeNativeSupervisedRecovery({
    installedRoot,backupRoot,transactionRoot,stagingRoot,cartridgeId:id,
    readSignedProvenance:({schedule,nativeJournalPresent})=>{
      const pending=!!schedule||nativeJournalPresent;
      const evidence=supervisedProvenance.verify({schedule,required:pending});
      if(evidence&&!pending)throw Error('R404_ORPHAN_PROVENANCE');
      return evidence;
    },
    clearSignedProvenance:evidence=>supervisedProvenance.clearCompleted({
      sourceVersion:evidence.proof.sourceVersion,
      targetVersion:evidence.proof.targetVersion
    }),
    requireShell:async(event)=>{
      const shell=getShellWebContents?.();
      core.check(shell&&!shell.isDestroyed()&&event.sender===shell&&
        event.senderFrame===shell.mainFrame,'SHELL_REQUIRED');
    },
    confirmHuman:async(info)=>{
      const answer=await dialog.showMessageBox({
        type:'warning',title:'C.Link — Recover Interrupted Cartridge Update',
        message:'Recover abandoned update lock for '+id+'?',
        detail:'Installed: '+info.installedVersion+'\nPrevious owner PID: '+info.ownerPid+
          '\nAction: '+info.action+'\nNative journal: '+String(info.hasJournal)+
          '\nScheduled record: '+String(info.hasSchedule)+
          '\nVerified previous backup: '+String(info.verifiedNativeBackup)+
          '\n\nThis may roll back an interrupted update. Other cartridges and saves are not touched.',
        buttons:['CANCEL','AUTHORIZE SUPERVISED RECOVERY'],
        defaultId:0,cancelId:0,noLink:true
      });
      return answer?.response===1;
    }
  });
  supervisors.set(id,shellSupervisor);return shellSupervisor;
 }
 function startup(){
  const ids=new Set(['conveyor-club']);
  const root=policyOverride||core.readJsonSafe(policiesFile,256*1024);
  if(root){core.check(root.schema==='clink.self-update-native-policies.v1'&&root.channels&&typeof root.channels==='object'&&!Array.isArray(root.channels),'INVALID_NATIVE_POLICY_FILE');for(const id of Object.keys(root.channels)){core.check(ID.test(id),'INVALID_ID');ids.add(id);}}
  if(fs.existsSync(transactionRoot)){
   const st=fs.lstatSync(transactionRoot);core.check(st.isDirectory()&&!st.isSymbolicLink(),'UNSAFE_TRANSACTION_ROOT');
   for(const n of fs.readdirSync(transactionRoot)){const m=/^([a-z0-9][a-z0-9-]{1,62})\.(?:scheduled\.json|signed-provenance\.json|process\.lock|recovery\.guard)$/.exec(n);if(m)ids.add(m[1]);}
  }
  core.check(ids.size<=128,'TOO_MANY_NATIVE_CHANNELS');for(const id of ids)bridgeFor(id);
 }
 function hasNativeRecovery(id){return bridges.has(id);}
 function openBlocked(id){return bridges.has(id)&&bridges.get(id).startupRecovery.ok!==true&&[journal(id),path.join(transactionRoot,id+'.scheduled.json'),path.join(transactionRoot,id+'.signed-provenance.json')].some(f=>fs.existsSync(f));}
 function state(event){const {id,wc}=caller(event);let run=frameRuns.get(wc);if(!run||run.frame!==wc.mainFrame){run={id,frame:wc.mainFrame};frameRuns.set(wc,run);}core.check(run.id===id,'FRAME_ID_CHANGED');return {id,wc,run};}
 async function routedStatus(event){const {id}=state(event);return bridgeFor(id).status(event);}
 async function routedCheck(event){const {id,run}=state(event);if(!run.check)run.check=bridgeFor(id).check(event);return run.check;}
 async function routedInstall(event){const {id,run}=state(event);if(!run.install){if([...bridges.values()].some(b=>b.isActive()))return {ok:false,code:'UPDATE_IN_PROGRESS'};run.install=bridgeFor(id).install(event);}return run.install;}
 async function onOpen(id,wc){
  const event={sender:wc,senderFrame:wc.mainFrame};
  try{const active=caller(event);core.check(active.id===id,'WRONG_OPEN_ID');
   if([...bridges.values()].some(b=>b.isActive()))return {ok:false,code:'UPDATE_IN_PROGRESS'};
   if(versionFor(id)===null)return {ok:false,code:'NOT_USER_INSTALLED_CART'};
   const checked=await routedCheck(event);if(!checked.ok){progress(wc,checked.code==='CHANNEL_NOT_APPROVED'?'UPDATE_STANDARD_NON_COMPLIANT':'UPDATE_CHECK_UNAVAILABLE');return checked;}
   if(!checked.updateAvailable)return checked;
   caller(event);return await routedInstall(event);
  }catch(e){return {ok:false,code:String(e.message||e).slice(0,140)};}
 }
 function register(){
  startup();
  const routes=[['clink:cart-self-update:status',routedStatus],['clink:cart-self-update:check',routedCheck],['clink:cart-self-update:install',routedInstall],['clink:cart-self-update:shell-approve',approveFromShell],
   ['clink:cart-self-update:shell-recovery-preview',(e,id='conveyor-club')=>{const shell=getShellWebContents?.();core.check(shell&&!shell.isDestroyed()&&e.sender===shell&&e.senderFrame===shell.mainFrame,'SHELL_REQUIRED');return supervisorFor(id).preview(e);}],
   ['clink:cart-self-update:shell-recovery-resolve',(e,input,id='conveyor-club')=>{const shell=getShellWebContents?.();core.check(shell&&!shell.isDestroyed()&&e.sender===shell&&e.senderFrame===shell.mainFrame,'SHELL_REQUIRED');return supervisorFor(id).resolve(e,input);}]];
  for(const [name,fn] of routes)ipcMain.handle(name,async(event,...args)=>{try{return await fn(event,...args);}catch(e){return {ok:false,error:String(e.message||e).slice(0,140)};}});
 }
 return {register,status:routedStatus,check:routedCheck,install:routedInstall,approveFromShell,onOpen,hasNativeRecovery,openBlocked,isBusy:()=>busy||[...bridges.values()].some(b=>b.isBusy()),isActive:()=>[...bridges.values()].some(b=>b.isActive())};
}
module.exports={makeSelfHost};
