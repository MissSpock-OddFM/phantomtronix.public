'use strict';
// Host-owned baseline health: pinned entry, fresh live main frame, loaded document.
// Functional application acceptance remains a separate gate.
function makeGenericHealth({id,getActive,verifyInstalled,readInstalledVersion,sleep=ms=>new Promise(r=>setTimeout(r,ms)),timeoutMs=12000,pollMs=150}){
 let old=null;
 const exact=(wc,entry)=>{try{const u=new URL(wc.getURL());return u.protocol==='quinplugin:'&&u.hostname===id&&u.pathname==='/'+entry&&!u.username&&!u.password&&!u.port&&!u.search&&!u.hash}catch{return false}};
 function captureBeforeRestart(target){const a=getActive(),rec=verifyInstalled(id);if(target!==id||a?.id!==id||!a.webContents||a.webContents.isDestroyed()||!exact(a.webContents,rec.entry))throw Error('OLD_FRAME_INVALID');old=a.webContents;}
 async function confirmReopened(target,version,tx){const before=old;old=null;if(!before||target!==id||typeof tx!=='string'||tx.length<8)return false;
  const deadline=Date.now()+timeoutMs;
  do{try{const a=getActive(),wc=a?.webContents,rec=verifyInstalled(id);if(a?.id===id&&wc&&wc!==before&&!wc.isDestroyed()&&wc.mainFrame&&rec.manifest.version===version&&readInstalledVersion(id)===version&&exact(wc,rec.entry)){
   const frame=wc.mainFrame,url=wc.getURL();let timer;let proof;try{proof=await Promise.race([wc.executeJavaScript("document.readyState === 'complete' && !!document.body && !!document.documentElement",false),new Promise(r=>{timer=setTimeout(()=>r(false),Math.max(1,deadline-Date.now()))})]);}finally{clearTimeout(timer)}
   const now=getActive();if(proof===true&&now?.id===id&&now.webContents===wc&&wc.mainFrame===frame&&!wc.isDestroyed()&&wc.getURL()===url&&readInstalledVersion(id)===version)return true;
  }}catch{} if(Date.now()>=deadline)break;await sleep(Math.min(pollMs,Math.max(1,deadline-Date.now())));}while(Date.now()<deadline);
  return false;
 }
 return {captureBeforeRestart,confirmReopened};
}
module.exports={makeGenericHealth};
