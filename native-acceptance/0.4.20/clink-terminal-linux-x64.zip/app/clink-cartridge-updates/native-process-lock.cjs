'use strict';
// R402: exclusive *cross-process* native update ownership, never supplied by
// cartridge JS. Linux/Unix/Windows O_EXCL file prevents two C.Link processes
// from simultaneously staging/swapping conveyor-club. Stale locks fail closed,
// NEVER auto-steal; they need verified recovery and shell-supervised resolution.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const SCHEMA='clink.native-update-process-lock.v1';
const VALID_TOKEN=/^[a-f0-9]{32}$/;
function insist(v,code){if(!v)throw Error('R402_LOCK_'+code);}
function makeNativeProcessLock(transactionRoot,ID='conveyor-club'){
 insist(typeof ID==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(ID),'INVALID_ID');
 insist(typeof transactionRoot==='string'&&path.isAbsolute(transactionRoot),'ABSOLUTE_ROOT_REQUIRED');
 const lockFile=path.join(transactionRoot,ID+'.process.lock');
 const recoveryGuardFile=path.join(transactionRoot,ID+'.recovery.guard');
 const FLAG=(fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|
   (fs.constants.O_NOFOLLOW||0));
 function verifyRoot(){
  fs.mkdirSync(transactionRoot,{recursive:true,mode:0o700});
  const st=fs.lstatSync(transactionRoot);
  insist(st.isDirectory()&&!st.isSymbolicLink(),'UNSAFE_ROOT');
  insist(fs.realpathSync(transactionRoot)===path.resolve(transactionRoot),'SYMLINKED_PARENT');
 }
 function read(){
  verifyRoot();
  let fd;
  try{fd=fs.openSync(lockFile,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0))}
  catch(error){if(error.code==='ENOENT')return null;throw error}
  try{
   const stat=fs.fstatSync(fd);
   insist(stat.isFile()&&stat.size>0&&stat.size<=1024,'UNSAFE_LOCK_FILE');
   const data=Buffer.alloc(stat.size);
   let off=0;
   while(off<data.length){
    const n=fs.readSync(fd,data,off,data.length-off,off);
    insist(n>0,'LOCK_READ_TRUNCATED');
    off+=n;
   }
   let obj;try{obj=JSON.parse(data.toString('utf8'))}
   catch{throw Error('R402_LOCK_INVALID_JSON')}
   const keys=['schema','cartridgeId','pid','token','createdAt'].sort();
   insist(obj&&typeof obj==='object'&&!Array.isArray(obj)&&
     Object.keys(obj).sort().join('|')===keys.join('|'),'UNKNOWN_FIELDS');
   insist(obj.schema===SCHEMA&&obj.cartridgeId===ID,'WRONG_ID');
   insist(Number.isSafeInteger(obj.pid)&&obj.pid>0,'INVALID_PID');
   insist(typeof obj.token==='string'&&VALID_TOKEN.test(obj.token),'INVALID_TOKEN');
   insist(typeof obj.createdAt==='string'&&/^\d{4}-\d\d-\d\dT/.test(obj.createdAt),'INVALID_TIME');
   return Object.freeze({record:Object.freeze(obj),dev:stat.dev,ino:stat.ino});
  }finally{fs.closeSync(fd)}
 }
 function acquire(){
  verifyRoot();
  // Supervisor barrier prevents a new process from taking the lock in the
  // narrow gap after stale owner removal, but before recovery is finalized.
  if(fs.existsSync(recoveryGuardFile))return Object.freeze({ok:false,code:'SUPERVISED_RECOVERY_IN_PROGRESS'});
  const token=crypto.randomBytes(16).toString('hex');
  const record={schema:SCHEMA,cartridgeId:ID,pid:process.pid,token,
    createdAt:new Date().toISOString()};
  let fd;
  try{fd=fs.openSync(lockFile,FLAG,0o600)}
  catch(e){
   if(e.code==='EEXIST')return Object.freeze({ok:false,code:'LOCK_HELD'});
   throw e;
  }
  let written=false;
  try{
   const b=Buffer.from(JSON.stringify(record),'utf8');
   fs.writeSync(fd,b,0,b.length,0);
   fs.fsyncSync(fd);
   const st=fs.fstatSync(fd);
   written=true;
   const ticket=Object.freeze({ok:true,token,dev:st.dev,ino:st.ino});
   if(fs.existsSync(recoveryGuardFile)){
    release(ticket);
    return Object.freeze({ok:false,code:'SUPERVISED_RECOVERY_IN_PROGRESS'});
   }
   return ticket;
  }finally{
   fs.closeSync(fd);
   if(!written){try{fs.unlinkSync(lockFile)}catch{}}
  }
 }
 function release(ticket){
  insist(ticket&&ticket.ok===true&&VALID_TOKEN.test(ticket.token),'INVALID_TICKET');
  const now=read();
  insist(now&&now.record.token===ticket.token &&
    now.dev===ticket.dev&&now.ino===ticket.ino,'NOT_CURRENT_OWNER');
  fs.unlinkSync(lockFile);
  return true;
 }
 function supervisedClear(expected,guardFile){
  verifyRoot();
  insist(guardFile===recoveryGuardFile&&fs.existsSync(guardFile),'SUPERVISOR_GUARD_REQUIRED');
  const guardStat=fs.lstatSync(guardFile);
  insist(guardStat.isFile()&&!guardStat.isSymbolicLink(),'INVALID_SUPERVISOR_GUARD');
  const now=read();
  insist(now&&expected&&now.record.token===expected.record.token&&
   now.record.pid===expected.record.pid&&
   now.ino===expected.ino&&now.dev===expected.dev,'OWNER_CHANGED');
  fs.unlinkSync(lockFile);
  return true;
 }
 return Object.freeze({acquire,release,read,supervisedClear,lockFile,recoveryGuardFile});
}
module.exports={makeNativeProcessLock,SCHEMA};
