'use strict';
// Miss Spock R398 — SOURCE-ONLY gate for one-cart signed installs.
// No native Electron hooks are implemented here; injected capabilities MUST come
// from the trusted C.Link host, never from cart JavaScript. Never publish this as
// a completed updater or replace the installed host without field verification.
const core=require('./core.cjs');
const wire=require('./native-v1-wire.cjs');

const MAX_METADATA_BYTES=32768;
function assert(condition,code){if(!condition)throw Error('R398_'+code);}
function installedVersion(v){
  assert(typeof v==='string' && v.length>0,'INSTALLED_CART_REQUIRED');
  core.semcmp(v,v);return v;
}
function readMetadata(raw){
  if(typeof raw==='string')raw=Buffer.from(raw,'utf8');
  assert(Buffer.isBuffer(raw)&&raw.length>0&&raw.length<=MAX_METADATA_BYTES,'METADATA_LENGTH');
  let value;try{value=JSON.parse(raw.toString('utf8'))}
  catch(error){throw Error('R398_METADATA_JSON')}
  return value;
}
const REQUIRED=[
 'requireMainFrame','installedVersion','terminalVersion',
 'readTrustedPolicy','readApprovedFingerprint','fetchPinnedMetadata',
 'pendingTransaction','stageVerifiedArchive','scheduleVerifiedSwap',
 'discardStagedArchive'
];
function makeNativeV1InstallGate(ops,ID=wire.ID){
 assert(typeof ID==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(ID),'INVALID_NATIVE_ID');
 for(const key of REQUIRED)assert(typeof ops?.[key]==='function','MISSING_NATIVE_'+key);
 // Prevent concurrent install() calls through this C.Link service instance.
 let inFlight=false;
 async function install(sender){
  await ops.requireMainFrame(sender,ID);
  if(inFlight)return {ok:false,scheduled:false,installed:false,code:'UPDATE_BUSY'};
  inFlight=true;
  let stageToken=null;
  let scheduleStarted=false;
  try {
    const previous=installedVersion(await ops.installedVersion(ID));
    assert((await ops.pendingTransaction(ID))===false,'PENDING_RECOVERY');
    const policy=await ops.readTrustedPolicy(ID);
    const fingerprint=await ops.readApprovedFingerprint(ID);
    // Fail-closed: native policy is meaningful only with exact Human-approved
    // fingerprint. A cart cannot provide policy, feed URL, signing key or ID.
    const trust=wire.validateApprovedTrust(policy,fingerprint,ID);
    const raw=await ops.fetchPinnedMetadata(trust.manifestUrl,MAX_METADATA_BYTES);
    const envelope=readMetadata(raw);
    const host=await ops.terminalVersion();
    // Crucial: reverify signed release DURING INSTALL, not the cached check().
    const release=wire.verifyNativeV1(envelope,policy,fingerprint,ID,previous,host);
    // Native main-frame must remain the authorized current cartridge after I/O.
    await ops.requireMainFrame(sender,ID);
    assert((await ops.installedVersion(ID))===previous,'INSTALLED_VERSION_CHANGED');
    const p2=await ops.readTrustedPolicy(ID);
    const f2=await ops.readApprovedFingerprint(ID);
    assert(wire.validateApprovedTrust(p2,f2,ID).approvalFingerprint===
      trust.approvalFingerprint,'TRUST_CHANGED');
    assert((await ops.pendingTransaction(ID))===false,'PENDING_RECOVERY');
    // Native staging capability MUST re-check download redirect origin, exact
    // bytes/SHA256, ZIP safety, manifest ID/version and all asset hashes.
    // It MUST return an opaque stage token, not a path supplied by the game.
    const staged=await ops.stageVerifiedArchive(Object.freeze({
      cartridgeId:ID,installedVersion:previous,version:release.version,
      url:release.artifactUrl,sha256:release.sha256,size:release.size,
      signedReleaseSha256:core.sha(Buffer.from(core.canonical(envelope.release),'utf8')),
      // Native-only callbacks; the game frame never supplies any trust data.
      signedEnvelope:envelope,approvedFingerprint:fingerprint
    }));
    assert(staged && staged.ok===true && typeof staged.stageToken==='string' &&
      /^[A-Za-z0-9_-]{16,128}$/.test(staged.stageToken),'STAGE_RECEIPT');
    stageToken=staged.stageToken;
    assert(staged.cartridgeId===ID&&staged.version===release.version &&
      staged.bytesVerified===release.size&&staged.sha256Verified===release.sha256 &&
      staged.manifestVerified===true&&staged.assetHashesVerified===true,
      'STAGED_ARCHIVE_UNVERIFIED');
    await ops.requireMainFrame(sender,ID);
    assert((await ops.installedVersion(ID))===previous,'INSTALLED_VERSION_CHANGED');
    assert((await ops.readApprovedFingerprint(ID))===fingerprint,'APPROVAL_CHANGED');
    assert((await ops.pendingTransaction(ID))===false,'PENDING_RECOVERY');
    // Host scheduling MUST durably journal a verified staged transaction and
    // own close/swap/reopen/rollback. Do not signal installed before health PASS.
    scheduleStarted=true;
    const receipt=await ops.scheduleVerifiedSwap(Object.freeze({
      cartridgeId:ID,expectedInstalledVersion:previous,
      version:release.version,stageToken
    }));
    assert(receipt && receipt.ok===true && receipt.scheduled===true &&
      receipt.installed!==true && typeof receipt.transactionId==='string' &&
      /^[A-Za-z0-9_-]{8,128}$/.test(receipt.transactionId),
      'TRANSACTION_NOT_SCHEDULED');
    stageToken=null;
    return Object.freeze({ok:true,scheduled:true,installed:false,
      code:'UPDATE_SCHEDULED_REOPEN_REQUIRED',cartridgeId:ID,
      previousVersion:previous,version:release.version,
      transactionId:receipt.transactionId});
  } catch(error){
    // Once scheduling begins, transaction state may have reached disk even if
    // the native callback rejects. Never delete a stage needed for recovery.
    if(scheduleStarted)return Object.freeze({ok:false,scheduled:false,installed:false,
      code:'TRANSACTION_STATE_UNKNOWN_RECOVERY_REQUIRED'});
    if(stageToken!==null){
      try{await ops.discardStagedArchive(stageToken)}
      catch(cleanupError){
        return {ok:false,scheduled:false,installed:false,
          code:'STAGE_CLEANUP_FAILED_RECOVERY_REQUIRED'};
      }
    }
    const code=typeof error?.message==='string'&&error.message.startsWith('R398_')?
      error.message:'UPDATE_VALIDATION_OR_IO_FAILED';
    return Object.freeze({ok:false,scheduled:false,installed:false,code});
  } finally {
    inFlight=false;
  }
 }
 return Object.freeze({install});
}
module.exports={makeNativeV1InstallGate,readMetadata,MAX_METADATA_BYTES};
