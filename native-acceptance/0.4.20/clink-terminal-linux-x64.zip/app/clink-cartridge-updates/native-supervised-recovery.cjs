'use strict';
// R403 source-only native C.Link shell SUPERVISED stale-lock recovery.
// A preview is NOT permission to delete; only the genuine authenticated
// C.Link shell may confirm recovery with native dialog, before ANY mutation.
// Never auto-clear a dead PID, guess a backup, trust a CART path or discard
// ambiguous state. The frozen game, player profile and other CARTs are sacred.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const core=require('./core.cjs');
const {makeNativeProcessLock}=require('./native-process-lock.cjs');
const {recoverScheduled,readSchedule}=require('./native-scheduled-recovery.cjs');
const WINDOW_MS=120000,SEMVER=/^\d+\.\d+\.\d+$/;
const backupPattern=id=>new RegExp('^'+id+'-\\d{10,16}-[0-9a-f]{6}$');
const NONCE=/^[0-9a-f]{48}$/;
function requireState(x,msg){if(!x)throw Error('R403_RECOVERY_'+msg);}
function fileHash(file){
 try{
  const stat=fs.lstatSync(file);
  requireState(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=65536,'UNSAFE_EVIDENCE_FILE');
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
 }catch(e){if(e.code==='ENOENT')return null;throw e}
}
function readNativeJournal(file,ID){
 const BACKUP=backupPattern(ID);
 const hash=fileHash(file);
 if(!hash)return {hash:null,previous:null,version:null};
 const b=fs.readFileSync(file);
 requireState(b.length>0&&b.length<=4096,'NATIVE_JOURNAL_SIZE');
 let value;try{value=JSON.parse(b.toString('utf8'))}catch{throw Error('R403_RECOVERY_INVALID_NATIVE_JOURNAL')}
 requireState(value&&value.schema==='clink.update-transaction.v1'&&value.targetId===ID&&
  typeof value.version==='string'&&SEMVER.test(value.version),'NATIVE_JOURNAL_IDENTITY');
 requireState(value.previous===null||(typeof value.previous==='string'&&BACKUP.test(value.previous)),
  'NATIVE_JOURNAL_BACKUP_REFERENCE');
 return {hash,previous:value.previous,version:value.version};
}
function ownerAliveDefault(pid){
 try{process.kill(pid,0);return true}
 catch(error){if(error.code==='ESRCH')return false;if(error.code==='EPERM')return true;throw error}
}
function makeNativeSupervisedRecovery({installedRoot,backupRoot,transactionRoot,
 stagingRoot,requireShell,confirmHuman,readSignedProvenance,clearSignedProvenance,processIsAlive=ownerAliveDefault,
 clock=()=>Date.now(),cartridgeId:ID='conveyor-club'}={}){
 requireState(typeof ID==='string'&&/^[a-z0-9][a-z0-9-]{1,62}$/.test(ID),'INVALID_ID');
 for(const [name,p] of Object.entries({installedRoot,backupRoot,transactionRoot,stagingRoot}))
  requireState(typeof p==='string'&&path.isAbsolute(p),'UNTRUSTED_'+name);
 requireState(typeof requireShell==='function'&&typeof confirmHuman==='function'&&
   typeof readSignedProvenance==='function'&&typeof clearSignedProvenance==='function'&&
   typeof processIsAlive==='function','SHELL_REQUIRED');
 const lock=makeNativeProcessLock(transactionRoot,ID);
 const guardFile=lock.recoveryGuardFile;
 const scheduledFile=path.join(transactionRoot,ID+'.scheduled.json');
 const journalFile=path.join(transactionRoot,ID+'.json');
 let pending=null;
 function checkedDirectory(dir){
  if(!fs.existsSync(dir))return;
  const stat=fs.lstatSync(dir);
  requireState(stat.isDirectory()&&!stat.isSymbolicLink()&&
    fs.realpathSync(dir)===path.resolve(dir),'UNSAFE_DIRECTORY');
 }
 function inspect(){
  for(const d of [installedRoot,backupRoot,transactionRoot,stagingRoot])checkedDirectory(d);
  const owned=lock.read();
  if(!owned)return {ok:false,code:'NO_PROCESS_LOCK'};
  const current=core.manifestVersion(installedRoot,ID);
  requireState(current&&SEMVER.test(current),'UNVERIFIED_INSTALLED_GAME');
  const schedule=readSchedule(scheduledFile,ID);
  const native=readNativeJournal(journalFile,ID);
  // Validate exact native backup provenance BEFORE calling any rollback engine.
  let validBackup=false,backupVersion=null;
  if(native.previous!==null){
    const previous=path.join(backupRoot,native.previous);
    checkedDirectory(previous);
    requireState(fs.existsSync(previous),'MISSING_NATIVE_BACKUP');
    // Native backups retain the ORIGINAL game manifest id "conveyor-club",
    // despite their timestamped folder names. Read directly, never infer IDs.
    const file=path.join(previous,'manifest.json');
    const st=fs.lstatSync(file);
    requireState(st.isFile()&&!st.isSymbolicLink(),'UNSAFE_BACKUP_MANIFEST');
    const manifest=JSON.parse(fs.readFileSync(file,'utf8'));
    requireState(manifest.id===ID&&typeof manifest.version==='string'&&
      SEMVER.test(manifest.version),'BACKUP_IDENTITY');
    validBackup=true;
    backupVersion=manifest.version;
  }
  if(native.hash && schedule){
    requireState(native.version===schedule.version,'JOURNAL_SCHEDULE_VERSION_MISMATCH');
  }
  // No rollback of an interrupted signed update without independent
  // Ed25519 publisher/approval/ZIP provenance tied to the native schedule.
  const signed=readSignedProvenance({schedule,nativeJournalPresent:!!native.hash});
  requireState(!(signed && !schedule && !native.hash),'ORPHAN_SIGNED_PROVENANCE');
  if(native.hash){
    requireState(signed?.proof?.targetVersion===native.version,
      'NATIVE_TARGET_NOT_SIGNED');
    // Same-CART update always had an existing old version. A native journal
    // pointing at no backup cannot authorize successful supervised rollback.
    requireState(native.previous!==null&&validBackup&&
      backupVersion===signed.proof.sourceVersion,
      'BACKUP_SOURCE_NOT_SIGNED');
  }
  const scheduleHash=fileHash(scheduledFile);
  const manifestHash=fileHash(path.join(installedRoot,ID,'manifest.json'));
  const backupNames=fs.existsSync(backupRoot)?fs.readdirSync(backupRoot).sort():[];
  const stageNames=fs.existsSync(stagingRoot)?fs.readdirSync(stagingRoot).sort():[];
  const evidence={ownerToken:owned.record.token,pid:owned.record.pid,
   inode:owned.ino,device:owned.dev,createdAt:owned.record.createdAt,
   installed:current,manifestHash,scheduleHash,nativeHash:native.hash,
   nativePrevious:native.previous,backupNames,stageNames,
   signedProvenanceSha256:signed?.fileSha256||null,
   signedReleaseSha256:signed?.proof?.releaseSha256||null,
   approvedPublisherFingerprint:signed?.proof?.approvalFingerprint||null,
   scheduleVersion:schedule?.version||null,transactionId:schedule?.transactionId||null};
  const fingerprint=crypto.createHash('sha256').update(JSON.stringify(evidence)).digest('hex');
  let mode='CLEAR_ONLY';
  if(schedule||native.hash) mode='RECOVER_OR_CANCEL';
  if(schedule&&!native.hash&&current===schedule.version)mode='AMBIGUOUS_NEW_VERSION';
  if(schedule&&!native.hash&&current!==schedule.previousVersion&&
     current!==schedule.version)mode='UNKNOWN_INSTALLED_VERSION';
  // If native journal does not reference a prior backup, full recovery must
  // rely on the native rollback algorithm; do not silently claim success.
  return {ok:true,owned,evidence,fingerprint,mode,validBackup,hasJournal:!!native.hash,
    hasSchedule:!!schedule,installed:current,signedProvenance:signed};
 }
 function verifyDead(owner){
  // Never use age as proof. A live/reused PID is a HARD STOP.
  requireState(owner.record.pid!==process.pid,'OWNER_IS_CURRENT_HOST');
  requireState(processIsAlive(owner.record.pid)===false,'OWNER_RUNNING_OR_UNKNOWN');
 }
 async function preview(event){
  await requireShell(event);
  pending=null;
  let state;
  try{state=inspect()}catch(err){return {ok:false,code:'INVALID_RECOVERY_EVIDENCE',reason:String(err.message).slice(0,120)}}
  if(!state.ok)return state;
  try{verifyDead(state.owned)}catch{return {ok:false,code:'OWNER_RUNNING_OR_UNKNOWN'}}
  if(state.mode==='AMBIGUOUS_NEW_VERSION'||state.mode==='UNKNOWN_INSTALLED_VERSION')
   return {ok:false,blocked:true,code:state.mode,installedVersion:state.installed,
     hasJournal:state.hasJournal,hasSchedule:state.hasSchedule};
  const nonce=crypto.randomBytes(24).toString('hex');
  pending={nonce,createdAt:clock(),fingerprint:state.fingerprint};
  return {ok:true,requiresHumanConsent:true,nonce,cartridgeId:ID,installedVersion:state.installed,
    ownerPid:state.owned.record.pid,hasNativeJournal:state.hasJournal,
    hasSchedule:state.hasSchedule,verifiedNativeBackup:state.validBackup,
    proposedAction:state.mode,expiresInSeconds:WINDOW_MS/1000};
 }
 function acquireGuard(){
  const flags=fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|
   (fs.constants.O_NOFOLLOW||0);
  let fd;
  try{fd=fs.openSync(guardFile,flags,0o600)}
  catch(e){if(e.code==='EEXIST')return null;throw e}
  const rec={schema:'clink.supervised-recovery-guard.v1',pid:process.pid,
    nonce:crypto.randomBytes(16).toString('hex')};
  try{
   const b=Buffer.from(JSON.stringify(rec));
   fs.writeSync(fd,b,0,b.length,0);fs.fsyncSync(fd);
   const st=fs.fstatSync(fd);
   return {record:rec,ino:st.ino,dev:st.dev};
  }finally{fs.closeSync(fd)}
 }
 function releaseGuard(ticket){
  const st=fs.lstatSync(guardFile);
  requireState(st.isFile()&&!st.isSymbolicLink()&&st.dev===ticket.dev&&
    st.ino===ticket.ino,'SUPERVISOR_GUARD_CHANGED');
  const data=JSON.parse(fs.readFileSync(guardFile,'utf8'));
  requireState(data.nonce===ticket.record.nonce,'SUPERVISOR_OWNER_CHANGED');
  fs.unlinkSync(guardFile);
 }
 async function resolve(event,nonce){
  await requireShell(event);
  const claim=pending;pending=null; // one attempt, regardless of outcome.
  if(!claim||typeof nonce!=='string'||!NONCE.test(nonce)||
    nonce!==claim.nonce||clock()-claim.createdAt>WINDOW_MS||
    clock()<claim.createdAt)return {ok:false,code:'PREVIEW_REQUIRED_OR_EXPIRED'};
  let guard;
  try{guard=acquireGuard()}
  catch{return {ok:false,code:'SUPERVISOR_GUARD_UNSAFE'}}
  if(!guard)return {ok:false,code:'OTHER_SUPERVISOR_ACTIVE'};
  try{
   const before=inspect();
   if(!before.ok||before.fingerprint!==claim.fingerprint)
    return {ok:false,code:'EVIDENCE_CHANGED'};
   verifyDead(before.owned);
   if(before.mode==='AMBIGUOUS_NEW_VERSION'||before.mode==='UNKNOWN_INSTALLED_VERSION')
    return {ok:false,code:'AMBIGUOUS_RECOVERY_BLOCKED'};
   const agreed=await confirmHuman({
     cartridgeId:ID,installedVersion:before.installed,ownerPid:before.owned.record.pid,
     action:before.mode,hasJournal:before.hasJournal,hasSchedule:before.hasSchedule,
     verifiedNativeBackup:before.validBackup,
     signedPublisher:before.signedProvenance?.proof.publisher||null,
     signedRepository:before.signedProvenance?.proof.repository||null,
     signedReleaseSha256:before.signedProvenance?.proof.releaseSha256||null,
     signedArchiveSha256:before.signedProvenance?.proof.archiveSha256||null
   });
   if(agreed!==true)return {ok:false,code:'HUMAN_DECLINED'};
   await requireShell(event);
   if(clock()-claim.createdAt>WINDOW_MS||clock()<claim.createdAt)
    return {ok:false,code:'PREVIEW_EXPIRED_DURING_APPROVAL'};
   const now=inspect();
   if(!now.ok||now.fingerprint!==before.fingerprint)
    return {ok:false,code:'EVIDENCE_CHANGED_DURING_APPROVAL'};
   verifyDead(now.owned);
   // Source of truth: original audited C.Link rollback algorithm.
   const outcome=recoverScheduled({installedRoot,backupRoot,transactionRoot,stagingRoot,cartridgeId:ID});
   if(!outcome.ok)return {ok:false,blocked:true,code:outcome.code};
   requireState(!fileHash(journalFile)&&!fileHash(scheduledFile),'JOURNAL_STILL_PENDING');
   if(now.signedProvenance)clearSignedProvenance(now.signedProvenance);
   requireState(core.manifestVersion(installedRoot,ID)!==null,'GAME_UNVERIFIED_AFTER_RECOVERY');
   // Guard still held: no competing installation may start between
   // final snapshot and clearing this stale lock's exact owner inode.
   lock.supervisedClear(now.owned,guardFile);
   return {ok:true,recovered:true,code:'SUPERVISED_LOCK_CLEARED',
     action:outcome.code,installedVersion:core.manifestVersion(installedRoot,ID)};
  }catch(error){
   return {ok:false,blocked:true,code:'RECOVERY_REFUSED',
     reason:String(error.message||error).slice(0,140)};
  }finally{
   try{releaseGuard(guard)}catch{}
  }
 }
 return Object.freeze({preview,resolve,lockFile:lock.lockFile,recoveryGuardFile:guardFile});
}
module.exports={makeNativeSupervisedRecovery};
